(function (root) {
  'use strict';
  async function normalizeFile(file) {
    const normalizer = root.QoqnusImageNormalizer;
    if (!normalizer) throw new Error('پردازشگر مشترک تصویر بارگذاری نشده است.');
    return normalizer.normalizeFile(file);
  }
  async function normalizeDataUrl(dataUrl) {
    const normalizer = root.QoqnusImageNormalizer;
    if (!normalizer) throw new Error('پردازشگر مشترک تصویر بارگذاری نشده است.');
    return normalizer.normalizeDataUrl(dataUrl);
  }
  function isWebpDataUrl(value) {
    return /^data:image\/webp;base64,[A-Za-z0-9+/]+={0,2}$/i.test(String(value || ''));
  }
  root.QoqnusCustomerPhoto = {
    MAX_SIDE: 500,
    MAX_OUTPUT_BYTES: 400 * 1024,
    isWebpDataUrl,
    normalizeFile,
    normalizeDataUrl
  };
})(typeof self !== 'undefined' ? self : globalThis);
