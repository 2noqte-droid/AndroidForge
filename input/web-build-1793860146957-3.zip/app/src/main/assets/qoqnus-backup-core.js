(function (root) {
  'use strict';
  const BACKUP_SCHEMA = 'qoqnus.mobile.backup.v2';
  const DROP_EXACT = new Set([
    'deviceCryptoKey', 'deviceId', 'durableQueueState',
    'selectedSyncSource', 'pinAttemptState', 'imageNormalization400V1',
    'shareInboxLastCount', 'shareLastPruneAt', 'changeJournal', 'knownPhoneHashesV1', 'lastUpdateCheckAt', 'softwareUpdateState'
  ]);
  const DROP_PREFIXES = ['peer:', 'durableSyncSnapshot:', 'shareSourceCache:', 'shareReceived:', 'shareOutbox:', 'mobilePeer:'];
  const TRANSIENT_KEYS = new Set(['lastRestoreSafetyCopy']);

  function isPortableMetaKey(key) {
    const value = String(key || '');
    if (!value || DROP_EXACT.has(value) || TRANSIENT_KEYS.has(value)) return false;
    return !DROP_PREFIXES.some(prefix => value.startsWith(prefix));
  }

  function filterPortableMetaRows(rows) {
    const source = Array.isArray(rows) ? rows : [];
    const byKey = new Map();
    for (const row of source) {
      if (!row || typeof row !== 'object') continue;
      const key = String(row.key || '');
      if (!isPortableMetaKey(key)) continue;
      byKey.set(key, { key, value: row.value });
    }
    return [...byKey.values()];
  }

  function canonicalize(value) {
    if (Array.isArray(value)) return value.map(canonicalize);
    if (!value || typeof value !== 'object') return value;
    const out = {};
    for (const key of Object.keys(value).sort()) {
      const item = value[key];
      if (item !== undefined) out[key] = canonicalize(item);
    }
    return out;
  }

  function toBase64(bytes) {
    let binary = '';
    const data = new Uint8Array(bytes);
    for (let i = 0; i < data.length; i += 0x8000) {
      binary += String.fromCharCode(...data.subarray(i, Math.min(i + 0x8000, data.length)));
    }
    return root.btoa(binary);
  }

  function countEmbeddedImages(value, seen = new Set()) {
    if (typeof value === 'string') {
      if (/^data:image\//i.test(value)) seen.add(value);
      return seen.size;
    }
    if (Array.isArray(value)) {
      for (const item of value) countEmbeddedImages(item, seen);
      return seen.size;
    }
    if (value && typeof value === 'object') {
      for (const item of Object.values(value)) countEmbeddedImages(item, seen);
    }
    return seen.size;
  }

  async function createBackupDocument({ records, meta, appVersion, decryptRecord, createdAt = Date.now(), recoveryCopy = false }) {
    if (!Array.isArray(records)) throw new Error('فهرست رکوردهای پشتیبان معتبر نیست.');
    const portableMeta = filterPortableMetaRows(meta);
    const counts = { recordCount: records.length, fileCount: 0, listingCount: 0, customerCount: 0, contactCount: 0, attachmentCount: 0, otherCount: 0 };
    for (const row of records) {
      const kind = String(row?.kind || 'other');
      if (kind === 'file') counts.fileCount++;
      else if (kind === 'listing') counts.listingCount++;
      else if (kind === 'customer') counts.customerCount++;
      else if (kind === 'contact') counts.contactCount++;
      else counts.otherCount++;
      if (typeof decryptRecord === 'function') {
        const plain = await decryptRecord(row);
        counts.attachmentCount += countEmbeddedImages(plain);
      }
    }
    const payload = {
      schema: BACKUP_SCHEMA,
      formatVersion: 2,
      createdAt: Number(createdAt) || Date.now(),
      appVersion: String(appVersion || ''),
      encryptedRecords: true,
      attachmentsIncluded: true,
      manifest: counts,
      ...(recoveryCopy ? { recoveryCopy: true } : {}),
      records,
      meta: portableMeta
    };
    const canonical = JSON.stringify(canonicalize(payload));
    const digest = await root.crypto.subtle.digest('SHA-256', new TextEncoder().encode(canonical));
    return { ...payload, integrity: { algorithm: 'SHA-256', digest: toBase64(digest) } };
  }

  function stripPrivateFields(value) {
    if (Array.isArray(value)) return value.map(stripPrivateFields);
    if (!value || typeof value !== 'object') return value;
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      if (/^(?:deviceToken|token|accessToken|pairToken|pairingCode|deviceCryptoKey|encryptionKey|privateKey|secretKey|password|pin|deviceId|ownerDeviceId)$/i.test(key)) continue;
      out[key] = stripPrivateFields(item);
    }
    return out;
  }

  async function createExtensionCompatibleBackup({ records, decryptRecord, appVersion, exportedAt = new Date().toISOString() }) {
    if (!Array.isArray(records) || typeof decryptRecord !== 'function') throw new Error('اطلاعات لازم برای ساخت پشتیبان مشترک کامل نیست.');
    const data = { queue: [], qoqnusCustomers: [], qoqnusOfficeFiles: [] };
    for (const row of records) {
      const kind = String(row?.kind || '');
      if (!['listing', 'customer', 'file'].includes(kind)) continue;
      const plain = stripPrivateFields(await decryptRecord(row));
      if (!plain || typeof plain !== 'object' || Array.isArray(plain)) continue;
      if (kind === 'customer') data.qoqnusCustomers.push(plain);
      else if (kind === 'file') data.qoqnusOfficeFiles.push(plain);
      else data.queue.push(plain);
    }
    return {
      schema: 'divar-to-rubika-full-backup',
      schemaVersion: 1,
      extensionVersion: String(appVersion || 'qoqnus-android'),
      exportedAt,
      data
    };
  }

  function flattenExtensionBackup(input) {
    const data = input && input.data && typeof input.data === 'object' && !Array.isArray(input.data) ? input.data : null;
    if (!data) return null;
    const rows = [];
    const add = (items, forcedKind) => {
      for (const record of (Array.isArray(items) ? items : [])) {
        if (!record || typeof record !== 'object' || Array.isArray(record)) continue;
        const kind = forcedKind || (record.recordKind === 'file' || record.bookKey === 'office-files' ? 'file' : 'listing');
        const id = String(record.id || record.recordId || record.uuid || '').trim();
        if (!id) throw new Error('یک رکورد در پشتیبان مشترک شناسه ندارد.');
        rows.push({ key: kind + ':' + id, kind, id, updatedAt: Number(record.updatedAt || record.updated_at) || Date.now(), legacyPlainRecord: record });
      }
    };
    add(data.queue, null);
    add(data.qoqnusCustomers, 'customer');
    add(data.qoqnusOfficeFiles || data.officeFiles, 'file');
    return rows;
  }

  async function verifyBackupDocument(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('ساختار فایل پشتیبان JSON معتبر نیست.');
    const schema = String(input.schema || input.format || input.version || '').toLowerCase();
    const version = Number(input.formatVersion) || (schema.endsWith('.v2') ? 2 : 1);
    if (version > 2) throw new Error('این پشتیبان با نسخهٔ جدیدتری ساخته شده و این نسخهٔ ققنوس قادر به بازیابی آن نیست.');
    if (schema && !/qoqnus|backup|v\d|^\d+(\.\d+)*$/.test(schema)) throw new Error('نسخهٔ فایل پشتیبان با ققنوس سازگار نیست.');
    const extensionRows = flattenExtensionBackup(input);
    if (!Array.isArray(input.records) && !Array.isArray(input.data) && !Array.isArray(input.items) && !extensionRows) throw new Error('فهرست رکوردها در فایل پیدا نشد؛ این قالب شناخته‌شده نیست.');
    if (input.integrity) {
      if (input.integrity.algorithm !== 'SHA-256' || typeof input.integrity.digest !== 'string') throw new Error('مشخصات صحت‌سنجی فایل پشتیبان معتبر نیست.');
      const { integrity, ...payload } = input;
      const canonical = JSON.stringify(canonicalize(payload));
      const digest = await root.crypto.subtle.digest('SHA-256', new TextEncoder().encode(canonical));
      if (toBase64(digest) !== input.integrity.digest) throw new Error('صحت فایل پشتیبان تأیید نشد؛ فایل ناقص یا دست‌کاری شده است. هیچ اطلاعاتی تغییر نکرد.');
    } else if (version >= 2) {
      throw new Error('فایل پشتیبان نسخهٔ ۲ فاقد اثرانگشت صحت‌سنجی است.');
    }
    const records = Array.isArray(input.records) ? input.records : (Array.isArray(input.data) ? input.data : (Array.isArray(input.items) ? input.items : extensionRows));
    if (input.manifest && Number.isFinite(Number(input.manifest.recordCount)) && Number(input.manifest.recordCount) !== records.length) {
      throw new Error('تعداد رکوردهای فایل با فهرست پشتیبان مطابقت ندارد.');
    }
    return { schema, formatVersion: version, createdAt: Number(input.createdAt || Date.parse(input.exportedAt || '') || 0), records, manifest: input.manifest || null };
  }

  function restoreMetaRows(metaRows, { localSalt, lockCheck, deviceId, deviceCryptoKey }) {
    const rows = filterPortableMetaRows(metaRows);
    const map = new Map(rows.map(row => [row.key, row.value]));
    map.set('localSalt', localSalt);
    map.set('lockCheck', lockCheck);
    map.set('deviceId', deviceId);
    map.set('deviceCryptoKey', deviceCryptoKey);
    return [...map.entries()].map(([key, value]) => ({ key, value }));
  }

  root.QoqnusBackupCore = {
    BACKUP_SCHEMA,
    isPortableMetaKey,
    filterPortableMetaRows,
    countEmbeddedImages,
    createBackupDocument,
    createExtensionCompatibleBackup,
    verifyBackupDocument,
    restoreMetaRows
  };
})(typeof self !== 'undefined' ? self : globalThis);
