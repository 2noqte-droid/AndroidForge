(function (root) {
  'use strict';

  const MAX_SIDE = 500;
  const MAX_OUTPUT_BYTES = 400 * 1024;
  const MAX_SOURCE_BYTES = 15 * 1024 * 1024;
  const QUALITY_STEPS = [0.86, 0.80, 0.74, 0.68, 0.62, 0.56, 0.50, 0.44, 0.38, 0.32];
  const SIZE_STEPS = [500, 450, 400, 350, 300, 250, 200];

  function fail(message) { throw new Error(message); }
  function isWebpBytes(bytes) {
    return !!bytes && bytes.length >= 12 &&
      bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 &&
      bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50;
  }
  function readAsDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new root.FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('خواندن تصویر پردازش‌شده ناموفق بود.'));
      reader.readAsDataURL(blob);
    });
  }
  async function decodeSource(file) {
    if (typeof root.createImageBitmap === 'function') {
      try {
        const bitmap = await root.createImageBitmap(file, { imageOrientation: 'from-image' });
        if (bitmap && bitmap.width > 0 && bitmap.height > 0) {
          return { image: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close && bitmap.close() };
        }
        bitmap && bitmap.close && bitmap.close();
      } catch (_) {
        try {
          const bitmap = await root.createImageBitmap(file);
          if (bitmap && bitmap.width > 0 && bitmap.height > 0) {
            return { image: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close && bitmap.close() };
          }
          bitmap && bitmap.close && bitmap.close();
        } catch (_) {}
      }
    }
    const url = root.URL.createObjectURL(file);
    try {
      const image = new root.Image();
      image.src = url;
      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = () => reject(new Error('خواندن تصویر ممکن نشد.'));
      });
      if (!(image.naturalWidth > 0 && image.naturalHeight > 0)) fail('ابعاد تصویر معتبر نیست.');
      return { image, width: image.naturalWidth, height: image.naturalHeight, close: () => root.URL.revokeObjectURL(url) };
    } catch (error) {
      root.URL.revokeObjectURL(url);
      throw error;
    }
  }
  async function alreadyStandard(file, width, height) {
    if (String(file.type || '').toLowerCase() !== 'image/webp' ||
        Math.max(width, height) > MAX_SIDE || Number(file.size) > MAX_OUTPUT_BYTES) return false;
    try { return isWebpBytes(new Uint8Array(await file.arrayBuffer())); }
    catch (_) { return false; }
  }
  async function normalizeFile(file) {
    if (!file || !String(file.type || '').toLowerCase().startsWith('image/')) fail('یک فایل تصویری انتخاب کنید.');
    if (Number(file.size) > MAX_SOURCE_BYTES) fail('عکس اصلی بیش از ۱۵ مگابایت است؛ تصویر کوچک‌تری انتخاب کنید.');
    const decoded = await decodeSource(file);
    try {
      if (await alreadyStandard(file, decoded.width, decoded.height)) {
        return { dataUrl: await readAsDataUrl(file), width: decoded.width, height: decoded.height, mime: 'image/webp', bytes: Number(file.size), unchanged: true };
      }
      const canvas = root.document.createElement('canvas');
      const context = canvas.getContext('2d', { alpha: false });
      if (!context) fail('پردازش تصویر در این دستگاه در دسترس نیست.');
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = 'high';

      for (const side of SIZE_STEPS) {
        const scale = Math.min(1, side / Math.max(decoded.width, decoded.height));
        const width = Math.max(1, Math.round(decoded.width * scale));
        const height = Math.max(1, Math.round(decoded.height * scale));
        canvas.width = width;
        canvas.height = height;
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = 'high';
        context.fillStyle = '#fff';
        context.fillRect(0, 0, width, height);
        context.drawImage(decoded.image, 0, 0, width, height);
        for (const quality of QUALITY_STEPS) {
          const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/webp', quality));
          if (!blob || !blob.size || String(blob.type || '').toLowerCase() !== 'image/webp') {
            fail('مبدل WebP در این دستگاه در دسترس نیست؛ تصویر ارسال نشد.');
          }
          if (blob.size <= MAX_OUTPUT_BYTES) {
            const bytes = new Uint8Array(await blob.arrayBuffer());
            if (!isWebpBytes(bytes)) fail('خروجی مبدل، فایل WebP معتبر نیست.');
            return { dataUrl: await readAsDataUrl(blob), width, height, mime: 'image/webp', bytes: blob.size, unchanged: false };
          }
        }
      }
      fail('حجم تصویر پس از بهینه‌سازی همچنان بیش از ۴۰۰ کیلوبایت است؛ تصویر دیگری انتخاب کنید.');
    } finally {
      try { decoded.close(); } catch (_) {}
    }
  }
  async function normalizeDataUrl(dataUrl) {
    const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(String(dataUrl || ''));
    if (!match) fail('قالب تصویر دریافتی معتبر نیست.');
    const mime = 'image/' + (match[1].toLowerCase() === 'jpg' ? 'jpeg' : match[1].toLowerCase());
    const raw = root.atob(match[2]);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return normalizeFile(new root.Blob([bytes], { type: mime }));
  }
  async function validateWebpDataUrl(dataUrl) {
    const match = /^data:image\/webp;base64,([A-Za-z0-9+/]+={0,2})$/i.exec(String(dataUrl || ''));
    if (!match) fail('تصویر دریافتی WebP نیست.');
    const raw = root.atob(match[1]), bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    if (bytes.length > MAX_OUTPUT_BYTES) fail('حجم تصویر دریافتی بیش از ۴۰۰ کیلوبایت است.');
    if (!isWebpBytes(bytes)) fail('امضای فایل WebP دریافتی معتبر نیست.');
    const blob = new root.Blob([bytes], { type: 'image/webp' });
    const decoded = await decodeSource(blob);
    try {
      if (Math.max(decoded.width, decoded.height) > MAX_SIDE) fail('ضلع بزرگ تصویر دریافتی بیش از ۵۰۰ پیکسل است.');
      return { width: decoded.width, height: decoded.height, bytes: bytes.length };
    } finally { try { decoded.close(); } catch (_) {} }
  }
  root.QoqnusImageNormalizer = {
    MAX_SIDE, MAX_OUTPUT_BYTES, MAX_SOURCE_BYTES,
    normalizeFile, normalizeDataUrl, validateWebpDataUrl, isWebpBytes
  };
})(typeof self !== 'undefined' ? self : globalThis);
