'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../app/src/main/assets');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const ids = [...html.matchAll(/\bid="([A-Za-z0-9_-]+)"/g)].map(x => x[1]);
assert.equal(new Set(ids).size, ids.length, 'all page IDs are unique');
const buttonTags = [...html.matchAll(/<button\b([^>]*)>/gi)].map(x => x[1]);
assert.ok(buttonTags.length >= 80, 'consumer UI contains the expected set of controls');
for (const attrs of buttonTags) assert.match(attrs, /\btype="(?:button|submit|reset)"/i, 'every button declares its action type');
const attr = (source, name) => source.match(new RegExp('(?:^|\\s)' + name + '="([^"]*)"', 'i'))?.[1] || '';
for (const attrs of buttonTags) {
  const id = attr(attrs, 'id');
  if (id && !/\btype="submit"/i.test(attrs)) assert.ok(app.includes(`$('${id}')`) || app.includes(`getElementById('${id}')`) || app.includes(id), `button #${id} is referenced by app logic`);
  if (/\bdata-view=/.test(attrs) || /\bdata-mobile-view=/.test(attrs)) assert.match(app, /\.tab\[data-view\]|\.mobile-nav-item\[data-mobile-view\]/, 'navigation controls are wired');
  if (/\bdata-home-action=/.test(attrs)) assert.match(app, /\[data-home-action\]/, 'dashboard shortcuts are wired');
  if (/\bdata-menu-view=/.test(attrs) || /\bdata-menu-action=/.test(attrs)) assert.match(app, /\.app-menu-item\[data-menu-(?:view|action)\]/, 'drawer menu controls are wired');
  if (/\bdata-pin-key=/.test(attrs)) assert.match(app, /\[data-pin-key\]/, 'quick PIN keypad is wired');
}
const formIds = [...html.matchAll(/<form\b[^>]*\bid="([A-Za-z0-9_-]+)"/gi)].map(x => x[1]);
for (const id of formIds) assert.match(app, new RegExp("\\$\\('" + id + "'\\)\\.addEventListener\\('submit'"), `form #${id} has a submit handler`);
for (const m of app.matchAll(/\$\('([A-Za-z0-9_-]+)'\)\??\.addEventListener/g)) assert.ok(ids.includes(m[1]), `event target #${m[1]} exists`);
for (const view of ['dashboard', 'customers', 'files', 'listings', 'sync', 'backup']) assert.ok(ids.includes('view-' + view), `navigation destination view-${view} exists`);
for (const action of ['customers', 'files', 'listings', 'register-file', 'register-customer', 'read-listing', 'sync', 'notifications']) assert.ok(app.includes(`case '${action}'`), `dashboard action ${action} is handled`);
console.log(`PASS V239: ${buttonTags.length} buttons have explicit types; ${formIds.length} forms have submit handlers; all navigation destinations, dashboard shortcuts, menu actions, keypad controls and direct listener targets are wired.`);
