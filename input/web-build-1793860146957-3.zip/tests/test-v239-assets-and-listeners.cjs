'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../app/src/main/assets');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const referenced = [
  ...[...html.matchAll(/<script[^>]+src=["']([^"']+)/g)].map(x => x[1]),
  ...[...html.matchAll(/<(?:link|img)[^>]+(?:href|src)=["']([^"']+)/g)].map(x => x[1])
];
for (const raw of referenced) {
  const local = raw.split(/[?#]/)[0];
  if (!local || /^(?:https?:|data:|#)/i.test(local)) continue;
  assert.ok(fs.existsSync(path.join(root, local)), `referenced asset exists: ${raw}`);
}
const ids = [...html.matchAll(/\bid="([A-Za-z0-9_-]+)"/g)].map(x => x[1]);
const idSet = new Set(ids);
assert.equal(idSet.size, ids.length, 'HTML IDs must be unique');
const direct = [...app.matchAll(/\$\('([A-Za-z0-9_-]+)'\)(?!\?)\.addEventListener/g)].map(x => x[1]);
for (const id of direct) assert.ok(idSet.has(id), `direct event target exists: ${id}`);
assert.ok(html.includes('id="startupSplash"') === false || app.includes('startupSplash'), 'no stale startup overlay in the web page');
console.log(`PASS V239: ${referenced.length} referenced local assets exist; ${ids.length} HTML IDs are unique; ${direct.length} direct listener targets exist.`);
