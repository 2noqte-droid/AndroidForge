'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.ok(start >= 0, `${name} exists`);
  const end = source.indexOf('\n}', start);
  assert.ok(end > start, `${name} closes`);
  return source.slice(start, end + 2);
}
const context = vm.createContext({
  CENTRAL_KINDS: new Set(['customer', 'file', 'listing']),
  Date,
  Math,
  Number,
  String,
  Map,
  Array
});
vm.runInContext(extract('centralBuildKnownRecords') + '\n' + extract('centralRememberDeletedAcks') +
  '\nthis.build=centralBuildKnownRecords;this.remember=centralRememberDeletedAcks;', context);

const local = [
  { kind: 'customer', record: { centralId: 'central-a', version: 4, centralServerStatus: 'active' } },
  { kind: 'file', record: { centralId: 'central-b', version: 2, centralServerStatus: 'deleted' } },
  { kind: 'tombstone', record: { centralId: 'not-a-record' } },
  { kind: 'listing', record: { id: 'local-only' } }
];
const oldAcks = [{ recordId: 'central-c', version: 7, status: 'deleted', acknowledgedAt: 100 }];
const known = context.build(local, oldAcks);
assert.deepEqual(JSON.parse(JSON.stringify(known)), [
  { recordId: 'central-a', version: 4, status: 'active' },
  { recordId: 'central-b', version: 2, status: 'deleted' },
  { recordId: 'central-c', version: 7, status: 'deleted' }
]);
const merged = context.remember(oldAcks, [
  { recordId: 'central-a', version: 5, status: 'deleted' },
  { recordId: 'central-c', version: 8, status: 'deleted' },
  { recordId: 'ignored-active', version: 1, status: 'active' }
], 999);
assert.deepEqual(JSON.parse(JSON.stringify(merged)), [
  { recordId: 'central-c', version: 8, status: 'deleted', acknowledgedAt: 999 },
  { recordId: 'central-a', version: 5, status: 'deleted', acknowledgedAt: 999 }
]);
assert.equal(context.build([], merged).length, 2, 'accepted remote deletions stay in the known-ID manifest after local row removal');
console.log('PASS V238: accepted remote deletions remain acknowledged in future manifests and are not rediscovered as unknown records.');
