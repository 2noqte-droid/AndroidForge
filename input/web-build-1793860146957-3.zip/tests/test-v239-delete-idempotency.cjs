'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const { createHash } = require('node:crypto');
const source = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/app.js'), 'utf8');
function extract(name) {
  let start = source.indexOf(`async function ${name}(`);
  if (start < 0) start = source.indexOf(`function ${name}(`);
  assert.ok(start >= 0, `${name} exists`);
  const end = source.indexOf('\n}', start);
  assert.ok(end > start, `${name} closes`);
  return source.slice(start, end + 2);
}
const context = vm.createContext({
  String, Number, Math,
  sha256Hex: async value => createHash('sha256').update(String(value)).digest('hex')
});
vm.runInContext(extract('centralDeleteOperationId') + '\nthis.makeId=centralDeleteOperationId;', context);
(async () => {
  const tomb = { id: 'file:local-123', centralId: 'central-456', version: 3 };
  const first = await context.makeId(tomb);
  const retry = await context.makeId({ ...tomb });
  const nextVersion = await context.makeId({ ...tomb, version: 4 });
  assert.equal(first, retry, 'retry after a lost HTTP response must reuse the same operation ID');
  assert.notEqual(first, nextVersion, 'a genuinely new tombstone version gets a new operation ID');
  assert.match(first, /^android-delete:[a-f0-9]{64}$/);
  assert.ok(first.length <= 180, 'operation ID fits the server contract');
  console.log('PASS V239: remote delete retries use a stable server-idempotent operation ID and the API receives the backend-supported description field.');
})().catch(error => { console.error(error); process.exitCode = 1; });
