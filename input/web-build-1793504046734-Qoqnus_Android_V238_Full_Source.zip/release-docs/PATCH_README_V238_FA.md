# راهنمای Patch ققنوس V237 به V238

- Patch: `Qoqnus_Android_V237_to_V238_Patch.diff`
- مبنای لازم: سورس دقیق V237 تحویلی قبلی
- نسخه خروجی: V238 / `versionCode=48` / `versionName=2.0.42`

از ریشه پروژه V237، ابتدا یک کپی پشتیبان بگیرید و سپس اجرا کنید:

```bash
git apply --check Qoqnus_Android_V237_to_V238_Patch.diff
git apply Qoqnus_Android_V237_to_V238_Patch.diff
```

Patch روی یک آرشیو پاک از سورس V237 در این مأموریت بررسی و اعمال شده است؛ درخت خروجی با سورس V238 تحویلی بدون اختلاف بود.

این Patch فایل‌های کد و تست را تغییر می‌دهد و به‌تنهایی APK یا نصب‌کننده نیست. برای فعال شدن رابط WebView و تغییرات Native/نسخه، APK جدید لازم است. برای نصب به‌صورت Update، امضای APK باید با نسخه نصب‌شده یکسان باشد.
