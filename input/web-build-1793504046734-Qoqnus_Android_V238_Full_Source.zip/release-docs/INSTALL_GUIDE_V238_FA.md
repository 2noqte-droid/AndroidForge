# راهنمای ساخت و نصب ققنوس V238

## شناسه نسخه

- `applicationId`: `ir.qoqnus.divarreader`
- `versionCode`: `48`
- `versionName`: `2.0.42`
- نسخه پایه: V237 (`versionCode=47`, `versionName=2.0.41`)

## وضعیت

APK آماده نصب در این بسته وجود ندارد. در محیط این اجرا Gradle، Gradle Wrapper، Android SDK و keystore انتشار موجود نبودند.

## ساخت

۱. ZIP سورس V238 را استخراج و پوشه ریشه دارای `settings.gradle.kts` را در Android Studio/CI باز کنید.  
۲. JDK 17، Android SDK Platform 35 و Android Build Tools متناسب نصب باشند.  
۳. Android Gradle Plugin پروژه 8.7.3 است؛ Gradle سازگار را در محیط build تأمین کنید.  
۴. کلید انتشار همان نسخه نصب‌شده را در تنظیم امن CI/Android Studio پیکربندی کنید؛ keystore و رمز را داخل سورس یا گفتگو قرار ندهید.  
۵. `:app:assembleRelease` را اجرا کنید.  
۶. APK را با `apksigner verify --verbose --print-certs` بررسی کنید و fingerprint گواهی آن را با APK نصب‌شده مقایسه کنید.  
۷. ابتدا به‌صورت upgrade روی دستگاه آزمایشی نصب کنید و فایل‌ها، مشتریان، تصاویر، قفل و تم را بررسی کنید.

## نصب

- برنامه موجود را حذف نکنید.
- داده‌های برنامه، WebView یا IndexedDB را پاک نکنید.
- فقط پس از تطابق fingerprint و موفقیت نصب آزمایشی، APK را به‌صورت update نصب کنید.
- اگر امضا متفاوت باشد، Android نصب را به‌عنوان به‌روزرسانی رد می‌کند.

## بازگشت

پیش از نصب، از داده‌های مهم داخل برنامه backup رمزگذاری‌شده بگیرید. برای rollback سورس، Patch V237→V238 را reverse کنید یا سورس V237 را جایگزین کنید؛ برای APK، فقط APK قبلی با امضای معتبر و versionCode مجاز می‌تواند به‌عنوان downgrade نصب شود و ممکن است Android downgrade را رد کند. پاک‌کردن داده برنامه راهکار rollback نیست.
