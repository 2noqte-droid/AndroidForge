'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');
const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const tests=[]; const test=(name,fn)=>tests.push({name,fn});
const block=(start,end)=>{const a=app.indexOf(start);assert.ok(a>=0,`missing ${start}`);const b=app.indexOf(end,a);assert.ok(b>a,`missing end ${end}`);return app.slice(a,b);};

test('three offices use the same compact filter shell and one persistent action footer',()=>{
 const setup=block('function setupCompactOfficeViews(', 'function enhanceFilterSelectWithRadios(');
 for(const view of ['customers','files','listings']) assert.ok(setup.includes(`view:'${view}'`),`missing ${view} filter config`);
 assert.match(setup,/panel\.className='office-filter-panel hidden'/);
 assert.match(setup,/qoqnus-filter-panel-heading/);
 assert.match(setup,/qoqnus-filter-group/);
 const actions=block('function setupSharedOfficeFilterActions(', 'function collectListingFilterState(');
 assert.match(actions,/for\(const \[view,formId\] of \[\['customers','customerSearchForm'\],\['files','fileSearchForm'\]\]\)/);
 assert.match(actions,/panel\.append\(row\)/);
 assert.match(app,/const panel=\$\('listingsOfficeFilters'\);\(panel\|\|root\)\.append\(actions\)/);
 assert.match(css,/\.office-filter-panel\{[\s\S]*max-height:calc\(100dvh - 190px\)!important;overflow:auto!important/);
 assert.match(css,/\.qoqnus-filter-panel-heading\{[\s\S]*position:sticky/);
 assert.match(css,/\.qoqnus-filter-actions\{position:sticky/);
});

test('single-choice selects are enhanced with radios while multi-choice groups remain checkboxes',()=>{
 const enhance=block('function enhanceFilterSelectWithRadios(', 'function syncOfficeFilterRadioGroups(');
 assert.match(enhance,/input\.type='radio'/);
 assert.match(enhance,/select\.value=input\.value/);
 assert.match(enhance,/select\.dispatchEvent\(new Event\('change',\{bubbles:true\}\)\)/);
 assert.match(enhance,/select\.hidden=true/);
 const config=block('function setupOfficeFilterControls(', 'function setupSharedOfficeFilterActions(');
 for(const id of ['customerPeriodFilter','customerTopicFilter','filePeriodFilter','fileTopicFilter','fileStatusFilter','listingPeriodFilter','listingStatusFilter']) assert.ok(config.includes(`'${id}'`),`missing radio single-choice ${id}`);
 for(const name of ['fileTransactionCriteria','filePropertyCriteria','fileRoomsCriteria','fileHvacCriteria','customerSearchField']) assert.match(html,new RegExp(`type="checkbox" name="${name}"`));
 assert.match(html,/type="radio" name="listingTransactionFilter"/);
});

test('customer and file filters stage state until submit instead of rerendering on each keystroke',()=>{
 assert.match(app,/let appliedCustomerAdvancedFilters=null/);
 assert.match(app,/let appliedFileAdvancedFilters=null/);
 assert.match(app,/function collectCustomerAdvancedFilterState\(\)/);
 assert.match(app,/function collectFileAdvancedFilterState\(\)/);
 const customers=block('async function renderCustomers(', 'async function renderFiles(');
 const files=app.slice(app.indexOf('async function renderFiles('), app.indexOf('async function renderAll(', app.indexOf('async function renderFiles('))); assert.ok(files.length>0);
 assert.match(customers,/const advanced=appliedCustomerAdvancedFilters/);
 assert.match(files,/const advanced=appliedFileAdvancedFilters/);
 assert.match(app,/customerSearchForm'\)\.addEventListener\('submit'/);
 assert.match(app,/fileSearchForm'\)\.addEventListener\('submit'/);
 assert.match(app,/Advanced office filters are staged and applied once/);
 assert.doesNotMatch(app,/\$\('customerAreaFilter'\)\.addEventListener\('input',renderCustomers/);
 assert.doesNotMatch(app,/\$\('fileSearch'\)\.addEventListener\('input',renderFiles/);
});

test('all three card types share the fixed RTL action row without changing action handlers',()=>{
 const helper=block('function createStandardCardActionRow(', 'async function buildOfficeCallIndex(');
 assert.match(helper,/const slots=\['more','check','view','delete','call'\]/);
 assert.match(helper,/row\.setAttribute\('dir','rtl'\)/);
 assert.match(helper,/row\.dataset\.actionOrder='more,check,view,delete,call'/);
 for(const [start,end] of [['function renderCustomerCard(','async function readDivarFromOfficeFile('],['function renderFileCard(','function renderCard('],['async function renderListings(','async function renderConflicts(']]){
  const source=block(start,end);assert.match(source,/createStandardCardActionRow\(/,`${start} must use shared row`);
 }
 assert.match(css,/grid-template-columns:repeat\(5,minmax\(0,1fr\)\)!important;direction:rtl!important/);
 assert.match(app,/function createIndexedRecordCallControl\(/);
 assert.match(app,/if\(phone&&tracking&&\['customer','file','listing'\]\.includes/);
 assert.match(app,/node\.disabled=true/);
});

test('shared action helper creates DOM slots in exact order',()=>{
 const source=block('function createStandardCardActionRow(', 'async function buildOfficeCallIndex(');
 class FakeNode {
  constructor(tag){this.tagName=tag;this.dataset={};this.attrs={};this.children=[];this.className='';}
  setAttribute(k,v){this.attrs[k]=String(v);}
  append(node){this.children.push(node);}
 }
 const document={createElement:tag=>new FakeNode(tag)};
 const sandbox={document,String};
 vm.runInNewContext(source+'\nthis.build=createStandardCardActionRow;',sandbox);
 const actions={};for(const slot of ['call','delete','view','check','more'])actions[slot]=new FakeNode('button');
 const row=sandbox.build(actions,'listing');
 assert.deepEqual(row.children.map(node=>node.dataset.actionSlot),['more','check','view','delete','call']);
 assert.equal(row.attrs.dir,'rtl');
 assert.equal(row.dataset.actionOrder,'more,check,view,delete,call');
});

test('a missing time-group helper does not hide the filtered records',()=>{
 const source=block('function buildTimeGroupedSections(', 'function appendTimeGroupedRecords(');
 class FakeNode { constructor(){this.dataset={};this.children=[];this.className='';} append(...nodes){this.children.push(...nodes);} setAttribute(){} }
 const list=new FakeNode();const rows=[{id:'a'},{id:'b'},{id:'c'}];
 const sandbox={window:{},document:{createElement:()=>new FakeNode()},console:{warn(){}},displayCount:n=>String(n)};
 vm.runInNewContext(source+'\nthis.build=buildTimeGroupedSections;',sandbox);
 const groups=sandbox.build(list,rows,'listing');
 assert.equal(groups.length,1);
 assert.equal(groups[0].group.records.length,3);
 assert.equal(groups[0].group.count,3);
});

test('listing titles and per-record fallbacks never expose technical source identifiers',()=>{
 const titleSource=block('function safeListingTitle(', 'function appendListingFallbackControls(');
 const sandbox={compactListingTitle:r=>String(r.title||'')};
 vm.runInNewContext(titleSource+'\nthis.safe=safeListingTitle;',sandbox);
 assert.equal(sandbox.safe({id:'divar:gai7UBvY',title:'divar:gai7UBvY',description:'خانه ویلایی در محله مرکزی'}),'خانه ویلایی در محله مرکزی');
 assert.equal(sandbox.safe({id:'divar:gai7UBvY',title:'divar:gai7UBvY'}),'آگهی ملک');
 const listings=block('async function renderListings(', 'async function renderConflicts(');
 assert.match(listings,/safeListingSummary\(record\)/);
 assert.match(listings,/appendListingFallbackControls\(card,record,id,transactionType,officeCallIndex\)/);
 assert.doesNotMatch(listings,/qoqnus-listing-render-error|نمایش این آگهی با خطا|شناسه:/);
 const fallback=block('function appendListingFallbackControls(', 'async function renderListings(');
 assert.match(fallback,/createStandardCardActionRow\(\{more,check,view,delete:del,call\},'listing'\)/);
 assert.match(fallback,/اطلاعات مالی/);
});

test('listing count, list rows and filtered records use the same set; legacy normalization is non-blocking',()=>{
 const listings=block('async function renderListings(', 'async function renderConflicts(');
 assert.match(listings,/const filtered=rows\.filter/);
 assert.match(listings,/listingCount'\)\.textContent=displayCount\(filtered\.length\)/);
 assert.match(listings,/buildTimeGroupedSections\(list,filtered,'listing'/);
 assert.match(listings,/listingPriceNormalizationPromise=\(async\(\)=>/);
 assert.doesNotMatch(listings,/await listingPriceNormalizationPromise/);
 assert.match(listings,/const normalizationRows=rows/);
 assert.match(app,/qoqnus time grouping fallback preserves all records/);
});

let failures=0;for(const item of tests){try{item.fn();console.log('PASS '+item.name);}catch(error){failures++;console.error('FAIL '+item.name+'\n'+(error.stack||error));}}
console.log(`QOQNUS V238 FILTER/ACTION/LISTING TESTS: ${tests.length-failures}/${tests.length} PASS`);
if(failures)process.exitCode=1;
