# پیگیری خطای ساخت قبلی AndroidForge

پیام دریافت‌شده:
`Build finished with status: failure. Diagnostics are in the run logs below.`

این فقط خلاصهٔ پایان کار است و خطای اصلی Gradle را مشخص نمی‌کند. برای یافتن علت دقیق، از صفحهٔ همان Run در GitHub Actions موارد زیر را بگیرید:

1. بخش Diagnosis در Summary.
2. Artifact با نام `AndroidForge-logs` و فایل لاگ ساخت/Gradle درون آن.
3. اگر شکست پیش از مرحلهٔ Build رخ داده، لاگ `Build & Publish Android Image` یا `regenerate-wrapper`.

در این بسته برای کم‌کردن خطاهای احتمالی:
- فایل‌های Gradle مستقیماً در ریشهٔ ZIP قرار دارند، نه زیر یک پوشهٔ اضافی.
- `compileSdk` و `targetSdk` روی 34 تنظیم شده‌اند.
- شناسهٔ برنامه حفظ شده و Gradle Wrapper از پیش‌ساخته‌شدهٔ ناقص داخل سورس اضافه نشده است؛ AndroidForge مطابق مستنداتش می‌تواند Wrapper را در محیط ساخت بسازد.

این تغییرها علت قبلی را ثابت نمی‌کنند و تضمین نمی‌دهند که ساخت ابری حتماً موفق شود. اگر این بسته نیز خطا داد، Artifact کامل لاگ را دانلود کنید؛ توکن GitHub را ارسال نکنید.
