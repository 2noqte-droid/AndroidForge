'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const html = read('app/src/main/assets/index.html');
const css = read('app/src/main/assets/app.css');
const js = read('app/src/main/assets/app.js');
const sw = read('app/src/main/assets/sw.js');
const manifest = JSON.parse(read('app/src/main/assets/manifest.webmanifest'));
const gradle = read('app/build.gradle.kts');
const activity = read('app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt');
const tests = [];
function test(name, fn) { fn(); tests.push(name); console.log('PASS ' + name); }
test('theme controls exist on login and main app surfaces', () => {
  assert.match(html, /id="themeToggleLock"/);
  assert.match(html, /id="themeToggle"/);
  assert.match(js, /function setupAccessibleTheme\(\)/);
  assert.match(js, /qoqnus-ui-theme-v1/);
  assert.match(js, /aria-pressed/);
});
test('theme preference is applied before stylesheet and supports both themes', () => {
  assert.match(html, /qoqnus-app-settings-v1/);
  assert.match(html, /m==="system"\?\(matchMedia/);
  assert.match(css, /html\[data-theme="dark"\]/);
  assert.match(css, /html\[data-theme="light"\]/);
});
test('both palettes use explicit high contrast foreground/background tokens', () => {
  for (const token of ['--ink:', '--muted:', '--paper:', '--line:', '--card:']) assert.ok(css.includes(token));
  assert.match(css, /--ink:#111827;--muted:#475569/);
  assert.match(css, /--ink:#f4f4f5;--muted:#d1d5db/);
});
test('functional text and labels have a 14px minimum, forms are larger', () => {
  assert.match(css, /font-size:max\(14px, 1em\)!important/);
  assert.match(css, /font-size:16px!important;line-height:1\.6!important;min-height:48px!important/);
  assert.match(css, /font-size:17px!important/);
});
test('small compact file-card text overrides are raised to readable minimum', () => {
  assert.ok(css.includes('.qoqnus-card-line-secondary'));
  assert.ok(css.includes('.qoqnus-card-line-features'));
  assert.match(css, /\.qoqnus-record-meta-line\{font-size:14px!important;line-height:1\.65!important;opacity:1!important\}/);
});
test('select controls and dropdown options remain readable in both themes', () => {
  assert.match(css, /html\[data-theme="dark"\] body select option\{background:#1c1d21!important;color:#f9fafb!important\}/);
  assert.match(css, /html\[data-theme="light"\] body select option\{background:#ffffff!important;color:#111827!important\}/);
  assert.match(css, /#syncSourceSelect/);
});
test('focus indicators and touch targets meet accessible minimums', () => {
  assert.match(css, /:focus-visible\{outline:3px solid #60a5fa!important/);
  assert.match(css, /min-height:44px/);
  assert.match(css, /\.theme-toggle\{width:44px;min-width:44px;height:44px;min-height:44px/);
});
test('release/cache identifiers and Android version align at V223', () => {
  assert.match(js, /const APP_VERSION='V236'/);
  assert.match(html, /qoqnus-build" content="V236-card-reference-layout/);
  assert.match(html, /app\.css\?v=236-card-reference-layout/);
  assert.match(sw, /qoqnus-mobile-pwa-v236-card-reference-layout/);
  assert.match(manifest.start_url, /build=V236-card-reference-layout/);
  assert.match(activity, /build=V236-card-reference-layout/);
  assert.match(gradle, /versionCode = 46/);
  assert.match(gradle, /versionName = "2\.0\.40"/);
});
test('no duplicate HTML IDs were introduced', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, new Set(ids).size, 'duplicate id in index.html');
});
console.log(`V223 accessibility source checks: ${tests.length} passed. Contrast tokens are numerically checked in report; not a device screenshot/Gradle build.`);
