'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const project = path.resolve(__dirname, '..');
const assets = path.join(project, 'app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));

function test(name, fn) {
  fn();
  process.stdout.write(`PASS ${name}\n`);
}

test('V223 app version and matching cache keys', () => {
  assert.match(js, /const APP_VERSION\s*=\s*'V235'/);
  assert.match(html, /app\.js\?v=235-sync-tombstone-review-settings/);
  assert.match(html, /app\.css\?v=235-sync-tombstone-review-settings/);
  assert.match(sw, /qoqnus-mobile-pwa-v235-sync-tombstone-review-settings/);
  assert.match(sw, /app\.js\?v=235-sync-tombstone-review-settings/);
});

test('dashboard, quick actions, and required navigation exist', () => {
  for (const id of ['view-dashboard', 'dashboardTitle', 'dashboardCustomerCount', 'dashboardFileCount', 'dashboardListingCount', 'notificationsButton', 'file-review']) {
    if (id === 'file-review') assert.match(js, /file-review/);
    else assert.ok(html.includes(`id="${id}"`), `missing id ${id}`);
  }
  for (const action of ['register-file', 'register-customer', 'read-listing', 'sync', 'notifications']) assert.ok(html.includes(`data-home-action="${action}"`), `missing action ${action}`);
});

test('HTML element IDs remain unique', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  const duplicates = ids.filter((id, idx) => ids.indexOf(id) !== idx);
  assert.deepEqual([...new Set(duplicates)], []);
});

test('all nav targets correspond to existing views', () => {
  const views = new Set([...html.matchAll(/\bid="view-([^" ]+)"/g)].map(m => m[1]));
  const targets = [
    ...[...html.matchAll(/\bdata-view="([^"]+)"/g)].map(m => m[1]),
    ...[...html.matchAll(/\bdata-menu-view="([^"]+)"/g)].map(m => m[1]),
    ...[...html.matchAll(/\bdata-mobile-view="([^"]+)"/g)].map(m => m[1]),
  ];
  for (const target of targets) assert.ok(views.has(target), `missing view ${target}`);
});

test('manifest icon assets exist and manifest remains RTL', () => {
  assert.equal(manifest.dir, 'rtl');
  assert.equal(manifest.lang, 'fa-IR');
  for (const icon of manifest.icons) assert.ok(fs.existsSync(path.join(assets, icon.src.replace(/^\.\//, ''))), `missing icon ${icon.src}`);
});

test('dark-classic and gold palette overrides are present', () => {
  assert.match(css, /color-scheme:\s*dark/);
  assert.match(css, /--paper:\s*#11110f/);
  assert.match(css, /#d4ad58/i);
  assert.match(css, /#1b1b18/i);
});

test('share URL normalization accepts direct detail links and rejects unsafe/non-detail URLs', () => {
  const listeners = {};
  const sandbox = {
    self: { addEventListener: (event, handler) => { listeners[event] = handler; }, registration: { scope: 'https://example.invalid/app/' }, location: { origin: 'https://example.invalid' } },
    URL, Response, FormData, Promise, Date, Map, Set, console,
    caches: { match: async () => null, open: async () => ({ addAll: async () => {}, put: async () => {} }), keys: async () => [] },
  };
  vm.runInNewContext(sw, sandbox, { filename: 'sw.js' });
  const normalize = sandbox.self.__qoqnusShareTargetTest.normalizeDivarDetailUrl;
  assert.equal(normalize('https://divar.ir/v/abc123?utm_source=share').url, 'https://divar.ir/v/abc123');
  assert.equal(normalize('https://www.divar.ir/v/house-for-sale/xyz_456/').id, 'xyz_456');
  assert.equal(normalize('https://divar.ir/s/tehran'), null);
  assert.equal(normalize('http://divar.ir/v/abc123'), null);
  assert.equal(normalize('https://divar.ir.evil.test/v/abc123'), null);
  assert.equal(normalize('https://example.com/v/abc123'), null);
});

process.stdout.write('V223 regression checks for existing V207 functionality complete. These checks do not replace Android Gradle compilation or phone testing.\n');
