'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');
const ui = require(path.join(assets, 'qoqnus-listing-presentation.js'));
const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const activity = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

test('Persian and Arabic digits are normalized', () => {
  assert.equal(ui.asciiDigits('۱۲۳۴۵۶۷۸۹۰'), '1234567890');
  assert.equal(ui.asciiDigits('١٢٣٤٥٦٧٨٩٠'), '1234567890');
});
test('money parser handles Persian million and grouped values', () => {
  assert.equal(ui.parseMoneyToman('۷ میلیون تومان'), 7000000);
  assert.equal(ui.parseMoneyToman('۷,۰۰۰,۰۰۰ تومان'), 7000000);
  assert.equal(ui.parseMoneyToman('٧٬٠٠٠٬٠٠٠'), 7000000);
});
test('rial values are converted to toman without mutating source', () => {
  assert.equal(ui.parseMoneyToman('۷۰,۰۰۰,۰۰۰ ریال'), 7000000);
  assert.equal(ui.parseMoneyToman(70000000, { forceRial: true }), 7000000);
  assert.equal(ui.explicitSaleTotal({ sale_price_rial: 7000000000 }).amountToman, 700000000);
});
test('direct sale total takes precedence over computed amount', () => {
  const result = ui.resolveSalePrice({ salePrice: '۹۵۰ میلیون تومان', buildingArea: '۱۲۰', pricePerMeter: '۷ میلیون تومان' }, { topic: 'residential' });
  assert.equal(result.amountToman, 950000000);
  assert.equal(result.source, 'explicit-total');
});
test('sale total is calculated from area multiplied by price per meter', () => {
  const result = ui.resolveSalePrice({ buildingArea: '۱۲۰ متر', pricePerMeter: '۷ میلیون تومان' }, { topic: 'residential' });
  assert.equal(result.amountToman, 840000000);
  assert.equal(result.source, 'area-x-price-per-meter');
});
test('land area and per-meter price calculate a total for land listings', () => {
  const result = ui.resolveSalePrice({ landArea: '۱۲۰ متر مربع', price_per_sqm: '۷,۰۰۰,۰۰۰' }, { topic: 'land' });
  assert.equal(result.amountToman, 840000000);
});
test('explicit per-meter text is never mistaken for total sale price', () => {
  const result = ui.resolveSalePrice({ price: 'متری ۷ میلیون تومان', area_sqm: 120 }, { topic: 'residential' });
  assert.equal(result.amountToman, 840000000);
  assert.equal(result.source, 'area-x-price-per-meter');
});
test('insufficient area or unit price does not fabricate a total', () => {
  assert.equal(ui.resolveSalePrice({ pricePerMeter: '۷ میلیون تومان' }, { topic: 'residential' }).amountToman, null);
  assert.equal(ui.resolveSalePrice({ buildingArea: 120 }, { topic: 'residential' }).amountToman, null);
});
test('the app’s real text-field probe reads area and per-meter price from imported listing detail text', () => {
  const getLineFunction = name => {
    const match = app.match(new RegExp('^function ' + name + '\\([^\\n]*$', 'm'));
    assert.ok(match, `missing active helper ${name}`);
    return match[0];
  };
  const probeSource = [
    getLineFunction('sourceListingLines'),
    getLineFunction('sourceListingValue'),
    getLineFunction('firstText'),
    getLineFunction('listingTopic'),
    getLineFunction('listingTransaction'),
    app.slice(app.indexOf('function listingPriceProbe('), app.indexOf('function listingSalePriceInfo(', app.indexOf('function listingPriceProbe(')))
  ].join('\n');
  const context = { normalizeText: value => String(value ?? '').replace(/[ي]/g,'ی').replace(/[ك]/g,'ک').toLowerCase().replace(/\s+/g,' ').trim() };
  vm.runInNewContext(probeSource + '\nglobalThis.probe=listingPriceProbe;globalThis.tx=listingTransaction;globalThis.topic=listingTopic;', context);
  const imported = { id: 'TXT-1', title: 'فروش آپارتمان', detailText: 'نوع معامله: فروش\nمتراژ: ۱۲۰\nقیمت: متری ۷ میلیون تومان' };
  const transaction = context.tx(imported);
  const probe = context.probe(imported);
  assert.equal(transaction, 'sale');
  assert.equal(ui.resolveSalePrice(probe, { topic: 'residential' }).amountToman, 840000000);
  const withDirectTotal = { id: 'TXT-2', title: 'فروش آپارتمان', detailText: 'نوع معامله: فروش\nمتراژ: ۱۲۰\nقیمت کل: ۹۰۰ میلیون تومان\nقیمت هر متر: ۷ میلیون تومان' };
  assert.equal(ui.resolveSalePrice(context.probe(withDirectTotal), { topic: 'residential' }).amountToman, 900000000);
});
test('normalization persists derived total without overwriting original source fields', () => {
  const original = { id: 'L-1', transactionType: 'sale', buildingArea: '۱۲۰', pricePerMeter: '۷ میلیون تومان' };
  const normalized = ui.normalizeRecord(original, { transaction: 'sale', topic: 'residential' });
  assert.equal(normalized.qoqnusComputedSaleTotalToman, 840000000);
  assert.equal(normalized.qoqnusComputedSaleTotalMethod, 'area-x-price-per-meter');
  assert.equal(normalized.buildingArea, original.buildingArea);
  assert.equal(normalized.pricePerMeter, original.pricePerMeter);
  assert.equal(normalized.id, original.id);
});
test('normalization is idempotent and removes stale derived values', () => {
  const record = { id: 'L-2', buildingArea: 120, pricePerMeter: 7000000, qoqnusComputedSaleTotalToman: 840000000, qoqnusComputedSaleTotalMethod: 'area-x-price-per-meter', qoqnusComputedSaleTotalVersion: 1 };
  const normalized = ui.normalizeRecord(record, { transaction: 'sale', topic: 'residential' });
  assert.equal(normalized, record);
  const stale = ui.normalizeRecord({ ...record, pricePerMeter: '' }, { transaction: 'sale', topic: 'residential' });
  assert.equal(Object.hasOwn(stale, 'qoqnusComputedSaleTotalToman'), false);
});
test('rent records never receive a sale-derived total', () => {
  const normalized = ui.normalizeRecord({ id: 'R-1', qoqnusComputedSaleTotalToman: 1 }, { transaction: 'rent' });
  assert.equal(Object.hasOwn(normalized, 'qoqnusComputedSaleTotalToman'), false);
});
test('active record store normalizes sale listings and active render path normalizes legacy records', () => {
  assert.match(app, /function storeRecord\(kind,record\).*normalizeRecord/s);
  assert.match(app, /async function renderListings\(\)[\s\S]*?normalizeRecord\(record/);
  assert.match(app, /function listingSummary\(r\)[\s\S]*?listingSalePriceInfo/);
  assert.match(app, /function listingFieldRows\(r\)[\s\S]*?listingSalePriceInfo/);
});
test('actual four listing actions are converted to accessible inline SVG icons', () => {
  assert.match(app, /function setListingActionIcon\(button,iconName,label\)/);
  for (const icon of ['more', 'check', 'bookmark', 'trash']) assert.ok(app.includes("setListingActionIcon("));
  assert.match(app, /button\.replaceChildren\(svg\)/);
  assert.match(app, /button\.setAttribute\('aria-label',label\)/);
  assert.match(app, /setListingActionIcon\(more,'more'/);
  assert.match(app, /setListingActionIcon\(deal,'check'/);
  assert.match(app, /setListingActionIcon\(finalSaveButton,finalSaved\?'bookmark-check':'bookmark'/);
  assert.match(app, /setListingActionIcon\(del,'trash'/);
  assert.match(app, /if\(isDivarImported\)\{const del=addButton/);
});
test('the live icon helper replaces button labels with SVG and keeps accessible names', () => {
  class FakeNode {
    constructor(tag) { this.tagName = tag; this.attributes = {}; this.children = []; this.dataset = {}; this.classNames = new Set(); this.classList = { add: name => this.classNames.add(name) }; }
    setAttribute(k, v) { this.attributes[k] = String(v); }
    append(node) { this.children.push(node); }
    replaceChildren(...nodes) { this.children = nodes; this.textContent = ''; }
  }
  const context = { document: { createElementNS: (_ns, tag) => new FakeNode(tag) } };
  const start = app.indexOf('function setListingActionIcon(');
  const end = app.indexOf('async function renderListings()', start);
  assert.ok(start >= 0 && end > start);
  vm.runInNewContext(app.slice(start, end) + '\nglobalThis.applyListingIcon=setListingActionIcon;', context);
  for (const [kind, label] of [['more','نمایش جزئیات آگهی'],['check','ثبت معامله'],['bookmark','ذخیره نهایی'],['trash','حذف آگهی']]) {
    const button = new FakeNode('button');
    button.textContent = label;
    context.applyListingIcon(button, kind, label);
    assert.equal(button.children.length, 1);
    assert.equal(button.children[0].tagName, 'svg');
    assert.equal(button.attributes['aria-label'], label);
    assert.equal(button.attributes.title, label);
    assert.equal(button.dataset.listingIconAction, kind);
    assert.ok(button.classNames.has('qoqnus-listing-icon-action'));
  }
});
test('real active listing DOM classes have explicit light and dark title/table CSS', () => {
  assert.match(app, /a\.className='record-card source-qoqnus-card qoqnus-property-card qoqnus-listing-card/);
  for (const theme of ['dark', 'light']) {
    assert.ok(css.includes(`html[data-theme="${theme}"] body .qoqnus-listing-card .qoqnus-listing-content .qoqnus-card-line-primary`));
    assert.ok(css.includes(`html[data-theme="${theme}"] body .qoqnus-listing-card .listing-details-table th`));
    assert.ok(css.includes(`html[data-theme="${theme}"] body .qoqnus-listing-card .listing-details-table td`));
  }
  assert.match(css, /\.qoqnus-listing-icon-action\{[^}]*min-height:46px/s);
});
test('key listing text/icon theme color pairs exceed WCAG AA normal-text contrast', () => {
  const luminance = hex => {
    const h = hex.replace('#','');
    const rgb = [0,2,4].map(i => parseInt(h.slice(i,i+2),16)/255).map(v => v <= 0.04045 ? v/12.92 : ((v+0.055)/1.055)**2.4);
    return 0.2126*rgb[0] + 0.7152*rgb[1] + 0.0722*rgb[2];
  };
  const contrast = (fg,bg) => { const vals=[luminance(fg),luminance(bg)].sort((a,b)=>b-a); return (vals[0]+0.05)/(vals[1]+0.05); };
  const pairs=[['#f8fafc','#1c1d21'],['#fbbf24','#1c1d21'],['#f8fafc','#303847'],['#f1f5f9','#222630'],['#111827','#ffffff'],['#0759b7','#ffffff'],['#111827','#e8eef7'],['#1f2937','#ffffff'],['#f8fafc','#30343d'],['#0f172a','#f1f5f9']];
  for (const [fg,bg] of pairs) assert.ok(contrast(fg,bg) >= 4.5, `${fg} on ${bg} contrast below 4.5:1`);
});
test('presentation helper is loaded before app.js and included in service-worker cache', () => {
  assert.ok(html.indexOf('qoqnus-listing-presentation.js') < html.indexOf('app.js?v=235-sync-tombstone-review-settings'));
  assert.match(sw, /qoqnus-listing-presentation\.js\?v=235-sync-tombstone-review-settings/);
  assert.match(sw, /qoqnus-mobile-pwa-v235-sync-tombstone-review-settings/);
  assert.match(html, /app\.css\?v=235-sync-tombstone-review-settings/);
  assert.match(html, /app\.js\?v=235-sync-tombstone-review-settings/);
});
test('APK WebView entry, PWA manifest and Gradle package version use V232', () => {
  assert.match(activity, /build=V235-sync-tombstone-review-settings/);
  assert.equal(manifest.start_url, './index.html?build=V235-sync-tombstone-review-settings');
  assert.match(gradle, /versionCode\s*=\s*45/);
  assert.match(gradle, /versionName\s*=\s*"2\.0\.39"/);
});
console.log(`QOQNUS V230 LISTING TESTS: ${passed}/${passed} PASS`);
