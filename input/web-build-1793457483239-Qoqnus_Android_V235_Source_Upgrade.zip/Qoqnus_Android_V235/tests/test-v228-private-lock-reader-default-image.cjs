const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const asset = p => path.join(root, 'app/src/main/assets', p);
const app = fs.readFileSync(asset('app.js'), 'utf8');
const html = fs.readFileSync(asset('index.html'), 'utf8');
const css = fs.readFileSync(asset('app.css'), 'utf8');
const sw = fs.readFileSync(asset('sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(asset('manifest.webmanifest'), 'utf8'));
const native = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const normalizer = fs.readFileSync(asset('qoqnus-divar-data-normalizer.js'), 'utf8');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

test('V232 release identifiers and cache-busting are aligned across Android/WebView/PWA', () => {
  assert.match(app, /const APP_VERSION='V235'/);
  assert.match(html, /qoqnus-build" content="V235-sync-tombstone-review-settings"/);
  assert.match(html, /app\.js\?v=235-sync-tombstone-review-settings/);
  assert.match(html, /app\.css\?v=235-sync-tombstone-review-settings/);
  assert.match(sw, /qoqnus-mobile-pwa-v235-sync-tombstone-review-settings/);
  assert.match(sw, /app\.js\?v=235-sync-tombstone-review-settings/);
  assert.match(manifest.start_url, /build=V235-sync-tombstone-review-settings/);
  assert.match(native, /build=V235-sync-tombstone-review-settings/);
  assert.match(gradle, /versionCode\s*=\s*45[\s\S]*versionName\s*=\s*"2\.0\.39"/);
});

test('PIN remains required for private office view; restricted encrypted background mode never unlocks it', () => {
  assert.match(app, /async function enterBackgroundOperationsMode\(\)/);
  assert.match(app, /cryptoKey=key;deviceId=await getMetaObj\('deviceId',''\);backgroundOperationsMode=true;quickEntryMode=false;fullOfficeUnlocked=false/);
  assert.match(app, /isReady:\(\)=>!!cryptoKey&&\(fullOfficeUnlocked\|\|backgroundOperationsMode\|\|quickEntryMode\)/);
  assert.match(app, /function showApp\(\)\{\s*backgroundOperationsMode=false;fullOfficeUnlocked=true/);
  assert.match(app, /function lockApp\(\)\{[\s\S]*fullOfficeUnlocked=false[\s\S]*cryptoKey=null/);
  assert.match(html, /ثبت سریع فقط فرم ثبت را باز می‌کند؛ دفترها و اطلاعات محرمانه همچنان قفل هستند/);
  assert.match(html, /lockedOperationsPanel/);
});

test('lock-screen sync uses the real selected peer and existing durable queue request', () => {
  assert.match(html, /id="lockedSyncSourceSelect"/);
  assert.match(app, /async function refreshLockedSyncSources\(\)/);
  assert.match(app, /async function runLockedSync\(mode='delta'\)/);
  assert.match(app, /\$\('syncSourceSelect'\)\.value=selected;await setMetaObj\('selectedSyncSource',selected\);startDurableQueueAutomation\(\);await requestSelectedSync\(mode\)/);
  assert.match(app, /async function durableQueueTick\(\)\{if\(durableQueueBusy\|\|!cryptoKey\|\|!navigator\.onLine\|\|activeSessionId\|\|\(\$\('appShell'\)\?\.classList\.contains\('hidden'\)&&!backgroundOperationsMode\)\)return/);
  assert.match(app, /if\(fullOfficeUnlocked\)await renderAll\(true\)/);
});

test('reader is reachable while private lists stay locked and saved records do not force private rendering', () => {
  assert.match(html, /id="lockedReaderUrl"/);
  assert.match(html, /id="startLockedReader"/);
  assert.match(app, /async function readListingFromLockScreen\(\)/);
  assert.match(app, /type:'OPEN_READER',url:link\.url,recordId:''/);
  assert.match(app, /if\(fullOfficeUnlocked\)\{activateView\('listings'\)/);
  assert.match(app, /else\{setStatus\('lockedOperationsStatus',fullRead\?/);
  assert.match(app, /readerLaunchWentBackground=false;if\(readerLaunchButton\)\{setReaderActionBusy\(readerLaunchButton,false\);readerLaunchButton=null;\}/);
  assert.match(app, /readerLaunchWentBackground&&!readerLaunchButton/);
});

test('listing reader action is an accessible eye icon and its icon survives busy state', () => {
  assert.match(app, /setListingActionIcon\(readButton,'eye','خواندن آگهی'\)/);
  assert.match(app, /function setReaderActionBusy\(button,busy\)\{[\s\S]*setListingActionIcon\(button,'eye'/);
  assert.match(app, /iconName==='eye'/);
  assert.match(app, /button\.setAttribute\('aria-label',label\)/);
  assert.match(app, /button\.setAttribute\('title',label\)/);
});

test('top and bottom detail collapse controls share one per-listing state and keep three-dot opener', () => {
  assert.match(app, /const setDetailOpen=open=>\{detail\.hidden=!open/);
  assert.match(app, /const makeCollapseControl=position=>/);
  assert.match(app, /detail\.append\(makeCollapseControl\('top'\)/);
  assert.match(app, /detail\.append\(makeCollapseControl\('bottom'\)\)/);
  assert.match(app, /makeCollapseControl\('top'\)[\s\S]*makeCollapseControl\('bottom'\)/);
  assert.match(app, /const open=detail\.hidden;setDetailOpen\(open\)/);
  assert.match(css, /\.qoqnus-listing-detail-collapse\{/);
  assert.match(css, /\.qoqnus-listing-detail-collapse--bottom/);
});

test('all app-owned image display paths use the shared phoenix fallback and never store it as a record image', () => {
  assert.match(app, /const DEFAULT_RECORD_IMAGE='\.\/icons\/qoqnus-default-400\.webp'/);
  assert.match(html, /customerPhotoPreview[^>]*src="\.\/icons\/qoqnus-default-400\.webp"/);
  assert.match(sw, /\.\/icons\/qoqnus-default-400\.webp/);
  assert.match(app, /function setImageFallback\(img\)/);
  assert.match(app, /function renderPhotoGallery[\s\S]*DEFAULT_RECORD_IMAGE/);
  assert.match(app, /function makeCustomerPhotoElement[\s\S]*DEFAULT_RECORD_IMAGE/);
  assert.match(app, /function openCustomerPhoto[\s\S]*setImageFallback\(img\)/);
  assert.match(app, /image\.src=photoSource\|\|DEFAULT_RECORD_IMAGE/);
  assert.match(app, /function setImageFallback\(img\)/);
  assert.match(app, /function updateCustomerPhotoPreview[\s\S]*setImageFallback\(preview\)/);
  const imageCreationLines = app.split('\n').filter(line => line.includes("document.createElement('img')"));
  assert.ok(imageCreationLines.length >= 6, 'expected every image surface to be covered');
  assert.ok(imageCreationLines.every(line => line.includes('setImageFallback(')), 'every dynamically-created image must have the shared fallback');
  assert.doesNotMatch(app, /profilePhotoWebp\s*:\s*DEFAULT_RECORD_IMAGE/);
  assert.doesNotMatch(app, /storeRecord\([^\n]*DEFAULT_RECORD_IMAGE/);
});

test('visible app UI contains no source brand label/logo text while URL parser and reader integration remain active', () => {
  const body = html.split('<body>')[1].split('</body>')[0]
    .replace(/<script\b[\s\S]*?<\/script>/gi, '')
    .replace(/<!--([\s\S]*?)-->/g, '')
    .replace(/\b(?:id|class|href|src|for|aria-label|title|placeholder)="[^"]*"/gi, '')
    .replace(/<[^>]*>/g, ' ');
  assert.doesNotMatch(body, /دیوار|divar/i);
  assert.doesNotMatch(html, /placeholder="https:\/\/divar\.ir/i);
  assert.match(normalizer, /stripSourceBrandForDisplay/);
  assert.match(normalizer, /normalizeRecord/);
  assert.match(app, /normalizeDivarDetailUrl/);
  assert.match(native, /private fun openDivar\(/);
  assert.match(native, /addWebMessageListener\(divarWeb/);
});

console.log(`QOQNUS V230 LOCK/READER/PLACEHOLDER TESTS: ${passed}/${passed} PASS`);
