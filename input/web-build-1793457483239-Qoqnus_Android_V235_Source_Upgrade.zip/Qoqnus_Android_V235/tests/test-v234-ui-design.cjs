'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');
const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const native = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
const tests = [];
const test = (name, fn) => tests.push({ name, fn });

function luminance(hex) {
  const parts = hex.replace('#', '').match(/../g).map(x => parseInt(x, 16) / 255);
  const rgb = parts.map(x => x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4);
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}
function contrast(a, b) {
  const values = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (values[0] + 0.05) / (values[1] + 0.05);
}

test('V235 release identity and cache identifiers are aligned', () => {
  assert.match(app, /const APP_VERSION='V235'/);
  assert.match(html, /qoqnus-build" content="V235-sync-tombstone-review-settings/);
  assert.match(html, /app\.js\?v=235-sync-tombstone-review-settings/);
  assert.match(html, /app\.css\?v=235-sync-tombstone-review-settings/);
  assert.match(sw, /qoqnus-mobile-pwa-v235-sync-tombstone-review-settings/);
  assert.match(manifest.start_url, /build=V235-sync-tombstone-review-settings/);
  assert.match(native, /build=V235-sync-tombstone-review-settings/);
  assert.match(gradle, /versionCode\s*=\s*45/);
  assert.match(gradle, /versionName\s*=\s*"2\.0\.39"/);
});

test('manual files and imported listings render through one shared property-card summary', () => {
  assert.match(app, /function createPropertyCardSummary\(record,kind,id,options=\{\}\)/);
  assert.match(app, /art\.append\(createPropertyCardSummary\(r,'file'/);
  assert.match(app, /const summaryBody=createPropertyCardSummary\(r,'listing'/);
  assert.match(app, /summary\.className='qoqnus-property-summary qoqnus-listing-body'/);
  assert.match(app, /ownerLine\.className='qoqnus-owner-name'/);
  assert.match(css, /\.qoqnus-property-summary\s*\{display:grid/);
});

test('owner name uses white in dark theme and readable ink in light theme', () => {
  assert.match(css, /html\[data-theme="dark"\] body \.qoqnus-property-card \.qoqnus-property-summary \.qoqnus-owner-name\{color:#ffffff!important\}/);
  assert.match(css, /html\[data-theme="light"\] body \.qoqnus-property-card \.qoqnus-property-summary \.qoqnus-owner-name\{color:#202733!important\}/);
  assert.ok(contrast('#ffffff', '#22252b') >= 4.5);
  assert.ok(contrast('#202733', '#ffffff') >= 4.5);
});

test('theme switch is mounted beside the Phoenix logo and initialized on load', () => {
  assert.match(html, /<div class="brand-group"><div class="brand-mark small">[\s\S]*?<button id="themeToggle" class="icon-button theme-toggle"/);
  assert.match(app, /function setupAccessibleTheme\(\)/);
  assert.match(app, /function readAppSettings\(\)/);
  assert.match(app, /function writeAppSettings\(next\)/);
  assert.match(app, /localStorage\.setItem\(APP_SETTINGS_KEY,JSON\.stringify\(settings\)\)/);
  assert.match(app, /setupAccessibleTheme\(\);\s*\n\s*setupStartupQuickEntry\(\);/);
  assert.match(html, /qoqnus-app-settings-v1/);
});

test('theme changes are relayed to native Android system bars', () => {
  assert.match(app, /type:'SET_SYSTEM_THEME',theme/);
  assert.match(native, /"SET_SYSTEM_THEME"\s*->\s*\{[\s\S]*?runOnUiThread \{ applySystemTheme\(theme\) \}/);
  assert.match(native, /window\.statusBarColor/);
  assert.match(native, /window\.navigationBarColor/);
  assert.match(native, /appRootView\?\.setBackgroundColor\(background\)/);
});

test('central theme variables cover surfaces, controls, text and state colors', () => {
  for (const token of ['--app-bg','--surface','--surface-raised','--text-primary','--text-secondary','--text-muted','--border-color','--accent-color','--owner-name-color','--success-color','--warning-color','--error-color','--control-bg','--control-border','--focus-ring']) {
    assert.ok(css.includes(token), `missing theme token ${token}`);
  }
  assert.ok(contrast('#f8fafc', '#22252b') >= 4.5);
  assert.ok(contrast('#c6ccd5', '#22252b') >= 4.5);
  assert.ok(contrast('#202733', '#ffffff') >= 4.5);
  assert.ok(contrast('#626d7b', '#f5f6f8') >= 4.5);
  assert.ok(contrast('#8a5b0a', '#ffffff') >= 4.5);
});

test('badge colors remain readable in both themes', () => {
  assert.match(css, /html\[data-theme="dark"\] body \.qoqnus-property-summary \.qoqnus-card-badges \.tag\{background:#343a44!important;color:#edf2f7!important/);
  assert.match(css, /html\[data-theme="light"\] body \.qoqnus-property-summary \.qoqnus-card-badges \.tag\{background:#edf1f5!important;color:#334155!important/);
});

test('legacy listing CSS cannot diverge from the shared manual/listing summary dimensions', () => {
  assert.match(css, /html\[data-theme\] body \.qoqnus-property-card \.qoqnus-property-summary\{display:grid;grid-template-columns:64px/);
  assert.match(css, /html\[data-theme\] body \.qoqnus-property-card \.qoqnus-property-summary \.qoqnus-listing-photo\{display:block;width:64px!important;height:72px!important/);
  assert.match(css, /html\[data-theme\] body \.qoqnus-property-card \.qoqnus-property-summary \.qoqnus-card-line-secondary[^\{]*\{[^}]*font-size:11px!important/);
  assert.match(css, /@media\(max-width:420px\)\{[\s\S]*?html\[data-theme\] body \.qoqnus-property-card \.qoqnus-property-summary\{grid-template-columns:48px/);
});

test('decorative snowflake-like four-point star was removed without removing reminder actions', () => {
  assert.doesNotMatch(html + css + app, /✦|✳|✥|❄|❆|❅|☃|❉|✻|✼|✺/u);
  assert.match(html, /class="dashboard-review"[\s\S]*?یادآوری روزانهٔ دفتر[\s\S]*?data-home-action="notifications"/);
});

let failures = 0;
for (const item of tests) {
  try { item.fn(); console.log('PASS ' + item.name); }
  catch (error) { failures++; console.error('FAIL ' + item.name + ': ' + error.message); }
}
console.log(`QOQNUS V235 UI DESIGN TESTS: ${tests.length - failures}/${tests.length} PASS`);
if (failures) process.exitCode = 1;
