# راهنمای patch متنی V235

این patch از سورس دقیق `Qoqnus_Android_V234_UI_Themes_Cards_Source.zip` ساخته شده است.

- پیشنهاد اصلی: به‌جای اعمال دستی patch، از ZIP کامل `Qoqnus_Android_V235_Source_Upgrade.zip` استفاده کنید.
- اگر patch متنی لازم است، ابتدا نسخه V234 را استخراج و از کل پوشه نسخه پشتیبان بگیرید؛ سپس از ریشه پروژه (جایی که `settings.gradle.kts` قرار دارد) اجرا کنید:

```bash
patch -p1 --dry-run < Qoqnus_Android_V235_Source_Patch.diff
patch -p1 < Qoqnus_Android_V235_Source_Patch.diff
```

- فایل patch شامل تغییرات متنی و اسناد V235 است؛ فایل باینری APK نیست.
- patch فقط برای همان baseline V234 و فایل‌های بدون تغییر محلی طراحی شده است. روی سورس متفاوت یا ویرایش‌شده، ابتدا diff و تعارض‌ها را بررسی کنید.
- بعد از اعمال، `node tests/test-v235-stability-sync-settings.cjs` و تمام تست‌های `tests/*.cjs` را اجرا کنید.
- ساخت Release APK به JDK 17، Android SDK، Gradle/AGP سازگار و کلید امضای انتشار همان نصب قبلی نیاز دارد.
