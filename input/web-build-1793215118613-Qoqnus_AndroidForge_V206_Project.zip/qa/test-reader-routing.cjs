'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const sourcePath = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'app.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const start = source.indexOf('function normalizeDivarDetailUrl');
const end = source.indexOf('function stopReaderLaunchWatchdog');
assert(start >= 0 && end > start, 'Reader route helper block must exist.');
const helpers = source.slice(start, end);
const sandbox = {
  URL,
  encodeURIComponent,
  Set,
  normalizeText: value => String(value ?? '').toLocaleLowerCase('fa-IR').replace(/[\u064a]/g, 'ی').replace(/[\u0643]/g, 'ک').trim(),
};
vm.createContext(sandbox);
vm.runInContext(helpers, sandbox);
const cases = [
  ['direct url', { url: 'https://divar.ir/v/apt-sale-abc123' }, 'apt-sale-abc123'],
  ['divarUrl alias', { divarUrl: 'https://divar.ir/v/slug-title/ID_123' }, 'ID_123'],
  ['snake-case URL', { divar_url: 'https://www.divar.ir/v/ONLYID' }, 'ONLYID'],
  ['nested URL', { metadata: { source: { href: 'https://divar.ir/v/nested-id-9' } } }, 'nested-id-9'],
  ['URL in description', { description: 'مشاهده آگهی: https://divar.ir/v/desc-id-8' }, 'desc-id-8'],
  ['explicit Divar id fallback', { id: 'divar:explicit_123' }, 'explicit_123'],
  ['explicit divarId fallback', { divarId: 'post_123', source: 'divar' }, 'post_123'],
];
for (const [label, record, expectedId] of cases) {
  const link = sandbox.divarLinkFromRecord(record);
  assert.ok(link, `${label}: link should resolve`);
  assert.equal(link.id, expectedId, `${label}: canonical ID`);
  assert.equal(sandbox.isDivarRecord(record, link), true, `${label}: should be classed as Divar`);
}
assert.equal(sandbox.divarLinkFromRecord({ url: 'https://example.com/v/not-divar' }), null, 'non-Divar host must not be accepted');
assert.equal(sandbox.isDivarRecord({ title: 'فایل مسکونی', source: 'manual-office-file' }), false, 'ordinary office file must remain a publishable office file');
assert.equal(sandbox.isDivarRecord({ sourceLabel: 'خوانشگر همراه ققنوس' }), true, 'reader-origin record must offer the read action even if its URL is missing');
const slug = sandbox.normalizeDivarDetailUrl('https://www.divar.ir/v/beautiful-villa/ABC_123?ref=share');
assert.deepEqual(JSON.parse(JSON.stringify(slug)), { id: 'ABC_123', url: 'https://divar.ir/v/beautiful-villa/ABC_123' });
// Integration guards for the office-file read flow: keep the source office-file ID all the way into Android.
assert.match(source, /async function readDivarIntoExistingRecord\(id,url,button,targetOfficeFileId=''/, 'reader launch must accept the office file ID');
assert.match(source, /recordId:String\(targetOfficeFileId\|\|id\|\|''\)/, 'Android bridge must receive the office-file ID when provided');
assert.match(source, /readDivarIntoExistingRecord\(id,link.url,readerButton,String\(fileId\)\)/, 'office-file read must preserve the target file ID');
assert.match(source, /targetOfficeFileId:String\(fileId\)/, 'link-only row must be attached to the source office file');
assert.match(source, /isImportedSource\)\{primaryAction=addButton\(r.readerState/, 'recognized Divar file card must use read/reread action instead of publish');
assert.doesNotMatch(source, /data-menu-view=[\"']shares[\"']|data-view=[\"']shares[\"']|view-shares/, 'standalone Shares page must not be restored');
console.log(`PASS: ${cases.length + 9} reader-routing and integration checks`);
