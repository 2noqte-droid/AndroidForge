'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const webCandidates = [process.env.QOQNUS_WEB_ASSETS_DIR, path.join(root, '..', 'web', 'public', 'mobile-app-apk')].filter(Boolean);
const web = webCandidates.find((candidate) => fs.existsSync(path.join(candidate, 'app.js'))) || null;
const asset = path.join(root, 'app', 'src', 'main', 'assets');
const read = (p) => fs.readFileSync(p, 'utf8');
const js = read(path.join(asset, 'app.js'));
const sw = read(path.join(asset, 'sw.js'));
const html = read(path.join(asset, 'index.html'));
const css = read(path.join(asset, 'app.css'));
const manifest = JSON.parse(read(path.join(asset, 'manifest.webmanifest')));
const build = read(path.join(root, 'app', 'build.gradle.kts'));
const mainActivity = read(path.join(root, 'app', 'src', 'main', 'java', 'ir', 'qoqnus', 'divarreader', 'MainActivity.kt'));
assert.match(js, /const APP_VERSION='V202'/, 'APP_VERSION must be V202');
assert.match(sw, /qoqnus-mobile-pwa-v202-ui-call-cache-fix/, 'Service Worker cache must be bumped');
assert.match(sw, /url\.pathname\.startsWith\(new URL\(self\.registration\.scope\)\.pathname\)/, 'runtime caching must follow actual app scope');
assert.doesNotMatch(sw, /url\.pathname\.includes\('\/mobile-app\/'\)/, 'hard-coded legacy cache path must be gone');
assert.match(html, /app\.js\?v=202-ui-call-cache-fix/, 'HTML must load versioned JS');
assert.match(html, /app\.css\?v=202-ui-call-cache-fix/, 'HTML must load versioned CSS');
assert.match(html, /qoqnus-build" content="V202-ui-call-cache-fix/, 'HTML build marker must be current');
assert.match(manifest.start_url, /V202-ui-call-cache-fix/, 'PWA start URL must bust old cache');
assert.match(manifest.share_target.action, /V202-ui-call-cache-fix/, 'Share Target must use current build marker');
assert.match(build, /versionCode\s*=\s*13/, 'Android versionCode must increment');
assert.match(build, /versionName\s*=\s*"2\.0\.7"/, 'Android versionName must increment');
assert.match(mainActivity, /index\.html\?build=V202-ui-call-cache-fix/, 'native wrapper must request current web build');
assert.match(js, /qoqnus-listing-summary-four-fields/, 'listing summary has dedicated compact four-field class');
assert.match(js, /inlineFactsLine\(\[title,roomText,locationText,shortDisplayMoney\(summary\.price\)\]/, 'listing summary must show title, rooms, location, price');
assert.doesNotMatch(js.slice(js.indexOf('qoqnus-listing-summary-four-fields'), js.indexOf('summaryBody.append(content)', js.indexOf('qoqnus-listing-summary-four-fields'))), /compactFeatureList/, 'feature list must not leak into compact listing summary');
assert.match(js, /انتشار از ربات مرکزی/ , 'central publish label must exist');
assert.match(js, /actions\.append\(publishButton\)/, 'central publish must be an action on listing cards');
assert.match(js, /const call=createCallControl\(r,'تماس با مالک'\)/, 'office-file call must inspect full record');
assert.match(js, /ownerPhoneNumber.*owner_phone_number/, 'phone variants must be recognized');
assert.match(js, /qoqnus-divar-source-card/, 'Divar-source files have a separate class');
assert.match(js, /qoqnus-office-sale-card/, 'manual sale files get green class');
assert.match(js, /qoqnus-office-rent-card/, 'manual rent files get yellow class');
if (web) {
  for (const name of ['app.js','app.css','sw.js','index.html','manifest.webmanifest','qoqnus-divar-data-normalizer.js','peer-protocol.js','qoqnus-divar-reader.js']) {
    assert.equal(fs.readFileSync(path.join(asset,name)).equals(fs.readFileSync(path.join(web,name))), true, `${name} native/web mirror must match`);
  }
  console.log('PASS: V202 version, cache path, listing summary, central publish, phone fields, semantic colors, manifest and Android/web asset parity');
} else {
  console.log('PASS: V202 version, cache path, listing summary, central publish, phone fields, semantic colors and manifest; set QOQNUS_WEB_ASSETS_DIR to also compare web assets');
}
