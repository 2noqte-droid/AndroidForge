# راهنمای ساخت APK ققنوس V206 در AndroidForge

## علت خطای قبلی
لاگ‌های قبلی نشان می‌دهند AndroidForge فرمان Gradle را در مسیر `workspace/mobile-app` اجرا کرده، اما آن پوشه در زمان ساخت هیچ فایل `settings.gradle(.kts)` یا `build.gradle(.kts)` نداشته است. این خطا پیش از کامپایل کد رخ می‌دهد و به معنی خطای Kotlin یا Android SDK نیست.

## بستهٔ درست
این ZIP باید به‌عنوان **پروژهٔ اندروید/Android source project** بارگذاری شود، نه به‌عنوان بستهٔ وب/PWA. پس از استخراج، ریشهٔ پروژه باید مستقیماً این موارد را داشته باشد:
- `settings.gradle.kts`
- `build.gradle.kts`
- `gradle.properties`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt`

اگر این فایل‌ها داخل یک زیرپوشه مثل `Qoqnus_Android_Source_V206_Selected_Sync/` یا `android/` قرار گرفته‌اند، همان زیرپوشه را به‌عنوان ریشهٔ پروژه انتخاب کنید یا محتویات آن را مستقیم در ریشهٔ `workspace/mobile-app` استخراج کنید.

## مراحل ساخت
1. پروژهٔ قبلی/نیمه‌استخراج‌شده را در AndroidForge بازنشانی کنید؛ سورس وب موبایل را به جای سورس اندروید بارگذاری نکنید.
2. ZIP حاضر را به‌عنوان پروژهٔ Android/Gradle وارد کنید.
3. بررسی کنید فایل `settings.gradle.kts` در ریشهٔ واقعی پروژه دیده شود.
4. Gradle Sync را اجرا کنید.
5. ابتدا `gradle tasks` یا مرحلهٔ Sync را اجرا کنید؛ سپس `gradle assembleDebug`.
6. اگر ساخت موفق بود، خروجی معمولاً در `app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.
7. APK را روی گوشی آزمایشی نصب کرده و موارد فایل `TEST_PLAN_FA.md` را اجرا کنید.

## مشخصات پروژه
- `applicationId`: `ir.qoqnus.divarreader`
- `compileSdk`: 34
- `minSdk`: 26
- `targetSdk`: 34
- `versionCode`: 17
- `versionName`: 2.1.1

## محدودیت
این بسته سورس Gradle است، نه APK آماده. این اصلاح بسته‌بندی به‌تنهایی ادعا نمی‌کند APK در AndroidForge ساخته یا روی گوشی آزمایش شده است. اگر خطا ادامه داشت، ZIP لاگ جدید را بفرستید.
