# یادداشت خطای ساخت قبلی — V206

لاگ AndroidForge برای هر دو فرمان `gradle assembleDebug` و `gradle bundleDebug` این خطا را ثبت کرده است:

`Directory '.../workspace/mobile-app' does not contain a Gradle build.`

علت مستقیم: در پوشه‌ای که AndroidForge به عنوان current working directory انتخاب کرده، فایل ریشهٔ Gradle (`settings.gradle` یا `settings.gradle.kts` و فایل build متناظر) وجود نداشته است. خطا پیش از مرحلهٔ کامپایل رخ داده؛ بنابراین این لاگ هنوز هیچ اشکال Kotlin/Android runtime را ثابت نمی‌کند.

راهکار: بستهٔ `Qoqnus_AndroidForge_V206_Project.zip` را به‌عنوان **Android source project** وارد کنید و مطمئن شوید فایل‌های Gradle در خود ریشهٔ `workspace/mobile-app` قرار گرفته‌اند، نه در زیرپوشه. از بستهٔ `Qoqnus_Mobile_Web_Assets...zip` برای AndroidForge استفاده نکنید.
