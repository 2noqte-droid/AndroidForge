plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.qoqnus.divarreader"
    compileSdk = 34
    defaultConfig {
        applicationId = "ir.qoqnus.divarreader"
        minSdk = 26
        targetSdk = 34
        versionCode = 17
        versionName = "2.1.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
