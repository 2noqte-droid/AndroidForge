# ققنوس Android V206 — پروژهٔ آمادهٔ ورود به AndroidForge

این بسته یک پروژهٔ کامل Gradle برای برنامهٔ اندروید ققنوس است؛ APK کامپایل‌شده در آن قرار ندارد.

## ساختار ریشه
فایل‌های `settings.gradle.kts`، `build.gradle.kts` و `gradle.properties` در ریشه و `app/build.gradle.kts` در ماژول برنامه قرار دارند. AndroidForge باید همین ریشه را به‌عنوان پروژهٔ Gradle باز کند.

## ساخت
در AndroidForge بسته را در حالت Android/Gradle source project وارد کنید، سپس Gradle Sync و `gradle assembleDebug` را اجرا کنید. اگر گزارش گفت ریشهٔ Gradle یافت نشد، فایل‌های پروژه احتمالاً یک سطح پایین‌تر استخراج شده‌اند؛ زیرپوشه‌ای را انتخاب کنید که `settings.gradle.kts` دارد.

نسخه: `versionCode=17`, `versionName=2.1.1`, `applicationId=ir.qoqnus.divarreader`.

محدودیت آزمون: در محیط آماده‌سازی این بسته، Android SDK/Gradle قابل اجرا نبود؛ موفقیت ساخت APK و آزمون روی گوشی تأیید نشده است. گزارش لاگ قبلی در `BUILD_FAILURE_NOTES_FA.md` است.
