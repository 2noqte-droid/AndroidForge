'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const crypto = require('node:crypto').webcrypto;
const root = path.resolve(__dirname, '../..');
const context = {
  crypto, TextEncoder, TextDecoder, Uint8Array, Set, Map, Date,
  btoa: value => Buffer.from(value, 'binary').toString('base64'),
  atob: value => Buffer.from(value, 'base64').toString('binary')
};
context.self = context;
context.globalThis = context;
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root, 'app/src/main/assets/qoqnus-backup-core.js'), 'utf8'), context);

(async () => {
  const sample = [
    { kind: 'listing', id: 'listing-001', updatedAt: 100 },
    { kind: 'customer', id: 'customer-001', updatedAt: 200 },
    { kind: 'file', id: 'file-001', updatedAt: 300 },
    { kind: 'tombstone', id: 'tombstone-001', updatedAt: 400 }
  ];
  const backup = await context.QoqnusBackupCore.createExtensionCompatibleBackup({
    records: sample,
    appVersion: 'V235',
    decryptRecord: async row => ({
      id: row.id,
      kind: row.kind,
      title: row.id,
      ownerDeviceId: 'must-not-export',
      deviceId: 'must-not-export',
      deviceToken: 'must-not-export',
      token: 'must-not-export',
      imageDataUrls: []
    })
  });
  assert.equal(backup.schema, 'divar-to-rubika-full-backup');
  assert.equal(backup.schemaVersion, 1);
  assert.ok(Array.isArray(backup.data.queue));
  assert.ok(Array.isArray(backup.data.qoqnusCustomers));
  assert.ok(Array.isArray(backup.data.qoqnusOfficeFiles));
  assert.equal(backup.data.queue.length, 1);
  assert.equal(backup.data.qoqnusCustomers.length, 1);
  assert.equal(backup.data.qoqnusOfficeFiles.length, 1);
  const serialized = JSON.stringify(backup);
  for (const secret of ['must-not-export', 'deviceToken', 'ownerDeviceId']) assert.ok(!serialized.includes(secret));
  const verified = await context.QoqnusBackupCore.verifyBackupDocument(backup);
  assert.equal(verified.records.length, 3);
  assert.equal(Array.from(verified.records, x => x.kind).sort().join(','), 'customer,file,listing');
  assert.ok(verified.records.every(x => x.legacyPlainRecord && x.legacyPlainRecord.id));

  const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
  const sendStart = app.indexOf('async function centralSendChanges()');
  const sendEnd = app.indexOf('async function centralDownloadPendingImages', sendStart);
  const sendBlock = app.slice(sendStart, sendEnd);
  const reserve = sendBlock.indexOf("centralApi('reserve_record_ids'");
  const titles = sendBlock.indexOf("centralApi('save_record_titles'");
  const data = sendBlock.indexOf("centralApi('save_record_data'");
  const queue = sendBlock.indexOf('centralQueueOutgoingImages(task');
  const images = sendBlock.indexOf('centralDrainOutgoingImages(cfg,2)', queue);
  assert.ok(sendStart >= 0 && reserve >= 0 && titles > reserve && data > titles && queue > data && images > queue, 'outgoing phases must match Chrome: IDs -> compact titles -> full data -> durable image queue');
  assert.match(app, /qoqnusCentralImageOutboxV1/, 'image queue must be durable and independently retryable');
  assert.ok(!app.includes("new URL('../mobile-peer.php'"), 'legacy PHP sync endpoint must not be called');
  assert.ok(!app.includes('durableQueueTick('), 'legacy polling loop must be removed');
  assert.ok(!app.includes('mobile-peer.php'), 'legacy PHP peer endpoint must be removed');
  const extDir = '/mnt/data/qoqnus_ext171_review/Qoqnus_Chrome_Extension_4.5.171';
  if (fs.existsSync(path.join(extDir, 'dashboard.js')) && fs.existsSync(path.join(extDir, 'background.js'))) {
    const dashboard = fs.readFileSync(path.join(extDir, 'dashboard.js'), 'utf8');
    const background = fs.readFileSync(path.join(extDir, 'background.js'), 'utf8');
    assert.ok(dashboard.includes('qoqnusPortableBackupData(rawData)'));
    assert.ok(background.includes('qoqnusPortableBackupData(rawData)'));
    const restoreStart = dashboard.indexOf('if(dashRestoreBtn)dashRestoreBtn.addEventListener');
    const restoreEnd = dashboard.indexOf('// Import report-channel posts', restoreStart);
    assert.ok(restoreStart >= 0 && !dashboard.slice(restoreStart, restoreEnd).includes('chrome.storage.local.clear()'), 'extension restore must preserve local device configuration');
    console.log('PASS: shared backup roundtrip, private-field exclusion, mobile import normalization, central sync phase order, and extension restore.');
  } else {
    console.log('PASS (mobile portion): shared backup roundtrip, private-field exclusion, mobile import normalization and central sync phase order. Extension source not present in this package; cross-app restore check deferred.');
  }
})().catch(error => { console.error(error); process.exit(1); });
