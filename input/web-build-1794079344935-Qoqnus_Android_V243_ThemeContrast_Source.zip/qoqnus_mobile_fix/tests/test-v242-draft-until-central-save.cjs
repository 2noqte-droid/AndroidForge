'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '../app/src/main/assets');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'app.css'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
const build = fs.readFileSync(path.resolve(__dirname, '../app/build.gradle.kts'), 'utf8');

// Local writes without a central ID must start as drafts; archived/published rows remain protected.
const store = app.slice(app.indexOf('function storeRecord('), app.indexOf('async function readRow('));
assert.match(store, /if\(SYNCABLE_RECORD_KINDS\.has\(String\(kind\)\)&&!record\.centralId\).*centralStatus:'draft',syncStatus:'draft'/);
assert.match(store, /String\(kind\)==='listing'&&!record\.centralId/);
assert.match(store, /status:'draft',centralDraftAt/);
assert.match(store, /\['published','archived','approved'\]\.includes\(existingStatus\)/);

// Older local listings with no ShitaChi ID are migrated to draft on first render.
assert.match(app, /async function ensureLegacyListingsAreDrafts\(\)/);
assert.match(app, /await ensureLegacyListingsAreDrafts\(\);\s*let rows=\(await recordsOf\('listing'\)\)/);

// ShitaChi must receive "saved", while the phone stays in draft until full JSON is accepted.
const prepare = app.slice(app.indexOf('async function centralPrepareRecord('), app.indexOf('async function centralQueueOutgoingImages('));
assert.match(prepare, /if\(kind==='listing'&&String\(record\.status\|\|''\)\.toLowerCase\(\)==='draft'\)cleanRecord\.status='saved'/);
const send = app.slice(app.indexOf('async function centralSendChanges()'), app.indexOf('async function centralReadList('));
const dataCall = send.indexOf("centralApi('save_record_data'");
const dataAcceptance = send.indexOf('rows.some(x=>!x.ok)', dataCall);
const localSave = send.indexOf("local.status='saved'", dataCall);
assert.ok(dataCall >= 0 && dataAcceptance > dataCall && localSave > dataAcceptance,
  'local draft release must occur only after the full save_record_data batch is accepted');
assert.match(send, /task\.kind==='listing'&&String\(local\.status\|\|''\)\.toLowerCase\(\)==='draft'/);
assert.match(send, /centralStamp\(local\.updatedAt\)===centralStamp\(task\.record\.updatedAt\)/);

// The UI identifies and filters drafts separately from centrally saved ads.
const statusMatch = app.match(/function listingStatus\(r\)\{[^\n]+/);
assert.ok(statusMatch, 'listingStatus helper should exist');
const listingStatus = vm.runInNewContext(statusMatch[0] + '; listingStatus');
assert.equal(listingStatus({ status: 'draft' }), 'draft');
assert.equal(listingStatus({ status: 'saved' }), 'saved');
assert.equal(listingStatus({ status: 'published' }), 'published');
assert.equal(listingStatus({ status: 'archived' }), 'archived');
assert.match(html, /<option value="draft">پیش‌نویس/);
assert.match(html, /qoqnus-build" content="V243-theme-contrast/);
assert.match(css, /\.qoqnus-listing-status-draft/);
assert.match(sw, /qoqnus-mobile-v243-theme-contrast/);
assert.match(build, /versionCode = 53/);
assert.match(build, /versionName = "2\.0\.47"/);
console.log('PASS V242: new/legacy unsynced listings remain drafts; ShitaChi receives saved state; local draft changes to saved only after server ID and full JSON acknowledgement; draft badge/filter and cache/build versions updated.');
