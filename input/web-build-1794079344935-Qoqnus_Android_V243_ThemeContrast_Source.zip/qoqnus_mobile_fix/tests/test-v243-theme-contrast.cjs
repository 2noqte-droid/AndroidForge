'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'app/src/main/assets/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'app/src/main/assets/sw.js'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');

function luminance(hex) {
  const channels = hex.replace('#', '').match(/../g).map(v => parseInt(v, 16) / 255);
  const rgb = channels.map(v => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}
function contrast(foreground, background) {
  const [hi, lo] = [luminance(foreground), luminance(background)].sort((a, b) => b - a);
  return (hi + 0.05) / (lo + 0.05);
}

// Theme-specific customer identity chips must override legacy dark-only .tag !important rules.
for (const selector of [
  'html[data-theme="dark"] body .qoqnus-customer-card .tag.qoqnus-customer-buyer',
  'html[data-theme="light"] body .qoqnus-customer-card .tag.qoqnus-customer-buyer',
  'html[data-theme="dark"] body .qoqnus-customer-card .tag.qoqnus-customer-tenant',
  'html[data-theme="light"] body .qoqnus-customer-card .tag.qoqnus-customer-tenant',
  'html[data-theme="dark"] body .qoqnus-customer-card .tag.qoqnus-customer-closed',
  'html[data-theme="light"] body .qoqnus-customer-card .tag.qoqnus-customer-closed',
]) assert.ok(css.includes(selector), `missing theme-safe badge selector: ${selector}`);
assert.match(css, /html\[data-theme="dark"\] body \.qoqnus-customer-card \.qoqnus-customer-name\{\s*color:#f8fafc!important/);
assert.match(css, /html\[data-theme="light"\] body \.qoqnus-customer-card \.qoqnus-customer-name\{\s*color:#17365d!important/);

// Notification cards and their text/buttons must use theme tokens, not hard-coded legacy colors.
assert.match(css, /html\[data-theme\] body \.notification-panel-content \.notification-card\{[\s\S]*?background:var\(--surface\)!important;color:var\(--text-primary\)!important/);
assert.match(css, /html\[data-theme\] body \.notification-panel-content \.notification-card p\{\s*color:var\(--text-secondary\)!important/);
assert.match(css, /html\[data-theme="dark"\] body \.notification-panel-content \.notification-card p\{\s*color:#d1d5db!important/);
assert.match(css, /html\[data-theme="light"\] body \.notification-panel-content \.notification-card p\{\s*color:#334155!important/);
assert.match(css, /notification-card \.notification-actions button/);

// Representative foreground/background pairs meet WCAG AA for normal text.
for (const [fg, bg] of [
  ['#dbeafe', '#1e3a5f'], ['#1555a5', '#e9f2ff'],
  ['#f8d98f', '#463718'], ['#8b5b00', '#fff4d8'],
  ['#a7f3d0', '#173a2a'], ['#137548', '#e0f8e9'],
  ['#f8fafc', '#22252b'], ['#d1d5db', '#22252b'],
  ['#202733', '#ffffff'], ['#334155', '#ffffff']
]) assert.ok(contrast(fg, bg) >= 4.5, `${fg} on ${bg} has insufficient contrast: ${contrast(fg, bg).toFixed(2)}`);

// New cache keys ensure the corrected stylesheet is actually fetched after release.
assert.match(html, /qoqnus-build" content="V243-theme-contrast/);
assert.match(html, /app\.css\?v=243-theme-contrast/);
assert.match(sw, /qoqnus-mobile-v243-theme-contrast/);
assert.match(gradle, /versionCode\s*=\s*53/);
assert.match(gradle, /versionName\s*=\s*"2\.0\.47"/);
console.log('PASS V243: customer badges/names, notification card surfaces/text/actions, AA contrast pairs, and theme cache/version identity.');
