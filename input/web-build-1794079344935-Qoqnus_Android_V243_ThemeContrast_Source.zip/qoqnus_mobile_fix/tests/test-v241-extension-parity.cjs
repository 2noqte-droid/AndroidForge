const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const mobile=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/app.js'),'utf8');
const ext=fs.readFileSync(process.env.QOQNUS_EXTENSION_SYNC||path.resolve(__dirname,'../../extension/qoqnus-central-record-sync.js'),'utf8');
const serverPath=process.env.QOQNUS_SHITACHI_CODE||'/mnt/data/qoqnus_compare/server/Qoqnus_ShitaChi_Patched/Code.gs';
const server=fs.readFileSync(serverPath,'utf8');
const manifestPath=path.join(path.dirname(serverPath),'appsscript.json');
const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
const send=mobile.slice(mobile.indexOf('async function centralSendChanges()'),mobile.indexOf('async function centralReadList'));
const phases=[
 send.indexOf("centralApi('reserve_record_ids'"),
 send.indexOf("centralApi('save_record_titles'"),
 send.indexOf("centralApi('save_record_data'"),
 send.indexOf('centralQueueOutgoingImages(task'),
 send.indexOf('centralDrainOutgoingImages(cfg,2)',send.indexOf('centralQueueOutgoingImages(task'))
];
assert.ok(phases.every((x,i)=>x>=0&&(i===0||x>phases[i-1])),'mobile outgoing phase order must match extension');
assert.match(mobile,/qoqnusCentralImageOutboxV1/);
assert.match(mobile,/nextAttemptAt/);
assert.match(mobile,/Math\.min\(6\*60\*60\*1000,30000\*Math\.pow\(2/);
assert.match(mobile,/\.slice\(0,2\)/);
assert.match(ext,/const MAX_IMAGE_EDGE = 500/);
assert.match(ext,/const MAX_IMAGE_BYTES = 400 \* 1024/);
assert.match(ext,/const qualities = \[0\.84, 0\.76, 0\.68, 0\.60, 0\.52, 0\.44, 0\.36, 0\.30\]/);
assert.match(ext,/for \(let pass = 0; pass < 7; pass\+\+\)/);
assert.match(server,/case 'save_record_titles':\s*result\s*=\s*qoqnusSaveRecordTitlesV16_/);
assert.match(server,/case 'save_record_data':\s*result\s*=\s*qoqnusSaveRecordDataV16_/);
assert.match(server,/MAX_IMAGE_BYTES:\s*409600/);
assert.match(server,/recovered:\s*true/);
assert.equal(manifest.timeZone,'Asia/Tehran');
assert.equal(manifest.webapp.access,'ANYONE_ANONYMOUS');
assert.match(server,/dimensions\.width > 500 \|\| dimensions\.height > 500/);
console.log('PASS V241 parity: Chrome ID→titles→data→image queue, mobile durable/retry queue, shared 400KiB/500px WebP contract and ShitaChi endpoints.');
