'use strict';
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const tests = [
  'test-v243-theme-contrast.cjs',
  'test-v242-draft-until-central-save.cjs',
  'test-v237-ui-runtime-and-central-sync.cjs',
  'test-v237-ui-design.cjs',
  'test-v238-deleted-manifest-ack.cjs',
  'test-v239-delete-idempotency.cjs',
  'test-v239-transfer-limits.cjs',
  'test-v240-image-and-transfer-contract.cjs',
  'test-v239-assets-and-listeners.cjs',
  'test-v239-consumer-wiring.cjs',
  '../test-artifacts/v237/central-backup-roundtrip.test.js',
  'test-v232-period-filter.cjs',
  'test-v232-time-grouping.cjs'
];
let failures = 0;
for (const test of tests) {
  const result = spawnSync(process.execPath, [path.join(__dirname, test)], { encoding: 'utf8' });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) { failures++; process.stderr.write(`FAIL release test: ${test}\n`); }
}
if (failures) process.exitCode = 1;
else console.log(`QOQNUS V240 RELEASE TESTS: ${tests.length}/${tests.length} PASS`);
