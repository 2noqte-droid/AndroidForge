ققنوس V241 — بسته تطبیق معماری موبایل با افزونه کروم

فایل‌ها:
- Android_V241_Source.zip: سورس اندروید با فایل‌های Gradle در ریشه، مناسب ورود به Android Studio/AndroidForge
- Chrome_Extension_V4.5.171.zip: افزونه مرجع با قرارداد تصویر 400KiB
- ShitaChi_V160_Source.zip: کد Apps Script و appsscript.json
- REPORT_V241_EXTENSION_PARITY_FA.md: گزارش تغییرات و آزمون‌ها

معماری خروجی موبایل مطابق افزونه:
1) reserve_record_ids — رزرو و تأیید شناسه‌های مرکزی
2) save_record_titles — ثبت عنوان و زیرعنوان فشرده
3) save_record_data — ثبت و تأیید JSON کامل رکورد
4) صف مستقل تصاویر WebP — حداکثر دو تصویر در هر اجرای دستی، uploadKey پایدار و retry با backoff

معماری ورودی:
1) check_ids
2) get_record_titles
3) انتخاب شناسه توسط مدیر
4) fetch_selected_records
5) staging محلی و تصمیم مدیر
6) دریافت تصاویر پس از پذیرش رکورد

قرارداد تصویر مشترک:
- WebP
- ضلع بزرگ حداکثر 500px
- حفظ نسبت تصویر؛ بدون برش مربع یا کشیدگی
- حداکثر 409600 بایت (400 KiB)

نکته ساخت:
APK در این محیط ساخته نشده است. سورس AndroidForge آماده است، اما Build واقعی و تست روی دستگاه باید در AndroidForge/Android Studio انجام شود.

Manifest شیتاچی در این بسته از نظر JSON اصلاح شده و تنظیم دسترسی Web App حفظ شده است.

نکته انتشار:
بسته شیتاچی سورس است؛ برای اعمال تغییرات روی سرویس زنده باید در Apps Script جایگزین، ذخیره و به‌صورت New version منتشر شود. از جدول Devices یا داده‌های موجود چیزی پاک نکنید.
