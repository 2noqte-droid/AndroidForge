(function(root){
 'use strict';
 const CHUNK=6000, MAX_BYTES=80*1024*1024;
 const hex=bytes=>Array.from(new Uint8Array(bytes)).map(b=>b.toString(16).padStart(2,'0')).join('');
 async function sha256(bytes){return hex(await crypto.subtle.digest('SHA-256',bytes));}
 function randomId(){const b=new Uint8Array(16);crypto.getRandomValues(b);return Array.from(b).map(x=>x.toString(16).padStart(2,'0')).join('');}
 function validateImageDataUrl(value,maxBytes=3*1024*1024){
   const s=String(value||'');const m=/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(s);if(!m)throw new Error('رسانه فقط باید تصویر JPEG، PNG یا WebP معتبر باشد.');
   const mime='image/'+(m[1].toLowerCase()==='jpg'?'jpeg':m[1].toLowerCase()),base64=m[2];if(base64.length%4!==0)throw new Error('رمزگذاری Base64 تصویر معتبر نیست.');
   let bytes=Math.floor(base64.length*3/4)-(base64.endsWith('==')?2:(base64.endsWith('=')?1:0));if(bytes<1||bytes>maxBytes)throw new Error('حجم هر تصویر باید حداکثر ۳ مگابایت باشد.');
   return {mime,base64,bytes,dataUrl:s};
 }
 async function mediaFingerprint(kind,id,index,dataUrl){return sha256(new TextEncoder().encode(String(kind)+'\u0000'+String(id)+'\u0000'+String(index)+'\u0000'+String(dataUrl)));}
 function normalizeTombstone(value){if(!value||typeof value!=='object')return null;const kind=String(value.kind||''),recordId=String(value.recordId||''),raw=Number(value.deletedAt);if(!['customer','contact','file','listing'].includes(kind)||!recordId||recordId.length>160||!Number.isFinite(raw)||raw<0)return null;return {kind,recordId,deletedAt:Math.floor(raw)};}
 async function tombstoneFingerprint(value){const normalized=normalizeTombstone(value);if(!normalized)throw new Error('حذف همگام‌سازی معتبر نیست.');return sha256(new TextEncoder().encode(JSON.stringify(normalized)));}
 async function selectTombstoneDelta(values,ackHashes={}){const latest=new Map();for(const value of Array.isArray(values)?values:[]){const t=normalizeTombstone(value);if(!t)continue;const key=t.kind+':'+t.recordId,old=latest.get(key);if(!old||t.deletedAt>old.deletedAt)latest.set(key,t);}const out=[];for(const [key,t] of latest){const fingerprint=await tombstoneFingerprint(t);if(String(ackHashes?.[key]||'')!==fingerprint)out.push({...t,fingerprint});}return out;}
 async function verifyTombstone(value){const t=normalizeTombstone(value);if(!t)return null;const expected=await tombstoneFingerprint(t),provided=String(value.fingerprint||'');if(provided&&provided!==expected)throw new Error('هش حذف همگام‌شده با محتوای آن سازگار نیست.');return {...t,fingerprint:expected};}
 async function drainMediaBatches(buildBatch,sendBatch,{maxBatches=8}={}){const limit=Math.max(1,Math.min(32,Math.floor(Number(maxBatches)||8)));let batches=0,itemsSent=0,stalled=false;while(batches<limit){const pack=await buildBatch();if(!pack||!Array.isArray(pack.items)||!pack.items.length)return {batches,itemsSent,remaining:false,stalled,limitReached:false};const accepted=Number(await sendBatch(pack));batches++;if(!Number.isFinite(accepted)||accepted!==pack.items.length){itemsSent+=Number.isFinite(accepted)?Math.max(0,Math.min(pack.items.length,accepted)):0;stalled=true;break;}itemsSent+=pack.items.length;}const remaining=await buildBatch();return {batches,itemsSent,remaining:!!(remaining&&Array.isArray(remaining.items)&&remaining.items.length),stalled,limitReached:batches>=limit};}
 function classifySyncChange({localFingerprint='',remoteFingerprint='',baseFingerprint='',collision=false,aliased=false,targetId='',remoteId=''}={}){const local=String(localFingerprint||''),incoming=String(remoteFingerprint||''),base=String(baseFingerprint||'');if(!local||!incoming||local===incoming)return 'same';if(collision||aliased)return 'conflict';if(!base)return String(targetId)===String(remoteId)?'conflict':'accept-remote';const localChanged=local!==base,remoteChanged=incoming!==base;if(localChanged&&remoteChanged)return 'conflict';if(localChanged&&!remoteChanged)return 'keep-local';return 'accept-remote';}
 function hasSyncConflict(change={}){return classifySyncChange(change)==='conflict';}
 function shouldApplyRemote(change={}){return classifySyncChange(change)==='accept-remote';}
 function bytesToBase64(bytes){let out='';for(let i=0;i<bytes.length;i+=0x8000)out+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));return btoa(out);}
 function base64ToBytes(s){const raw=atob(s);const out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
 function attach(channel,onPayload,onStatus){
   const incoming=new Map(),pending=new Map(); let closed=false;
   const status=(msg)=>{try{onStatus&&onStatus(msg);}catch{}};
   const rawSend=async obj=>{if(closed||channel.readyState!=='open')throw new Error('ارتباط مستقیم دستگاه‌ها قطع شده است.');while(channel.bufferedAmount>512*1024){await new Promise(r=>setTimeout(r,25));if(closed||channel.readyState!=='open')throw new Error('ارتباط مستقیم قطع شد.');}channel.send(JSON.stringify(obj));};
   async function sendPayload(type,payload){
     const json=JSON.stringify({type,payload}); const bytes=new TextEncoder().encode(json); if(bytes.length>MAX_BYTES)throw new Error('حجم بستهٔ انتقال بیش از ۸۰ مگابایت است؛ عکس‌های قدیمی را کم یا فشرده کنید.');
     const tid=randomId(),hash=await sha256(bytes),total=Math.ceil(bytes.length/CHUNK);
     const promise=new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(tid);reject(new Error('تأیید دریافت بسته از دستگاه مقابل نرسید. دوباره همگام‌سازی کنید.'));},120000);pending.set(tid,{resolve:()=>{clearTimeout(timer);resolve({transfer_id:tid,sha256:hash,bytes:bytes.length});},reject,hash,timer});});
     await rawSend({__qoqnus:'start',transfer_id:tid,sha256:hash,total,bytes:bytes.length});
     for(let i=0;i<total;i++){const piece=bytes.subarray(i*CHUNK,Math.min((i+1)*CHUNK,bytes.length));await rawSend({__qoqnus:'chunk',transfer_id:tid,index:i,data:bytesToBase64(piece)});}
     return promise;
   }
   async function handle(event){
     let msg;try{msg=JSON.parse(typeof event.data==='string'?event.data:'');}catch{return;}
     if(msg?.__qoqnus==='start'){
       const tid=String(msg.transfer_id||''),total=Number(msg.total),bytes=Number(msg.bytes),hash=String(msg.sha256||'');
       if(!/^[a-f0-9]{32}$/.test(tid)||!Number.isInteger(total)||total<1||total>Math.ceil(MAX_BYTES/CHUNK)||!Number.isInteger(bytes)||bytes<1||bytes>MAX_BYTES||!/^[a-f0-9]{64}$/.test(hash))return;
       incoming.set(tid,{total,bytes,hash,pieces:new Array(total),received:0});return;
     }
     if(msg?.__qoqnus==='chunk'){
       const tid=String(msg.transfer_id||''),x=incoming.get(tid),idx=Number(msg.index);if(!x||!Number.isInteger(idx)||idx<0||idx>=x.total||x.pieces[idx])return;
       try{const p=base64ToBytes(String(msg.data||''));if(p.length>CHUNK+8)return;x.pieces[idx]=p;x.received++;}catch{return;}
       if(x.received===x.total){incoming.delete(tid);const all=new Uint8Array(x.pieces.reduce((n,p)=>n+p.length,0));let off=0;for(const p of x.pieces){all.set(p,off);off+=p.length;}if(all.length!==x.bytes||await sha256(all)!==x.hash){status('صحت انتقال بسته تأیید نشد؛ انتقال دوباره لازم است.');return;}try{const value=JSON.parse(new TextDecoder().decode(all));await rawSend({__qoqnus:'ack',transfer_id:tid,sha256:x.hash});await onPayload(value.type,value.payload);}catch(err){status(String(err?.message||'پردازش بسته ناموفق بود.'));}}
       return;
     }
     if(msg?.__qoqnus==='ack'){
       const p=pending.get(String(msg.transfer_id||''));if(!p)return;pending.delete(String(msg.transfer_id));clearTimeout(p.timer);if(String(msg.sha256||'')!==p.hash){p.reject(new Error('هش رسید انتقال با بسته سازگار نیست.'));return;}p.resolve();return;
     }
     if(msg?.__qoqnus==='app'){await onPayload(String(msg.type||''),msg.payload||{});return;}
   }
   channel.addEventListener('message',e=>{handle(e).catch(err=>status(String(err?.message||err)));});
   channel.addEventListener('close',()=>{closed=true;for(const [id,p] of pending){clearTimeout(p.timer);p.reject(new Error('ارتباط بسته شد.'));}pending.clear();status('ارتباط مستقیم بسته شد.');});
   channel.addEventListener('error',()=>status('خطای ارتباط مستقیم دستگاه‌ها.'));
   return {sendPayload,sendMessage:obj=>rawSend({__qoqnus:'app',type:String(obj.type||''),payload:obj.payload||{}}),close(){closed=true;for(const p of pending.values()){clearTimeout(p.timer);p.reject(new Error('ارتباط بسته شد.'));}pending.clear();}};
 }
 root.QoqnusPeerProtocol={attach,sha256,randomId,validateImageDataUrl,mediaFingerprint,normalizeTombstone,tombstoneFingerprint,selectTombstoneDelta,verifyTombstone,classifySyncChange,hasSyncConflict,shouldApplyRemote,drainMediaBatches};
})(typeof self!=='undefined'?self:globalThis);
