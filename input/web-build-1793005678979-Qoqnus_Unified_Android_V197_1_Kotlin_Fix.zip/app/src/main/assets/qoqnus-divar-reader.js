(() => {
  'use strict';
  const clean = (v, max = 30000) => String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ').replace(/[ \t\r]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim().slice(0, max);
  const safeText = (v, max = 30000) => clean(v, max).replace(/(?:(?:\+|00)?98\s*)?0?9[\d۰-۹٠-٩\s()\-]{8,15}/gu, '[شمارهٔ تماس؛ برای ثبت شماره، آن را جداگانه و با اقدام کاربر ثبت کنید]');
  const send = (payload) => { try { if (window.qoqnusDivarBridge && typeof window.qoqnusDivarBridge.postMessage === 'function') window.qoqnusDivarBridge.postMessage(JSON.stringify(payload)); } catch (_) {} };
  const canonical = () => {
    try {
      const u = new URL(location.href);
      if (!['divar.ir', 'www.divar.ir'].includes(u.hostname.toLowerCase())) return null;
      const segments = u.pathname.split('/').filter(Boolean);
      if (segments.length < 2 || segments.length > 3 || segments[0].toLowerCase() !== 'v') return null;
      const id = decodeURIComponent(segments[segments.length - 1]);
      if (!/^[A-Za-z0-9][A-Za-z0-9_-]{2,120}$/.test(id)) return null;
      let path = '/v/' + id;
      if (segments.length === 3) {
        const slug = decodeURIComponent(segments[1]);
        if (!slug || slug.includes('/') || slug === '.' || slug === '..') return null;
        path = '/v/' + segments[1] + '/' + id;
      }
      return { id, url: 'https://divar.ir' + path };
    } catch (_) { return null; }
  };
  const jsonLdItems = () => {
    const out = [];
    for (const node of document.querySelectorAll('script[type="application/ld+json"]')) {
      if (!node.textContent || node.textContent.length > 500000) continue;
      try { const x = JSON.parse(node.textContent); const visit = v => { if (!v || typeof v !== 'object') return; if (Array.isArray(v)) return v.forEach(visit); out.push(v); if (v['@graph']) visit(v['@graph']); if (v.mainEntity) visit(v.mainEntity); }; visit(x); } catch (_) {}
    }
    return out;
  };
  const visibleText = el => {
    try { const s = getComputedStyle(el), r = el.getBoundingClientRect(); return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0 && r.width > 0 && r.height > 0; } catch (_) { return false; }
  };
  const extractRows = () => {
    const rows = {};
    for (const tr of document.querySelectorAll('tr')) {
      if (!visibleText(tr)) continue;
      const cells = [...tr.querySelectorAll('th,td')].map(x => clean(x.innerText, 200)).filter(Boolean);
      if (cells.length >= 2) rows[cells[0]] = cells.slice(1).join('، ').slice(0, 500);
    }
    for (const dl of document.querySelectorAll('dl')) {
      const children = [...dl.children];
      for (let i = 0; i < children.length - 1; i++) if (children[i].tagName === 'DT' && children[i + 1].tagName === 'DD') {
        const k = clean(children[i].innerText, 150), v = clean(children[i + 1].innerText, 500); if (k && v) rows[k] = v;
      }
    }
    return Object.fromEntries(Object.entries(rows).slice(0, 120));
  };
  const images = () => {
    const values = [];
    const add = v => { try { const u = new URL(String(v || ''), location.href); if (u.protocol === 'https:' && !values.includes(u.href) && !/\.svg(?:$|\?)/i.test(u.pathname)) values.push(u.href); } catch (_) {} };
    for (const key of ['og:image', 'twitter:image']) { const m = document.querySelector('meta[property="' + key + '"],meta[name="' + key + '"]'); if (m) add(m.content); }
    for (const img of document.querySelectorAll('main img, [role="main"] img, img')) { if (!visibleText(img)) continue; add(img.currentSrc || img.src); if (values.length >= 35) break; }
    return values.slice(0, 35);
  };
  const structured = () => {
    const all = jsonLdItems();
    const choose = pred => all.find(pred) || {};
    const item = choose(x => /Product|Offer|RealEstateListing|Residence|House|Apartment/.test(String(x['@type'] || '')));
    const offer = item.offers && (Array.isArray(item.offers) ? item.offers[0] : item.offers) || choose(x => /Offer/.test(String(x['@type'] || '')));
    const address = item.address && (typeof item.address === 'string' ? item.address : [item.address.addressLocality, item.address.streetAddress, item.address.addressRegion].filter(Boolean).join('، '));
    return { item, offer: offer || {}, address: address || '' };
  };
  window.__QOQNUS_READER_READ_CURRENT__ = () => {
    const link = canonical();
    if (!link) { send({type:'QOQNUS_DIVAR_READER_ERROR', message:'این صفحه، جزئیات یک آگهی نیست. یک آگهی را باز کنید تا نشانی آن /v/شناسه باشد.'}); return; }
    const st = structured(), body = clean(document.body?.innerText || '', 60000);
    const h1 = [...document.querySelectorAll('h1')].find(visibleText);
    const meta = (key) => document.querySelector('meta[property="' + key + '"],meta[name="' + key + '"]')?.content || '';
    const title = clean(h1?.innerText || meta('og:title') || st.item.name || st.item.headline || document.title.replace(/\s*[|—-]\s*دیوار\s*$/u,''), 240) || ('آگهی ' + link.id);
    const description = clean(meta('description') || st.item.description || '', 8000);
    const rows = extractRows();
    const usefulBody = body.replace(/(?:دسته‌ها|من|چت|تماس|پشتیبانی|گزارش آگهی|ثبت آگهی)/g,' ').trim();
    if ((!title || /^آگهی\s+[A-Za-z0-9_-]+$/u.test(title)) && usefulBody.length < 160 && !Object.keys(rows).length) { send({type:'QOQNUS_DIVAR_READER_ERROR', message:'اطلاعات قابل‌خواندن از این صفحه دریافت نشد. صفحه را کامل باز کن و دوباره تلاش کن.'}); return; }
    if (usefulBody.length < 80 && Object.keys(rows).length===0) { send({type:'QOQNUS_DIVAR_READER_ERROR', message:'جزئیات صفحه هنوز بارگذاری نشده است. چند لحظه صبر کن و دوباره «خواندن و ذخیره» را بزن.'}); return; }
    const lineValue = (pattern) => { const lines = body.split('\n').map(x => clean(x,500)).filter(Boolean); const re = pattern; const exact = lines.find(x => re.test(x)); if (!exact) return ''; const match = exact.match(/[:：]\s*(.+)$/u); return clean(match ? match[1] : exact.replace(re,'').trim(), 160); };
    const areaText = lineValue(/^(?:متراژ|مساحت|زیربنا|متراژ بنا|متراژ ساختمان)\s*[:：]?/u);
    const roomsText = lineValue(/^(?:تعداد خواب|خواب|اتاق)\s*[:：]?/u);
    const locationText = lineValue(/^(?:موقعیت|محل|محله|آدرس|نشانی)\s*[:：]?/u) || clean(st.address,300);
    const priceText = clean(st.offer.price || lineValue(/^(?:قیمت کل|قیمت فروش|قیمت|ودیعه|رهن|اجاره ماهانه|اجاره)\s*[:：]?/u), 180);
    const attrs = {...rows};
    const payload = {
      schema:'qoqnus.listing-reader.v1', readerState:'complete', detailReadState:'complete', mobileReaderState:'complete',
      id:'divar:' + link.id, divarId:link.id, postId:link.id, url:link.url, detailUrl:link.url, sourceUrl:link.url, canonicalUrl:link.url,
      title, text:safeText(body,30000), content:safeText(body,30000), description:safeText(description,8000), publicDescription:safeText(description,8000), detailText:safeText(Object.entries(rows).map(([k,v])=>k+': '+v).join('\n'),12000),
      location:locationText, locationText:locationText, priceText, salePrice:clean(st.offer.price || '',60), area:areaText, area_sqm:areaText, rooms:roomsText,
      attributes:attrs, facts:{location:locationText, priceText, area:areaText, rooms:roomsText}, imageUrls:images(), phones:[],
      source:'qoqnus-mobile-reader', sourceLabel:'خوانشگر همراه ققنوس', collectedFrom:'android-webview-reader', extractedAt:Date.now(), createdAt:Date.now(), updatedAt:Date.now(), status:'saved', sendStatus:'not_sent', reviewStatus:'not_required', publicationState:'not_sent'
    };
    send({type:'QOQNUS_DIVAR_READER_RESULT', payload});
  };
})();
