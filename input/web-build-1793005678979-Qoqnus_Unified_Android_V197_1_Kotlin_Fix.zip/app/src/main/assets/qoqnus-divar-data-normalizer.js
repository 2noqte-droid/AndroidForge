const norm=s=>(s||'').toLowerCase().replace(/[ي]/g,'ی').replace(/[ك]/g,'ک').replace(/\s+/g,' ').trim();
function stripSourceBrandForDisplay(value){return String(value??'')
 .replace(/https?:\/\/[^\s]+/giu,' ')
 .replace(/با\s+تشکر\s+از\s*(?:وب\s*سایت|سایت|سامانه)?\s*دیوار/giu,'با تشکر از ققنوس')
 .replace(/از\s+(?:(?:وب\s*سایت|سایت|سامانه|پلتفرم)\s+)?دیوار/giu,' ')
 .replace(/در\s+دیوار(?=\s|[،,؛:.!?؟\n]|$)/giu,' ')
 .replace(/(?:وب\s*سایت|سایت|سامانه|پلتفرم)\s+دیوار/giu,' ')
 .replace(/آگهی\s+دیوار/giu,'آگهی')
 .replace(/صفحه\s+دیوار/giu,'صفحه')
 .replace(/از\s+دیوار(?=\s*(?:[،,؛:.!?؟\n]|$))/giu,' ')
 .replace(/در\s+دیوار(?=\s*(?:[،,؛:.!?؟\n]|$))/giu,' ')
 .replace(/(?:^|\n)\s*دیوار\s*(?=\n|$)/giu,' ')
 .replace(/\bdivar(?:\.ir)?\b/giu,' ')
 .replace(/\s+([،,؛:.!?؟])/gu,'$1').replace(/[ \t]{2,}/gu,' ').replace(/█\s*ثبت آگهی رایگان\s+░░\s*مشاوره خرید و اجاره/gu,'█ ثبت آگهی رایگان  ░░ مشاوره خرید و اجاره').replace(/\n[ \t]+/gu,'\n').trim();}
const LISTING_TYPE_LABELS={rent_residential:'اجاره مسکونی',rent_shop:'اجاره مغازه و ملک تجاری',rent_land:'اجاره زمین و باغ',rent_other:'اجاره سایر املاک',sale_residential:'فروش مسکونی',sale_shop:'فروش مغازه و ملک تجاری',sale_land:'فروش زمین و باغ',sale_other:'فروش سایر املاک',unknown:'نوع نامشخص'};
const CONTACT_CATEGORY_LABELS={rent_villa:'اجاره ویلایی',rent_booth:'اجاره غرفه/دکه',rent_shop:'اجاره مغازه/تجاری',rent_office:'اجاره دفتر کار/اداری',rent_apartment:'اجاره آپارتمان/خانه',rent_land:'اجاره زمین و باغ',rent_other:'اجاره سایر املاک',sale_villa:'فروش ویلایی',sale_booth:'فروش غرفه/دکه',sale_shop:'فروش مغازه/تجاری',sale_office:'فروش دفتر کار/اداری',sale_apartment:'فروش آپارتمان/خانه',sale_land:'فروش زمین و باغ',sale_other:'فروش سایر املاک',unknown:'نیازمند بررسی'};
function classifyContactCategory(item={}){
 const cats=Array.isArray(item.categories)?item.categories.map(x=>String(x||'')):[];
 const links=Array.isArray(item.categoryLinks)?item.categoryLinks.flatMap(x=>[x?.text||'',x?.href||'']):[];
 const source=norm([item.title||item.listingTitle||'',...cats,...links,item.url||item.listingUrl||''].join(' '));
 const full=norm([source,item.description||'',item.note||'',item.detailText||'',item.text||'',item.facts?.propertyType||'',item.facts?.transactionLabel||'',item.location||''].join(' '));
 let transaction='';
 if(/(?:rent[-_/]|اجاره|رهن|ودیعه|اجاره\s*ماهانه)/i.test(source))transaction='rent';
 else if(/(?:sale[-_/]|sell[-_/]|buy[-_/]|فروش|فروشی|خرید)/i.test(source))transaction='sale';
 else if(/^rent_/.test(String(item.listingType||'')))transaction='rent';
 else if(/^sale_/.test(String(item.listingType||'')))transaction='sale';
 else if(/(?:اجاره|رهن|ودیعه|اجاره\s*ماهانه)/i.test(full))transaction='rent';
 else if(/(?:فروش|فروشی|خرید|قیمت\s*فروش)/i.test(full))transaction='sale';
 if(!transaction)return 'unknown';
 const typeSource=source+' '+full;
 let subtype='other';
 if(/(?:غرفه|غرفه‌ای|غرفه\s*ای|دکه|کانتر|booth|stall)/i.test(typeSource))subtype='booth';
 else if(/(?:مغازه|فروشگاه|واحد\s*تجاری|ملک\s*تجاری|تجاری|shop|commercial|storefront)/i.test(typeSource))subtype='shop';
 else if(/(?:دفتر\s*کار|دفتر\s*اداری|اداری|مطب|office|workspace)/i.test(typeSource))subtype='office';
 else if(/(?:باغ\s*ویلا|ویلایی|ویلا|villa)/i.test(typeSource))subtype='villa';
 else if(/(?:زمین|باغ|قطعه\s*زمین|land|garden)/i.test(typeSource))subtype='land';
 else if(/(?:آپارتمان|سوئیت|مسکونی|خانه|منزل|flat|apartment|residential)/i.test(typeSource))subtype='apartment';
 if(subtype==='other'){const legacy=String(item.listingType||'');if(/_residential$/.test(legacy))subtype='apartment';else if(/_shop$/.test(legacy))subtype='shop';else if(/_land$/.test(legacy))subtype='land';}
 return transaction+'_'+subtype;
}
function contactCategoryLabel(category){return CONTACT_CATEGORY_LABELS[category]||CONTACT_CATEGORY_LABELS.unknown;}
function classifyListingType(item={}){
 const cats=Array.isArray(item.categories)?item.categories.map(x=>String(x||'')):[];
 const links=Array.isArray(item.categoryLinks)?item.categoryLinks.flatMap(x=>[x?.text||'',x?.href||'']):[];
 // Property type is inferred from title/category/path, not from descriptive fields such as "land area".
 const source=norm([item.title||'',...cats,...links,item.url||''].join(' '));
 const full=norm([source,item.description||'',item.detailText||'',item.text||'',item.publicDescription||''].join(' '));
 let transaction='';
 if(/(?:rent[-_/]|اجاره|رهن)/i.test(source))transaction='rent';
 else if(/(?:buy[-_/]|sell[-_/]|sale[-_/]|فروش|خرید)/i.test(source))transaction='sale';
 else if(/(?:اجاره|رهن)/i.test(full))transaction='rent';
 else if(/(?:فروش|خرید)/i.test(full))transaction='sale';
 const land=/(?:زمین|باغ|قطعه زمین|land|garden)/i.test(source);
 const shop=/(?:مغازه|واحد تجاری|ملک تجاری|تجاری|دفتر کار|اداری|کارگاه|shop|commercial)/i.test(source);
 const residential=/(?:مسکونی|آپارتمان|خانه|منزل|ویلا|ویلایی|residential|villa|apartment)/i.test(source)||(!land&&!shop&&/(?:آپارتمان|خانه|منزل|ویلا|ویلایی)/i.test(full));
 if(!transaction)return 'unknown';
 if(land)return transaction+'_land';
 if(shop)return transaction+'_shop';
 if(residential)return transaction+'_residential';
 return transaction+'_other';
}
function listingTypeLabel(type){return LISTING_TYPE_LABELS[type]||LISTING_TYPE_LABELS.unknown;}

function removeAgePhrase(value){return String(value||'').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/(?:^|[\s،,])(?:امروز|دیروز|پریروز)\s*(?:در\s*)?/gi,' ').replace(/(?:^|[\s،,])(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش\s*(?:در\s*)?/gi,' ').replace(/(?:^|[\s,])(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?)\s+ago(?:\s+(?:in\s+)?)?/gi,' ').replace(/\s+/g,' ' ).replace(/^[،,؛|\s-]+|[،,؛|\s-]+$/g,'').trim();}
function renderEmojiAliases(value){const aliases={moneybag:'💰',dollar:'💵',arrows_counterclockwise:'🔄',round_pushpin:'📍',triangular_ruler:'📐',house:'🏠',bed:'🛏️',car:'🚗',package:'📦',sunny:'🌤️',memo:'📝',telephone_receiver:'📞',white_check_mark:'✅',x:'❌',evergreen_tree:'🌳',office:'🏢',house_with_garden:'🏡',money_with_wings:'💸',heavy_check_mark:'✔️'};return String(value||'').replace(/:([a-z0-9_+-]+):/gi,(m,k)=>aliases[k]||m);}
function stripCategoryBreadcrumbTail(value, categories=[]){let s=String(value||'').trim();const candidates=[...categories].map(x=>String(x||'').trim()).filter(Boolean).sort((a,b)=>b.length-a.length);for(let pass=0;pass<8;pass++){let changed=false;for(const c of candidates){const re=new RegExp('(?:\\s|^)'+c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*$','i');if(re.test(s)&&s.length>c.length+18){s=s.replace(re,'').trim();changed=true;break;}}if(changed)continue;const tail=/(?:\s|^)(?:املاک|اجاره(?:[ٔ‌ ]?)\s*(?:خانه\s*و\s*ویلا|مسکونی|آپارتمان|ویلا|زمین|باغ)|اجاره(?:[ٔ‌ ]?)\s+خانه|خرید(?:\s+و\s+فروش)?(?:\s+(?:خانه|زمین|ویلا|مسکونی|آپارتمان))?|فروش(?:\s+(?:خانه|زمین|ویلا|مسکونی|آپارتمان))?)(?:\s+در\s+[\u0600-\u06FF\s\d۰-۹٠-٩-]{2,55})?\s*$/i;const m=s.match(tail);if(m&&s.length-m[0].trimStart().length>5){s=s.slice(0,m.index).trim();continue;}break;}return s;}
function locationTags(item,url){const s=norm((item.text||'')+' '+url);const t=[];if(/نیشابور|neyshabur/.test(s))t.push('#نیشابور');if(/سراب.?کوشک|saraab-koushk/.test(s))t.push('#سراب_کوشک');if(/ویلا|villa/.test(s))t.push('#ویلا');if(/آپارتمان|apartment/.test(s))t.push('#آپارتمان');if(/اجاره|رهن|rent/.test(s))t.push('#اجاره');if(/فروش|خرید|sell|buy/.test(s))t.push('#فروش');return t;}
function classifyAgency(item){
 const name=norm(item.sellerName||'');
 const text=norm(item.text||'');
 const strongName=/(املاک|مشاور املاک|آژانس املاک|بنگاه املاک|دفتر املاک|دپارتمان املاک|مشاورین املاک|گروه املاک)/.test(name);
 const strongText=/(مشاور املاک|آژانس املاک|بنگاه املاک|دفتر املاک|مشاورین املاک|گروه املاک|دپارتمان تخصصی|برای اطلاعات بیشتر.{0,45}املاک|به املاک.{0,45}(مراجعه|تماس|زنگ|مراجعه کنید))/.test(text);
 const anyWord=/املاک/.test(text);
 if(item.sellerClass==='agency'||strongName) return {color:'red',label:'املاکی',reason:'نام یا دسته‌بندی آگهی‌دهنده نشانهٔ بنگاه دارد'};
 if(strongText||anyWord) return {color:'yellow',label:'نیازمند بررسی متن',reason:'در متن آگهی واژه یا عبارت مرتبط با املاک دیده شد'};
 return {color:'green',label:'نشانه‌ای پیدا نشد',reason:'نشانهٔ مشخصی در اطلاعات قابل‌دسترسی پیدا نشد'};
}
function stripAgeLine(line){return removeAgePhrase(String(line||'').trim());}
function asciiDigits(s){return String(s||'').replace(/[۰-۹٠-٩]/g,d=>{const fa='۰۱۲۳۴۵۶۷۸۹',ar='٠١٢٣٤٥٦٧٨٩';const f=fa.indexOf(d);return String(f>=0?f:ar.indexOf(d));});}
function persianDigits(value){return String(value||'').replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);}
function cleanListingDescription(value,categories=[]){
 let s=String(value||'').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/\u00a0/g,' ').trim();
 if(!s)return '';
 s=s.replace(/https?:\/\/\S+/gi,' ');
 // متن‌های زمان انتشار، نه مشخصات ملک، هرگز وارد پیام کانال نشوند.
 s=s.replace(/(?:^|[\n،;؛])\s*(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش\s+در\s+[^\n.!؟]*/gi,' ');
 s=s.replace(/(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش/gi,' ');
 s=s.replace(/با تشکر از\s*(?:سایت\s*)?دیوار/gi,'با تشکر از ققنوس');
 // Cut appended controls/navigation/footer text that is not part of the seller's description.
 const junk=/(?:^|\s)(?:[۰-۹0-9]{1,3}\s*)?یادداشت تنها برای شما قابل دیدن است|برو به اطلاعات تماس|دسته‌ها\s+دیوار\s+من\s+چت(?:\s+و\s+تماس)?|(?:درباره[ٔ ]*دیوار|دریافت برنامه|اتاق خبر|دیواری شو|ثبت آگهی|پشتیبانی و قو(?:ا|انین)|گزارش آگهی|تصویر\s*[۰-۹0-9]+\s*از\s*[۰-۹0-9]+)/i;
 const m=s.match(junk);if(m)s=s.slice(0,m.index).trim();
 s=s.replace(/برای هر نوع پرداخت.{0,220}?(?:پرداخت امن|پرداخت امن را انتخاب کنید)[.!، ]*/ig,' ')
  .replace(/درخواست بیعانه،? از نشانه‌های کلاهبرداری[.!، ]*/ig,' ')
  .replace(/\bسایت\s+دیوار\b/ig,' ')
  .replace(/\bصفحه\s+دیوار\b/ig,'صفحه')
  .replace(/آگهی\s+دیوار/ig,'آگهی')
  .replace(/از\s+سایت\s+دیوار/ig,' ')
  .replace(/\s+/g,' ').replace(/[ .،؛]+$/,'').trim();
 // Known platform mentions/navigation are removed without deleting literal property features such as brick walls.
 s=s.replace(/\s{2,}/g,' ').trim();
 s=stripCategoryBreadcrumbTail(s,categories);
 s=s.replace(/(?:با تشکر از\s*)?(?:سایت|وب\s*سایت|سامانه)\s+دیوار/gi,'').replace(/با تشکر از\s*دیوار/gi,'با تشکر از ققنوس');
 return renderEmojiAliases(stripSourceBrandForDisplay(s.slice(0,700)));
}
function contactDisplayDigits(){return '9 3 2 1 1 1 2 5 1 9 0';}
function contactInlineKeypad(){return {rows:[{buttons:[{id:'qoqnus-call-phone',type:'Link',button_text:`📞 تماس : ${contactDisplayDigits()}`,button_link:{type:'url',link_url:'tel:+989152111239'}}]}]};}
// Text-styled Qoqnus actions can be hidden from Settings. The call button remains the original Rubika keypad.
const QOQNUS_BOT_URL='https://rubika.ir/qoqnusBot';
const QOQNUS_LISTING_START_URL=QOQNUS_BOT_URL+'?start=channel_add_listing';
const QOQNUS_CONSULT_START_URL=QOQNUS_BOT_URL+'?start=channel_request_order';
const RUBIKA_AD_CTA_TEXT='\n█ ثبت آگهی رایگان  ░░ مشاوره خرید و اجاره\n';
function addRubikaAdCta(value,showActions=true){
  let text=String(value||'').trim();
  const footerStarts=[
    /\n?━━━━━━━━━━━━━━━━━━━━\n█ ثبت آگهی رایگان[\s\S]*$/,
    /\n?█ ثبت آگهی رایگان\s+░░\s*مشاوره خرید و اجاره(?:\s+█)?[\s\S]*$/,
    /\n?【 ثبت آگهی رایگان 】[\s\S]*$/,
    /\n?░▒▓█ تماس با ما █▓▒░[\s\S]*$/
  ];
  for(const pattern of footerStarts)text=text.replace(pattern,'').trimEnd();
  const shownNumber='۰۹۱۵۲۱۱۱۲۳۹';
  text=text.split('\n').filter(line=>!line.includes(shownNumber)&&!/^[\s]*📞[\s]*تماس[\s]*[:：]?[\s]*$/u.test(line)).join('\n').trimEnd();
  return showActions ? text+RUBIKA_AD_CTA_TEXT : text;
}
function rubikaFormattedPayload(value){
  const text=stripSourceBrandForDisplay(String(value||''));const parts=[];
  // Bold and underline the first meaningful line (the listing title), not the footer.
  const lines=text.split('\n');let heading='';let headingIndex=0;let running=0;
  for(const line of lines){const trimmed=line.trim();if(trimmed&&!/^━{3,}$/.test(trimmed)&&!/^█.*ثبت آگهی رایگان/.test(trimmed)&&!/^░▒▓█ تماس با ما/.test(trimmed)){heading=trimmed;headingIndex=running+line.indexOf(trimmed);break;}running+=line.length+1;}
  if(heading){parts.push({type:'Bold',from_index:headingIndex,length:heading.length});parts.push({type:'Underline',from_index:headingIndex,length:heading.length});}
  // Bold field labels without changing message text. This mirrors the selected Qoqnus template.
  let lineStart=0;
  for(const line of lines){
   const labelMatch=line.match(/^\s*([^:：\n]{1,40}[:：])(?=\s|$)/u);
   if(labelMatch&&/(?:قیمت کل|قیمت هر متر|رهن|اجاره|قابل تبدیل|موقعیت|خیابان|متراژ زمین|متراژ کل|متراژ ساخته.?شده|سال ساخت|تعداد اتاق|پارکینگ|انباری|بالکن|توضیحات بیشتر|دسته.?بندی|تماس)\s*[:：]/u.test(labelMatch[1])){
    const rawPrefix=line.slice(0,line.search(/\S|$/));const from=lineStart+rawPrefix.length;const text=labelMatch[1].trim();
    if(!parts.some(part=>part.type==='Bold'&&part.from_index===from&&part.length===text.length))parts.push({type:'Bold',from_index:from,length:text.length});
   }
   lineStart+=line.length+1;
  }
  const registerLabel='ثبت آگهی رایگان';const registerAt=text.lastIndexOf(registerLabel);
  if(registerAt>=0)parts.push({type:'Link',from_index:registerAt,length:registerLabel.length,link_url:QOQNUS_LISTING_START_URL});
  const consultLabel='مشاوره خرید و اجاره';const consultAt=text.lastIndexOf(consultLabel);
  if(consultAt>=0)parts.push({type:'Link',from_index:consultAt,length:consultLabel.length,link_url:QOQNUS_CONSULT_START_URL});
  const callLabel='تماس با ما';const callAt=text.lastIndexOf(callLabel);
  if(callAt>=0)parts.push({type:'Link',from_index:callAt,length:callLabel.length,link_url:'tel:+989152111239'});
  const shownNumber=contactDisplayDigits();const numberAt=text.lastIndexOf(shownNumber);
  if(numberAt>=0)parts.push({type:'Link',from_index:numberAt,length:shownNumber.length,link_url:'tel:+989152111239'});
  return {text,metadata:parts.length?{meta_data_parts:parts}:undefined,contactLinkIncluded:numberAt>=0};
}

function normalizePhoneCandidate(candidate){let d=asciiDigits(candidate).replace(/\D/g,'');if(d.startsWith('0098'))d='0'+d.slice(4);else if(d.startsWith('98')&&d.length===12)d='0'+d.slice(2);else if(d.length===10&&d.startsWith('9'))d='0'+d;return /^09\d{9}$/.test(d)?d:'';}
function listingPhoneNumbers(item={}){
 const raw=Array.isArray(item.phones)?item.phones.slice():(item.phones?[item.phones]:[]);
 for(const key of ['phone','contactPhone'])if(item[key])raw.push(item[key]);
 return [...new Set(raw.flatMap(value=>extractPhoneNumbers(String(value||''))))];
}
function listingHasPhone(item={}){return listingPhoneNumbers(item).length>0;}
function extractPhoneNumbers(text){const source=asciiDigits(text);const matches=source.match(/(?<![0-9])(?:(?:\+|00)?98[ .()\-]*)?0?9(?:[ .()\-]*[0-9]){9}(?![0-9])/g)||[];return [...new Set(matches.map(normalizePhoneCandidate).filter(Boolean))];}
function removePrivateContact(text){
 let s=String(text||'').replace(/https?:\/\/\S+/gi,'');
 // Persian and Arabic digits are converted in a same-length shadow string; match offsets
 // are therefore also valid in the original string.
 const ascii=asciiDigits(s);
 const rx=/(?<![0-9])(?:(?:\+|00)?98[ .()\-]*)?0?9(?:[ .()\-]*[0-9]){9}(?![0-9])/g;
 const ranges=[...ascii.matchAll(rx)].map(m=>[m.index,m.index+m[0].length]).sort((a,b)=>b[0]-a[0]);
 for(const [a,b] of ranges)s=s.slice(0,a)+' '+s.slice(b);
 s=s.replace(/(?:شماره\s*تماس|تماس\s*با|برای\s*تماس|تماس\s*بگیرید|زنگ\s*بزنید|تماس|شماره|تلفن)\s*[:：-]?\s*/gi,' ');
 return s.replace(/[ \t]{2,}/g,' ').trim();
}
function cleanPublicValue(value){
 return removePrivateContact(String(value||'')).replace(/^[\s:：|—-]+|[\s|—-]+$/g,'').trim();
}
function retainQueue(items,activeLimit=1500){const all=Array.isArray(items)?items:[];const archived=all.filter(x=>x.status==='archived'||x.status==='published');const active=all.filter(x=>!['archived','published'].includes(x.status)).slice(0,activeLimit);return [...active,...archived];}
function detailLines(item){
 // Keep distinct extraction sources: Divar sometimes exposes the structured price and attributes
 // outside the main visible text container.
 const sources=[item.detailText,item.text,item.publicDescription,item.priceText,...(Array.isArray(item.attributes)?item.attributes:[])];
 const out=[];const seen=new Set();
 for(const source of sources){
  if(!source)continue;
  for(const row of String(source).split(/\r?\n/)){
   const line=cleanPublicValue(stripAgeLine(row));if(!line)continue;
   const key=norm(line);if(seen.has(key))continue;seen.add(key);out.push(line);
  }
 }
 return out;
}
function extractValueAfter(lines, labels){
 const rx=labels && typeof labels.test==='function'?labels:new RegExp('^(?:'+labels.join('|')+')\\s*(?:[:：])?\\s*(.*)$','i');
 for(let i=0;i<lines.length;i++){
  const m=lines[i].match(rx); if(!m)continue;
  if(m[1]&&m[1].trim())return cleanPublicValue(m[1]);
  for(let j=i+1;j<Math.min(lines.length,i+4);j++){
   const v=cleanPublicValue(lines[j]);
   if(!v||/^(?:زنگ خطرهای قبل از معامله|اطلاعات تماس|ویژگی‌ها و امکانات|سایر ویژگی‌ها و امکانات|بررسی و کارشناسی|گزارش آگهی|توضیحات|موقعیت مکانی)$/i.test(v))continue;
   return v;
  }
 }
 return '';
}
function validYearValue(value){
 const d=asciiDigits(String(value||'')).trim();
 if(!/^\d{4}$/.test(d))return false;
 const n=Number(d);return (n>=1300&&n<=1499)||(n>=1900&&n<=2100);
}
function validRoomValue(value){
 const d=asciiDigits(String(value||'')).replace(/[^0-9]/g,'');
 if(!d||d.length>2)return false;
 const n=Number(d);return Number.isInteger(n)&&n>=0&&n<=20;
}
function validAreaValue(value){
 const d=asciiDigits(String(value||'')).replace(/[^0-9]/g,'');
 if(!d||d.length>7)return false;
 const n=Number(d);return Number.isFinite(n)&&n>0&&n<=1000000;
}
function isMoneyCandidate(value){
 const v=cleanPublicValue(value||'');if(!v)return false;
 if(/رایگان|مجانی|ندارد|نامشخص|قابل\s*تبدیل|غیر\s*قابل\s*تبدیل|تومان\s*\)?$/i.test(v)&&!/[0-9۰-۹٠-٩]/.test(v))return false;
 const d=asciiDigits(v).replace(/\D/g,'');
 if(!d)return false;
 // Four-digit years and small property counts are not prices; require a currency/unit or a plausible amount.
 if(d.length>=5)return true;
 if(/تومان|ریال|میلیون|میلیارد/.test(norm(v))&&d.length>=5)return true;
 return false;
}
function normalizeMoneyLabelLine(value){
 return String(value||'').replace(/[\u200b-\u200f\u202a-\u202e\u2060\ufeff]/g,'').replace(/^\s*:[a-z0-9_+-]+:\s*/i,'').replace(/^\s*[^\p{L}\p{N}]+/u,'').replace(/\s+/g,' ').trim();
}
function extractMoneyField(lines,labelRx){
 const sectionOrLabel=/^(?:اجاره(?:ٔ|ی)?\s*ماهانه|اجاره ماهیانه|مبلغ اجاره|ودیعه|مبلغ ودیعه|مبلغ رهن|رهن|قیمت(?: کل| فروش| زمین| ملک)?|قیمت هر متر(?: مربع)?|هر متر مربع|متراژ|ساخت|اتاق|تعداد اتاق|تعداد خواب|ویژگی.?ها و امکانات|سایر ویژگی.?ها و امکانات|توضیحات|موقعیت مکانی|اطلاعات تماس|گزارش آگهی|بررسی و کارشناسی)$/i;
 for(let i=0;i<lines.length;i++){
  const sourceLine=normalizeMoneyLabelLine(lines[i]);
  const match=sourceLine.match(labelRx);if(!match)continue;
  const inline=cleanPublicValue(match[1]||'');
  if(isMoneyCandidate(inline))return inline;
  // A label can be followed by descriptive UI text; never treat that text as a price.
  // Still inspect only its nearby value rows, stopping at the next known field label.
  for(let j=i+1;j<Math.min(lines.length,i+4);j++){
   const candidate=cleanPublicValue(normalizeMoneyLabelLine(lines[j]));if(!candidate)continue;
   if(sectionOrLabel.test(normalizeMoneyLabelLine(candidate)))break;
   if(isMoneyCandidate(candidate))return candidate;
   if(/^(?:تومان|ریال)$/i.test(candidate)&&j<=i+2)continue;
   // At most one non-value UI line may separate a price label from its amount.
   if(j>i+1 && !/^(?:قابل تبدیل|غیر قابل تبدیل|این ملک قابل تبدیل است)[.!؟،]*$/i.test(candidate))break;
  }
 }
 // Fallback for Divar layouts where label+amount occur in the same longer text node.
 // Search each line independently: searching across newlines would misread "رهن و اجاره" as a rent value.
 const patterns=[
  /(?:مبلغ\s*ودیعه|مبلغ\s*رهن|ودیعه|رهن(?!\s*و\s*اجاره))\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g,
  /(?:مبلغ\s*اجاره|اجاره(?:[ٔ‌]?\s*ماهانه|\s*ماهیانه)?)\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g,
  /(?:قیمت(?:\s*(?:کل|فروش|زمین|ملک))?)\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g,
  /(?:قیمت\s*هر\s*متر(?:\s*مربع)?|هر\s*متر\s*مربع)\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g
 ];
 const rxIndex=labelRx.source.includes('ودیعه')||labelRx.source.includes('مبلغ رهن')?0:labelRx.source.includes('مبلغ اجاره')||labelRx.source.includes('اجاره')?1:labelRx.source.includes('قیمت هر متر')||labelRx.source.includes('هر متر')?3:2;
 for(const row of lines.map(normalizeMoneyLabelLine)){
  patterns[rxIndex].lastIndex=0;let m;
  while((m=patterns[rxIndex].exec(row))){const val=cleanPublicValue(`${m[1]||''} ${m[2]||''}`);if(isMoneyCandidate(val))return val;}
 }
 return '';
}
function extractCombinedRentAmounts(lines){
 const start=lines.findIndex(x=>/^(?:رهن\s*و\s*اجاره|ودیعه\s*و\s*اجاره|مبلغ\s*رهن\s*و\s*اجاره)(?:\s|$)/i.test(normalizeMoneyLabelLine(x)));
 if(start<0)return {deposit:'',monthlyRent:''};
 const candidates=[];
 for(let i=start+1;i<Math.min(lines.length,start+7);i++){
  const row=normalizeMoneyLabelLine(lines[i]);if(!row)continue;
  if(/^(?:موقعیت|آدرس|متراژ|ساخت|اتاق|توضیحات|ویژگی.?ها|اطلاعات تماس|گزارش آگهی|بررسی و کارشناسی)$/i.test(row))break;
  if(isMoneyCandidate(row)&&(/[۰-۹٠-٩0-9]/.test(row))){candidates.push(cleanPublicValue(row));if(candidates.length===2)break;}
 }
 return candidates.length>=2?{deposit:candidates[0],monthlyRent:candidates[1]}:{deposit:'',monthlyRent:''};
}
function numberWordToInt(value){
 const s=norm(value);const nums={'صفر':0,'یک':1,'اول':1,'دو':2,'سه':3,'چهار':4,'پنج':5,'شش':6,'هفت':7,'هشت':8,'نه':9,'ده':10,'۱':1,'۲':2,'۳':3,'۴':4,'۵':5,'۶':6,'۷':7,'۸':8,'۹':9,'۱۰':10};
 if(Object.prototype.hasOwnProperty.call(nums,s))return nums[s];const d=asciiDigits(s).replace(/\D/g,'');return d&&Number(d)<=20?Number(d):null;
}
function extractRooms(lines,description,tableIndex){
 const explicit=/^(?:تعداد اتاق|تعداد خواب)\s*(?:[:：]\s*(.*))?$/i;
 for(let i=0;i<lines.length;i++){
  const m=String(lines[i]||'').match(explicit);if(!m)continue;
  let v=String(m[1]||'').trim();
  if(!v){for(let j=i+1;j<Math.min(lines.length,i+3);j++){const candidate=String(lines[j]||'').trim();if(/^(?:ودیعه|اجاره|متراژ|ساخت|اتاق|ویژگی.?ها|توضیحات|موقعیت|قیمت)/i.test(candidate))break;if(validRoomValue(candidate)){v=candidate;break;}}}
  if(validRoomValue(v))return persianDigits(asciiDigits(v));
 }
 // The Divar facts table can render three headings first, followed by three separate values.
 if(tableIndex>=0){
  const values=lines.slice(tableIndex+3,tableIndex+9).filter(x=>/^[۰-۹٠-٩0-9]{1,6}$/.test(String(x).trim()));
  const year=values.find(validYearValue);
  if(year){const yi=values.indexOf(year);const candidate=values[yi+1];if(validRoomValue(candidate))return persianDigits(candidate);}
 }
 const d=String(description||'');
 const m=d.match(/(?:^|\s)(یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|[۰-۹٠-٩0-9]{1,2})\s*(?:خواب|اتاق)(?:\s|$)/);
 if(m){const n=numberWordToInt(m[1]);if(n!==null&&n<=20)return persianDigits(String(n));}
 return '';
}
function normalizeStreet(raw){
 let s=removeAgePhrase(cleanPublicValue(String(raw||''))).replace(/[ًٌٍَُِّْٔ]/g,'').trim();
 s=s.replace(/^(?:خیابان|بلوار|کوچه|میدان|شهرک|جاده|خ\.?|خ)\s*/,'').trim();
 if(!s)return '';
 if(/^(?:بلوار|میدان|کوچه|شهرک|جاده|خیابان)\s*/.test(s))return persianDigits(s);
 return persianDigits('خیابان '+s);
}
function splitPropertyLocation(raw){
 const parts=String(removeAgePhrase(raw||'')).split(/[،,؛|]/).map(x=>removeAgePhrase(cleanPublicValue(x))).filter(Boolean);
 const out={city:'',neighborhood:'',street:'',full:''};
 if(!parts.length)return out;
 out.city=parts.shift()||'';
 // Street information is sometimes appended to the neighborhood in the same DOM line.
 const joined=parts.join('، ');
 const streetMatch=joined.match(/(?:^|\s)(خیابان|خ\.?|بلوار|کوچه|میدان|جاده)\s*([^،;|]+)$/i);
 if(streetMatch){
  const before=joined.slice(0,streetMatch.index).trim().replace(/[،,؛|]+$/,'').trim();
  out.neighborhood=before;
  out.street=normalizeStreet(streetMatch[1]+' '+streetMatch[2]);
 }else if(parts.length){
  out.neighborhood=parts.shift()||'';
  if(parts.length)out.street=normalizeStreet(parts.join('، '));
 }
 out.city=removeAgePhrase(out.city);
 out.neighborhood=removeAgePhrase(out.neighborhood);
 out.full=[out.city,out.neighborhood,out.street].filter(Boolean).join('، ');
 return out;
}
function extractListingFacts(item){
 const lines=detailLines(item),raw=lines.join('\n');
 const cats=Array.isArray(item.categories)?item.categories.filter(Boolean).map(x=>String(x).trim()):[];
 const categoryLinks=Array.isArray(item.categoryLinks)?item.categoryLinks:[];
 const categoryText=cats.join(' ')+' '+categoryLinks.map(x=>`${x?.text||''} ${x?.href||''}`).join(' ')+' '+String(item.url||'');
 const title=cleanPublicValue(item.title||lines[0]||'آگهی ملک');
 const classification=norm(`${title} ${categoryText}`);
 const detectionText=norm(`${classification} ${raw}`);
 const rentPattern=/(?:اجاره|رهن|rent-villa|rent-residential|rent-apartment|rent-house)/i;
 const salePattern=/(?:فروش|خرید|buy-villa|buy-residential|buy-land|sell-land|sell-villa|sale)/i;
 const categoriesSayRent=rentPattern.test(norm(cats.join(' ')+' '+categoryLinks.map(x=>x?.href||'').join(' ')+' '+String(item.url||'')));
 const categoriesSaySale=salePattern.test(norm(cats.join(' ')+' '+categoryLinks.map(x=>x?.href||'').join(' ')+' '+String(item.url||'')));
 const isRent=categoriesSayRent||(!categoriesSaySale&&rentPattern.test(detectionText));
 const isSale=categoriesSaySale||(!categoriesSayRent&&salePattern.test(detectionText));
 const isLand=/(?:زمین|باغ|land)/i.test(`${title} ${cats.join(' ')} ${categoryLinks.map(x=>x?.text||'').join(' ')} ${String(item.url||'')}`);
 let propertyType=isLand?'زمین/باغ':/(?:ویلا|ویلایی|خانه و ویلا)/.test(classification)?'ویلا':/(?:تجاری|مغازه|سوله|انبار|کارگاه|دفتر کار)/.test(classification)?'تجاری':/آپارتمان/.test(classification)?'آپارتمان':/(?:خانه|منزل|مسکونی)/.test(classification)?'خانه':'ملک';
 let location=removeAgePhrase(stripAgeLine(cleanPublicValue(item.location||'')));
 if(!location){const loc=lines.find(x=>/(?:دقیقه|ساعت|روز|هفته|ماه)\s*پیش\s+در\s+/.test(x));if(loc)location=removeAgePhrase(loc);}
 if(!location){const loc=lines.find(x=>/^(?:نیشابور|تهران|مشهد|سرآب|سرآب|شهرک|خیابان|خ\s)/.test(x));if(loc)location=loc;}
 if(location&&!/(?:خ\.?|خیابان|بلوار|کوچه|میدان|شهرک)\s*[^،,]+/.test(location)){const streetLine=lines.find(x=>/^(?:خ\.?|خیابان|بلوار|کوچه|میدان|شهرک)\s*\S+/.test(x));if(streetLine)location+='، '+streetLine;}
 const locationParts=splitPropertyLocation(location);
 let deposit=extractMoneyField(lines,/^(?:ودیعه|مبلغ ودیعه|مبلغ رهن|رهن(?!\s*و\s*اجاره))\s*(?:[:：])?\s*(.*)$/i);
 let monthlyRent=extractMoneyField(lines,/^(?:اجاره(?:ٔ|ی)?\s*ماهانه|اجاره ماهیانه|مبلغ اجاره|اجاره)\s*(?:[:：])?\s*(.*)$/i);
 if(isRent&&(!deposit||!monthlyRent)){const combined=extractCombinedRentAmounts(lines);if(!deposit)deposit=combined.deposit;if(!monthlyRent)monthlyRent=combined.monthlyRent;}
 let salePrice=isRent?'':extractMoneyField(lines,/^(?:قیمت کل|قیمت فروش|قیمت زمین|قیمت ملک|قیمت)\s*(?:[:：])?\s*(.*)$/i);
 // Never infer a purchase price from an arbitrary number (e.g. year, area, phone) in the page text.
 let pricePerMeter=extractMoneyField(lines,/^(?:قیمت هر متر مربع|قیمت هر متر|هر متر مربع)\s*(?:[:：])?\s*(.*)$/i);
 let builtArea=extractValueAfter(lines,/^(?:زیربنا|متراژ بنا|متراژ ساختمان|متراژ ساخته.?شده)\s*(?:[:：])?\s*(.*)$/i);
 let landArea=extractValueAfter(lines,/^(?:متراژ زمین|مساحت زمین|متراژ کل|مساحت کل)\s*(?:[:：])?\s*(.*)$/i);
 let year=extractValueAfter(lines,/^(?:سال ساخت|ساخت)\s*(?:[:：])?\s*(.*)$/i);
 if(!validAreaValue(builtArea))builtArea='';
 if(!validAreaValue(landArea))landArea='';
 if(!validYearValue(year))year='';
 const headingIndex=lines.findIndex((x,i)=>norm(x)==='متراژ'&&norm(lines[i+1]||'')==='ساخت'&&norm(lines[i+2]||'')==='اتاق');
 if(headingIndex>=0){
  const candidates=lines.slice(headingIndex+3,headingIndex+9).filter(x=>/^[۰-۹٠-٩0-9]{1,7}$/.test(String(x).trim()));
  if(!builtArea&&candidates.length&&validAreaValue(candidates[0]))builtArea=candidates[0];
  if(!year){const foundYear=candidates.find(validYearValue);if(foundYear)year=foundYear;}
 }
 if(!builtArea){const m=raw.match(/(?:زیربنا|متراژ\s+ساخت|متراژ\s+بنا|متراژ\s+ساخته.?شده)\s*[:：]?\s*([۰-۹0-9]{1,5})/);if(m&&validAreaValue(m[1]))builtArea=m[1];}
 if(!landArea){const m=raw.match(/(?:متراژ\s+زمین|مساحت\s+زمین|متراژ\s+کل|مساحت\s+کل)\s*[:：]?\s*([۰-۹0-9,٬.]+\s*(?:متر(?:\s*مربع)?|مترمربع)?)/);if(m&&validAreaValue(m[1]))landArea=m[1];}
 if(isLand&&!landArea){const m=raw.match(/(?:متراژ|مساحت)\s*[:：]?\s*([۰-۹0-9,٬.]+)\s*(?:متر(?:\s*مربع)?|مترمربع)/);if(m&&validAreaValue(m[1]))landArea=m[1];}
 if(!year){const m=raw.match(/(?:سال\s*ساخت|ساخت)\s*[:：]\s*((?:۱۳|۱۴|20)\d{2}|[۰-۹]{4})/);if(m&&validYearValue(m[1]))year=m[1];}
 let rooms=extractRooms(lines,String(item.description||''),headingIndex);
 if(!rooms){const m=raw.match(/(?:تعداد اتاق|تعداد خواب)\s*[:：]\s*([۰-۹0-9]{1,2})/);if(m&&validRoomValue(m[1]))rooms=persianDigits(asciiDigits(m[1]));}
 const any=/پارکینگ/.test(raw), storage=/انباری/.test(raw), balcony=/بالکن/.test(raw);
 const amenityWords=['پارکینگ','انباری','بالکن','آسانسور','حیاط','دربست','تراس','کولر','پکیج','شوفاژ','اسپیلت','سرامیک','کابینت','نگهبانی'];
 const amenities=[...new Set(amenityWords.filter(a=>new RegExp(a,'i').test(raw)))];
 let description=String(item.description||'').trim();
 const stopRe=/^(?:ویژگی.?ها و امکانات|سایر ویژگی.?ها و امکانات|مشخصات ملک|اطلاعات تماس|موقعیت مکانی|گزارش آگهی|بررسی و کارشناسی|یادداشت تنها برای شما قابل دیدن است|زنگ خطرهای قبل از معامله|اجارهٔ? خانه|خرید خانه|اجاره و فروش|املاک|تصویرها برای همین ملک است\?|تصویر\s*[0-9۰-۹]+\s*از\s*[0-9۰-۹]+)$/i;
 if(!description){const descRx=/^(?:توضیحات(?:\s+(?:آگهی|بیشتر))?|شرح آگهی)\s*[:：]?\s*(.*)$/i;const ix=lines.findIndex(x=>descRx.test(norm(x)));if(ix>=0){const parts=[];const first=norm(lines[ix]).match(descRx);if(first&&first[1])parts.push(first[1].trim());for(let i=ix+1;i<lines.length;i++){const ln=lines[i];if(stopRe.test(norm(ln))||cats.some(c=>norm(c)===norm(ln)))break;parts.push(ln);}description=parts.join(' ');}}
 description=cleanListingDescription(description.split(/\n+/).map(cleanPublicValue).filter(x=>x&&!stopRe.test(norm(x))&&!cats.some(c=>norm(c)===norm(x))&&!/^(?:برای هر نوع پرداخت|درخواست بیعانه|ودیعه|اجاره(?:ٔ|ی)? ماهانه|متراژ|ساخت|اتاق|توضیحات)$/i.test(norm(x))).join(' '),cats);
 const cleanVal=x=>{const v=cleanPublicValue(x);return !v||/^[-—]+$/.test(v)?'':v;};
 const bodyText=norm(raw);
 let convertible=null;if(/غیر\s*قابل\s*تبدیل|غیرقابل\s*تبدیل/.test(bodyText))convertible=false;else if(/(?:^|\s)قابل\s*تبدیل/.test(bodyText))convertible=true;
 const featureFlags={parking:any,storage,balcony};
 const monthlyRentValue=cleanVal(monthlyRent);
 const safeMonthlyRent= /^(?:رایگان|مجانی|ندارد|نامشخص)$/i.test(norm(monthlyRentValue))?'':monthlyRentValue;
 const listingType=item.listingType||classifyListingType({...item,title,categories:cats});return {title,transactionType:isRent?'rent':isSale?'sale':'unknown',transactionLabel:isRent?'اجاره':isSale?'خرید و فروش':'نامشخص',listingType,listingTypeLabel:listingTypeLabel(listingType),propertyType,location,city:locationParts.city,neighborhood:locationParts.neighborhood,street:locationParts.street,fullLocation:locationParts.full,categories:cats,deposit:cleanVal(deposit),monthlyRent:safeMonthlyRent,salePrice:cleanVal(salePrice),pricePerMeter:cleanVal(pricePerMeter),builtArea:cleanVal(builtArea),landArea:cleanVal(landArea),year:cleanVal(year),rooms:cleanVal(rooms),amenities,featureFlags,convertible,description};
}
function tagFromText(s){return '#'+String(s||'').trim().replace(/^#+/,'').replace(/[\s،,؛;|/\\]+/g,'_').replace(/[.:：()\[\]{}]+/g,'').replace(/_+/g,'_').replace(/^_|_$/g,'');}
function makeTags(item,facts){
 const tags=[];const add=x=>{const original=String(x||'').replace(/^#/,'').trim();const spaced=original.replace(/_/g,' ');if(!spaced||/(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش|(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?)\s+ago/i.test(spaced))return;const cleaned=removeAgePhrase(spaced.replace(/^(?:در\s*)/,'').trim());if(!cleaned)return;const token=tagFromText(cleaned.replace(/^#/,'').trim());if(token.length>1&&token.length<48&&!tags.some(t=>norm(t)===norm(token)))tags.push(token);};
 const categories=(facts.categories||[]).map(x=>norm(x));
 if(facts.transactionType==='rent'||categories.some(x=>/اجاره|رهن/.test(x)))add('اجاره');
 else if(facts.transactionType==='sale'||categories.some(x=>/خرید|فروش/.test(x)))add('خرید_و_فروش');
 if(categories.some(x=>/مسکونی/.test(x)))add('مسکونی');
 if(facts.propertyType==='زمین/باغ'||categories.some(x=>/زمین|باغ/.test(x)))add('زمین_و_باغ');
 else if(facts.propertyType==='ویلا'||categories.some(x=>/خانه\s*و\s*ویلا|ویلا|ویلایی/.test(x)))add('ویلایی');
 else if(categories.some(x=>/تجاری|مغازه|سوله|دفتر کار|کارگاه/.test(x)))add('تجاری');
 else if(facts.propertyType==='آپارتمان'||categories.some(x=>/آپارتمان/.test(x)))add('آپارتمان');
 else if(facts.propertyType==='خانه')add('خانه');
 // The locality is authored from normalized location fields, never from time-stamped page snippets.
 [facts.city,facts.neighborhood].filter(Boolean).forEach(x=>add(x));
 if(facts.street)add(String(facts.street).replace(/^(?:خیابان|خ\.?|خ)\s*/,'').trim());
 for(const raw of item.tags||[]){
   let t=String(raw||'').replace(/^#/,'').replace(/_/g,' ').trim();if(!t)continue;
   if(/(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش|^(?:در\s*)?(?:نیشابور|تهران|مشهد)\s+(?:در\s+)?(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش/i.test(t))continue;
   if(/^(?:فایل ملک|املاک|اجاره خانه و ویلا|خانه و ویلا|خرید و فروش|دسته ها|دیوار|من|چت|پشتیبانی)$/i.test(t))continue;
   if(/^(?:زمین و باغ|زمین)$/.test(norm(t))&&facts.propertyType!=='زمین/باغ')continue;
   if(/^اجاره$/.test(norm(t))&&facts.transactionType==='sale')continue;
   if(/^(?:فروش|خرید و فروش)$/.test(norm(t))&&facts.transactionType==='rent')continue;
   if(/در\s+(?:نیشابور|سرآب|سرآب)/.test(t)&&/(?:پیش|دقیقه|ساعت|روز|هفته|ماه)/.test(t))continue;
   add(t);
 }
 add('املاک_ققنوس');
 return tags.slice(0,9).map(t=>t.startsWith('#')?t:'#'+t);
}

/* Canonical cross-platform record adapter. Keep input and output schema stable for Chrome and mobile. */
function normalizeQoqnusDivarRecord(item={}) {
  const source = item && typeof item === 'object' ? {...item} : {};
  const categories = Array.isArray(source.categories) ? source.categories.map(v=>String(v??'').trim()).filter(Boolean) : [];
  const categoryLinks = Array.isArray(source.categoryLinks) ? source.categoryLinks.filter(v=>v&&typeof v==='object').map(v=>({text:String(v.text||'').trim(),href:String(v.href||'').trim()})) : [];
  const title = stripSourceBrandForDisplay(String(source.title || source.headline || source.name || '').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/\s+/g,' ').trim()).slice(0,240);
  const rawDetail = String(source.detailText || source.detail_text || source.text || source.content || source.publicDescription || source.description || '');
  const rawPublic = String(source.publicDescription || source.public_description || source.description || source.sellerDescription || source.seller_description || '');
  const coreInput = {
    ...source, title,
    categories, categoryLinks,
    text: rawDetail,
    detailText: rawDetail,
    description: rawPublic || source.description || '',
    publicDescription: rawPublic || source.publicDescription || '',
    location: source.location || source.locationText || source.location_text || '',
    priceText: source.priceText || source.price_text || ''
  };
  const type = classifyListingType(coreInput);
  const facts = extractListingFacts({...coreInput, listingType: source.listingType && source.listingType !== 'unknown' ? source.listingType : type});
  const finalTitle = String(facts.title || title || 'آگهی ملک').trim().slice(0,240);
  const publicRaw = rawPublic || facts.description || '';
  const publicDescription = cleanListingDescription(removePrivateContact(publicRaw), categories).slice(0,7000);
  const detailText = stripSourceBrandForDisplay(removePrivateContact(rawDetail))
    .split(/\r?\n/)
    .map(x=>stripAgeLine(String(x||'').trim()))
    .filter(x=>x && norm(x)!=='دیوار' && !/^(?:امروز|دیروز|پریروز|دسته‌ها|من|چت|پشتیبانی|گزارش آگهی)$/iu.test(x))
    .join('\n').slice(0,12000);
  const attrsRaw = source.attributes;
  let attributes;
  if (Array.isArray(attrsRaw)) {
    attributes = attrsRaw.map(x=>String(x??'').trim()).filter(Boolean).slice(0,120);
  } else if (attrsRaw && typeof attrsRaw === 'object') {
    attributes = {};
    for (const [key,value] of Object.entries(attrsRaw).slice(0,120)) {
      if (/(?:شماره\s*(?:تماس|تلفن)|اطلاعات\s*تماس|phone|contact|mobile)/iu.test(key)) continue;
      const cleanValue = cleanPublicValue(value);
      if (cleanValue) attributes[String(key).trim().slice(0,120)] = cleanValue.slice(0,1000);
    }
  } else {
    attributes = {};
  }
  const imagesRaw = source.imageUrls || source.image_urls || source.images || source.photos || source.imageLinks || source.photoUrls || [];
  const imageValues = Array.isArray(imagesRaw) ? imagesRaw : [imagesRaw];
  const imageUrls = [...new Set(imageValues.map(x=>typeof x==='string'?x:(x&&typeof x==='object'?(x.url||x.src||x.href||''):''))
    .map(x=>String(x||'').trim()).filter(x=>/^https?:\/\//i.test(x)&&!/(?:avatar|profile|logo|icon|badge|emoji)/i.test(x)))].slice(0,50);
  const phoneValues = Array.isArray(source.phones) ? source.phones : (source.phones ? [source.phones] : (source.phone ? [source.phone] : []));
  const phones = [...new Set(phoneValues.map(normalizePhoneCandidate).filter(Boolean))].slice(0,20);
  const normalizedFacts = {...(source.facts && typeof source.facts === 'object' ? source.facts : {})};
  // A partial reread must not erase a previously known property field with an empty parse result.
  for (const [key,value] of Object.entries(facts)) {
    const empty = value===undefined || value===null || value==='' || (Array.isArray(value)&&value.length===0);
    if (!empty || normalizedFacts[key]===undefined) normalizedFacts[key]=value;
  }
  normalizedFacts.title = finalTitle;
  normalizedFacts.listingType = facts.listingType || source.listingType || type;
  normalizedFacts.listingTypeLabel = facts.listingTypeLabel || listingTypeLabel(normalizedFacts.listingType);
  const mergedForTags = {...coreInput, title:finalTitle, categories, categoryLinks, text:detailText, detailText};
  const agencyCheck = classifyAgency({...mergedForTags, sellerName:source.sellerName||source.seller_name||'', text:detailText || publicDescription});
  const safeDescription = String(facts.description || publicDescription || '').trim().slice(0,7000);
  return {
    ...source,
    title: finalTitle,
    headline: String(source.headline || finalTitle).slice(0,240),
    listingType: facts.listingType || type || 'unknown',
    listingTypeLabel: facts.listingTypeLabel || listingTypeLabel(facts.listingType || type),
    transactionType: facts.transactionType || source.transactionType || source.transaction_type || 'unknown',
    transactionLabel: facts.transactionLabel || source.transactionLabel || 'نامشخص',
    propertyType: facts.propertyType || source.propertyType || source.property_type || '',
    location: facts.location || coreInput.location || '',
    locationText: facts.location || coreInput.location || '',
    city: facts.city || source.city || '',
    neighborhood: facts.neighborhood || source.neighborhood || '',
    street: facts.street || source.street || '',
    fullLocation: facts.fullLocation || source.fullLocation || '',
    deposit: facts.deposit || source.deposit || source.rentDeposit || '',
    monthlyRent: facts.monthlyRent || source.monthlyRent || source.rent_price || '',
    salePrice: facts.salePrice || source.salePrice || source.price || '',
    pricePerMeter: facts.pricePerMeter || source.pricePerMeter || '',
    builtArea: facts.builtArea || source.builtArea || source.buildingArea || source.area_sqm || '',
    landArea: facts.landArea || source.landArea || '',
    year: facts.year || source.year || '',
    rooms: facts.rooms || source.rooms || source.bedrooms || '',
    amenities: Array.isArray(facts.amenities) && facts.amenities.length ? facts.amenities : (Array.isArray(source.amenities) ? source.amenities : []),
    featureFlags: facts.featureFlags || source.featureFlags || {},
    convertible: facts.convertible !== undefined && facts.convertible !== null ? facts.convertible : (source.convertible ?? null),
    description: safeDescription,
    publicDescription: publicDescription || safeDescription,
    public_description: publicDescription || safeDescription,
    text: detailText || publicDescription || safeDescription,
    content: detailText || publicDescription || safeDescription,
    detailText,
    detail_text: detailText,
    priceText: cleanPublicValue(source.priceText || source.price_text || ''),
    categories: uniqueNormalizedText(categories, 30),
    categoryLinks: categoryLinks.slice(0,30),
    attributes,
    imageUrls,
    phones,
    tags: makeTags(mergedForTags, normalizedFacts),
    facts: normalizedFacts,
    agency: agencyCheck.label === 'املاکی',
    agencyCheck,
    normalizedSchema: 'qoqnus.divar-normalized.v1',
    normalizerVersion: '4.5.88',
    normalizerSource: 'qoqnus-shared-listing-core-4.5.88'
  };
}
function uniqueNormalizedText(values, max=100) {
 const seen=new Set(), out=[];
 for (const value of (Array.isArray(values)?values:[])) {
  const v=String(value??'').trim(), key=norm(v);
  if(!v||!key||seen.has(key))continue;
  seen.add(key);out.push(v);if(out.length>=max)break;
 }
 return out;
}
if (typeof globalThis !== 'undefined') {
 globalThis.QoqnusDivarNormalizer = Object.freeze({
  version:'4.5.88', sourceVersion:'4.5.88', normalizeRecord:normalizeQoqnusDivarRecord,
  norm, classifyContactCategory, contactCategoryLabel, classifyListingType, listingTypeLabel,
  removeAgePhrase, renderEmojiAliases, stripCategoryBreadcrumbTail, locationTags, stripSourceBrandForDisplay,
  classifyAgency, stripAgeLine, asciiDigits, persianDigits, cleanListingDescription,
  normalizePhoneCandidate, extractPhoneNumbers, listingPhoneNumbers, listingHasPhone, removePrivateContact, cleanPublicValue, normalizeMoneyLabelLine,
  splitPropertyLocation, extractListingFacts, makeTags, normalizeQoqnusDivarRecord
 });
}
