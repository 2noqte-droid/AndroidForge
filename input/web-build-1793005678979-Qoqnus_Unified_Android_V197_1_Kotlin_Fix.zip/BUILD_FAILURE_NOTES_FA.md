# گزارش تشخیص و اصلاح شکست ساخت AndroidForge — V197.1

## علت قطعی از لاگ کاربر
فرایند شکست در مرحلهٔ `:app:compileDebugKotlin` با خطا زیر متوقف شد:

`MainActivity.kt:121:13 Unresolved reference 'singleLine'`

این مورد در هر دو هدف `assembleDebug` و `bundleDebug` تکرار شد. مراحل قبلی Android resources و manifest موفق بودند؛ بنابراین خطای ثبت‌شده در این اجرا خطای کامپایل Kotlin است، نه خطای دسترسی مخزن یا دانلود SDK.

## اصلاح اعمال‌شده
- تغییر `singleLine = true` به `isSingleLine = true` در `EditText` در فایل `app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt`.
- افزایش `versionCode` از 6 به 7 و `versionName` از 2.0.0 به 2.0.1 برای تمایز خروجی اصلاح‌شده.
- به‌روزرسانی نشانگر build به `V197.1` در HTML/JavaScript و URL شروع WebView.

## نتیجه و محدودیت
این یک اصلاح مستقیم متناسب با خطای گزارش‌شده است. محیط محلی فعلی Android SDK/Gradle ندارد؛ بنابراین APK اینجا کامپایل نشده است. باید این ZIP جدید در AndroidForge بارگذاری و دوباره Build شود. اگر مرحلهٔ Kotlin بعد از این اصلاح خطای دیگری داد، لاگ جدید برای تشخیص بعدی لازم است.

## کار لازم کاربر
1. فایل `Qoqnus_Unified_Android_V197_1_Kotlin_Fix.zip` را به‌عنوان Source ZIP بارگذاری کنید.
2. Android / Debug را انتخاب و Build را اجرا کنید.
3. اگر موفق شد، Artifact APK را دریافت کنید؛ اگر شکست خورد، `AndroidForge-logs` جدید را ارسال کنید.
4. توکن GitHub را ارسال نکنید.
