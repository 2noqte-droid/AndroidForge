(function(root){
 'use strict';
 const hex=bytes=>Array.from(new Uint8Array(bytes)).map(b=>b.toString(16).padStart(2,'0')).join('');
 async function sha256(bytes){return hex(await crypto.subtle.digest('SHA-256',bytes));}
 function randomId(){const b=new Uint8Array(16);crypto.getRandomValues(b);return Array.from(b).map(x=>x.toString(16).padStart(2,'0')).join('');}
 function classifyQueueRecord(record){if(!record||typeof record!=='object'||!record.id)return '';if(record.source==='office-file'||String(record.id).startsWith('MOBFILE-'))return 'file';return 'listing';}
 function validateImageDataUrl(value,maxBytes=3*1024*1024){
   const s=String(value||'');const m=/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(s);if(!m)throw new Error('رسانه فقط باید تصویر JPEG، PNG یا WebP معتبر باشد.');
   const mime='image/'+(m[1].toLowerCase()==='jpg'?'jpeg':m[1].toLowerCase()),base64=m[2];if(base64.length%4!==0)throw new Error('رمزگذاری Base64 تصویر معتبر نیست.');
   let bytes=Math.floor(base64.length*3/4)-(base64.endsWith('==')?2:(base64.endsWith('=')?1:0));if(bytes<1||bytes>maxBytes)throw new Error('حجم هر تصویر باید حداکثر ۳ مگابایت باشد.');
   return {mime,base64,bytes,dataUrl:s};
 }
 async function mediaFingerprint(kind,id,index,dataUrl){return sha256(new TextEncoder().encode(String(kind)+'\u0000'+String(id)+'\u0000'+String(index)+'\u0000'+String(dataUrl)));}
 function normalizeTombstone(value){if(!value||typeof value!=='object')return null;const kind=String(value.kind||''),recordId=String(value.recordId||''),raw=Number(value.deletedAt);if(!['customer','contact','file','listing'].includes(kind)||!recordId||recordId.length>160||!Number.isFinite(raw)||raw<0)return null;return {kind,recordId,deletedAt:Math.floor(raw)};}
 async function tombstoneFingerprint(value){const normalized=normalizeTombstone(value);if(!normalized)throw new Error('حذف همگام‌سازی معتبر نیست.');return sha256(new TextEncoder().encode(JSON.stringify(normalized)));}
 async function selectTombstoneDelta(values,ackHashes={}){const latest=new Map();for(const value of Array.isArray(values)?values:[]){const t=normalizeTombstone(value);if(!t)continue;const key=t.kind+':'+t.recordId,old=latest.get(key);if(!old||t.deletedAt>old.deletedAt)latest.set(key,t);}const out=[];for(const [key,t] of latest){const fingerprint=await tombstoneFingerprint(t);if(String(ackHashes?.[key]||'')!==fingerprint)out.push({...t,fingerprint});}return out;}
 async function verifyTombstone(value){const t=normalizeTombstone(value);if(!t)return null;const expected=await tombstoneFingerprint(t),provided=String(value.fingerprint||'');if(provided&&provided!==expected)throw new Error('هش حذف همگام‌شده با محتوای آن سازگار نیست.');return {...t,fingerprint:expected};}
 function classifySyncChange({localFingerprint='',remoteFingerprint='',baseFingerprint='',collision=false,aliased=false,targetId='',remoteId=''}={}){const local=String(localFingerprint||''),incoming=String(remoteFingerprint||''),base=String(baseFingerprint||'');if(!local||!incoming||local===incoming)return 'same';if(collision||aliased)return 'conflict';if(!base)return String(targetId)===String(remoteId)?'conflict':'accept-remote';const localChanged=local!==base,remoteChanged=incoming!==base;if(localChanged&&remoteChanged)return 'conflict';if(localChanged&&!remoteChanged)return 'keep-local';return 'accept-remote';}
 function hasSyncConflict(change={}){return classifySyncChange(change)==='conflict';}
 function shouldApplyRemote(change={}){return classifySyncChange(change)==='accept-remote';}
 function attach(channel,onPayload,onStatus){
   const allowed=new Set(['hello','pairing-credentials','pairing-ack','sync-complete','sync-error']);
   let closed=false;
   const status=msg=>{try{onStatus&&onStatus(msg)}catch{}};
   async function sendMessage(obj){
     const type=String(obj?.type||'');
     if(!allowed.has(type))throw new Error('کانال WebRTC فقط برای جفت‌سازی اولیه است؛ انتقال داده باید از صف رمزگذاری‌شده انجام شود.');
     if(closed||channel.readyState!=='open')throw new Error('کانال جفت‌سازی اولیه بسته است.');
     const wire=JSON.stringify({__qoqnus:'app',type,payload:obj?.payload&&typeof obj.payload==='object'?obj.payload:{}});
     if(new TextEncoder().encode(wire).length>65536)throw new Error('پیام جفت‌سازی از حد مجاز بزرگ‌تر است.');
     channel.send(wire);
   }
   async function handle(event){
     let msg;try{msg=JSON.parse(typeof event.data==='string'?event.data:'')}catch{return;}
     // Never process the previous chunked __qoqnus start/chunk/ack data-transfer protocol.
     if(msg?.__qoqnus!=='app')return;
     const type=String(msg.type||'');
     if(!allowed.has(type)){status('پیام داده از مسیر WebRTC رد شد؛ فقط جفت‌سازی اولیه مجاز است.');return;}
     try{await onPayload(type,msg.payload&&typeof msg.payload==='object'?msg.payload:{})}
     catch(err){status(String(err?.message||'پردازش پیام جفت‌سازی ناموفق بود.'))}
   }
   channel.addEventListener('message',e=>{handle(e).catch(err=>status(String(err?.message||err)))});
   channel.addEventListener('close',()=>{closed=true;status('کانال جفت‌سازی اولیه بسته شد.')});
   channel.addEventListener('error',()=>status('خطای کانال جفت‌سازی اولیه.'));
   return {sendMessage,close(){closed=true}};
 }

 const QUEUE_KEY_DB='qoqnus-peer-queue-crypto-v1';
 function queueKeyDb(){return new Promise((resolve,reject)=>{if(typeof indexedDB==='undefined'){reject(new Error('ذخیرهٔ امن کلید صف همگام‌سازی در این محیط پشتیبانی نمی‌شود.'));return;}const req=indexedDB.open(QUEUE_KEY_DB,1);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('keys'))db.createObjectStore('keys',{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('بازکردن مخزن کلید همگام‌سازی ناموفق بود.'));});}
 function queueKeyDbGet(id){return queueKeyDb().then(db=>new Promise((resolve,reject)=>{const tx=db.transaction('keys','readonly'),req=tx.objectStore('keys').get(id);req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error||new Error('خواندن کلید همگام‌سازی ناموفق بود.'));tx.oncomplete=()=>db.close();tx.onerror=()=>{db.close();reject(tx.error);};}));}
 function queueKeyDbPut(value){return queueKeyDb().then(db=>new Promise((resolve,reject)=>{const tx=db.transaction('keys','readwrite');tx.objectStore('keys').put(value);tx.oncomplete=()=>{db.close();resolve(true);};tx.onerror=()=>{db.close();reject(tx.error||new Error('ذخیرهٔ کلید همگام‌سازی ناموفق بود.'));};tx.onabort=()=>{db.close();reject(tx.error||new Error('ذخیرهٔ کلید همگام‌سازی لغو شد.'));};}));}
 const queueB64 = bytes => {let s='';for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));return btoa(s)};
 const queueUnb64 = value => {const s=atob(String(value||'')),b=new Uint8Array(s.length);for(let i=0;i<s.length;i++)b[i]=s.charCodeAt(i);return b};
 async function queueIdentity(){let saved=await queueKeyDbGet('self');if(saved?.privateKey&&saved?.publicJwk?.kty==='EC'&&saved.publicJwk.crv==='P-256')return saved;const generated=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);const privateJwk=await crypto.subtle.exportKey('jwk',generated.privateKey);const publicJwk=await crypto.subtle.exportKey('jwk',generated.publicKey);const privateKey=await crypto.subtle.importKey('jwk',privateJwk,{name:'ECDH',namedCurve:'P-256'},false,['deriveBits']);saved={id:'self',privateKey,publicJwk:{kty:'EC',crv:'P-256',x:publicJwk.x,y:publicJwk.y,ext:true,key_ops:[]},createdAt:Date.now()};await queueKeyDbPut(saved);return saved;}
 async function queueAesKey(privateKey,publicJwk,salt,usage){const peer=await crypto.subtle.importKey('jwk',publicJwk,{name:'ECDH',namedCurve:'P-256'},false,[]);const shared=await crypto.subtle.deriveBits({name:'ECDH',public:peer},privateKey,256);const hkdf=await crypto.subtle.importKey('raw',shared,'HKDF',false,['deriveKey']);return crypto.subtle.deriveKey({name:'HKDF',hash:'SHA-256',salt,info:new TextEncoder().encode('qoqnus.durable-sync.v1')},hkdf,{name:'AES-GCM',length:256},false,[usage]);}
 async function sealQueuePayload(publicJwk,payload,aadText){if(!publicJwk||publicJwk.kty!=='EC'||publicJwk.crv!=='P-256'||!publicJwk.x||!publicJwk.y)throw new Error('کلید عمومی دستگاه مقصد معتبر نیست.');const target=await crypto.subtle.importKey('jwk',publicJwk,{name:'ECDH',namedCurve:'P-256'},false,[]);const ephem=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));const shared=await crypto.subtle.deriveBits({name:'ECDH',public:target},ephem.privateKey,256);const hkdf=await crypto.subtle.importKey('raw',shared,'HKDF',false,['deriveKey']);const aes=await crypto.subtle.deriveKey({name:'HKDF',hash:'SHA-256',salt,info:new TextEncoder().encode('qoqnus.durable-sync.v1')},hkdf,{name:'AES-GCM',length:256},false,['encrypt']);const plain=new TextEncoder().encode(JSON.stringify(payload));if(plain.byteLength>5*1024*1024)throw new Error('بستهٔ تغییرات برای صف آفلاین بزرگ است؛ انتقال عکس را جداگانه انجام دهید.');const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(String(aadText||''))},aes,plain);const epk=await crypto.subtle.exportKey('jwk',ephem.publicKey);return {schema:'qoqnus.sealed-queue.v1',v:1,alg:'ECDH-P256-HKDF-SHA256-AES-256-GCM',epk:{kty:'EC',crv:'P-256',x:epk.x,y:epk.y,ext:true,key_ops:[]},salt:queueB64(salt),iv:queueB64(iv),ciphertext:queueB64(new Uint8Array(cipher))};}
 async function openQueuePayload(envelope,aadText,identity){if(!envelope||envelope.schema!=='qoqnus.sealed-queue.v1'||Number(envelope.v)!==1||envelope.alg!=='ECDH-P256-HKDF-SHA256-AES-256-GCM')throw new Error('قالب بستهٔ رمزگذاری‌شده معتبر نیست.');const id=identity||await queueIdentity(),salt=queueUnb64(envelope.salt),iv=queueUnb64(envelope.iv),cipher=queueUnb64(envelope.ciphertext);if(salt.length!==16||iv.length!==12||cipher.length<17||cipher.length>6*1024*1024)throw new Error('طول بستهٔ رمزگذاری‌شده خارج از محدوده است.');const aes=await queueAesKey(id.privateKey,envelope.epk,salt,'decrypt');const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(String(aadText||''))},aes,cipher);return JSON.parse(new TextDecoder().decode(plain));}

 root.QoqnusPeerProtocol={attach,sha256,randomId,classifyQueueRecord,validateImageDataUrl,mediaFingerprint,normalizeTombstone,tombstoneFingerprint,selectTombstoneDelta,verifyTombstone,classifySyncChange,hasSyncConflict,shouldApplyRemote,queueIdentity,sealQueuePayload,openQueuePayload};
})(typeof self!=='undefined'?self:globalThis);
