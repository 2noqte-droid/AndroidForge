# گزارش فنی ققنوس V229 — حذف گزارش تشخیصی از ابتدای تب آگهی‌ها

## علت نمایش گزارش در تب آگهی‌ها
در `app/src/main/assets/index.html` یک عنصر با شناسهٔ `listingSyncAuditNote` در ابتدای `view-listings` قرار داشت. در `app/src/main/assets/app.js`، تابع `renderListings()` هر بار آخرین شیء `lastListingSyncAudit` را می‌خواند، متن مفصل تعدادهای منبع/دریافت/ذخیره، شناسه‌های فایل دفتر، موارد بایگانی و اختلاف شناسه‌ها را داخل آن عنصر می‌نوشت و دکمهٔ دانلود JSON را همان‌جا می‌ساخت. به همین دلیل گزارش در ابتدای تب آگهی‌ها دیده می‌شد.

## تغییرات انجام‌شده

### ۱) تب آگهی‌ها
- عنصر `listingSyncAuditNote` به‌طور کامل از HTML تب آگهی‌ها حذف شد.
- تمام بلوک تولید و نمایش متن گزارش از `renderListings()` برداشته شد.
- محاسبهٔ عادی فهرست و رندر کارت‌های آگهی بدون تغییر باقی ماند.
- هیچ رکورد، مقدار IndexedDB یا دادهٔ همگام‌سازی حذف یا بازنویسی نشد.

### ۲) تب همگام‌سازی
- دکمهٔ `downloadListingSyncAuditReport` به بخش `view-sync` اضافه شد.
- دکمه فقط در صورت وجود `lastListingSyncAudit` معتبر قابل مشاهده است.
- خروجی JSON با تابع مستقل `downloadListingSyncAuditReport()` ساخته می‌شود.
- دادهٔ اصلی audit همان شیء ذخیره‌شده در IndexedDB است؛ فقط شمارش محلی هنگام دانلود دوباره محاسبه می‌شود.
- پس از ثبت گزارش همگام‌سازی جدید، وضعیت نمایش دکمه تازه می‌شود.

### ۳) نسخه و کش
- `APP_VERSION`: V228 به V229
- Android `versionCode`: 38 به 39
- Android `versionName`: 2.0.32 به 2.0.33
- کلید Service Worker و query نسخهٔ HTML/JS/CSS/manifest به `V229-sync-audit-moved-to-sync` تغییر کرد.
- نشانی شروع WebView نیز build جدید V229 را دریافت می‌کند.

## فایل‌های تغییرکرده
- `app/src/main/assets/index.html`
- `app/src/main/assets/app.js`
- `app/src/main/assets/sw.js`
- `app/src/main/assets/manifest.webmanifest`
- `app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt`
- `app/build.gradle.kts`
- آزمون‌های رگرسیون مرتبط در `tests/`
- `README_V229_FA.md`

## آزمون‌ها
- `node --check app/src/main/assets/app.js`: موفق
- `node --check app/src/main/assets/sw.js`: موفق
- ۱۸ فایل آزمون Node.js: بدون شکست
- آزمون اختصاصی جایگاه گزارش: ۱۱/۱۱ موفق
- آزمون audit/backup: موفق
- `manifest.webmanifest`: JSON معتبر
- منابع XML اندروید: parse موفق
- فایل ZIP: تست CRC موفق
- یک زیربخش اختیاری cross-client crypto در تست V220 به‌دلیل نبود harness مستقل افزونه در همان تست `SKIP` گزارش می‌کند؛ این مورد به تغییر جایگاه گزارش مربوط نیست.

## محدودیت‌ها
- در محیط فعلی `gradle` و فایل `gradlew` وجود ندارد؛ APK واقعی ساخته نشده است.
- اجرای واقعی روی گوشی انجام نشده است.
- برای مشاهدهٔ تغییر در نسخهٔ وب میزبانی‌شده، دارایی‌های وب باید روی هاست منتشر شوند؛ تغییر سورس به‌تنهایی نسخهٔ آنلاین را تغییر نمی‌دهد.

## نتیجه
متن گزارش دیگر در ابتدای تب آگهی‌ها رندر نمی‌شود. اطلاعات تشخیصی حفظ شده و دانلود گزارش از تب همگام‌سازی در دسترس است.
