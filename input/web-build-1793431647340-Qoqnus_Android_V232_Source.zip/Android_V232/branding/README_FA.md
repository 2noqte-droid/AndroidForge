# هویت بصری ققنوس

- `Qoqnus_Phoenix_Logo.svg`: لوگوی کامل برداری با رنگ طلایی/مسی و زمینهٔ شفاف.
- `Qoqnus_Phoenix_Logo.png`: نسخهٔ PNG با وضوح 640×760 و زمینهٔ شفاف.
- `Qoqnus_Phoenix_Logo_Monochrome.svg` و `.png`: نسخهٔ تک‌رنگ طلایی.
- آیکون نصب برنامه در `app/src/main/res/drawable-nodpi/ic_launcher.png` و `app/src/main/assets/icons/`.

نکته: PNGهای لوگوی کامل و تک‌رنگ دارای کانال شفافیت هستند. برای نمایش روی زمینهٔ تیره مناسب‌اند.
