# ققنوس V223 — رفع خواندن فایل پشتیبان

## علت اصلی
بازیابی قدیمی، فایل انتخاب‌شده از Android Storage Access Framework را به‌صورت `content://` به WebView می‌داد و JavaScript مستقیم `file.text()` را اجرا می‌کرد؛ درحالی‌که WebView با `allowContentAccess=false` پیکربندی شده بود. این دو مسیر با هم ناسازگار بودند.

## اصلاح
- فایل JSON در Native با `ContentResolver` باز و خوانده می‌شود.
- محتوا در قطعات کنترل‌شدهٔ ۴۸ KiB از پل امن WebView عبور می‌کند.
- سقف فایل ۱۵۰ MiB، آفست‌ها، UTF-8، اندازهٔ نهایی و فایل خالی اعتبارسنجی می‌شوند.
- برای PWA/مرورگر از `FileReader` استفاده می‌شود.
- `allowContentAccess=false` حفظ شده است.
- مسیر خروجی پشتیبان و توابع `exportBackup`, `normalizeBackupPayload` و `downloadRecoveryBackup` حفظ شده‌اند.
- JSON خروجی پیش از ذخیره با verifier هستهٔ پشتیبان بررسی می‌شود.

## نسخه
`versionCode=33`, `versionName=2.0.27`, Build `V223-backup-file-import`.

## آزمون‌ها
۱۵/۱۵ فایل آزمون Node.js موفق‌اند؛ آزمون کامل صف با سورس افزونه و PHP نیز موفق است. جزئیات در `REPORT_V223_BACKUP_IMPORT_FA.md` و `V223_test_results.log` آمده است.

## محدودیت
APK ساخته نشده است، چون Gradle/Gradle Wrapper و Android SDK در محیط حاضر موجود نیست. آزمون روی گوشی واقعی و فایل JSON واقعی کاربر نیز اجرا نشده است.
