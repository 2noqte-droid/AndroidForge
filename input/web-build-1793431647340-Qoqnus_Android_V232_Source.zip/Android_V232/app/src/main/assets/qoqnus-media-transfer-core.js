(function (root) {
  'use strict';
  const MAX_MEDIA_IMAGES_PER_RECORD = 100;
  const DATA_IMAGE_PREFIX = /^data:image\//i;

  function collectMediaDataCandidates(record) {
    const out = [], seen = new Set();
    const add = value => {
      if (typeof value === 'string') {
        const text = value.trim();
        if (DATA_IMAGE_PREFIX.test(text) && !seen.has(text)) {
          seen.add(text);
          out.push(text);
        }
        return;
      }
      if (Array.isArray(value)) { value.forEach(add); return; }
      if (value && typeof value === 'object') {
        for (const key of ['dataUrl', 'dataURL', 'src', 'data']) if (value[key] != null) add(value[key]);
      }
    };
    for (const key of ['imageDataUrls','localImageDataUrls','photoDataUrls','localPhotos','imageDataUrl','image_data_url','photoDataUrl','imageUrls','imageUrl','image_url','images','photos','pictures']) {
      if (record && record[key] !== undefined) add(record[key]);
    }
    if (out.length > MAX_MEDIA_IMAGES_PER_RECORD) {
      throw new Error('این رکورد بیش از ۱۰۰ تصویر ضمیمه دارد؛ برای جلوگیری از انتقال ناقص، همگام‌سازی متوقف شد.');
    }
    return out;
  }

  function validateMediaIndex(value) {
    const index = Number(value);
    if (!Number.isInteger(index) || index < 0 || index >= MAX_MEDIA_IMAGES_PER_RECORD) {
      throw new Error('شمارهٔ تصویر خارج از محدودهٔ پشتیبانی‌شده است.');
    }
    return index;
  }

  root.QoqnusMediaTransferCore = {
    MAX_MEDIA_IMAGES_PER_RECORD,
    collectMediaDataCandidates,
    validateMediaIndex
  };
})(typeof self !== 'undefined' ? self : globalThis);
