/* Qoqnus listing price normalization and card presentation helpers. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.QoqnusListingPresentation = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const DERIVED_TOTAL = 'qoqnusComputedSaleTotalToman';
  const DERIVED_METHOD = 'qoqnusComputedSaleTotalMethod';
  const DERIVED_VERSION = 'qoqnusComputedSaleTotalVersion';

  function asciiDigits(value) {
    return String(value ?? '')
      .replace(/[۰-۹]/g, ch => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(ch)))
      .replace(/[٠-٩]/g, ch => String('٠١٢٣٤٥٦٧٨٩'.indexOf(ch)))
      .replace(/[\u200e\u200f\u202a-\u202e]/g, '');
  }

  function numericToken(value) {
    const text = asciiDigits(value).replace(/٫/g, '.');
    const match = text.match(/\d[\d\s,٬،.]*\d|\d/);
    if (!match) return null;
    let token = match[0].replace(/\s/g, '');
    const separators = [...token.matchAll(/[,.٬،]/g)].map(m => ({ char: m[0], index: m.index }));
    if (!separators.length) {
      const n = Number(token);
      return Number.isFinite(n) ? n : null;
    }
    const last = separators[separators.length - 1];
    const tail = token.length - last.index - 1;
    const unique = new Set(separators.map(x => x.char));
    const grouped = separators.length > 1 || tail === 3;
    if (grouped) token = token.replace(/[,.٬،]/g, '');
    else token = token.replace(/[٬،]/g, '').replace(',', '.');
    const n = Number(token);
    return Number.isFinite(n) ? n : null;
  }

  function parseMoneyToman(value, options = {}) {
    if (value === null || value === undefined || value === '') return null;
    if (typeof value === 'number') {
      if (!Number.isFinite(value) || value <= 0) return null;
      const amount = options.forceRial === true ? value / 10 : value;
      return amount > 0 && amount <= Number.MAX_SAFE_INTEGER ? Math.round(amount) : null;
    }
    const text = asciiDigits(value).trim();
    if (!text) return null;
    const parsed = numericToken(text);
    if (!(parsed > 0)) return null;
    let multiplier = 1;
    if (!options.noMultiplier) {
      if (/میلیارد|\bbillion\b/i.test(text)) multiplier = 1e9;
      else if (/میلیون|\bmillion\b/i.test(text)) multiplier = 1e6;
      else if (/هزار|\bthousand\b/i.test(text)) multiplier = 1e3;
    }
    const rial = options.forceRial === true || (/ریال/u.test(text) && !/تومان/u.test(text));
    const amount = parsed * multiplier / (rial ? 10 : 1);
    return Number.isFinite(amount) && amount > 0 && amount <= Number.MAX_SAFE_INTEGER ? Math.round(amount) : null;
  }

  function parseArea(value) {
    if (value === null || value === undefined || value === '') return null;
    const parsed = numericToken(value);
    return Number.isFinite(parsed) && parsed > 0 && parsed <= 1000000 ? parsed : null;
  }

  function firstParsed(objects, keys) {
    for (const obj of objects) {
      if (!obj || typeof obj !== 'object') continue;
      for (const key of keys) {
        const value = obj[key];
        if (value === null || value === undefined || value === '') continue;
        const amount = parseMoneyToman(value, { forceRial: /(?:rial|riyal|_rial|_riyal)/i.test(key) });
        if (amount) return { amountToman: amount, raw: value, key };
      }
    }
    return null;
  }

  function saleArea(record, topic = '') {
    const f = record?.facts && typeof record.facts === 'object' ? record.facts : {};
    const objects = [record, f];
    const land = topic === 'land' || /زمین|باغ|کلنگی|land/i.test([
      record?.title, record?.propertyType, record?.property_type, record?.listingType,
      record?.listingTypeLabel, f.propertyType
    ].join(' '));
    const keys = land
      ? ['landArea', 'land_area', 'land_area_sqm', 'area_sqm', 'area']
      : ['builtArea', 'built_area', 'buildingArea', 'building_area', 'area_building', 'area_sqm', 'area'];
    for (const obj of objects) {
      for (const key of keys) {
        const value = obj?.[key];
        const amount = parseArea(value);
        if (amount) return { area: amount, key, land };
      }
    }
    return { area: null, key: '', land };
  }

  function explicitSaleTotal(record) {
    const f = record?.facts && typeof record.facts === 'object' ? record.facts : {};
    const explicitKeys = [
      'totalSalePriceToman', 'total_sale_price_toman', 'totalSalePriceRial', 'total_sale_price_rial',
      'totalPriceToman', 'total_price_toman', 'totalPriceRial', 'total_price_rial',
      'salePriceRial', 'sale_price_rial', 'priceRial', 'price_rial',
      'totalPrice', 'total_price', 'askingPrice', 'asking_price',
      'salePriceToman', 'sale_price_toman', 'salePrice', 'sale_price'
    ];
    const isPerMeter = value => typeof value === 'string' && /(?:هر\s*متر|متری|per\s*(?:sqm|m2|square\s*met))/iu.test(value);
    const directObjects = [record, f].map(obj => {
      if (!obj || typeof obj !== 'object') return obj;
      const copy = { ...obj };
      for (const key of explicitKeys) if (isPerMeter(copy[key])) delete copy[key];
      return copy;
    });
    const direct = firstParsed(directObjects, explicitKeys);
    if (direct) return direct;
    // Generic `price` is a legacy total-price field in Qoqnus records. Keep it
    // behind explicit total fields so an explicit per-square-metre value wins.
    const genericObjects = [record, f].map(obj => {
      if (!obj || typeof obj !== 'object') return obj;
      const copy = { ...obj };
      if (isPerMeter(copy.price)) delete copy.price;
      return copy;
    });
    return firstParsed(genericObjects, ['priceToman', 'price_toman', 'price']);
  }

  function pricePerMeter(record) {
    const f = record?.facts && typeof record.facts === 'object' ? record.facts : {};
    const direct = firstParsed([record, f], [
      'pricePerMeterToman', 'price_per_meter_toman', 'pricePerMeterRial', 'price_per_meter_rial',
      'price_per_sqm_rial', 'pricePerMeter', 'price_per_meter', 'price_per_sqm', 'pricePerSqm', 'price_per_sq_meter'
    ]);
    if (direct) return direct;
    for (const obj of [record, f]) {
      const value = obj?.price;
      if (typeof value === 'string' && /(?:هر\s*متر|متری|per\s*(?:sqm|m2|square\s*met))/iu.test(value)) {
        const amountToman = parseMoneyToman(value);
        if (amountToman) return { amountToman, raw: value, key: 'price' };
      }
    }
    return null;
  }

  function resolveSalePrice(record, options = {}) {
    const explicit = explicitSaleTotal(record);
    if (explicit) return { amountToman: explicit.amountToman, source: 'explicit-total', raw: explicit.raw, key: explicit.key };

    const topic = options.topic || '';
    const areaInfo = saleArea(record, topic);
    const meter = pricePerMeter(record);
    if (areaInfo.area && meter?.amountToman) {
      const total = Math.round(areaInfo.area * meter.amountToman);
      if (Number.isSafeInteger(total) && total > 0) {
        return {
          amountToman: total,
          source: 'area-x-price-per-meter',
          area: areaInfo.area,
          pricePerMeterToman: meter.amountToman,
          areaField: areaInfo.key,
          pricePerMeterField: meter.key
        };
      }
    }
    const rawText = [record?.salePrice, record?.sale_price, record?.price, record?.facts?.salePrice, record?.priceText]
      .find(value => typeof value === 'string' && value.trim() && !parseMoneyToman(value));
    return {
      amountToman: null,
      source: 'unavailable',
      rawText: rawText ? String(rawText).trim() : '',
      area: areaInfo.area,
      pricePerMeterToman: meter?.amountToman || null
    };
  }

  function normalizeRecord(record, context = {}) {
    if (!record || typeof record !== 'object' || Array.isArray(record)) return record;
    const transaction = String(context.transaction || '').toLowerCase();
    const next = { ...record };
    const hadDerived = Object.prototype.hasOwnProperty.call(next, DERIVED_TOTAL) ||
      Object.prototype.hasOwnProperty.call(next, DERIVED_METHOD) ||
      Object.prototype.hasOwnProperty.call(next, DERIVED_VERSION);

    if (transaction !== 'sale') {
      if (!hadDerived) return record;
      delete next[DERIVED_TOTAL]; delete next[DERIVED_METHOD]; delete next[DERIVED_VERSION];
      return next;
    }

    const probe = context.probe && typeof context.probe === 'object' ? { ...next, ...context.probe } : next;
    const explicit = explicitSaleTotal(probe);
    if (explicit) {
      if (!hadDerived) return record;
      delete next[DERIVED_TOTAL]; delete next[DERIVED_METHOD]; delete next[DERIVED_VERSION];
      return next;
    }

    const resolved = resolveSalePrice(probe, { topic: context.topic || '' });
    if (resolved.source === 'area-x-price-per-meter') {
      if (Number(next[DERIVED_TOTAL]) === resolved.amountToman &&
          next[DERIVED_METHOD] === resolved.source && Number(next[DERIVED_VERSION]) === 1) return record;
      next[DERIVED_TOTAL] = resolved.amountToman;
      next[DERIVED_METHOD] = resolved.source;
      next[DERIVED_VERSION] = 1;
      return next;
    }

    if (!hadDerived) return record;
    delete next[DERIVED_TOTAL]; delete next[DERIVED_METHOD]; delete next[DERIVED_VERSION];
    return next;
  }

  function formatToman(amount) {
    const value = Number(amount);
    return Number.isFinite(value) && value > 0 ? Math.round(value).toLocaleString('fa-IR') + ' تومان' : '';
  }

  function compactToman(amount) {
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) return '';
    const n = Math.round(value);
    const fmt = x => Number(x.toFixed(1)).toLocaleString('fa-IR', { maximumFractionDigits: 1 });
    if (n >= 1e12) return fmt(n / 1e12) + ' تریلیون';
    if (n >= 1e9) return fmt(n / 1e9) + ' میلیارد';
    if (n >= 1e6) return fmt(n / 1e6) + ' میلیون';
    return fmt(n) + ' تومان';
  }

  return Object.freeze({
    DERIVED_TOTAL, DERIVED_METHOD, DERIVED_VERSION,
    asciiDigits, parseMoneyToman, parseArea, saleArea, explicitSaleTotal,
    pricePerMeter, resolveSalePrice, normalizeRecord, formatToman, compactToman
  });
});
