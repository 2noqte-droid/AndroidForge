(function (root) {
  'use strict';
  const DEFAULT_MAX_BYTES = 150 * 1024 * 1024;

  function createChunkReceiver({ name = 'qoqnus-backup.json', totalBytes = -1, maxBytes = DEFAULT_MAX_BYTES } = {}) {
    const expectedTotal = Number(totalBytes);
    const limit = Number(maxBytes) > 0 ? Number(maxBytes) : DEFAULT_MAX_BYTES;
    const decoder = new TextDecoder('utf-8', { fatal: true });
    const parts = [];
    let offset = 0;
    let finished = false;

    return {
      get offset() { return offset; },
      push(expectedOffset, base64, done) {
        if (finished) throw new Error('جریان خواندن فایل پشتیبان قبلاً پایان یافته است.');
        if (!Number.isInteger(Number(expectedOffset)) || Number(expectedOffset) !== offset) {
          throw new Error('ترتیب قطعات فایل پشتیبان نادرست است.');
        }
        const binary = root.atob(String(base64 || ''));
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        offset += bytes.length;
        if (offset > limit) throw new Error('فایل پشتیبان بیش از ۱۵۰ مگابایت است.');
        if (bytes.length) parts.push(decoder.decode(bytes, { stream: !done }));
        if (!done) return { complete: false, nextOffset: offset };
        parts.push(decoder.decode());
        if (Number.isFinite(expectedTotal) && expectedTotal >= 0 && offset !== expectedTotal) {
          throw new Error('حجم واقعی فایل با اندازه اعلام‌شده مطابقت ندارد؛ فایل ناقص است.');
        }
        const text = parts.join('').replace(/^\uFEFF/, '');
        if (!text.trim()) throw new Error('فایل انتخاب‌شده خالی است.');
        finished = true;
        return { complete: true, text, name: String(name || 'qoqnus-backup.json'), bytes: offset };
      }
    };
  }

  async function readFileAsText(file, maxBytes = DEFAULT_MAX_BYTES) {
    if (!file) throw new Error('فایل پشتیبان انتخاب نشده است.');
    const size = Number(file.size);
    if (Number.isFinite(size) && size > maxBytes) throw new Error('فایل پشتیبان بیش از ۱۵۰ مگابایت است.');
    let text = '';
    if (typeof root.FileReader === 'function') {
      try {
        text = await new Promise((resolve, reject) => {
          const reader = new root.FileReader();
          reader.onerror = () => reject(reader.error || new Error('خواندن فایل از انتخاب‌گر ناموفق بود.'));
          reader.onabort = () => reject(new Error('خواندن فایل پشتیبان لغو شد.'));
          reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '');
          try { reader.readAsText(file, 'UTF-8'); } catch (error) { reject(error); }
        });
      } catch (readerError) {
        if (typeof file.text !== 'function') throw readerError;
        text = await file.text();
      }
    } else if (typeof file.text === 'function') {
      text = await file.text();
    } else {
      throw new Error('این نسخهٔ WebView امکان خواندن فایل را ندارد؛ برنامه را به‌روزرسانی کنید.');
    }
    text = String(text || '').replace(/^\uFEFF/, '');
    if (!text.trim()) throw new Error('فایل انتخاب‌شده خالی است یا دسترسی خواندن آن وجود ندارد.');
    return text;
  }

  root.QoqnusBackupFileReader = { createChunkReceiver, readFileAsText, DEFAULT_MAX_BYTES };
})(typeof self !== 'undefined' ? self : globalThis);
