/* Qoqnus timeline grouping — stable Tehran calendar-day buckets. */
(function installQoqnusTimeGrouping(root) {
  'use strict';
  const TIME_ZONE = 'Asia/Tehran';
  const GROUPS = [
    { key: 'today', label: 'امروز' },
    { key: 'yesterday', label: 'دیروز' },
    { key: 'week', label: 'هفته گذشته' },
    { key: 'month', label: 'ماه گذشته' },
    { key: 'year', label: 'سال گذشته' },
    { key: 'older', label: 'قدیمی‌تر' },
    { key: 'unknown', label: 'تاریخ نامشخص' }
  ];
  const formatter = new Intl.DateTimeFormat('en-US-u-ca-gregory-nu-latn', {
    timeZone: TIME_ZONE,
    year: 'numeric', month: '2-digit', day: '2-digit'
  });

  function partsFor(value) {
    const timestamp = Number(value);
    if (!Number.isFinite(timestamp) || timestamp <= 0) return null;
    const parts = formatter.formatToParts(new Date(timestamp));
    const fields = Object.create(null);
    for (const part of parts) if (part.type !== 'literal') fields[part.type] = Number(part.value);
    const year = fields.year, month = fields.month, day = fields.day;
    if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
    return { year, month, day };
  }

  function ordinalFor(value) {
    const parts = partsFor(value);
    return parts ? Math.floor(Date.UTC(parts.year, parts.month - 1, parts.day) / 86400000) : NaN;
  }

  function dateKey(value) {
    const parts = partsFor(value);
    return parts ? `${String(parts.year).padStart(4, '0')}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}` : '';
  }

  function classify(timestamp, nowOrdinal) {
    const ordinal = ordinalFor(timestamp);
    if (!Number.isFinite(ordinal)) return 'unknown';
    const age = nowOrdinal - ordinal;
    if (age < 0) return 'unknown';
    if (age === 0) return 'today';
    if (age === 1) return 'yesterday';
    if (age >= 2 && age <= 7) return 'week';
    if (age >= 8 && age <= 30) return 'month';
    if (age >= 31 && age <= 365) return 'year';
    return 'older';
  }

  function groupRecords(records, timestampSelector, now = Date.now()) {
    const safeRecords = Array.isArray(records) ? records : [];
    const nowOrdinal = ordinalFor(now);
    const buckets = new Map(GROUPS.map(group => [group.key, []]));
    safeRecords.forEach((record, index) => {
      let timestamp = 0;
      try { timestamp = Number(timestampSelector ? timestampSelector(record) : 0) || 0; } catch { timestamp = 0; }
      const key = Number.isFinite(nowOrdinal) ? classify(timestamp, nowOrdinal) : 'unknown';
      buckets.get(key).push({ record, timestamp, index });
    });

    const result = [];
    for (const group of GROUPS) {
      const items = buckets.get(group.key);
      if (!items.length) continue;
      if (group.key !== 'unknown') {
        items.sort((a, b) => (b.timestamp - a.timestamp) || (a.index - b.index));
      }
      result.push({ key: group.key, label: group.label, count: items.length, records: items.map(item => item.record) });
    }
    return result;
  }

  const api = Object.freeze({ TIME_ZONE, GROUPS, dateKey, ordinalFor, groupRecords });
  root.QoqnusTimeGrouping = api;
  if (typeof module === 'object' && module && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
