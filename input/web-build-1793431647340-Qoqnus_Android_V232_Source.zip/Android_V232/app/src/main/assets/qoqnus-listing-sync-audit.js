(function(root){
 'use strict';
 function hiddenReason(record){
  const outcome=String(record?.dealOutcome||record?.archiveReason||'').trim().toLowerCase();
  if(Number(record?.archiveBucket)===2)return 'archive2';
  if(outcome==='sold'||outcome==='rented')return outcome;
  return '';
 }
 function summarizeRows(rows){
  const source=Array.isArray(rows)?rows:[],hiddenIds=[],visibleIds=[];let archiveBucket2Count=0,soldRentedCount=0;
  for(const record of source){const id=String(record?.id||'');const reason=hiddenReason(record);if(reason){if(reason==='archive2')archiveBucket2Count++;else soldRentedCount++;if(id)hiddenIds.push(id);}else if(id)visibleIds.push(id);}
  return {total:source.length,visible:visibleIds.length,hidden:hiddenIds.length,archiveBucket2Count,soldRentedCount,hiddenIds,visibleIds};
 }
 function countPackKinds(items){const out={listing:0,file:0,customer:0,contact:0,other:0};for(const item of Array.isArray(items)?items:[]){const kind=String(item?.kind||'');out[kind in out?kind:'other']++;}return out;}
 function uniqueIds(values){return [...new Set((Array.isArray(values)?values:[]).map(x=>String(x||'')).filter(Boolean))];}
 function compareSnapshotIds(sourceIdsByKind,receivedIdsByKind,localIdsByKind){
  const out={};for(const kind of ['listing','file']){const source=uniqueIds(sourceIdsByKind?.[kind]),received=new Set(uniqueIds(receivedIdsByKind?.[kind])),local=new Set(uniqueIds(localIdsByKind?.[kind]));out[kind]={expected:source.length,received:source.filter(id=>received.has(id)).length,stored:source.filter(id=>local.has(id)).length,notReceived:source.filter(id=>!received.has(id)),notStored:source.filter(id=>!local.has(id))};}return out;
 }
 // Full source-vs-local comparison is deliberately separate from the current
 // request snapshot: an incremental delta is not expected to resend unchanged rows.
 function compareSourceInventory(sourceIdsByKind,localIdsByKind,snapshotIdsByKind=null){
  const out={};for(const kind of ['listing','file']){const source=uniqueIds(sourceIdsByKind?.[kind]),local=uniqueIds(localIdsByKind?.[kind]),localSet=new Set(local),sourceSet=new Set(source),snapshot=snapshotIdsByKind?new Set(uniqueIds(snapshotIdsByKind?.[kind])):null,missingLocalIds=source.filter(id=>!localSet.has(id));out[kind]={sourceUniqueCount:source.length,localUniqueCount:local.length,matchedCount:source.filter(id=>localSet.has(id)).length,missingLocalIds,missingLocalInSnapshotIds:snapshot?missingLocalIds.filter(id=>snapshot.has(id)):[],missingLocalNotInSnapshotIds:snapshot?missingLocalIds.filter(id=>!snapshot.has(id)):[],snapshotUniqueCount:snapshot?snapshot.size:null,localOnlyIds:local.filter(id=>!sourceSet.has(id))};}return out;
 }
 function mergeAudits(previous,next){
  const a=previous&&typeof previous==='object'?previous:{},b=next&&typeof next==='object'?next:{};
  const merged={...a,...b,kindCounts:{...a.kindCounts},at:Number(b.at)||Number(a.at)||Date.now()};
  for(const key of ['listing','file','customer','contact','other'])merged.kindCounts[key]=(Number(a.kindCounts?.[key])||0)+(Number(b.kindCounts?.[key])||0);
  for(const key of ['receivedIds','fileIds','insertedIds','updatedIds','duplicateIds','conflictIds','keptLocalIds','skippedIds','archivedIds'])merged[key]=uniqueIds([...(a[key]||[]),...(b[key]||[])]);
  merged.skippedItems=[...(a.skippedItems||[]),...(b.skippedItems||[])].filter((item,index,all)=>all.findIndex(x=>String(x.kind)===String(item.kind)&&String(x.id)===String(item.id)&&String(x.reason)===String(item.reason))===index).slice(0,500);
  merged.canonicalCollisionGroups=[...(a.canonicalCollisionGroups||[]),...(b.canonicalCollisionGroups||[])].slice(0,200);
  merged.sourceInventory={...(a.sourceInventory||{}),...(b.sourceInventory||{})};for(const key of ['idsByKind','snapshotIdsByKind','duplicateSourceIdsByKind','conflictingDuplicateIdsByKind','unclassifiedQueueRows'])if(!b.sourceInventory?.[key]&&a.sourceInventory?.[key])merged.sourceInventory[key]=a.sourceInventory[key];merged.requestId=b.requestId||a.requestId||'';merged.sessionId=b.sessionId||a.sessionId||'';merged.requestMode=b.requestMode||a.requestMode||'';merged.requestEpoch=Number(b.requestEpoch)||Number(a.requestEpoch)||0;merged.chunksSeen=(Number(a.chunksSeen)||0)+(Number(b.chunksSeen)||0);merged.chunkOffsets=uniqueIds([...(a.chunkOffsets||[]),...(b.chunkOffsets||[])]);
  return merged;
 }
 root.QoqnusListingSyncAudit={hiddenReason,summarizeRows,countPackKinds,uniqueIds,compareSnapshotIds,compareSourceInventory,mergeAudits};
})(typeof self!=='undefined'?self:globalThis);
