(function (root) {
  'use strict';
  const SIZE = 400;
  const MAX_SOURCE_BYTES = 15 * 1024 * 1024;
  const TARGET_BYTES = 140 * 1024;
  const MAX_OUTPUT_BYTES = 220 * 1024;
  const QUALITIES = [0.86, 0.81, 0.76, 0.71, 0.66, 0.60, 0.54];

  function fail(message) { throw new Error(message); }
  function isWebpDataUrl(value) {
    const s = String(value || '');
    if (s.length > 300000) return false;
    return /^data:image\/webp;base64,[A-Za-z0-9+/]+={0,2}$/.test(s);
  }
  function readAsDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new root.FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('خواندن تصویر پردازش‌شده ناموفق بود.'));
      reader.readAsDataURL(blob);
    });
  }
  async function decodeSource(file) {
    if (typeof root.createImageBitmap === 'function') {
      try {
        const bitmap = await root.createImageBitmap(file, { imageOrientation: 'from-image' });
        if (bitmap && bitmap.width > 0 && bitmap.height > 0) {
          return { image: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close && bitmap.close() };
        }
        bitmap && bitmap.close && bitmap.close();
      } catch (_) { /* Use the image-element fallback. */ }
    }
    const url = root.URL.createObjectURL(file);
    try {
      const image = new root.Image(); image.src = url;
      await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error('بازکردن تصویر ممکن نشد.')); });
      if (!(image.naturalWidth > 0 && image.naturalHeight > 0)) fail('ابعاد تصویر معتبر نیست.');
      return { image, width: image.naturalWidth, height: image.naturalHeight, close: () => root.URL.revokeObjectURL(url) };
    } catch (error) { root.URL.revokeObjectURL(url); throw error; }
  }
  async function normalizeFile(file) {
    if (!file || !String(file.type || '').toLowerCase().startsWith('image/')) fail('یک فایل تصویری انتخاب کنید.');
    if (Number(file.size) > MAX_SOURCE_BYTES) fail('حجم تصویر اصلی بیش از ۱۵ مگابایت است؛ تصویر کوچک‌تری انتخاب کنید.');
    const decoded = await decodeSource(file);
    try {
      const canvas = root.document.createElement('canvas');
      canvas.width = SIZE; canvas.height = SIZE;
      const ctx = canvas.getContext('2d', { alpha: false, colorSpace: 'srgb' });
      if (!ctx) fail('پردازش تصویر در این دستگاه در دسترس نیست.');
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, SIZE, SIZE);
      // Center-crop to a square, filling the 400x400 canvas without stretching.
      const scale = Math.max(SIZE / decoded.width, SIZE / decoded.height);
      const dw = decoded.width * scale, dh = decoded.height * scale;
      ctx.drawImage(decoded.image, (SIZE - dw) / 2, (SIZE - dh) / 2, dw, dh);
      let blob = null;
      for (const quality of QUALITIES) {
        blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/webp', quality));
        if (!blob) fail('ساخت تصویر WebP ناموفق بود.');
        if (blob.type !== 'image/webp') fail('این دستگاه خروجی WebP را پشتیبانی نمی‌کند؛ تصویر ذخیره نشد تا استاندارد یکسان بماند.');
        if (blob.size <= TARGET_BYTES) break;
      }
      if (!blob || blob.size > MAX_OUTPUT_BYTES) fail('حجم تصویر پس از فشرده‌سازی هنوز زیاد است؛ تصویر دیگری انتخاب کنید.');
      const dataUrl = await readAsDataUrl(blob);
      if (!isWebpDataUrl(dataUrl)) fail('قالب نهایی تصویر WebP معتبر نیست.');
      return { dataUrl, width: SIZE, height: SIZE, mime: 'image/webp', bytes: blob.size };
    } finally { try { decoded.close(); } catch (_) {} }
  }
  async function normalizeDataUrl(dataUrl) {
    const s = String(dataUrl || '');
    const match = /^data:image\/(webp|jpeg|jpg|png);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(s);
    if (!match || s.length > 500000) fail('ساختار تصویر مشتری در پشتیبان معتبر نیست.');
    const raw = root.atob(match[2]), bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    const mime = 'image/' + (match[1].toLowerCase() === 'jpg' ? 'jpeg' : match[1].toLowerCase());
    return normalizeFile(new root.Blob([bytes], { type: mime }));
  }
  root.QoqnusCustomerPhoto = { SIZE, TARGET_BYTES, MAX_OUTPUT_BYTES, isWebpDataUrl, normalizeFile, normalizeDataUrl };
})(typeof self !== 'undefined' ? self : globalThis);
