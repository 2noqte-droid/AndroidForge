(function (root) {
  'use strict';

  const SIZE = 400;
  const TARGET_BYTES = 160 * 1024;
  const MAX_OUTPUT_BYTES = 360 * 1024;
  const MAX_SOURCE_BYTES = 15 * 1024 * 1024;
  const WEBP_QUALITIES = [0.84, 0.78, 0.72, 0.66, 0.60, 0.54];
  const JPEG_QUALITIES = [0.84, 0.78, 0.72, 0.66, 0.60, 0.54];

  function fail(message) { throw new Error(message); }

  // Return true only when a JPEG's metadata segments are safely absent. Malformed
  // streams are treated as unknown so they will be decoded and re-encoded.
  function jpegMetadataFree(bytes) {
    if (!bytes || bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) return false;
    let offset = 2;
    while (offset < bytes.length - 1) {
      if (bytes[offset] !== 0xff) return false;
      while (offset < bytes.length && bytes[offset] === 0xff) offset++;
      if (offset >= bytes.length) return false;
      const marker = bytes[offset++];
      if (marker === 0xda || marker === 0xd9) return true; // SOS/EOI: no metadata seen before image data.
      if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      if (offset + 1 >= bytes.length) return false;
      const length = (bytes[offset] << 8) | bytes[offset + 1];
      if (length < 2 || offset + length > bytes.length) return false;
      // APP1 contains EXIF/XMP (including GPS), APP13 commonly carries IPTC,
      // and COM carries comments. Canvas output removes all of these.
      if (marker === 0xe1 || marker === 0xed || marker === 0xfe) return false;
      offset += length;
    }
    return false;
  }

  function readAsDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new root.FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('خواندن تصویر پردازش‌شده ناموفق بود.'));
      reader.readAsDataURL(blob);
    });
  }

  async function decodeSource(file) {
    if (typeof root.createImageBitmap === 'function') {
      try {
        const bitmap = await root.createImageBitmap(file, { imageOrientation: 'from-image' });
        if (bitmap && bitmap.width > 0 && bitmap.height > 0) {
          return { image: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close && bitmap.close() };
        }
        bitmap && bitmap.close && bitmap.close();
      } catch (_) {
        try {
          const bitmap = await root.createImageBitmap(file);
          if (bitmap && bitmap.width > 0 && bitmap.height > 0) {
            return { image: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close && bitmap.close() };
          }
          bitmap && bitmap.close && bitmap.close();
        } catch (_) { /* Fall through to HTMLImageElement. */ }
      }
    }
    const url = root.URL.createObjectURL(file);
    try {
      const image = new root.Image();
      image.src = url;
      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = () => reject(new Error('خواندن تصویر ممکن نشد.'));
      });
      if (!(image.naturalWidth > 0 && image.naturalHeight > 0)) fail('ابعاد تصویر معتبر نیست.');
      return { image, width: image.naturalWidth, height: image.naturalHeight, close: () => root.URL.revokeObjectURL(url) };
    } catch (error) {
      root.URL.revokeObjectURL(url);
      throw error;
    }
  }

  async function alreadyStandard(file, width, height) {
    if (String(file.type || '').toLowerCase() !== 'image/jpeg' || width !== SIZE || height !== SIZE || Number(file.size) > TARGET_BYTES) return false;
    try { return jpegMetadataFree(new Uint8Array(await file.arrayBuffer())); }
    catch (_) { return false; }
  }

  async function normalizeFile(file) {
    if (!file || !String(file.type || '').toLowerCase().startsWith('image/')) fail('یک فایل تصویری انتخاب کنید.');
    if (Number(file.size) > MAX_SOURCE_BYTES) fail('عکس اصلی بیش از ۱۵ مگابایت است؛ تصویر کوچک‌تری انتخاب کنید.');

    const decoded = await decodeSource(file);
    try {
      if (await alreadyStandard(file, decoded.width, decoded.height)) {
        return { dataUrl: await readAsDataUrl(file), width: SIZE, height: SIZE, mime: 'image/jpeg', bytes: Number(file.size), unchanged: true };
      }

      const canvas = root.document.createElement('canvas');
      canvas.width = SIZE;
      canvas.height = SIZE;
      const context = canvas.getContext('2d', { alpha: false });
      if (!context) fail('پردازش تصویر در این دستگاه در دسترس نیست.');
      context.fillStyle = '#fff';
      context.fillRect(0, 0, SIZE, SIZE);

      // Fit instead of crop: preserve the entire building/photo in a square white canvas.
      const scale = Math.min(SIZE / decoded.width, SIZE / decoded.height);
      const drawWidth = decoded.width * scale;
      const drawHeight = decoded.height * scale;
      context.drawImage(decoded.image, (SIZE - drawWidth) / 2, (SIZE - drawHeight) / 2, drawWidth, drawHeight);

      async function encode(type, qualities) {
        let output = null;
        for (const quality of qualities) {
          output = await new Promise((resolve) => canvas.toBlob(resolve, type, quality));
          if (!output || !output.size) return null;
          // Browsers signal unsupported encoders by returning a PNG despite the requested MIME.
          if (String(output.type || '').toLowerCase() !== type) return null;
          if (output.size <= TARGET_BYTES) break;
        }
        return output;
      }
      // Match the Chrome extension: prefer WebP, then fall back to JPEG when unsupported
      // or when the WebP encoder cannot produce an output within the transfer size limit.
      let blob = await encode('image/webp', WEBP_QUALITIES);
      if (!blob || blob.size > MAX_OUTPUT_BYTES) blob = await encode('image/jpeg', JPEG_QUALITIES);
      if (!blob || blob.size > MAX_OUTPUT_BYTES) fail('حجم تصویر پس از بهینه‌سازی هنوز زیاد است؛ تصویر دیگری انتخاب کنید.');
      return { dataUrl: await readAsDataUrl(blob), width: SIZE, height: SIZE, mime: blob.type, bytes: blob.size, unchanged: false };
    } finally {
      try { decoded.close(); } catch (_) { /* Ignore decoder cleanup failures. */ }
    }
  }

  async function normalizeDataUrl(dataUrl) {
    const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(String(dataUrl || ''));
    if (!match) fail('قالب تصویر دریافتی معتبر نیست.');
    const mime = 'image/' + (match[1].toLowerCase() === 'jpg' ? 'jpeg' : match[1].toLowerCase());
    const raw = root.atob(match[2]);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    const blob = new root.Blob([bytes], { type: mime });
    const result = await normalizeFile(blob);
    return result;
  }

  root.QoqnusImageNormalizer = {
    SIZE,
    TARGET_BYTES,
    MAX_OUTPUT_BYTES,
    normalizeFile,
    normalizeDataUrl,
    jpegMetadataFree
  };
})(typeof self !== 'undefined' ? self : globalThis);
