# یادداشت ساخت AndroidForge — V199

خطای Kotlin قبلی `Unresolved reference 'singleLine'` با `isSingleLine = true` اصلاح شده بود. در V199 این property صحیح حفظ شده است.

برای این بسته باید پس از بارگذاری ZIP سورس، فرایند AndroidForge را اجرا کرد. اگر Build شکست خورد، از همان Run در GitHub Actions artifact `AndroidForge-logs` یا متن بخش `Build project` و `Diagnose failure` را دریافت کنید.

این محیط Android SDK/ANDROID_HOME و Gradle ندارد؛ بنابراین در اینجا APK نهایی کامپایل نشده و این بسته نباید به‌عنوان APK آماده نصب تلقی شود. توکن GitHub یا اسرار مخزن را در گزارش ارسالی منتشر نکنید.
