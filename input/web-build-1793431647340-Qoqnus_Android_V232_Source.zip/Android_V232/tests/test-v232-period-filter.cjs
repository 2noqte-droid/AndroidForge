'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const Grouping = require('../app/src/main/assets/qoqnus-time-grouping.js');
const app = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/app.js'), 'utf8');
const extract = name => {
  const match = app.match(new RegExp(`function ${name}\\([^)]*\\)\\s*\\{[\\s\\S]*?\\n\\}`, 'm'));
  assert.ok(match, `${name} is present`);
  return match[0];
};
const fixedNow = Date.parse('2026-03-25T08:00:00.000Z'); // 11:30 Tehran, Wednesday.
class FixedDate extends Date { static now() { return fixedNow; } }
const context = vm.createContext({
  Date: FixedDate,
  window: { QoqnusTimeGrouping: Grouping },
  Number,
  String,
  Math,
  Object,
  Array
});
vm.runInContext([
  extract('parseRecordTimestamp'),
  extract('recordCreatedTimestamp'),
  extract('matchesPeriod'),
  'globalThis.matchesPeriodUnderTest = matchesPeriod;'
].join('\n'), context);
const matches = context.matchesPeriodUnderTest;
const tehranToday = Date.parse('2026-03-25T02:00:00Z'); // 05:30 Tehran, today.
const tehranYesterday = Date.parse('2026-03-24T02:00:00Z');
const lastWeek = Date.parse('2026-03-16T02:00:00Z');
const lastMonth = Date.parse('2026-02-20T02:00:00Z');
const lastYear = Date.parse('2025-06-20T02:00:00Z');
assert.equal(matches({ createdAt: tehranToday }, 'day'), true);
assert.equal(matches({ createdAt: tehranYesterday }, 'day'), false);
assert.equal(matches({ createdAt: tehranYesterday }, 'week'), true);
assert.equal(matches({ createdAt: lastWeek }, 'week'), false);
assert.equal(matches({ createdAt: lastWeek }, 'month'), true);
assert.equal(matches({ createdAt: lastMonth }, 'month'), false);
assert.equal(matches({ createdAt: lastMonth }, 'year'), true);
assert.equal(matches({ createdAt: lastYear }, 'year'), false);
assert.equal(matches({ createdAt: lastMonth, updatedAt: tehranToday }, 'day'), false,
  'a recently edited old record must remain outside the today filter');
assert.equal(matches({ updatedAt: tehranToday }, 'day'), false,
  'missing createdAt must not be guessed from updatedAt');
console.log('V232 Tehran date filters: PASS (calendar-day windows, week boundary, month/year filters, original creation date only)');
