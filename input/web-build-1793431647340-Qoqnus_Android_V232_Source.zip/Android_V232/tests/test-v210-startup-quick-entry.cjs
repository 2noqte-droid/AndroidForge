'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));
const activity = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
const androidManifest = fs.readFileSync(path.join(root, 'app/src/main/AndroidManifest.xml'), 'utf8');
const build = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const cases = [];
const test = (name, fn) => cases.push({name, fn});

test('V223 versions and cache identifiers are aligned', () => {
  assert.match(js, /const APP_VERSION='V232'/);
  assert.match(html, /qoqnus-build" content="V232-three-way-sync-time-groups/);
  assert.match(html, /app\.js\?v=232-three-way-sync-time-groups/);
  assert.match(html, /app\.css\?v=232-tehran-time-groups/);
  assert.match(sw, /qoqnus-mobile-pwa-v232-three-way-sync-time-groups/);
  assert.match(manifest.start_url, /build=V232-three-way-sync-time-groups/);
  assert.match(activity, /build=V232-three-way-sync-time-groups/);
  assert.match(build, /versionCode\s*=\s*42/);
  assert.match(build, /versionName\s*=\s*"2\.0\.36"/);
});

test('startup displays four PIN positions and a three-column 0-9 keypad with clear/backspace', () => {
  assert.match(html, /id="pinKeypadPanel"/);
  assert.match(html, /id="pinDigitsDisplay"/);
  for (const key of ['1','2','3','4','5','6','7','8','9','0','backspace','clear']) assert.ok(html.includes(`data-pin-key="${key}"`), `missing keypad key ${key}`);
  assert.match(js, /function updatePinIndicators\(\)/);
  assert.match(js, /function configureLockMode\(\)/);
  assert.match(js, /unlockQuickPin\(input\)/);
  assert.match(css, /\.pin-keypad-grid\s*\{\s*display:grid;grid-template-columns:repeat\(3/);
});

test('phone focus/input switches to quick-entry without clearing digits and without showing private app shell', () => {
  assert.match(html, /id="quickEntryPhone" type="tel" inputmode="tel"/);
  assert.match(js, /phone\.addEventListener\('focus',\(\)=>\{quickEntryPhone=phone\.value;enterQuickEntryMode\(\)\.catch/);
  assert.match(js, /phone\.addEventListener\('input',\(\)=>\{quickEntryPhone=phone\.value;enterQuickEntryMode\(\)\.catch/);
  assert.match(js, /function showQuickEntryControls\(\)/);
  assert.match(js, /\$\('unlockForm'\)\?\.classList\.add\('hidden'\)/);
  assert.match(js, /quickEntryMode=true;fullOfficeUnlocked=false/);
  const quickMode = js.slice(js.indexOf('async function enterQuickEntryMode()'), js.indexOf('\nfunction exitQuickEntryMode('));
  assert.doesNotMatch(quickMode, /showApp\(\)/);
  assert.match(js, /\$\('quickEntryFile'\)\.addEventListener\('click',\(\)=>startQuickEntryForm\('file'\)/);
  assert.match(js, /\$\('quickEntryCustomer'\)\.addEventListener\('click',\(\)=>startQuickEntryForm\('customer'\)/);
});

test('first-run focus still changes to quick-entry but disables saves until secure vault setup', () => {
  const quickMode = js.slice(js.indexOf('async function enterQuickEntryMode()'), js.indexOf('\nfunction exitQuickEntryMode('));
  assert.match(quickMode, /showQuickEntryControls\(\);/);
  assert.match(quickMode, /if\(!configured\)\{/);
  assert.match(quickMode, /quickEntryFile'\)\.disabled=true/);
  assert.match(quickMode, /quickEntryCustomer'\)\.disabled=true/);
  assert.match(quickMode, /راه‌اندازی اولیه لازم است/);
  assert.match(js, /quickEntryBack'\)\.addEventListener\('click',\(\)=>exitQuickEntryMode\(\)/);
});

test('quick entry reuses the actual customer/file forms and restores them afterward', () => {
  assert.match(html, /id="quickEntryFormHost"/);
  assert.match(js, /quickFormContext=\{kind,form,parent,nextSibling\}/);
  assert.match(js, /\$\('quickEntryFormHost'\)\.appendChild\(form\)/);
  assert.match(js, /function restoreQuickEntryForm\(\)/);
  assert.match(js, /function cancelQuickEntryForm\(\)/);
  assert.match(js, /if\(quickEntryMode\)\{finishQuickEntrySave\('customer'/);
  assert.match(js, /if\(quickEntryMode\)\{quickEntryStagedFiles=\[\];setStatus\('quickMediaStatus'/);
  assert.match(js, /function finishQuickEntrySave\(kind,message\)/);
  assert.match(js, /cryptoKey=null;fullOfficeUnlocked=false/);
});

test('camera/gallery images are staged then processed by existing image compressor and file saver', () => {
  assert.match(html, /id="quickCameraInput"[^>]*accept="image\/\*" capture="environment"/);
  assert.match(html, /id="quickGalleryInput"[^>]*accept="image\/\*" multiple/);
  assert.match(html, /id="quickMediaChooser"/);
  assert.match(js, /async function acceptQuickEntryImages\(fileList\)/);
  assert.match(js, /async function compressImage\(file\)/);
  assert.match(js, /const chosen=\[\.\.\.\(quickEntryMode\?quickEntryStagedFiles:\[\]\),\.\.\.\(\$\('filePhotos'\)\.files\|\|\[\]\)\]/);
  assert.match(js, /imageDataUrls:photos,imageUrls:photos/);
});

test('Android file chooser preserves image requests and camera output is internal via FileProvider', () => {
  assert.match(activity, /fileChooserParams\?\.acceptTypes/);
  assert.match(activity, /isCaptureEnabled == true/);
  assert.match(activity, /MediaStore\.ACTION_IMAGE_CAPTURE/);
  assert.match(activity, /FileProvider\.getUriForFile/);
  assert.match(activity, /type = "image\/\*"/);
  assert.match(androidManifest, /androidx\.core\.content\.FileProvider/);
  assert.ok(fs.existsSync(path.join(root, 'app/src/main/res/xml/file_paths.xml')));
});

test('native splash uses Phoenix app icon and is removed only after first app load', () => {
  assert.match(activity, /startupSplashView: View\?/);
  assert.match(activity, /setImageResource\(R\.drawable\.ic_launcher\)/);
  assert.match(activity, /if \(isApp && !startupSplashDismissed\)/);
  assert.match(activity, /splash\.animate\(\)\.alpha\(0f\)\.setDuration\(180L\)/);
});

test('unique HTML ids and key quick-entry event handlers', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  const duplicates = ids.filter((id, i) => ids.indexOf(id) !== i);
  assert.deepEqual([...new Set(duplicates)], []);
  for (const id of ['quickMediaChoose','quickMediaCamera','quickMediaGallery','quickMediaCancel','quickEntryBack','quickEntryStatus','quickMediaStatus']) assert.ok(html.includes(`id="${id}"`), `missing ${id}`);
});

(async()=>{for(const item of cases){item.fn();process.stdout.write(`PASS ${item.name}\n`);}process.stdout.write(`V223 startup/quick-entry source checks: ${cases.length} passed. These are source-level checks, not emulator/device tests.\n`)})().catch(e=>{console.error(e);process.exitCode=1});
