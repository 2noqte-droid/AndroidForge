'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const rootDir = path.resolve(__dirname, '..');
const assets = path.join(rootDir, 'app/src/main/assets');
const js = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));
const build = fs.readFileSync(path.join(rootDir, 'app/build.gradle.kts'), 'utf8');
const tests = [];
const test = (name, fn) => tests.push({ name, fn });
test('customer image controls support standard Android gallery/file picker without broad storage permission', () => {
  assert.match(html, /id="customerPhotoFile"[^>]*type="file" accept="image\/\*"/);
  assert.match(html, /id="chooseCustomerPhoto"/);
  assert.match(html, /id="removeCustomerPhoto"/);
  assert.doesNotMatch(fs.readFileSync(path.join(rootDir,'app/src/main/AndroidManifest.xml'),'utf8'), /READ_EXTERNAL_STORAGE|READ_MEDIA_IMAGES/);
});
test('customer photo encoder enforces WebP 400-square center crop, EXIF orientation decoding, and size guard', () => {
  const normalizer = fs.readFileSync(path.join(assets, 'qoqnus-customer-photo.js'), 'utf8');
  assert.match(normalizer, /const SIZE = 400/);
  assert.match(normalizer, /imageOrientation: 'from-image'/);
  assert.match(normalizer, /Math\.max\(SIZE \/ decoded\.width, SIZE \/ decoded\.height\)/);
  assert.match(normalizer, /canvas\.toBlob\(resolve, 'image\/webp', quality\)/);
  assert.match(normalizer, /MAX_SOURCE_BYTES = 15 \* 1024 \* 1024/);
  assert.match(normalizer, /MAX_OUTPUT_BYTES = 220 \* 1024/);
});
test('customer profile image is retained by save/edit/delete-preview flow and displayed on cards/details', () => {
  assert.match(js, /profilePhotoWebp:pendingCustomerPhotoWebp\|\|''/);
  assert.match(js, /'profilePhotoWebp'\]\.some/);
  assert.match(js, /pendingCustomerPhotoWebp=customerPhotoValue\(r\)/);
  assert.match(js, /function makeCustomerPhotoElement/);
  assert.match(js, /makeCustomerPhotoElement\(r,'thumb'\)/);
  assert.match(js, /makeCustomerPhotoElement\(r,'detail'\)/);
  assert.match(js, /function clearCustomerPhoto\(\)/);
  assert.match(css, /\.qoqnus-customer-photo--thumb/);
  assert.match(css, /\.qoqnus-customer-photo--detail/);
});
test('backup v2 includes customer WebP and refuses corrupted image restore before commit', () => {
  assert.match(js, /profilePhotoWebp/);
  assert.match(js, /QoqnusCustomerPhoto\.normalizeDataUrl\(record\.profilePhotoWebp\)/);
  assert.match(js, /تصویر مشتری .* قابل بازیابی نیست/);
  assert.doesNotMatch(js, /delete record\.profilePhotoWebp/);
  assert.match(js, /QoqnusBackupCore\.createBackupDocument/);
  assert.match(js, /attachmentCount/);
});
test('sync fingerprint and sync record preserve bounded customer WebP payload for changed customer records', () => {
  assert.match(js, /kind==='customer'&&key==='profilePhotoWebp'/);
  assert.match(js, /profilePhotoWebp/);
  assert.match(js, /syncJournalFingerprint\(kind,record\)/);
  assert.match(js, /syncRec=safeSyncRecord\(kind,record\),fp=await fingerprint\(syncRec\)/);
});
test('theme/contrast V219 and customer processor cache/build identifiers align', () => {
  assert.match(js, /const APP_VERSION='V232'/);
  assert.match(html, /qoqnus-customer-photo\.js\?v=1-customer-webp-400/);
  assert.match(sw, /qoqnus-customer-photo\.js\?v=1-customer-webp-400/);
  assert.match(sw, /qoqnus-mobile-pwa-v232-three-way-sync-time-groups/);
  assert.match(manifest.start_url, /build=V232-three-way-sync-time-groups/);
  assert.match(build, /versionCode\s*=\s*42/);
  assert.match(build, /versionName\s*=\s*"2\.0\.36"/);
});
(async () => {
  const normalizerPath = path.join(assets, 'qoqnus-customer-photo.js');
  require(normalizerPath);
  const normalizer = global.QoqnusCustomerPhoto;
  const old = { createImageBitmap: global.createImageBitmap, FileReader: global.FileReader, document: global.document };
  try {
    let options, drawArgs, canvasSize, outType;
    global.createImageBitmap = async (_file, opts) => { options = opts; return { width: 800, height: 400, close() {} }; };
    global.FileReader = class { readAsDataURL(blob) { blob.arrayBuffer().then(ab => { this.result = `data:${blob.type};base64,${Buffer.from(ab).toString('base64')}`; this.onload(); }).catch(e => this.onerror(e)); } };
    global.document = { createElement(name) { assert.equal(name, 'canvas'); return { width: 0, height: 0, getContext() { return { fillStyle: '', fillRect() {}, drawImage(...args) { drawArgs = args; } }; }, toBlob(cb,type) { outType=type; cb(new Blob([Buffer.from('webp-data')], {type:'image/webp'})); } }; } };
    const result = await normalizer.normalizeFile({ type:'image/png', size:1000 });
    assert.equal(result.width, 400); assert.equal(result.height, 400); assert.equal(result.mime, 'image/webp'); assert.match(result.dataUrl, /^data:image\/webp;base64,/);
    assert.equal(options.imageOrientation, 'from-image'); assert.equal(outType, 'image/webp');
    assert.equal(drawArgs[1], -200); assert.equal(drawArgs[2], 0); assert.equal(drawArgs[3], 800); assert.equal(drawArgs[4], 400);
    console.log('PASS image normalizer mock proves 400x400 WebP center crop and EXIF-aware decoder option');
  } finally { global.createImageBitmap=old.createImageBitmap; global.FileReader=old.FileReader; global.document=old.document; }
  let failures=0;
  for (const item of tests) { try { await item.fn(); console.log('PASS '+item.name); } catch (e) { failures++; console.error('FAIL '+item.name+'\n'+(e.stack||e)); } }
  console.log(`V219 customer photo source checks: ${tests.length-failures}/${tests.length} passed`);
  if (failures) process.exitCode=1;
})();
