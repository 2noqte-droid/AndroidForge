'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Grouping = require('../app/src/main/assets/qoqnus-time-grouping.js');

const now = Date.parse('2026-10-31T21:30:00.000Z'); // 2026-11-01 01:00 in Tehran.
const rows = [
  { id: 'today-old', createdAt: Date.parse('2026-10-31T21:01:00.000Z') },
  { id: 'yesterday', createdAt: Date.parse('2026-10-31T20:00:00.000Z') },
  { id: 'week-2', createdAt: Date.parse('2026-10-30T12:00:00.000Z') },
  { id: 'week-7', createdAt: Date.parse('2026-10-25T12:00:00.000Z') },
  { id: 'month-8', createdAt: Date.parse('2026-10-24T12:00:00.000Z') },
  { id: 'month-30', createdAt: Date.parse('2026-10-02T12:00:00.000Z') },
  { id: 'year-31', createdAt: Date.parse('2026-10-01T12:00:00.000Z') },
  { id: 'year-365', createdAt: Date.parse('2025-11-01T12:00:00.000Z') },
  { id: 'older-366', createdAt: Date.parse('2025-10-31T12:00:00.000Z') },
  { id: 'today-new', createdAt: Date.parse('2026-10-31T21:20:00.000Z') },
  { id: 'future', createdAt: Date.parse('2026-11-02T12:00:00.000Z') },
  { id: 'missing' },
  { id: 'invalid', createdAt: 'not-a-date' }
];

const groups = Grouping.groupRecords(rows, r => r.createdAt, now);
const ids = Object.fromEntries(groups.map(g => [g.key, g.records.map(r => r.id)]));
assert.deepEqual(groups.map(g => g.key), ['today', 'yesterday', 'week', 'month', 'year', 'older', 'unknown']);
assert.deepEqual(ids.today, ['today-new', 'today-old']);
assert.deepEqual(ids.yesterday, ['yesterday']);
assert.deepEqual(ids.week, ['week-2', 'week-7']);
assert.deepEqual(ids.month, ['month-8', 'month-30']);
assert.deepEqual(ids.year, ['year-31', 'year-365']);
assert.deepEqual(ids.older, ['older-366']);
assert.deepEqual(ids.unknown, ['future', 'missing', 'invalid']);
assert.equal(groups.reduce((sum, g) => sum + g.count, 0), rows.length, 'every record belongs to exactly one group');
assert.equal(new Set(groups.flatMap(g => g.records.map(r => r.id))).size, rows.length, 'no record appears twice');
assert.equal(Grouping.dateKey(now), '2026-11-01', 'Tehran date is independent of device timezone');
assert.equal(Grouping.TIME_ZONE, 'Asia/Tehran');

// Filter-before-grouping behavior: records excluded by the active search are never counted.
const filtered = rows.filter(r => r.id.startsWith('week-'));
const filteredGroups = Grouping.groupRecords(filtered, r => r.createdAt, now);
assert.equal(filteredGroups.reduce((sum, g) => sum + g.count, 0), 2);
assert.deepEqual(filteredGroups.map(g => g.key), ['week']);

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'app/src/main/assets/sw.js'), 'utf8');
const createdHelper = app.match(/function recordCreatedTimestamp\(record\)\s*\{([\s\S]*?)\n\}/)?.[1] || '';
assert.ok(createdHelper, 'creation timestamp selector exists');
const createdFields = createdHelper.match(/for\s*\(const key of \[([^\]]+)\]/)?.[1] || '';
assert.ok(createdFields, 'creation field whitelist exists');
assert.doesNotMatch(createdFields, /updatedAt|updated_at|lastModified/i, 'creation bucketing never falls back to last update');
assert.match(app, /appendTimeGroupedRecords\(list,filtered,[\s\S]*?'customer'\)/);
assert.match(app, /appendTimeGroupedRecords\(list,filtered,[\s\S]*?'file'\)/);
assert.match(app, /buildTimeGroupedSections\(list,filtered,'listing'/);
assert.match(html, /qoqnus-time-grouping\.js\?v=1-tehran-calendar-groups/);
assert.match(sw, /qoqnus-time-grouping\.js\?v=1-tehran-calendar-groups/);
const periodFilter = app.match(/function matchesPeriod\(r,period\)\{([\s\S]*?)\n?\}/)?.[1] || '';
assert.match(periodFilter, /recordCreatedTimestamp\(r\)/, 'period filters must use original creation time');
assert.match(periodFilter, /QoqnusTimeGrouping/ , 'period filters must use Tehran calendar helpers');
assert.doesNotMatch(periodFilter, /recordTimestamp\(r\)|new Date\(ts\)/, 'period filters must not use updated timestamp or device-local calendar');
assert.match(html, /id=\"syncRunSummary\"/, 'sync view must show persisted operation summary');
assert.match(app, /createdByKind/);
assert.match(app, /updatedByKind/);
assert.match(app, /deletedByKind/);
assert.match(app, /durableSyncProcessedAckIdsV1/, 'outgoing counts must be idempotent across repeated ACK processing');
assert.match(app, /summary\.imagesReceived\+=/);
assert.match(app, /summary\.imagesSentConfirmed=\(Number\(summary\.imagesSentConfirmed\)\|\|0\)\+\(Array\.isArray\(ack\?\.accepted\)\?ack\.accepted\.length:0\)/);
assert.match(app, /lastSuccess>0&&lastSuccess<=Date\.now\(\)&&Date\.now\(\)-lastSuccess<24\*60\*60\*1000/, 'daily sync reminder is based on elapsed 24 hours');
console.log('V232 Tehran time grouping + sync transparency: PASS (calendar boundaries, date-created filters, UI groups, durable ACK counters, media counts and 24h reminder)');
