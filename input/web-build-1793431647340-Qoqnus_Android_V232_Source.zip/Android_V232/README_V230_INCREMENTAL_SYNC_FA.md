# ققنوس V230 — اصلاح همگام‌سازی افزایشی آگهی‌ها

## خلاصه
این نسخه برای جلوگیری از جاافتادن آگهی‌های جدید و ویرایش‌شده در همگام‌سازی افزایشی آماده شده است. کلاینت اندروید از همان صف رمزگذاری‌شده و ACK موجود استفاده می‌کند؛ تغییر اصلی در افزونهٔ Chrome است تا رکوردهای محلی در صورت نبود/کهنه بودن رویداد change-journal دوباره با cursor و ACK هر دستگاه تطبیق داده شوند.

## نسخه‌ها
- Android source: `2.0.34`, `versionCode=40`, `APP_VERSION=V230`
- Chrome extension: `4.5.155`
- Existing sync contract: `qoqnus.peer-sync.v1` / `qoqnus.sealed-queue.v1`

## فایل‌های کلیدی
- `app/src/main/assets/app.js`: کلاینت موبایل صف پایدار و ACK پس از ذخیرهٔ معتبر؛ مسیر پروتکل داده بازنویسی نشده است.
- `app/src/main/assets/index.html`, `sw.js`, `manifest.webmanifest`: شناسه‌های build/cache به V230 تغییر کرده‌اند تا منابع قدیمی کش نشوند.
- `app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt`: شناسه build URL همسان شده است.
- `app/build.gradle.kts`: نسخه به 2.0.34 / code 40 افزایش یافته است.

## نصب/Build
این بسته سورس است، نه APK. برای ساخت، پروژه را با Android Gradle Plugin و Android SDK سازگار (compileSdk 35، JDK 17) در محیط اندروید باز و `assembleDebug` یا `assembleRelease` اجرا کنید. APK در این محیط ساخته نشده است.

## رفتار مورد انتظار
پس از همگام‌سازی اولیه، آگهی جدید یا ویرایش‌شده در افزونه باید در درخواست افزایشی بعدی از طریق همان change-journal و ACK مستقل هر دستگاه ارسال شود. نیازی به پاک‌کردن داده یا اجرای همگام‌سازی کامل نیست، مگر آنکه دورهٔ صف سمت سرور منقضی شده باشد و `fullSyncRequired` واقعاً فعال شده باشد.
