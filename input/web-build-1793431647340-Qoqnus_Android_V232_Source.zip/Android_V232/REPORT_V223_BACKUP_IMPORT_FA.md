# گزارش فنی ققنوس V223 — رفع خواندن فایل پشتیبان در Android WebView

## نتیجه ریشه‌یابی

در مسیر قبلی بازیابی، WebView از `WebChromeClient.onShowFileChooser` یک `content://` URI را از انتخاب‌گر اندروید دریافت می‌کرد و کد JavaScript مستقیماً `file.text()` را برای خواندن فایل صدا می‌زد. در `MainActivity.kt` نیز `WebSettings.allowContentAccess` عمداً `false` بود. مستندات Android تصریح می‌کند این تنظیم دسترسی WebView به URLهای content provider را غیرفعال می‌کند. بنابراین مسیر انتخاب فایل و مسیر خواندن فایل با یکدیگر هماهنگ نبودند.

## اصلاحات انجام‌شده

### ۱. خواندن فایل در Native با ContentResolver

- `MainActivity.kt` درخواست فایل JSON را از روی `acceptTypes` تشخیص می‌دهد.
- انتخاب‌گر از `ACTION_OPEN_DOCUMENT` استفاده می‌کند و مجوز گستردهٔ حافظه درخواست نمی‌شود.
- پس از انتخاب، فایل از طریق `ContentResolver.openInputStream(uri)` خوانده می‌شود؛ WebView دیگر لازم نیست مستقیماً URI را باز کند.
- فایل با قطعات ۴۸ KiB از طریق پل محدودشدهٔ `WebViewCompat.addWebMessageListener` به JavaScript منتقل می‌شود.
- ترتیب آفست، سقف ۱۵۰ MiB، اندازهٔ اعلام‌شده و پایان واقعی جریان کنترل می‌شوند.
- `allowContentAccess=false` حفظ شده است؛ برای رفع مشکل امنیت WebView تضعیف نشده است.

### ۲. پردازش فایل در JavaScript

فایل جدید `qoqnus-backup-file-reader.js`:
- قطعات Base64 را با کنترل آفست و UTF-8 تجمیع می‌کند.
- مرز جدا شدن بایت‌های فارسی بین قطعات را مدیریت می‌کند.
- BOM ابتدای JSON را حذف می‌کند.
- فایل خالی، UTF-8 خراب، آفست اشتباه، اندازه ناقص و فایل بزرگ‌تر از حد را رد می‌کند.
- در PWA/مرورگر از `FileReader` استفاده می‌کند و `file.text()` فقط fallback است.

### ۳. حفظ مسیر خروجی و اعتبارسنجی

- تابع `exportBackup`, پل `__qoqnusTakeBackupChunk`, `normalizeBackupPayload` و `downloadRecoveryBackup` حفظ شده‌اند.
- فایل تولیدشده پیش از ذخیره با `QoqnusBackupCore.verifyBackupDocument` دوباره اعتبارسنجی می‌شود.
- بازیابی همچنان از اعتبارسنجی V2 و پشتیبانی قالب قدیمی V1 استفاده می‌کند.
- نوشتن دیتابیس همچنان در تراکنش واحد انجام می‌شود و پیش از جایگزینی، نسخهٔ اضطراری تهیه می‌شود.
- تا پیش از اعتبارسنجی کامل، تغییر دیتابیس آغاز نمی‌شود.

## فایل‌های تغییرکرده

- `app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt`
- `app/src/main/assets/app.js`
- `app/src/main/assets/index.html`
- `app/src/main/assets/sw.js`
- `app/src/main/assets/manifest.webmanifest`
- `app/src/main/assets/qoqnus-backup-file-reader.js` (جدید)
- تست‌های رگرسیون در `tests/`
- `app/build.gradle.kts` برای شناسهٔ نسخهٔ جدید

## نسخه

- `versionCode = 33`
- `versionName = 2.0.27`
- برچسب Build: `V223-backup-file-import`

## آزمون‌ها

- ۱۵ فایل آزمون Node.js: همگی موفق.
- آزمون round-trip JSON تولیدشدهٔ خود ققنوس و اعتبارسنجی V2: موفق.
- آزمون سازگاری قالب legacy V1 در تست هستهٔ پشتیبان: موفق.
- آزمون شبیه‌سازی انتقال Native با قطعات ۴۸ KiB، UTF-8 شکسته‌شده در مرز قطعه و BOM: موفق.
- آزمون رد فایل خالی، UTF-8 خراب، آفست نادرست، اندازهٔ ناقص و حجم بیش از حد: موفق.
- آزمون بررسی وجود/اتصال توابع خروجی و بازیابی: موفق.
- آزمون همگام‌سازی با سورس واقعی افزونهٔ 4.5.154 و `mobile-peer.php` موجود: موفق.
- `node --check` برای فایل‌های JavaScript مرتبط: موفق.
- `unzip -t` بستهٔ تحویل: موفق.

## محدودیت‌های تأیید

- در محیط حاضر Gradle، Gradle Wrapper و Android SDK نصب/در دسترس نبود؛ APK ساخته نشده است.
- آزمون فیزیکی روی دستگاه Android و انتخاب فایل از ارائه‌دهنده‌های واقعی مانند Downloads/Drive اجرا نشده است.
- فایل JSON واقعی‌ای که در گوشی کاربر خطا می‌دهد در این پیام بارگذاری نشده؛ آزمون انجام‌شده با JSON ساخته‌شده توسط همان هستهٔ پشتیبان ققنوس بوده است.

بنابراین اصلاح مسیر خواندن فایل در سورس و آزمون قرارداد تأیید شده است؛ اما تأیید نهایی روی گوشی به نصب APK ساخته‌شده از همین سورس و تست فایل واقعی کاربر نیاز دارد.
