(()=>{
'use strict';
const $=id=>document.getElementById(id);
const TITLES={overviewTab:'پیشخوان',queueTab:'آگهی ققنوس',officeAdsTab:'ثبت آگهی دفتری',archiveTab:'بایگانی فایل‌ها',contactsTab:'دفتر فایل',customersTab:'دفتر مشتریان',draftsTab:'پیش‌نویس‌ها',invitationTab:'دعوت مشتریان',settingsTab:'تنظیمات و اتصالات',connectionsTab:'اتصال روبیکا و ایتا',sendSettingsTab:'قالب و تنظیمات انتشار',defaultImagesTab:'تصاویر پیش‌فرض',syncTab:'اتصال سرورها',backupTab:'پشتیبان‌گیری و بازیابی'};
function activate(id){const btn=document.querySelector('.wp-nav .tab[data-tab="'+id+'"]');if(btn){btn.click();}else if(typeof window.activateTab==='function'){window.activateTab(id);}updateTitle(id);}
function updateTitle(id){const h=$('pageTitle');if(h)h.textContent=TITLES[id]||document.querySelector('.wp-nav [data-tab="'+id+'"]')?.dataset.pageTitle||'مدیریت افزونه';}
async function renderOverview(){try{
 const d=await chrome.storage.local.get({queue:[],contactArchive:[],qoqnusCustomers:[],qoqnusSync:{apiUrl:'',secret:''},qoqnusCentralOffice:null,rubika:{token:''},eitaa:{enabled:false,token:''},lastQoqnusSync:null});
 const q=Array.isArray(d.queue)?d.queue:[];const active=q.filter(x=>['pending','approved','review'].includes(x.status)).length;const archived=q.filter(x=>['archived','published'].includes(x.status)).length;
 const contactCount=q.filter(x=>x?.source==='office-file').length;
 const customers=Array.isArray(d.qoqnusCustomers)?d.qoqnusCustomers.length:0;
 [['overviewQueueCount',active],['overviewArchiveCount',archived],['overviewContactsCount',contactCount],['overviewCustomersCount',customers]].forEach(([id,v])=>{const e=$(id);if(e)e.textContent=String(v);});
 const c=$('overviewConnectionStatus');if(c){const api=!!String(d.qoqnusSync?.apiUrl||'').trim()&&!!String(d.qoqnusSync?.secret||'').trim(),google=!!(d.qoqnusCentralOffice?.apiUrl&&d.qoqnusCentralOffice?.deviceToken),rubika=!!String(d.rubika?.token||'').trim(),eitaa=!!(d.eitaa?.enabled&&d.eitaa?.token);c.textContent=`سرور ققنوس: ${api?'تنظیم شده':'نیازمند تنظیم'}؛ دفتر گوگل: ${google?'متصل':'نیازمند اتصال'}؛ روبیکا: ${rubika?'دارای توکن':'تنظیم نشده'}؛ ایتا: ${eitaa?'فعال':'غیرفعال'}.`;}
 const sync=$('overviewSyncSummary');if(sync){const last=d.lastQoqnusSync;sync.textContent=last?('آخرین وضعیت همگام‌سازی: '+String(last.status||last.message||'ثبت شده')):'وضعیت آخرین همگام‌سازی پس از اجرای اتصال نمایش داده می‌شود.';}
 }catch(e){const c=$('overviewConnectionStatus');if(c)c.textContent='خواندن وضعیت محلی ناموفق بود: '+String(e?.message||e);}}
function wire(){
 
 const toggle=$('wpSidebarToggle'),overlay=$('wpSidebarOverlay'),shell=document.querySelector('.app-shell');toggle?.addEventListener('click',()=>shell?.classList.toggle('sidebar-open'));overlay?.addEventListener('click',()=>shell?.classList.remove('sidebar-open'));
 document.querySelectorAll('.wp-nav .tab[data-tab]').forEach(b=>b.addEventListener('click',()=>{updateTitle(b.dataset.tab);shell?.classList.remove('sidebar-open');if(b.dataset.tab==='overviewTab')renderOverview();}));
 // Centralized navigation for every settings shortcut and dynamically rendered
 // draft badge. Without this delegated listener, all [data-go-tab] buttons were inert.
 document.addEventListener('click',event=>{
   const trigger=event.target?.closest?.('[data-go-tab]');
   if(!trigger)return;
   const targetId=String(trigger.getAttribute('data-go-tab')||'').trim();
   const target=$(targetId);
   if(!target||!target.classList.contains('tabpage'))return;
   event.preventDefault();
   activate(targetId);
 });
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&['queue','contactArchive','qoqnusCustomers','qoqnusSync','rubika','eitaa','lastQoqnusSync','qoqnusCentralOffice','qoqnusCentralOutbox','qoqnusCentralLastSync'].some(k=>changes[k]))renderOverview();});
 renderOverview();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wire);else wire();
})();
