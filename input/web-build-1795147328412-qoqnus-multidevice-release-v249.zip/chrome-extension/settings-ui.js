(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const TYPES = [
    ['rent_residential','اجاره مسکونی'],['rent_shop','اجاره مغازه و ملک تجاری'],['rent_land','اجاره زمین و باغ'],['rent_other','اجاره سایر املاک'],
    ['sale_residential','فروش مسکونی'],['sale_shop','فروش مغازه و ملک تجاری'],['sale_land','فروش زمین و باغ'],['sale_other','فروش سایر املاک'],['unknown','نوع نامشخص']
  ];
  const DEFAULT_TEMPLATE = `{{title}}
━━━━━━━━━━━━━━━━━━━━
{{deposit}}
{{monthly_rent}}
{{convertible}}
{{sale_price}}
{{price_per_meter}}
{{location}}
{{street}}
{{land_area}}
{{built_area}}
{{year}}
{{rooms}}
{{amenities}}
{{description}}
🏷️ دسته‌بندی:
{{tags}}
━━━━━━━━━━━━━━━━━━━━
{{contact}}
█ ثبت آگهی رایگان  ░░ مشاوره خرید و اجاره`;
  const DEFAULTS = {messageTemplate:DEFAULT_TEMPLATE,imageMode:'second',sendTextFallback:true,includeDescription:true,includeAmenities:true,includeStreet:true,includeTags:true,descriptionMaxLength:400,defaultImages:{}};
  let draftImages = {};
  let busy = false;
  const say = (id, text, good=false) => { const el=$(id); if(!el)return;el.textContent=text;el.className=good?'muted':'muted'; if(text.startsWith('در حال'))el.classList.add('live-work'); };
  function collect() {
    return {
      messageTemplate:$('messageTemplate')?.value || DEFAULT_TEMPLATE,
      imageMode:$('imageMode')?.value || 'second',
      sendTextFallback:!!$('sendTextFallback')?.checked,
      includeDescription:!!$('includeDescription')?.checked,
      includeAmenities:!!$('includeAmenities')?.checked,
      includeStreet:!!$('includeStreet')?.checked,
      includeTags:!!$('includeTags')?.checked,
      descriptionMaxLength:Number($('descriptionMaxLength')?.value || 400),
      defaultImages:{...draftImages}
    };
  }
  function renderImages() {
    const grid=$('defaultImagesGrid'); if(!grid)return; grid.innerHTML='';
    for(const [key,label] of TYPES) {
      const wrap=document.createElement('div');wrap.className='filter';
      const existing=draftImages[key]||'';
      wrap.innerHTML=`<strong>${label}</strong><div class="row"><label>انتخاب تصویر<input type="file" accept="image/png,image/jpeg,image/webp" data-image-type="${key}"></label><div class="muted" data-image-preview="${key}">${existing?`تصویر پیش‌فرض ثبت شده است (${Math.max(1,Math.round(existing.length/1365))} کیلوبایت تقریبی).`:'تصویری انتخاب نشده است.'}${existing?`<br><button type="button" class="alt" data-clear-image="${key}">حذف تصویر</button>`:''}</div></div>`;
      if(existing){const img=document.createElement('img');img.src=existing;img.alt=label;img.loading='lazy';img.style.cssText='max-width:160px;max-height:110px;object-fit:contain;border:1px solid #ddd;border-radius:8px;margin-top:8px';wrap.appendChild(img);}
      grid.appendChild(wrap);
    }
  }
  async function shrinkImage(file) {
    if(!file || !/^image\/(jpeg|png|webp)$/i.test(file.type)) throw new Error('فرمت تصویر باید JPG، PNG یا WebP باشد.');
    const bitmap=await createImageBitmap(file);
    try {
      const max=1440,scale=Math.min(1,max/Math.max(bitmap.width,bitmap.height));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
      const ctx=canvas.getContext('2d'); if(!ctx)throw new Error('پردازش تصویر در این مرورگر پشتیبانی نمی‌شود.');ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
      const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('فشرده‌سازی تصویر ناموفق بود.')),'image/jpeg',0.78));
      if(blob.size>1.25*1024*1024)throw new Error('تصویر پس از فشرده‌سازی هنوز بزرگ است؛ تصویر کوچک‌تری انتخاب کن.');
      const data=await new Promise((resolve,reject)=>{const fr=new FileReader();fr.onload=()=>resolve(String(fr.result));fr.onerror=()=>reject(new Error('خواندن تصویر ناموفق بود.'));fr.readAsDataURL(blob);});
      if(data.length>1800000)throw new Error('حجم دادهٔ تصویر بیش از حد مجاز است.');
      return data;
    } finally { bitmap.close?.(); }
  }
  async function save() {
    if(busy)return;busy=true;const btn=$('saveSendSettings');if(btn){btn.disabled=true;btn.classList.add('is-busy');}
    say('sendSettingsStatus','در حال ذخیرهٔ قالب، تنظیمات ارسال و تصاویر پیش‌فرض…');
    try { const r=await chrome.runtime.sendMessage({type:'RUBIKA_SEND_SETTINGS_SAVE',settings:collect()});if(!r?.ok)throw new Error(r?.error||'تنظیمات ارسال ذخیره نشد.');draftImages={...(r.sendSettings?.defaultImages||draftImages)};say('sendSettingsStatus','تنظیمات ارسال و قالب پیام در حافظهٔ محلی ذخیره شد.',true); }
    catch(e){say('sendSettingsStatus','خطا در ذخیره تنظیمات: '+String(e?.message||e));}
    finally {busy=false;if(btn){btn.disabled=false;btn.classList.remove('is-busy');}}
  }
  async function preview() {
    const btn=$('previewPost');if(btn){btn.disabled=true;btn.classList.add('is-busy');}
    say('sendSettingsStatus','در حال ساخت پیش‌نمایش از قالب فعلی…');
    try {const r=await chrome.runtime.sendMessage({type:'RUBIKA_PREVIEW_POST',settings:collect()});if(!r?.ok)throw new Error(r?.error||'پیش‌نمایش ساخته نشد.');$('messagePreview').textContent=r.post||'پیش‌نمایش خالی است.';say('sendSettingsStatus','پیش‌نمایش آماده شد. برای ذخیرهٔ دائمی، «ذخیره تنظیمات ارسال» را بزن.',true);}
    catch(e){say('sendSettingsStatus','خطا در ساخت پیش‌نمایش: '+String(e?.message||e));}
    finally{if(btn){btn.disabled=false;btn.classList.remove('is-busy');}}
  }
  async function load() {
    const st=await chrome.storage.local.get({rubika:{},eitaa:{enabled:false,token:'',chatId:''},sendSettings:DEFAULTS});
    const r=st.rubika||{}; if($('rubikaToken'))$('rubikaToken').value=r.token||'';
    const ei=st.eitaa||{};if($('eitaaToken'))$('eitaaToken').value=ei.token||'';if($('eitaaChatId'))$('eitaaChatId').value=ei.chatId||'amlak_qoqnus';if($('eitaaEnabled'))$('eitaaEnabled').checked=!!ei.enabled;
    draftImages={...(st.sendSettings?.defaultImages||{})};
    const cfg={...DEFAULTS,...(st.sendSettings||{}),defaultImages:draftImages};
    if($('imageMode'))$('imageMode').value=cfg.imageMode;
    for(const id of ['sendTextFallback','includeDescription','includeAmenities','includeStreet','includeTags'])if($(id))$(id).checked=cfg[id]!==false;
    if($('descriptionMaxLength'))$('descriptionMaxLength').value=String(cfg.descriptionMaxLength||400);
    if($('messageTemplate'))$('messageTemplate').value=cfg.messageTemplate||DEFAULT_TEMPLATE;
    renderImages();
    try{const result=await chrome.runtime.sendMessage({type:'RUBIKA_PREVIEW_POST',settings:cfg});if(result?.ok)$('messagePreview').textContent=result.post;}catch{}
  }
  $('saveSendSettings')?.addEventListener('click',save);
  $('restoreTemplate')?.addEventListener('click',()=>{if(!confirm('قالب پیام به قالب پیشنهادی برگردد؟'))return;$('messageTemplate').value=DEFAULT_TEMPLATE;say('sendSettingsStatus','قالب پیشنهادی جایگزین شد؛ برای ثبت نهایی ذخیره را بزن.');});
  $('previewPost')?.addEventListener('click',preview);
  $('defaultImagesGrid')?.addEventListener('change',async e=>{
    const input=e.target.closest('input[type=file][data-image-type]');if(!input||!input.files?.[0])return;
    const key=input.dataset.imageType;input.disabled=true; say('defaultImagesStatus',`در حال فشرده‌سازی تصویر «${TYPES.find(x=>x[0]===key)?.[1]||key}»…`);
    try{draftImages[key]=await shrinkImage(input.files[0]);renderImages();say('defaultImagesStatus','تصویر آماده شد؛ برای ذخیرهٔ دائمی «ذخیره تنظیمات ارسال» را بزن.',true);}
    catch(err){say('defaultImagesStatus','خطا: '+String(err?.message||err));input.value='';}
    finally{input.disabled=false;}
  });
  $('defaultImagesGrid')?.addEventListener('click',e=>{
    const b=e.target.closest('button[data-clear-image]');if(!b)return;delete draftImages[b.dataset.clearImage];renderImages();say('defaultImagesStatus','تصویر حذف شد؛ برای ثبت تغییر، تنظیمات ارسال را ذخیره کن.');
  });
  $('saveRubika')?.addEventListener('click',async()=>{
    const b=$('saveRubika');b.disabled=true;b.classList.add('is-busy');say('rubikaStatus','در حال ذخیرهٔ اتصال روبیکا…');
    try{await chrome.storage.local.set({rubika:{token:String($('rubikaToken')?.value||'').trim(),chatId:'c0BP6Ev06c8af23c29d26b1614255daa'}});say('rubikaStatus','توکن در ذخیره‌سازی محلی ثبت شد. حالا اتصال را آزمایش کن.',true);}
    catch(e){say('rubikaStatus','خطا در ذخیره توکن: '+String(e?.message||e));}
    finally{b.disabled=false;b.classList.remove('is-busy');}
  });
  $('testSendRubika')?.addEventListener('click',async()=>{
    const b=$('testSendRubika');b.disabled=true;b.classList.add('is-busy');say('rubikaStatus','در حال ارسال پیام آزمایشی واقعی به کانال؛ لطفاً صبر کن…');
    try{
      const token=String($('rubikaToken')?.value||'').trim();if(token)await chrome.storage.local.set({rubika:{token,chatId:'c0BP6Ev06c8af23c29d26b1614255daa'}});
      const r=await chrome.runtime.sendMessage({type:'RUBIKA_SEND_TEST'});if(!r?.ok){const extra=[r?.method?'روش: '+r.method:'',r?.httpStatus?'HTTP: '+r.httpStatus:'',r?.apiStatus?'API: '+r.apiStatus:'',r?.details?'پاسخ: '+r.details:''].filter(Boolean).join(' | ');throw new Error((r?.stage?'مرحلهٔ '+r.stage+' — ':'')+(r?.error||'ارسال پیام آزمایشی ناموفق بود.')+(extra?' | '+extra:''));}
      say('rubikaStatus',`پیام آزمایشی واقعاً به کانال ارسال شد. شناسه پیام: ${r.messageId}`,true);
    }catch(e){say('rubikaStatus','خطا در ارسال آزمایشی کانال: '+String(e?.message||e));}
    finally{b.disabled=false;b.classList.remove('is-busy');}
  });
  async function collectPlatform(kind){
    if(kind==='eitaa')return {enabled:!!$('eitaaEnabled')?.checked,token:String($('eitaaToken')?.value||'').trim(),chatId:String($('eitaaChatId')?.value||'').trim()};
    return {enabled:false,token:'',chatId:''};
  }
  $('saveEitaa')?.addEventListener('click',async()=>{
    const b=$('saveEitaa');b.disabled=true;b.classList.add('is-busy');say('eitaaStatus','در حال ذخیره اتصال ایتا…');
    try{const cfg=await collectPlatform('eitaa');if(cfg.enabled&&(!cfg.token||!cfg.chatId))throw new Error('برای فعال‌کردن ایتا، توکن و شناسهٔ مقصد را وارد کن.');await chrome.storage.local.set({eitaa:cfg});say('eitaaStatus',cfg.enabled?'اتصال ایتا ذخیره شد؛ حالا پیام آزمایشی را بفرست.':'تنظیمات ایتا ذخیره شد؛ ارسال ایتا غیرفعال است.',true);}
    catch(e){say('eitaaStatus','خطا: '+String(e?.message||e));}finally{b.disabled=false;b.classList.remove('is-busy');}
  });
  async function runEitaaTest(buttonId, messageType, progressText, successText){
    const b=$(buttonId);if(!b)return;b.disabled=true;b.classList.add('is-busy');say('eitaaStatus',progressText);
    try{
      const cfg=await collectPlatform('eitaa');if(!cfg.token||!cfg.chatId)throw new Error('توکن و شناسهٔ مقصد ایتا را وارد کن.');
      // A successful test now activates the configured destination, so a working test
      // cannot silently coexist with a disabled Eitaa delivery checkbox.
      const testCfg={...cfg,enabled:true};
      const r=await chrome.runtime.sendMessage({type:messageType,config:testCfg});
      if(!r?.ok){const extra=[r?.stage?'مرحله: '+r.stage:'',r?.httpStatus?'HTTP: '+r.httpStatus:'',r?.apiStatus?'API: '+r.apiStatus:'',r?.details?'پاسخ سرور: '+r.details:''].filter(Boolean).join(' | ');throw new Error((r?.error||'آزمون ایتا ناموفق بود.')+(extra?' | '+extra:''));}
      $('eitaaEnabled').checked=true;await chrome.storage.local.set({eitaa:testCfg});
      say('eitaaStatus',successText+' ایتا اکنون فعال است. وضعیت API: '+(r.result||'موفق'),true);
    }catch(e){say('eitaaStatus','خطا در آزمون ایتا: '+String(e?.message||e));}
    finally{b.disabled=false;b.classList.remove('is-busy');}
  }
  $('testEitaa')?.addEventListener('click',()=>runEitaaTest('testEitaa','EITAA_SEND_TEST','در حال ارسال پیام آزمایشی متنی واقعی به مقصد ایتا…','پیام متنی آزمایشی ارسال شد.'));
  $('testEitaaMedia')?.addEventListener('click',()=>runEitaaTest('testEitaaMedia','EITAA_SEND_MEDIA_TEST','در حال ارسال تصویر آزمایشی همراه کپشن به مقصد ایتا…','تصویر آزمایشی همراه کپشن ارسال شد.'));
  $('testRubika')?.addEventListener('click',async()=>{
    const b=$('testRubika');b.disabled=true;b.classList.add('is-busy');say('rubikaStatus','در حال بررسی اتصال ربات با روبیکا…');
    try{const token=String($('rubikaToken')?.value||'').trim();if(token)await chrome.storage.local.set({rubika:{token,chatId:'c0BP6Ev06c8af23c29d26b1614255daa'}});const r=await chrome.runtime.sendMessage({type:'RUBIKA_TEST'});if(!r?.ok)throw new Error(r?.error||'اتصال برقرار نشد.');say('rubikaStatus','اتصال ربات موفق بود. این آزمون ارسال به کانال را انجام نمی‌دهد.',true);}
    catch(e){say('rubikaStatus','خطا در اتصال روبیکا: '+String(e?.message||e));}
    finally{b.disabled=false;b.classList.remove('is-busy');}
  });
  document.addEventListener('DOMContentLoaded',()=>load().catch(e=>say('sendSettingsStatus','خطای بارگذاری تنظیمات: '+String(e?.message||e))));
  // Chrome local dashboard scripts may load after DOMContentLoaded has already fired in some reloads.
  if(document.readyState!=='loading')load().catch(e=>say('sendSettingsStatus','خطای بارگذاری تنظیمات: '+String(e?.message||e)));
})();
