(() => {
  'use strict';
  const normalizeDigits = value => String(value || '').replace(/[۰-۹٠-٩]/g, ch => {
    const fa = '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch);
    return String(fa >= 0 ? fa : '٠١٢٣٤٥٦٧٨٩'.indexOf(ch));
  }).replace(/\D/g, '');
  const normalizeText = value => String(value || '').toLocaleLowerCase('fa-IR')
    .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .replace(/\s+/g, ' ').trim();
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  function findSearchInput() {
    const selectors = [
      'input[type="search"]',
      'input[placeholder*="جستجو"]', 'input[placeholder*="جستو"]',
      'input[aria-label*="جستجو"]', 'input[aria-label*="Search"]',
      'input[placeholder*="Search"]', 'input[placeholder*="search"]',
      'input[placeholder*="مخاطب"]', 'input[aria-label*="مخاطب"]',
      '[role="search"] input'
    ];
    for (const selector of selectors) {
      const found = [...document.querySelectorAll(selector)].find(el => visible(el) && !el.disabled && !el.readOnly);
      if (found) return found;
    }
    return null;
  }
  function setInputValue(input, value) {
    const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function clickSearchButton(input) {
    const form = input.closest('form');
    if (form) { try { form.requestSubmit(); return; } catch {} }
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
  }
  async function lookup({ phone, name }) {
    const normalizedPhone = normalizeDigits(phone);
    const normalizedName = normalizeText(name);
    if (!/^09\d{9}$/.test(normalizedPhone)) return { ok: false, status: 'lookup-failed', message: 'شماره موبایل معتبر نیست.' };
    let input = findSearchInput();
    if (!input) {
      const searchButton = [...document.querySelectorAll('button,[role="button"]')].find(el => visible(el) && /جستجو|search|مخاطب/i.test([el.getAttribute('aria-label'), el.getAttribute('title'), el.innerText].filter(Boolean).join(' ')));
      if (searchButton) { searchButton.click(); await wait(500); input = findSearchInput(); }
    }
    if (!input) return { ok: false, status: 'lookup-failed', message: 'کادر جست‌وجوی قابل‌شناسایی در روبیکا وب پیدا نشد. وارد صفحهٔ مخاطبان/جست‌وجو شو و دوباره تلاش کن.' };
    try { input.focus(); setInputValue(input, normalizedPhone); clickSearchButton(input); }
    catch (e) { return { ok: false, status: 'lookup-failed', message: 'جست‌وجو در رابط روبیکا وب شروع نشد: ' + String(e?.message || e) }; }
    await wait(1800);
    const body = normalizeText(document.body?.innerText || '');
    const digits = normalizeDigits(document.body?.innerText || '');
    const emptyPhrases = ['موردی یافت نشد','نتیجه ای یافت نشد','نتیجه‌ای یافت نشد','کاربری پیدا نشد','مخاطبی پیدا نشد','مخاطبی یافت نشد','هیچ نتیجه ای','هیچ نتیجه‌ای','no results','no users found','not found'];
    if (emptyPhrases.some(phrase => body.includes(normalizeText(phrase)))) {
      return { ok: true, status: 'no-account', evidence: 'explicit-empty-state', message: 'روبیکا وب پیام صریحِ نبود نتیجه را نشان داد؛ برای اطمینان می‌توان دستی هم بررسی کرد.' };
    }
    if (digits.includes(normalizedPhone)) {
      return { ok: true, status: 'has-account', evidence: 'exact-phone-visible', message: 'شمارهٔ دقیق در محتوای قابل‌مشاهدهٔ نتیجه پیدا شد.' };
    }
    if (normalizedName.length >= 4) {
      const candidates = [...document.querySelectorAll('[role="listitem"], [role="option"], li, article, [class*="contact"], [class*="user"], [class*="search-result"], [class*="SearchResult"]')]
        .filter(el => visible(el) && normalizeText(el.innerText || '').includes(normalizedName));
      if (candidates.length) return { ok: true, status: 'candidate-found', evidence: 'name-match-only', message: 'نتیجه‌ای با نام مشتری پیدا شد، اما شماره در نتیجه دیده نشد؛ تطبیق نیازمند تأیید مدیر است.' };
    }
    return { ok: false, status: 'lookup-failed', evidence: 'no-conclusive-dom-result', message: 'نتیجهٔ قابل‌اعتماد تشخیص داده نشد. این به معنی نداشتن حساب نیست؛ رابط روبیکا ممکن است نتیجه را به شکل دیگری نمایش دهد.' };
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type !== 'QOQNUS_RUBIKA_WEB_LOOKUP') return;
    lookup({ phone: msg.phone, name: msg.name }).then(sendResponse).catch(error => sendResponse({ ok: false, status: 'lookup-failed', message: String(error?.message || error) }));
    return true;
  });
})();
