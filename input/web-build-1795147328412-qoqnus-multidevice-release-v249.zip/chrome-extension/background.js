const QOQNUS_DEFAULT_SYNC_URL='https://aghaj.ir/RobikaBot/rubika_realestate/public/extension-sync.php';
if (typeof importScripts === 'function') importScripts('qoqnus-central-record-sync.js','background-modules/field-validation.js');
const FIXED_RUBIKA_CHAT_ID='c0BP6Ev06c8af23c29d26b1614255daa';
function parseApiJson(raw){
 const s=String(raw||'').replace(/^\uFEFF/,'').trim();
 try{return JSON.parse(s)}catch{}
 const start=s.indexOf('{'); if(start<0) throw new Error('پاسخ روبیکا JSON معتبر ندارد: '+s.slice(0,160));
 let depth=0,inString=false,escape=false;
 for(let i=start;i<s.length;i++){
  const c=s[i];
  if(inString){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')inString=false;continue;}
  if(c==='"'){inString=true;continue;}
  if(c==='{')depth++;
  else if(c==='}'){depth--;if(depth===0)return JSON.parse(s.slice(start,i+1));}
 }
 throw new Error('پاسخ روبیکا ناقص است: '+s.slice(0,160));
}
const LEGACY_DEFAULT_MESSAGE_TEMPLATE = `{{title}}
━━━━━━━━━━━━━━━━━━━━

{{deposit}}
{{monthly_rent}}
{{convertible}}
{{sale_price}}
{{price_per_meter}}
{{location}}
{{street}}
{{land_area}}
{{built_area}}
{{year}}
{{rooms}}
{{amenities}}

{{description}}


{{tags}}

━━━━━━━━━━━━━━━━━━━━
{{contact}}`;
const DEFAULT_MESSAGE_TEMPLATE = `{{title}}
━━━━━━━━━━━━━━━━━━━━
{{deposit}}
{{monthly_rent}}
{{convertible}}
{{sale_price}}
{{price_per_meter}}
{{location}}
{{street}}
{{land_area}}
{{built_area}}
{{year}}
{{rooms}}
{{amenities}}
{{description}}
🏷️ دسته‌بندی:
{{tags}}
━━━━━━━━━━━━━━━━━━━━
{{contact}}
█ ثبت آگهی رایگان  ░░ مشاوره خرید و اجاره`;
const DEFAULT_SEND_SETTINGS = {
 messageTemplate: DEFAULT_MESSAGE_TEMPLATE,
 imageMode: 'second',
 sendTextFallback: true,
 includeDescription: true,
 includeAmenities: true,
 includeStreet: true,
 includeTags: true,
 descriptionMaxLength: 400,
 defaultImages: {}
};
const DEFAULTS = {settings:{autoPublish:false, publishMode:'review'}, sendSettings:DEFAULT_SEND_SETTINGS, queue:[], contactArchive:[]};
function normalizeSendSettings(raw={}) {
 const src=raw&&typeof raw==='object'?raw:{};
 const images={};
 const allowedTypes=['rent_residential','rent_shop','rent_land','rent_other','sale_residential','sale_shop','sale_land','sale_other','unknown'];
 for(const key of allowedTypes){const v=String(src.defaultImages?.[key]||'');if(/^data:image\/(?:jpeg|png|webp);base64,/i.test(v)&&v.length<1800000)images[key]=v;}
 const rawTemplate=String(src.messageTemplate||'').trim();
 const template=(!rawTemplate||rawTemplate===LEGACY_DEFAULT_MESSAGE_TEMPLATE)?DEFAULT_MESSAGE_TEMPLATE:rawTemplate.slice(0,6000);
 const mode=['second','first','default','none'].includes(src.imageMode)?src.imageMode:'second';
 const max=Number(src.descriptionMaxLength);
 return {
  ...DEFAULT_SEND_SETTINGS,
  messageTemplate:template,
  imageMode:mode,
  sendTextFallback:src.sendTextFallback!==false,
  includeDescription:src.includeDescription!==false,
  includeAmenities:src.includeAmenities!==false,
  includeStreet:src.includeStreet!==false,
  includeTags:src.includeTags!==false,
  descriptionMaxLength:[250,400,600,700].includes(max)?max:400,
  defaultImages:images
 };
}
chrome.runtime.onInstalled.addListener(async()=>{const old=await chrome.storage.local.get(null);const sendSettings=normalizeSendSettings(old.sendSettings||{});const migratedQueue=(old.queue||[]).map(item=>{const listingType=item.listingType||classifyListingType(item);const normalized={...item,listingType,listingTypeLabel:listingTypeLabel(listingType)};normalized.facts=extractListingFacts(normalized);normalized.publicPost=makePost(normalized,sendSettings);return normalized;});const contactArchive=(old.contactArchive||[]).map(x=>{const t=x.listingType&&x.listingType!=='unknown'?x.listingType:classifyListingType({title:x.listingTitle||x.name||'',description:x.note||'',url:x.listingUrl||'',listingId:x.listingId||''});const cc=x.contactCategory&&CONTACT_CATEGORY_LABELS[x.contactCategory]?x.contactCategory:classifyContactCategory({title:x.listingTitle||x.name||'',description:x.note||'',url:x.listingUrl||'',listingType:t});return {...x,name:(x.source==='listing-auto'&&x.name===x.listingTitle?'':x.name||''),listingTitle:x.listingTitle||'',listingType:t,listingTypeLabel:x.listingTypeLabel&&x.listingTypeLabel!=='نوع نامشخص'?x.listingTypeLabel:listingTypeLabel(t),contactCategory:cc,contactCategoryLabel:contactCategoryLabel(cc)};});await chrome.storage.local.set({...DEFAULTS,...old,sendSettings,queue:migratedQueue,contactArchive,settings:{...DEFAULTS.settings,...(old.settings||{}),autoPublish:false}});setupAlarm();processQueuedRubikaSends().catch(()=>{});});
chrome.runtime.onStartup.addListener(()=>{setupAlarm();processQueuedRubikaSends().catch(()=>{});});
async function setupAlarm(){// No automatic listing scans or phone-share relays; alarms are reserved for outbound-message retry and central drafts.
 try{await chrome.alarms.clear('divar-scan');await chrome.alarms.clear('divar-scan-now');await chrome.alarms.clear('qoqnus-mobile-share-relay');}catch{}
}
// Atomic-ish read/modify/write helper used throughout the send pipeline. Missing this helper prevents every send from progressing.
async function updateQueueItem(id, patch){
 const latest=await chrome.storage.local.get({queue:[]});
 const queue=Array.isArray(latest.queue)?latest.queue:[];
 let updated=null;
 const next=queue.map(item=>{if(String(item.id)!==String(id))return item;updated={...item,...patch};return updated;});
 if(!updated)throw new Error('آگهی برای به‌روزرسانی در بانک محلی پیدا نشد: '+String(id));
 await chrome.storage.local.set({queue:next});
 return updated;
}
// Phone-to-phone peer sync has been retired. Keep the rolling backup independent of it.
chrome.storage.onChanged.addListener((changes,area)=>{
 if(area!=='local')return;
 if(changes.settings)setupAlarm();
 if(Object.keys(changes).length){
  try{chrome.alarms.create('qoqnus-auto-backup',{delayInMinutes:0.25});}catch{}
 }
});
let qoqnusAutoBackupBusy=false;
async function qoqnusWriteRollingBackup(){
 if(qoqnusAutoBackupBusy)return;
 qoqnusAutoBackupBusy=true;
 try{
  const data=await chrome.storage.local.get(null);
  const pack={schema:'divar-to-rubika-full-backup',schemaVersion:1,backupMode:'rolling-auto',extensionVersion:chrome.runtime.getManifest().version,exportedAt:new Date().toISOString(),data};
  if(!chrome.offscreen)throw new Error('این نسخهٔ کروم از صفحهٔ پشتیبان خودکار پشتیبانی نمی‌کند.');
  if(!(await chrome.offscreen.hasDocument()))await chrome.offscreen.createDocument({url:'backup-offscreen.html',reasons:['BLOBS'],justification:'ساخت فایل JSON پشتیبان چرخشی از داده‌های محلی افزونه بدون ایجاد فایل‌های متعدد'});
  const result=await chrome.runtime.sendMessage({type:'QOQNUS_OFFSCREEN_WRITE_BACKUP',json:JSON.stringify(pack)});
  if(!result?.ok)throw new Error(result?.error||'نوشتن فایل پشتیبان ناموفق بود.');
 }catch(e){console.warn('پشتیبان خودکار ققنوس انجام نشد:',e?.message||e);}
 finally{qoqnusAutoBackupBusy=false;}
}
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm?.name==='qoqnus-auto-backup')qoqnusWriteRollingBackup();});

const norm=s=>(s||'').toLowerCase().replace(/[ي]/g,'ی').replace(/[ك]/g,'ک').replace(/\s+/g,' ').trim();
const LISTING_TYPE_LABELS={rent_residential:'اجاره مسکونی',rent_shop:'اجاره مغازه و ملک تجاری',rent_land:'اجاره زمین و باغ',rent_other:'اجاره سایر املاک',sale_residential:'فروش مسکونی',sale_shop:'فروش مغازه و ملک تجاری',sale_land:'فروش زمین و باغ',sale_other:'فروش سایر املاک',unknown:'نوع نامشخص'};
const CONTACT_CATEGORY_LABELS={rent_villa:'اجاره ویلایی',rent_booth:'اجاره غرفه/دکه',rent_shop:'اجاره مغازه/تجاری',rent_office:'اجاره دفتر کار/اداری',rent_apartment:'اجاره آپارتمان/خانه',rent_land:'اجاره زمین و باغ',rent_other:'اجاره سایر املاک',sale_villa:'فروش ویلایی',sale_booth:'فروش غرفه/دکه',sale_shop:'فروش مغازه/تجاری',sale_office:'فروش دفتر کار/اداری',sale_apartment:'فروش آپارتمان/خانه',sale_land:'فروش زمین و باغ',sale_other:'فروش سایر املاک',unknown:'نیازمند بررسی'};
function classifyContactCategory(item={}){
 const cats=Array.isArray(item.categories)?item.categories.map(x=>String(x||'')):[];
 const links=Array.isArray(item.categoryLinks)?item.categoryLinks.flatMap(x=>[x?.text||'',x?.href||'']):[];
 const source=norm([item.title||item.listingTitle||'',...cats,...links,item.url||item.listingUrl||''].join(' '));
 const full=norm([source,item.description||'',item.note||'',item.detailText||'',item.text||'',item.facts?.propertyType||'',item.facts?.transactionLabel||'',item.location||''].join(' '));
 let transaction='';
 if(/(?:rent[-_/]|اجاره|رهن|ودیعه|اجاره\s*ماهانه)/i.test(source))transaction='rent';
 else if(/(?:sale[-_/]|sell[-_/]|buy[-_/]|فروش|فروشی|خرید)/i.test(source))transaction='sale';
 else if(/^rent_/.test(String(item.listingType||'')))transaction='rent';
 else if(/^sale_/.test(String(item.listingType||'')))transaction='sale';
 else if(/(?:اجاره|رهن|ودیعه|اجاره\s*ماهانه)/i.test(full))transaction='rent';
 else if(/(?:فروش|فروشی|خرید|قیمت\s*فروش)/i.test(full))transaction='sale';
 if(!transaction)return 'unknown';
 const typeSource=source+' '+full;
 let subtype='other';
 if(/(?:غرفه|غرفه‌ای|غرفه\s*ای|دکه|کانتر|booth|stall)/i.test(typeSource))subtype='booth';
 else if(/(?:مغازه|فروشگاه|واحد\s*تجاری|ملک\s*تجاری|تجاری|shop|commercial|storefront)/i.test(typeSource))subtype='shop';
 else if(/(?:دفتر\s*کار|دفتر\s*اداری|اداری|مطب|office|workspace)/i.test(typeSource))subtype='office';
 else if(/(?:باغ\s*ویلا|ویلایی|ویلا|villa)/i.test(typeSource))subtype='villa';
 else if(/(?:زمین|باغ|قطعه\s*زمین|land|garden)/i.test(typeSource))subtype='land';
 else if(/(?:آپارتمان|سوئیت|مسکونی|خانه|منزل|flat|apartment|residential)/i.test(typeSource))subtype='apartment';
 if(subtype==='other'){const legacy=String(item.listingType||'');if(/_residential$/.test(legacy))subtype='apartment';else if(/_shop$/.test(legacy))subtype='shop';else if(/_land$/.test(legacy))subtype='land';}
 return transaction+'_'+subtype;
}
function contactCategoryLabel(category){return CONTACT_CATEGORY_LABELS[category]||CONTACT_CATEGORY_LABELS.unknown;}
function classifyListingType(item={}){
 const cats=Array.isArray(item.categories)?item.categories.map(x=>String(x||'')):[];
 const links=Array.isArray(item.categoryLinks)?item.categoryLinks.flatMap(x=>[x?.text||'',x?.href||'']):[];
 // Property type is inferred from title/category/path, not from descriptive fields such as "land area".
 const source=norm([item.title||'',...cats,...links,item.url||''].join(' '));
 const full=norm([source,item.description||'',item.detailText||'',item.text||'',item.publicDescription||''].join(' '));
 let transaction='';
 if(/(?:rent[-_/]|اجاره|رهن)/i.test(source))transaction='rent';
 else if(/(?:buy[-_/]|sell[-_/]|sale[-_/]|فروش|خرید)/i.test(source))transaction='sale';
 else if(/(?:اجاره|رهن)/i.test(full))transaction='rent';
 else if(/(?:فروش|خرید)/i.test(full))transaction='sale';
 const land=/(?:زمین|باغ|قطعه زمین|land|garden)/i.test(source);
 const shop=/(?:مغازه|واحد تجاری|ملک تجاری|تجاری|دفتر کار|اداری|کارگاه|shop|commercial)/i.test(source);
 const residential=/(?:مسکونی|آپارتمان|خانه|منزل|ویلا|ویلایی|residential|villa|apartment)/i.test(source)||(!land&&!shop&&/(?:آپارتمان|خانه|منزل|ویلا|ویلایی)/i.test(full));
 if(!transaction)return 'unknown';
 if(land)return transaction+'_land';
 if(shop)return transaction+'_shop';
 if(residential)return transaction+'_residential';
 return transaction+'_other';
}
function listingTypeLabel(type){return LISTING_TYPE_LABELS[type]||LISTING_TYPE_LABELS.unknown;}

function removeAgePhrase(value){return String(value||'').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/(?:^|[\s،,])(?:امروز|دیروز|پریروز)\s*(?:در\s*)?/gi,' ').replace(/(?:^|[\s،,])(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش\s*(?:در\s*)?/gi,' ').replace(/(?:^|[\s,])(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?)\s+ago(?:\s+(?:in\s+)?)?/gi,' ').replace(/\s+/g,' ' ).replace(/^[،,؛|\s-]+|[،,؛|\s-]+$/g,'').trim();}
function renderEmojiAliases(value){const aliases={moneybag:'💰',dollar:'💵',arrows_counterclockwise:'🔄',round_pushpin:'📍',triangular_ruler:'📐',house:'🏠',bed:'🛏️',car:'🚗',package:'📦',sunny:'🌤️',memo:'📝',telephone_receiver:'📞',white_check_mark:'✅',x:'❌',evergreen_tree:'🌳',office:'🏢',house_with_garden:'🏡',money_with_wings:'💸',heavy_check_mark:'✔️'};return String(value||'').replace(/:([a-z0-9_+-]+):/gi,(m,k)=>aliases[k]||m);}
function stripCategoryBreadcrumbTail(value, categories=[]){let s=String(value||'').trim();const candidates=[...categories].map(x=>String(x||'').trim()).filter(Boolean).sort((a,b)=>b.length-a.length);for(let pass=0;pass<8;pass++){let changed=false;for(const c of candidates){const re=new RegExp('(?:\\s|^)'+c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*$','i');if(re.test(s)&&s.length>c.length+18){s=s.replace(re,'').trim();changed=true;break;}}if(changed)continue;const tail=/(?:\s|^)(?:املاک|اجاره(?:[ٔ‌ ]?)\s*(?:خانه\s*و\s*ویلا|مسکونی|آپارتمان|ویلا|زمین|باغ)|اجاره(?:[ٔ‌ ]?)\s+خانه|خرید(?:\s+و\s+فروش)?(?:\s+(?:خانه|زمین|ویلا|مسکونی|آپارتمان))?|فروش(?:\s+(?:خانه|زمین|ویلا|مسکونی|آپارتمان))?)(?:\s+در\s+[\u0600-\u06FF\s\d۰-۹٠-٩-]{2,55})?\s*$/i;const m=s.match(tail);if(m&&s.length-m[0].trimStart().length>5){s=s.slice(0,m.index).trim();continue;}break;}return s;}
function locationTags(item,url){const s=norm((item.text||'')+' '+url);const t=[];if(/نیشابور|neyshabur/.test(s))t.push('#نیشابور');if(/سراب.?کوشک|saraab-koushk/.test(s))t.push('#سراب_کوشک');if(/ویلا|villa/.test(s))t.push('#ویلا');if(/آپارتمان|apartment/.test(s))t.push('#آپارتمان');if(/اجاره|رهن|rent/.test(s))t.push('#اجاره');if(/فروش|خرید|sell|buy/.test(s))t.push('#فروش');return t;}
function classifyAgency(item){
 const name=norm(item.sellerName||'');
 const text=norm(item.text||'');
 const strongName=/(املاک|مشاور املاک|آژانس املاک|بنگاه املاک|دفتر املاک|دپارتمان املاک|مشاورین املاک|گروه املاک)/.test(name);
 const strongText=/(مشاور املاک|آژانس املاک|بنگاه املاک|دفتر املاک|مشاورین املاک|گروه املاک|دپارتمان تخصصی|برای اطلاعات بیشتر.{0,45}املاک|به املاک.{0,45}(مراجعه|تماس|زنگ|مراجعه کنید))/.test(text);
 const anyWord=/املاک/.test(text);
 if(item.sellerClass==='agency'||strongName) return {color:'red',label:'املاکی',reason:'نام یا دسته‌بندی آگهی‌دهنده نشانهٔ بنگاه دارد'};
 if(strongText||anyWord) return {color:'yellow',label:'نیازمند بررسی متن',reason:'در متن آگهی واژه یا عبارت مرتبط با املاک دیده شد'};
 return {color:'green',label:'نشانه‌ای پیدا نشد',reason:'نشانهٔ مشخصی در اطلاعات قابل‌دسترسی پیدا نشد'};
}
function stripAgeLine(line){return removeAgePhrase(String(line||'').trim());}
function cleanListingDescription(value,categories=[]){
 let s=String(value||'').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/\u00a0/g,' ').trim();
 if(!s)return '';
 s=s.replace(/https?:\/\/\S+/gi,' ');
 // متن‌های زمان انتشار، نه مشخصات ملک، هرگز وارد پیام کانال نشوند.
 s=s.replace(/(?:^|[\n،;؛])\s*(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش\s+در\s+[^\n.!؟]*/gi,' ');
 s=s.replace(/(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش/gi,' ');
 s=s.replace(/با تشکر از\s*(?:سایت\s*)?دیوار/gi,'با تشکر از ققنوس');
 // Cut appended controls/navigation/footer text that is not part of the seller's description.
 const junk=/(?:^|\s)(?:[۰-۹0-9]{1,3}\s*)?یادداشت تنها برای شما قابل دیدن است|برو به اطلاعات تماس|دسته‌ها\s+دیوار\s+من\s+چت(?:\s+و\s+تماس)?|(?:درباره[ٔ ]*دیوار|دریافت برنامه|اتاق خبر|دیواری شو|ثبت آگهی|پشتیبانی و قو(?:ا|انین)|گزارش آگهی|تصویر\s*[۰-۹0-9]+\s*از\s*[۰-۹0-9]+)/i;
 const m=s.match(junk);if(m)s=s.slice(0,m.index).trim();
 s=s.replace(/برای هر نوع پرداخت.{0,220}?(?:پرداخت امن|پرداخت امن را انتخاب کنید)[.!، ]*/ig,' ')
  .replace(/درخواست بیعانه،? از نشانه‌های کلاهبرداری[.!، ]*/ig,' ')
  .replace(/\bسایت\s+دیوار\b/ig,' ')
  .replace(/\bصفحه\s+دیوار\b/ig,'صفحه')
  .replace(/آگهی\s+دیوار/ig,'آگهی')
  .replace(/از\s+سایت\s+دیوار/ig,' ')
  .replace(/\s+/g,' ').replace(/[ .،؛]+$/,'').trim();
 // Known platform mentions/navigation are removed without deleting literal property features such as brick walls.
 s=s.replace(/\s{2,}/g,' ').trim();
 s=stripCategoryBreadcrumbTail(s,categories);
 s=s.replace(/(?:با تشکر از\s*)?(?:سایت|وب\s*سایت|سامانه)\s+دیوار/gi,'').replace(/با تشکر از\s*دیوار/gi,'با تشکر از ققنوس');
 return renderEmojiAliases(s.slice(0,700));
}
function contactDisplayDigits(){return '9 3 2 1 1 1 2 5 1 9 0';}
function contactInlineKeypad(){return {rows:[{buttons:[{id:'qoqnus-call-phone',type:'Link',button_text:`📞 تماس : ${contactDisplayDigits()}`,button_link:{type:'url',link_url:'tel:+989152111239'}}]}]};}
// Text-styled Qoqnus actions can be hidden from Settings. The call button remains the original Rubika keypad.
const QOQNUS_BOT_URL='https://rubika.ir/qoqnusBot';
const QOQNUS_LISTING_START_URL=QOQNUS_BOT_URL+'?start=channel_add_listing';
const QOQNUS_CONSULT_START_URL=QOQNUS_BOT_URL+'?start=channel_request_order';
const RUBIKA_AD_CTA_TEXT='\n█ ثبت آگهی رایگان  ░░ مشاوره خرید و اجاره\n';
function addRubikaAdCta(value,showActions=true){
  let text=String(value||'').trim();
  const footerStarts=[
    /\n?━━━━━━━━━━━━━━━━━━━━\n█ ثبت آگهی رایگان[\s\S]*$/,
    /\n?█ ثبت آگهی رایگان\s+░░\s*مشاوره خرید و اجاره(?:\s+█)?[\s\S]*$/,
    /\n?【 ثبت آگهی رایگان 】[\s\S]*$/,
    /\n?░▒▓█ تماس با ما █▓▒░[\s\S]*$/
  ];
  for(const pattern of footerStarts)text=text.replace(pattern,'').trimEnd();
  const shownNumber='۰۹۱۵۲۱۱۱۲۳۹';
  text=text.split('\n').filter(line=>!line.includes(shownNumber)&&!/^[\s]*📞[\s]*تماس[\s]*[:：]?[\s]*$/u.test(line)).join('\n').trimEnd();
  return showActions ? text+RUBIKA_AD_CTA_TEXT : text;
}
function rubikaFormattedPayload(value){
  const text=String(value||'');const parts=[];
  // Bold and underline the first meaningful line (the listing title), not the footer.
  const lines=text.split('\n');let heading='';let headingIndex=0;let running=0;
  for(const line of lines){const trimmed=line.trim();if(trimmed&&!/^━{3,}$/.test(trimmed)&&!/^█.*ثبت آگهی رایگان/.test(trimmed)&&!/^░▒▓█ تماس با ما/.test(trimmed)){heading=trimmed;headingIndex=running+line.indexOf(trimmed);break;}running+=line.length+1;}
  if(heading){parts.push({type:'Bold',from_index:headingIndex,length:heading.length});parts.push({type:'Underline',from_index:headingIndex,length:heading.length});}
  // Bold field labels without changing message text. This mirrors the selected Qoqnus template.
  let lineStart=0;
  for(const line of lines){
   const labelMatch=line.match(/^\s*([^:：\n]{1,40}[:：])(?=\s|$)/u);
   if(labelMatch&&/(?:قیمت کل|قیمت هر متر|رهن|اجاره|قابل تبدیل|موقعیت|خیابان|متراژ زمین|متراژ کل|متراژ ساخته.?شده|سال ساخت|تعداد اتاق|پارکینگ|انباری|بالکن|توضیحات بیشتر|دسته.?بندی|تماس)\s*[:：]/u.test(labelMatch[1])){
    const rawPrefix=line.slice(0,line.search(/\S|$/));const from=lineStart+rawPrefix.length;const text=labelMatch[1].trim();
    if(!parts.some(part=>part.type==='Bold'&&part.from_index===from&&part.length===text.length))parts.push({type:'Bold',from_index:from,length:text.length});
   }
   lineStart+=line.length+1;
  }
  const registerLabel='ثبت آگهی رایگان';const registerAt=text.lastIndexOf(registerLabel);
  if(registerAt>=0)parts.push({type:'Link',from_index:registerAt,length:registerLabel.length,link_url:QOQNUS_LISTING_START_URL});
  const consultLabel='مشاوره خرید و اجاره';const consultAt=text.lastIndexOf(consultLabel);
  if(consultAt>=0)parts.push({type:'Link',from_index:consultAt,length:consultLabel.length,link_url:QOQNUS_CONSULT_START_URL});
  const callLabel='تماس با ما';const callAt=text.lastIndexOf(callLabel);
  if(callAt>=0)parts.push({type:'Link',from_index:callAt,length:callLabel.length,link_url:'tel:+989152111239'});
  const shownNumber=contactDisplayDigits();const numberAt=text.lastIndexOf(shownNumber);
  if(numberAt>=0)parts.push({type:'Link',from_index:numberAt,length:shownNumber.length,link_url:'tel:+989152111239'});
  return {text,metadata:parts.length?{meta_data_parts:parts}:undefined,contactLinkIncluded:numberAt>=0};
}

function removePrivateContact(text){
 let s=String(text||'').replace(/https?:\/\/\S+/gi,'');
 // Persian and Arabic digits are converted in a same-length shadow string; match offsets
 // are therefore also valid in the original string.
 const ascii=asciiDigits(s);
 const rx=/(?<![0-9])(?:(?:\+|00)?98[ .()\-]*)?0?9(?:[ .()\-]*[0-9]){9}(?![0-9])/g;
 const ranges=[...ascii.matchAll(rx)].map(m=>[m.index,m.index+m[0].length]).sort((a,b)=>b[0]-a[0]);
 for(const [a,b] of ranges)s=s.slice(0,a)+' '+s.slice(b);
 s=s.replace(/(?:شماره\s*تماس|تماس\s*با|برای\s*تماس|تماس\s*بگیرید|زنگ\s*بزنید|شماره|تلفن)\s*[:：-]?\s*/gi,' ');
 return s.replace(/[ \t]{2,}/g,' ').trim();
}
function cleanPublicValue(value){
 return removePrivateContact(String(value||'')).replace(/^[\s:：|—-]+|[\s|—-]+$/g,'').trim();
}
function retainQueue(items,activeLimit=1500){
 const all=(Array.isArray(items)?items:[]).map(record=>{
  if(!record||typeof record!=='object')return record;
  const source=String(record.source||record.sourceType||'').toLowerCase();
  const isOffice=source==='office-file'||source==='office-ad'||source==='manual-office-ad'||record.bookKey==='office-files';
  const meta=isOffice?{recordKind:'file',sourceType:'office-file',bookKey:'office-files'}:{recordKind:'listing',sourceType:'qoqnus-import',bookKey:'qoqnus-files'};
  return record.recordKind===meta.recordKind&&record.sourceType===meta.sourceType&&record.bookKey===meta.bookKey?record:{...record,...meta};
 });
 const archived=all.filter(x=>x.status==='archived'||x.status==='published');
 const active=all.filter(x=>!['archived','published'].includes(x.status)).slice(0,activeLimit);
 return [...active,...archived];
}
function detailLines(item){
 // Keep distinct extraction sources: Divar sometimes exposes the structured price and attributes
 // outside the main visible text container.
 const sources=[item.detailText,item.text,item.publicDescription,item.priceText,...(Array.isArray(item.attributes)?item.attributes:[])];
 const out=[];const seen=new Set();
 for(const source of sources){
  if(!source)continue;
  for(const row of String(source).split(/\r?\n/)){
   const line=cleanPublicValue(stripAgeLine(row));if(!line)continue;
   const key=norm(line);if(seen.has(key))continue;seen.add(key);out.push(line);
  }
 }
 return out;
}
function extractValueAfter(lines, labels){
 const rx=labels && typeof labels.test==='function'?labels:new RegExp('^(?:'+labels.join('|')+')\\s*(?:[:：])?\\s*(.*)$','i');
 for(let i=0;i<lines.length;i++){
  const m=lines[i].match(rx); if(!m)continue;
  if(m[1]&&m[1].trim())return cleanPublicValue(m[1]);
  for(let j=i+1;j<Math.min(lines.length,i+4);j++){
   const v=cleanPublicValue(lines[j]);
   if(!v||/^(?:زنگ خطرهای قبل از معامله|اطلاعات تماس|ویژگی‌ها و امکانات|سایر ویژگی‌ها و امکانات|بررسی و کارشناسی|گزارش آگهی|توضیحات|موقعیت مکانی)$/i.test(v))continue;
   return v;
  }
 }
 return '';
}
function isMoneyCandidate(value){
 const v=cleanPublicValue(value||'');if(!v)return false;
 if(/رایگان|مجانی|ندارد|نامشخص|قابل\s*تبدیل|غیر\s*قابل\s*تبدیل|تومان\s*\)?$/i.test(v)&&!/[0-9۰-۹٠-٩]/.test(v))return false;
 const d=asciiDigits(v).replace(/\D/g,'');
 if(!d)return false;
 // Four-digit years and small property counts are not prices; require a currency/unit or a plausible amount.
 if(d.length>=5)return true;
 if(/تومان|ریال|میلیون|میلیارد/.test(norm(v))&&d.length>=5)return true;
 return false;
}
function normalizeMoneyLabelLine(value){
 return String(value||'').replace(/[\u200b-\u200f\u202a-\u202e\u2060\ufeff]/g,'').replace(/^\s*:[a-z0-9_+-]+:\s*/i,'').replace(/^\s*[^\p{L}\p{N}]+/u,'').replace(/\s+/g,' ').trim();
}
function extractMoneyField(lines,labelRx){
 const sectionOrLabel=/^(?:اجاره(?:ٔ|ی)?\s*ماهانه|اجاره ماهیانه|مبلغ اجاره|ودیعه|مبلغ ودیعه|مبلغ رهن|رهن|قیمت(?: کل| فروش| زمین| ملک)?|قیمت هر متر(?: مربع)?|هر متر مربع|متراژ|ساخت|اتاق|تعداد اتاق|تعداد خواب|ویژگی.?ها و امکانات|سایر ویژگی.?ها و امکانات|توضیحات|موقعیت مکانی|اطلاعات تماس|گزارش آگهی|بررسی و کارشناسی)$/i;
 for(let i=0;i<lines.length;i++){
  const sourceLine=normalizeMoneyLabelLine(lines[i]);
  const match=sourceLine.match(labelRx);if(!match)continue;
  const inline=cleanPublicValue(match[1]||'');
  if(isMoneyCandidate(inline))return inline;
  // A label can be followed by descriptive UI text; never treat that text as a price.
  // Still inspect only its nearby value rows, stopping at the next known field label.
  for(let j=i+1;j<Math.min(lines.length,i+4);j++){
   const candidate=cleanPublicValue(normalizeMoneyLabelLine(lines[j]));if(!candidate)continue;
   if(sectionOrLabel.test(normalizeMoneyLabelLine(candidate)))break;
   if(isMoneyCandidate(candidate))return candidate;
   if(/^(?:تومان|ریال)$/i.test(candidate)&&j<=i+2)continue;
   // At most one non-value UI line may separate a price label from its amount.
   if(j>i+1 && !/^(?:قابل تبدیل|غیر قابل تبدیل|این ملک قابل تبدیل است)[.!؟،]*$/i.test(candidate))break;
  }
 }
 // Fallback for Divar layouts where label+amount occur in the same longer text node.
 // Search each line independently: searching across newlines would misread "رهن و اجاره" as a rent value.
 const patterns=[
  /(?:مبلغ\s*ودیعه|مبلغ\s*رهن|ودیعه|رهن(?!\s*و\s*اجاره))\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g,
  /(?:مبلغ\s*اجاره|اجاره(?:[ٔ‌]?\s*ماهانه|\s*ماهیانه)?)\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g,
  /(?:قیمت(?:\s*(?:کل|فروش|زمین|ملک))?)\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g,
  /(?:قیمت\s*هر\s*متر(?:\s*مربع)?|هر\s*متر\s*مربع)\s*[:：]?\s*([۰-۹٠-٩0-9][۰-۹٠-٩0-9,٬،.]*)(?:\s*(تومان|ریال|میلیون|میلیارد))?/g
 ];
 const rxIndex=labelRx.source.includes('ودیعه')||labelRx.source.includes('مبلغ رهن')?0:labelRx.source.includes('مبلغ اجاره')||labelRx.source.includes('اجاره')?1:labelRx.source.includes('قیمت هر متر')||labelRx.source.includes('هر متر')?3:2;
 for(const row of lines.map(normalizeMoneyLabelLine)){
  patterns[rxIndex].lastIndex=0;let m;
  while((m=patterns[rxIndex].exec(row))){const val=cleanPublicValue(`${m[1]||''} ${m[2]||''}`);if(isMoneyCandidate(val))return val;}
 }
 return '';
}
function extractCombinedRentAmounts(lines){
 const start=lines.findIndex(x=>/^(?:رهن\s*و\s*اجاره|ودیعه\s*و\s*اجاره|مبلغ\s*رهن\s*و\s*اجاره)(?:\s|$)/i.test(normalizeMoneyLabelLine(x)));
 if(start<0)return {deposit:'',monthlyRent:''};
 const candidates=[];
 for(let i=start+1;i<Math.min(lines.length,start+7);i++){
  const row=normalizeMoneyLabelLine(lines[i]);if(!row)continue;
  if(/^(?:موقعیت|آدرس|متراژ|ساخت|اتاق|توضیحات|ویژگی.?ها|اطلاعات تماس|گزارش آگهی|بررسی و کارشناسی)$/i.test(row))break;
  if(isMoneyCandidate(row)&&(/[۰-۹٠-٩0-9]/.test(row))){candidates.push(cleanPublicValue(row));if(candidates.length===2)break;}
 }
 return candidates.length>=2?{deposit:candidates[0],monthlyRent:candidates[1]}:{deposit:'',monthlyRent:''};
}
function extractRooms(lines,description,tableIndex){
 const explicit=/^(?:تعداد اتاق|تعداد خواب)\s*(?:[:：]\s*(.*))?$/i;
 for(let i=0;i<lines.length;i++){
  const m=String(lines[i]||'').match(explicit);if(!m)continue;
  let v=String(m[1]||'').trim();
  if(!v){for(let j=i+1;j<Math.min(lines.length,i+3);j++){const candidate=String(lines[j]||'').trim();if(/^(?:ودیعه|اجاره|متراژ|ساخت|اتاق|ویژگی.?ها|توضیحات|موقعیت|قیمت)/i.test(candidate))break;if(validRoomValue(candidate)){v=candidate;break;}}}
  if(validRoomValue(v))return persianDigits(asciiDigits(v));
 }
 // The Divar facts table can render three headings first, followed by three separate values.
 if(tableIndex>=0){
  const values=lines.slice(tableIndex+3,tableIndex+9).filter(x=>/^[۰-۹٠-٩0-9]{1,6}$/.test(String(x).trim()));
  const year=values.find(validYearValue);
  if(year){const yi=values.indexOf(year);const candidate=values[yi+1];if(validRoomValue(candidate))return persianDigits(candidate);}
 }
 const d=String(description||'');
 const m=d.match(/(?:^|\s)(یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|[۰-۹٠-٩0-9]{1,2})\s*(?:خواب|اتاق)(?:\s|$)/);
 if(m){const n=numberWordToInt(m[1]);if(n!==null&&n<=20)return persianDigits(String(n));}
 return '';
}
function normalizeStreet(raw){
 let s=removeAgePhrase(cleanPublicValue(String(raw||''))).replace(/[ًٌٍَُِّْٔ]/g,'').trim();
 s=s.replace(/^(?:خیابان|بلوار|کوچه|میدان|شهرک|جاده|خ\.?|خ)\s*/,'').trim();
 if(!s)return '';
 if(/^(?:بلوار|میدان|کوچه|شهرک|جاده|خیابان)\s*/.test(s))return persianDigits(s);
 return persianDigits('خیابان '+s);
}
function splitPropertyLocation(raw){
 const parts=String(removeAgePhrase(raw||'')).split(/[،,؛|]/).map(x=>removeAgePhrase(cleanPublicValue(x))).filter(Boolean);
 const out={city:'',neighborhood:'',street:'',full:''};
 if(!parts.length)return out;
 out.city=parts.shift()||'';
 // Street information is sometimes appended to the neighborhood in the same DOM line.
 const joined=parts.join('، ');
 const streetMatch=joined.match(/(?:^|\s)(خیابان|خ\.?|بلوار|کوچه|میدان|جاده)\s*([^،;|]+)$/i);
 if(streetMatch){
  const before=joined.slice(0,streetMatch.index).trim().replace(/[،,؛|]+$/,'').trim();
  out.neighborhood=before;
  out.street=normalizeStreet(streetMatch[1]+' '+streetMatch[2]);
 }else if(parts.length){
  out.neighborhood=parts.shift()||'';
  if(parts.length)out.street=normalizeStreet(parts.join('، '));
 }
 out.city=removeAgePhrase(out.city);
 out.neighborhood=removeAgePhrase(out.neighborhood);
 out.full=[out.city,out.neighborhood,out.street].filter(Boolean).join('، ');
 return out;
}
function extractListingFacts(item){
 const lines=detailLines(item),raw=lines.join('\n');
 const cats=Array.isArray(item.categories)?item.categories.filter(Boolean).map(x=>String(x).trim()):[];
 const categoryLinks=Array.isArray(item.categoryLinks)?item.categoryLinks:[];
 const categoryText=cats.join(' ')+' '+categoryLinks.map(x=>`${x?.text||''} ${x?.href||''}`).join(' ')+' '+String(item.url||'');
 const title=cleanPublicValue(item.title||lines[0]||'آگهی ملک');
 const classification=norm(`${title} ${categoryText}`);
 const detectionText=norm(`${classification} ${raw}`);
 const rentPattern=/(?:اجاره|رهن|rent-villa|rent-residential|rent-apartment|rent-house)/i;
 const salePattern=/(?:فروش|خرید|buy-villa|buy-residential|buy-land|sell-land|sell-villa|sale)/i;
 const categoriesSayRent=rentPattern.test(norm(cats.join(' ')+' '+categoryLinks.map(x=>x?.href||'').join(' ')+' '+String(item.url||'')));
 const categoriesSaySale=salePattern.test(norm(cats.join(' ')+' '+categoryLinks.map(x=>x?.href||'').join(' ')+' '+String(item.url||'')));
 const isRent=categoriesSayRent||(!categoriesSaySale&&rentPattern.test(detectionText));
 const isSale=categoriesSaySale||(!categoriesSayRent&&salePattern.test(detectionText));
 const isLand=/(?:زمین|باغ|land)/i.test(`${title} ${cats.join(' ')} ${categoryLinks.map(x=>x?.text||'').join(' ')} ${String(item.url||'')}`);
 let propertyType=isLand?'زمین/باغ':/(?:ویلا|ویلایی|خانه و ویلا)/.test(classification)?'ویلا':/(?:تجاری|مغازه|سوله|انبار|کارگاه|دفتر کار)/.test(classification)?'تجاری':/آپارتمان/.test(classification)?'آپارتمان':/(?:خانه|منزل|مسکونی)/.test(classification)?'خانه':'ملک';
 let location=removeAgePhrase(stripAgeLine(cleanPublicValue(item.location||'')));
 if(!location){const loc=lines.find(x=>/(?:دقیقه|ساعت|روز|هفته|ماه)\s*پیش\s+در\s+/.test(x));if(loc)location=removeAgePhrase(loc);}
 if(!location){const loc=lines.find(x=>/^(?:نیشابور|تهران|مشهد|سرآب|سرآب|شهرک|خیابان|خ\s)/.test(x));if(loc)location=loc;}
 if(location&&!/(?:خ\.?|خیابان|بلوار|کوچه|میدان|شهرک)\s*[^،,]+/.test(location)){const streetLine=lines.find(x=>/^(?:خ\.?|خیابان|بلوار|کوچه|میدان|شهرک)\s*\S+/.test(x));if(streetLine)location+='، '+streetLine;}
 const locationParts=splitPropertyLocation(location);
 let deposit=extractMoneyField(lines,/^(?:ودیعه|مبلغ ودیعه|مبلغ رهن|رهن(?!\s*و\s*اجاره))\s*(?:[:：])?\s*(.*)$/i);
 let monthlyRent=extractMoneyField(lines,/^(?:اجاره(?:ٔ|ی)?\s*ماهانه|اجاره ماهیانه|مبلغ اجاره|اجاره)\s*(?:[:：])?\s*(.*)$/i);
 if(isRent&&(!deposit||!monthlyRent)){const combined=extractCombinedRentAmounts(lines);if(!deposit)deposit=combined.deposit;if(!monthlyRent)monthlyRent=combined.monthlyRent;}
 let salePrice=isRent?'':extractMoneyField(lines,/^(?:قیمت کل|قیمت فروش|قیمت زمین|قیمت ملک|قیمت)\s*(?:[:：])?\s*(.*)$/i);
 // Never infer a purchase price from an arbitrary number (e.g. year, area, phone) in the page text.
 let pricePerMeter=extractMoneyField(lines,/^(?:قیمت هر متر مربع|قیمت هر متر|هر متر مربع)\s*(?:[:：])?\s*(.*)$/i);
 let builtArea=extractValueAfter(lines,/^(?:زیربنا|متراژ بنا|متراژ ساختمان|متراژ ساخته.?شده)\s*(?:[:：])?\s*(.*)$/i);
 let landArea=extractValueAfter(lines,/^(?:متراژ زمین|مساحت زمین|متراژ کل|مساحت کل)\s*(?:[:：])?\s*(.*)$/i);
 let year=extractValueAfter(lines,/^(?:سال ساخت|ساخت)\s*(?:[:：])?\s*(.*)$/i);
 if(!validAreaValue(builtArea))builtArea='';
 if(!validAreaValue(landArea))landArea='';
 if(!validYearValue(year))year='';
 const headingIndex=lines.findIndex((x,i)=>norm(x)==='متراژ'&&norm(lines[i+1]||'')==='ساخت'&&norm(lines[i+2]||'')==='اتاق');
 if(headingIndex>=0){
  const candidates=lines.slice(headingIndex+3,headingIndex+9).filter(x=>/^[۰-۹٠-٩0-9]{1,7}$/.test(String(x).trim()));
  if(!builtArea&&candidates.length&&validAreaValue(candidates[0]))builtArea=candidates[0];
  if(!year){const foundYear=candidates.find(validYearValue);if(foundYear)year=foundYear;}
 }
 if(!builtArea){const m=raw.match(/(?:زیربنا|متراژ\s+ساخت|متراژ\s+بنا|متراژ\s+ساخته.?شده)\s*[:：]?\s*([۰-۹0-9]{1,5})/);if(m&&validAreaValue(m[1]))builtArea=m[1];}
 if(!landArea){const m=raw.match(/(?:متراژ\s+زمین|مساحت\s+زمین|متراژ\s+کل|مساحت\s+کل)\s*[:：]?\s*([۰-۹0-9,٬.]+\s*(?:متر(?:\s*مربع)?|مترمربع)?)/);if(m&&validAreaValue(m[1]))landArea=m[1];}
 if(isLand&&!landArea){const m=raw.match(/(?:متراژ|مساحت)\s*[:：]?\s*([۰-۹0-9,٬.]+)\s*(?:متر(?:\s*مربع)?|مترمربع)/);if(m&&validAreaValue(m[1]))landArea=m[1];}
 if(!year){const m=raw.match(/(?:سال\s*ساخت|ساخت)\s*[:：]\s*((?:۱۳|۱۴|20)\d{2}|[۰-۹]{4})/);if(m&&validYearValue(m[1]))year=m[1];}
 let rooms=extractRooms(lines,String(item.description||''),headingIndex);
 if(!rooms){const m=raw.match(/(?:تعداد اتاق|تعداد خواب)\s*[:：]\s*([۰-۹0-9]{1,2})/);if(m&&validRoomValue(m[1]))rooms=persianDigits(asciiDigits(m[1]));}
 const any=/پارکینگ/.test(raw), storage=/انباری/.test(raw), balcony=/بالکن/.test(raw);
 const amenityWords=['پارکینگ','انباری','بالکن','آسانسور','حیاط','دربست','تراس','کولر','پکیج','شوفاژ','اسپیلت','سرامیک','کابینت','نگهبانی'];
 const amenities=[...new Set(amenityWords.filter(a=>new RegExp(a,'i').test(raw)))];
 let description=String(item.description||'').trim();
 const stopRe=/^(?:ویژگی.?ها و امکانات|سایر ویژگی.?ها و امکانات|مشخصات ملک|اطلاعات تماس|موقعیت مکانی|گزارش آگهی|بررسی و کارشناسی|یادداشت تنها برای شما قابل دیدن است|زنگ خطرهای قبل از معامله|اجارهٔ? خانه|خرید خانه|اجاره و فروش|املاک|تصویرها برای همین ملک است\?|تصویر\s*[0-9۰-۹]+\s*از\s*[0-9۰-۹]+)$/i;
 if(!description){const descRx=/^(?:توضیحات(?:\s+(?:آگهی|بیشتر))?|شرح آگهی)\s*[:：]?\s*(.*)$/i;const ix=lines.findIndex(x=>descRx.test(norm(x)));if(ix>=0){const parts=[];const first=norm(lines[ix]).match(descRx);if(first&&first[1])parts.push(first[1].trim());for(let i=ix+1;i<lines.length;i++){const ln=lines[i];if(stopRe.test(norm(ln))||cats.some(c=>norm(c)===norm(ln)))break;parts.push(ln);}description=parts.join(' ');}}
 description=cleanListingDescription(description.split(/\n+/).map(cleanPublicValue).filter(x=>x&&!stopRe.test(norm(x))&&!cats.some(c=>norm(c)===norm(x))&&!/^(?:برای هر نوع پرداخت|درخواست بیعانه|ودیعه|اجاره(?:ٔ|ی)? ماهانه|متراژ|ساخت|اتاق|توضیحات)$/i.test(norm(x))).join(' '),cats);
 const cleanVal=x=>{const v=cleanPublicValue(x);return !v||/^[-—]+$/.test(v)?'':v;};
 const bodyText=norm(raw);
 let convertible=null;if(/غیر\s*قابل\s*تبدیل|غیرقابل\s*تبدیل/.test(bodyText))convertible=false;else if(/(?:^|\s)قابل\s*تبدیل/.test(bodyText))convertible=true;
 const featureFlags={parking:any,storage,balcony};
 const monthlyRentValue=cleanVal(monthlyRent);
 const safeMonthlyRent= /^(?:رایگان|مجانی|ندارد|نامشخص)$/i.test(norm(monthlyRentValue))?'':monthlyRentValue;
 const listingType=item.listingType||classifyListingType({...item,title,categories:cats});return {title,transactionType:isRent?'rent':isSale?'sale':'unknown',transactionLabel:isRent?'اجاره':isSale?'خرید و فروش':'نامشخص',listingType,listingTypeLabel:listingTypeLabel(listingType),propertyType,location,city:locationParts.city,neighborhood:locationParts.neighborhood,street:locationParts.street,fullLocation:locationParts.full,categories:cats,deposit:cleanVal(deposit),monthlyRent:safeMonthlyRent,salePrice:cleanVal(salePrice),pricePerMeter:cleanVal(pricePerMeter),builtArea:cleanVal(builtArea),landArea:cleanVal(landArea),year:cleanVal(year),rooms:cleanVal(rooms),amenities,featureFlags,convertible,description};
}
function tagFromText(s){return '#'+String(s||'').trim().replace(/^#+/,'').replace(/[\s،,؛;|/\\]+/g,'_').replace(/[.:：()\[\]{}]+/g,'').replace(/_+/g,'_').replace(/^_|_$/g,'');}
function makeTags(item,facts){
 const tags=[];const add=x=>{const original=String(x||'').replace(/^#/,'').trim();const spaced=original.replace(/_/g,' ');if(!spaced||/(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش|(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?)\s+ago/i.test(spaced))return;const cleaned=removeAgePhrase(spaced.replace(/^(?:در\s*)/,'').trim());if(!cleaned)return;const token=tagFromText(cleaned.replace(/^#/,'').trim());if(token.length>1&&token.length<48&&!tags.some(t=>norm(t)===norm(token)))tags.push(token);};
 const categories=(facts.categories||[]).map(x=>norm(x));
 if(facts.transactionType==='rent'||categories.some(x=>/اجاره|رهن/.test(x)))add('اجاره');
 else if(facts.transactionType==='sale'||categories.some(x=>/خرید|فروش/.test(x)))add('خرید_و_فروش');
 if(categories.some(x=>/مسکونی/.test(x)))add('مسکونی');
 if(facts.propertyType==='زمین/باغ'||categories.some(x=>/زمین|باغ/.test(x)))add('زمین_و_باغ');
 else if(facts.propertyType==='ویلا'||categories.some(x=>/خانه\s*و\s*ویلا|ویلا|ویلایی/.test(x)))add('ویلایی');
 else if(categories.some(x=>/تجاری|مغازه|سوله|دفتر کار|کارگاه/.test(x)))add('تجاری');
 else if(facts.propertyType==='آپارتمان'||categories.some(x=>/آپارتمان/.test(x)))add('آپارتمان');
 else if(facts.propertyType==='خانه')add('خانه');
 // The locality is authored from normalized location fields, never from time-stamped page snippets.
 [facts.city,facts.neighborhood].filter(Boolean).forEach(x=>add(x));
 if(facts.street)add(String(facts.street).replace(/^(?:خیابان|خ\.?|خ)\s*/,'').trim());
 for(const raw of item.tags||[]){
   let t=String(raw||'').replace(/^#/,'').replace(/_/g,' ').trim();if(!t)continue;
   if(/(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش|^(?:در\s*)?(?:نیشابور|تهران|مشهد)\s+(?:در\s+)?(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش/i.test(t))continue;
   if(/^(?:فایل ملک|املاک|اجاره خانه و ویلا|خانه و ویلا|خرید و فروش|دسته ها|دیوار|من|چت|پشتیبانی)$/i.test(t))continue;
   if(/^(?:زمین و باغ|زمین)$/.test(norm(t))&&facts.propertyType!=='زمین/باغ')continue;
   if(/^اجاره$/.test(norm(t))&&facts.transactionType==='sale')continue;
   if(/^(?:فروش|خرید و فروش)$/.test(norm(t))&&facts.transactionType==='rent')continue;
   if(/در\s+(?:نیشابور|سرآب|سرآب)/.test(t)&&/(?:پیش|دقیقه|ساعت|روز|هفته|ماه)/.test(t))continue;
   add(t);
 }
 add('املاک_ققنوس');
 return tags.slice(0,9).map(t=>t.startsWith('#')?t:'#'+t);
}
function officeFilePostFacts(item={}){
 const property=String(item.officePropertyType||'');const transaction=String(item.officeTransactionType||item.transactionType||'sale');
 const amenities=Array.isArray(item.amenities)?[...new Set(item.amenities.map(v=>String(v||'').trim()).filter(Boolean))]:[];
 const propertyType=property==='land'?'زمین/باغ':property==='villa'?'ویلا':'تجاری';
 const listingType=item.listingType|| (transaction==='rent'?(property==='villa'?'rent_residential':'rent_shop'):(property==='land'?'sale_land':property==='villa'?'sale_residential':'sale_shop'));
 const location=String(item.location||[item.city||'نیشابور',item.neighborhood||''].filter(Boolean).join('، '));
 return {
  title:String(item.title||'فایل ملک'),transactionType:transaction,transactionLabel:transaction==='rent'?'اجاره':'خرید و فروش',
  listingType,listingTypeLabel:listingTypeLabel(listingType),propertyType,location,city:String(item.city||'نیشابور'),neighborhood:String(item.neighborhood||''),street:String(item.street||''),
  fullLocation:[item.city||'نیشابور',item.neighborhood||'',item.street||''].filter(Boolean).join('، '),categories:Array.isArray(item.categories)?item.categories:[],
  deposit:String(item.deposit||''),monthlyRent:String(item.monthlyRent||''),salePrice:String(item.salePrice||''),pricePerMeter:String(item.pricePerMeter||''),
  builtArea:property==='villa'?String(item.buildingArea||item.builtArea||''):'',landArea:(property==='land'||property==='villa')?String(item.area_sqm||item.landArea||''):(property==='commercial'?String(item.area_sqm||''):''),
  year:String(item.year||''),rooms:String(item.rooms||''),amenities,featureFlags:{parking:amenities.includes('پارکینگ'),storage:amenities.includes('انباری'),balcony:amenities.includes('بالکن')},
  convertible:item.convertible===true?true:item.convertible===false?false:null,description:String(item.publicDescription||item.description||'')
 };
}
function makePost(x, rawConfig={}){
 const cfg=normalizeSendSettings(rawConfig||{});const f=x?.source==='office-file'?officeFilePostFacts(x):extractListingFacts(x);
 const commercial=/(?:تجاری|مغازه|سوله|انبار|کارگاه|دفتر کار)/i.test(String(f.title||'')+' '+(f.categories||[]).join(' ')+' '+String(x.title||''));
 const icon=f.propertyType==='زمین/باغ'?'🌳':commercial?'🏬':f.propertyType==='آپارتمان'?'🏢':f.transactionType==='rent'?'🏡':'🏠';
 const title=cleanPublicValue(f.title||x.title||'آگهی ملک').replace(/[\r\n]+/g,' ').replace(/^(?:🏡|🏠|🏢|🌳|🏘️?|🏬)\s*/,'').trim();
 const priceRows=[];
 if(f.transactionType==='rent'){
  if(f.deposit)priceRows.push(`💰 رهن: ${moneyDisplay(f.deposit)}`);
  if(f.monthlyRent)priceRows.push(`💵 اجاره: ${moneyDisplay(f.monthlyRent)}`);
  if(f.deposit||f.monthlyRent){if(f.convertible===true)priceRows.push('🔄 قابل تبدیل: ✅');else if(f.convertible===false)priceRows.push('🔄 قابل تبدیل: ❌');}
 }else if(f.transactionType==='sale'){
  if(f.salePrice)priceRows.push(`💰 قیمت کل: ${moneyDisplay(f.salePrice)}`);
  if(f.pricePerMeter)priceRows.push(`📏 قیمت هر متر: ${moneyDisplay(f.pricePerMeter)}`);
 }
 const loc=[removeAgePhrase(f.city),removeAgePhrase(f.neighborhood)].map(v=>cleanPublicValue(v).replace(/^[،,؛\s]+|[،,؛\s]+$/g,'')).filter(Boolean).join('، ');
 let locationLine='';if(loc)locationLine=`📍 موقعیت: ${persianDigits(loc)}`;else if(f.location){const v=cleanPublicValue(removeAgePhrase(f.location)).replace(/^[،,؛\s]+|[،,؛\s]+$/g,'');if(v)locationLine=`📍 موقعیت: ${persianDigits(v)}`;}
 let streetLine='';if(cfg.includeStreet&&f.street){const streetLabel=String(f.street).replace(/^(?:خیابان|خ\.?|خ)\s*/,'').replace(/^[:：\s]+/,'').trim();if(streetLabel)streetLine=`🛣 خیابان: ${persianDigits(streetLabel)}`;}
 let landAreaLine='';if(x?.source==='office-file'){const oa=String(x.area_sqm||'');if(oa){const areaLabel=x.officePropertyType==='commercial'?'متراژ واحد':'متراژ زمین';landAreaLine=`📐 ${areaLabel}: ${areaDisplay(oa)}`;}}else if(f.propertyType==='زمین/باغ'){if(f.landArea)landAreaLine=`📐 متراژ زمین: ${areaDisplay(f.landArea)}`;}else if(f.landArea)landAreaLine=`📐 متراژ کل: ${areaDisplay(f.landArea)}`;
 const builtAreaLine=f.propertyType!=='زمین/باغ'&&f.builtArea?`🏠 متراژ ساخته‌شده: ${areaDisplay(f.builtArea)}`:'';
 const yearLine=f.propertyType!=='زمین/باغ'&&f.year?`🏗 سال ساخت: ${persianDigits(f.year)}`:'';
 const roomsLine=f.propertyType!=='زمین/باغ'&&f.rooms?`🛏 تعداد اتاق: ${persianDigits(f.rooms)}`:'';
 let amenitiesLine='';if(cfg.includeAmenities&&f.propertyType!=='زمین/باغ'){if(x?.source==='office-file'){if(Array.isArray(f.amenities)&&f.amenities.length)amenitiesLine=`🏠 امکانات: ${f.amenities.join('، ')}`;}else{const flags=f.featureFlags||{};amenitiesLine=`🚗 پارکینگ: ${flags.parking?'✅':'❌'}  |  📦 انباری: ${flags.storage?'✅':'❌'}  |  🌤 بالکن: ${flags.balcony?'✅':'❌'}`;}}
 let descriptionLine='';if(cfg.includeDescription&&f.description){const desc=String(f.description).trim().slice(0,cfg.descriptionMaxLength);if(desc)descriptionLine=`📝 توضیحات بیشتر: ${desc}`;}
 const tagsLine=cfg.includeTags?makeTags(x,f).reduce((rows,tag,index)=>{if(index%3===0)rows.push([]);rows[rows.length-1].push(tag);return rows;},[]).map(row=>row.join(' ')).join('\n'):'';
 const values={
  title:`${icon} ${title}`,
  price_block:priceRows.join('\n'),
  deposit:priceRows.find(z=>z.startsWith('💰 رهن:'))||'',
  monthly_rent:priceRows.find(z=>z.startsWith('💵 اجاره:'))||'',
  convertible:priceRows.find(z=>z.startsWith('🔄 قابل تبدیل:'))||'',
  sale_price:priceRows.find(z=>z.startsWith('💰 قیمت کل:'))||'',
  price_per_meter:priceRows.find(z=>z.startsWith('📏 قیمت هر متر:'))||'',
  location:locationLine,
  street:streetLine,
  land_area:landAreaLine,
  built_area:builtAreaLine,
  year:yearLine,
  rooms:roomsLine,
  amenities:amenitiesLine,
  description:descriptionLine,
  tags:tagsLine,
  contact:`📞 تماس : ${contactDisplayDigits()}`,
  separator:'━━━━━━━━━━━━━━━━━━━━',
  listing_type:listingTypeLabel(f.listingType)
 };
 let template=String(cfg.messageTemplate||DEFAULT_MESSAGE_TEMPLATE).trim()||DEFAULT_MESSAGE_TEMPLATE;
 let text=template.replace(/\{\{([a-z_]+)\}\}/gi,(whole,key)=>Object.prototype.hasOwnProperty.call(values,key.toLowerCase())?values[key.toLowerCase()]:'');
 // A variable is a complete display row. Remove empty rows from optional facts; preserve user-authored headings.
 text=text.split('\n').filter(line=>!/^\s*\{\{[a-z_]+\}\}\s*$/i.test(line)).join('\n');
 text=text.replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n');if(template===DEFAULT_MESSAGE_TEMPLATE)text=text.replace(/\n{2,}/g,'\n');else text=text.replace(/\n{3,}/g,'\n\n');text=text.trim();
 if(text.length>2800)text=text.slice(0,2795).replace(/\s+\S*$/,'')+'…';
 return renderEmojiAliases(text);
}
function resolveImageUrl(item, rawConfig={}){
 const cfg=normalizeSendSettings(rawConfig||{});if(cfg.imageMode==='none')return '';
 const imgs=Array.isArray(item.imageUrls)?item.imageUrls.filter(u=>/^(?:https?:\/\/|data:image\/)/i.test(String(u||''))):[];
 const selected=Number(item.selectedImageIndex||0);if(selected>0&&imgs[selected-1])return imgs[selected-1];
 const defaultImages=cfg.defaultImages||{};const type=item.listingType||classifyListingType(item);const defaultImage=defaultImages[type]||defaultImages.unknown||'';
 if(cfg.imageMode==='default')return defaultImage;
 if(cfg.imageMode==='first')return imgs[0]||imgs[1]||defaultImage;
 return imgs[1]||imgs[0]||defaultImage;
}
function moneyDisplay(value){const s=cleanPublicValue(value);if(!s)return '';if(/رایگان|مجانی|توافقی/.test(norm(s)))return s;const numeric=asciiDigits(s).replace(/[\s,٬،]/g,'').replace(/(?:تومان|ریال)/g,'');if(/^\d+$/.test(numeric)){const amount=persianDigits(new Intl.NumberFormat('en-US').format(Number(numeric)));const unit=/ریال/.test(s)?'ریال':'تومان';return amount+' '+unit;}if(/تومان|ریال|میلیون|میلیارد/.test(s))return s;return s+' تومان';}
function areaDisplay(value){let s=cleanPublicValue(value);s=persianDigits(asciiDigits(s));s=s.replace(/متر\s*مربع/g,'مترمربع');return /متر/.test(s)?s:s+' مترمربع';}

async function waitForContentScript(tabId,timeoutMs=45000){
 const started=Date.now();let lastError='ابزار ثبت آگهی هنوز آماده نیست.';
 while(Date.now()-started<timeoutMs){
  const tab=await chrome.tabs.get(tabId).catch(()=>null);if(!tab)throw new Error('صفحهٔ آگهی بسته شد.');
  try{const ping=await chrome.tabs.sendMessage(tabId,{type:'DIVAR_PING'});if(ping?.ok)return true;}catch(e){lastError=e?.message||String(e);}
  await new Promise(r=>setTimeout(r,700));
 }
 throw new Error('ابزار ثبت آگهی در ۴۵ ثانیه آماده نشد: '+lastError);
}
function mergeFreshDetailIntoListing(oldItem, detail, sendSettings) {
 const old=oldItem||{};const d=detail||{};
 const freshText=String(d.publicDescription||d.text||'').trim();
 const freshDetailText=String(d.detailText||'').trim();
 const freshImages=Array.isArray(d.imageUrls)?d.imageUrls.filter(x=>/^https?:\/\//i.test(String(x||''))):[];
 const oldImages=Array.isArray(old.imageUrls)?old.imageUrls.filter(x=>/^https?:\/\//i.test(String(x||''))):[];
 const imageUrls=[...new Set([...freshImages,...oldImages])].slice(0,35);
 const hasUsefulDetail=!!(d.title&&freshDetailText.length>=30);
 const merged={
  ...old,
  ...(hasUsefulDetail?d:{}),
  id:old.id||d.id,
  url:old.url||d.url,
  title:hasUsefulDetail?String(d.title||old.title||'آگهی').trim().slice(0,300):old.title,
  location:String(d.location||old.location||'').trim(),
  categories:Array.isArray(d.categories)&&d.categories.length?d.categories:(old.categories||[]),
  categoryLinks:Array.isArray(d.categoryLinks)&&d.categoryLinks.length?d.categoryLinks:(old.categoryLinks||[]),
  text:freshText.length>=25?freshText:String(old.text||old.publicDescription||''),
  publicDescription:freshText.length>=25?String(d.publicDescription||d.text).slice(0,7000):String(old.publicDescription||old.text||''),
  detailText:freshDetailText.length>=30?freshDetailText.slice(0,10000):String(old.detailText||old.text||''),
  description:String(d.description||old.description||'').slice(0,5000),
  priceText:String(d.priceText||old.priceText||''),
  attributes:Array.isArray(d.attributes)&&d.attributes.length?d.attributes.slice(0,40):(old.attributes||[]),
  imageUrls,
  code:old.code||generateListingCode(),
  collectedAt:old.collectedAt||Date.now(),
  status:old.status||'pending',
  source:old.source||'phone-read-refresh',
  tags:[...new Set([...(old.tags||[]),...(d.tags||[])])],
  lastFullRefreshAt:Date.now(),
  lastFullRefreshStatus:hasUsefulDetail?'success':'partial',
  lastFullRefreshMessage:hasUsefulDetail?'اطلاعات آگهی از صفحهٔ جزئیات دوباره خوانده شد.':'صفحه باز شد، اما اطلاعات کافی برای جایگزینی جزئیات قبلی به‌دست نیامد.'
 };
 merged.listingType=classifyListingType(merged);merged.listingTypeLabel=listingTypeLabel(merged.listingType);
 merged.facts=extractListingFacts(merged);
 merged.agencyCheck=classifyAgency({...merged,text:String(merged.detailText||'')+'\n'+String(merged.description||'')});
 merged.ageKnown=d.ageKnown===true&&Number.isFinite(Number(d.ageDays))?true:old.ageKnown===true;
 if(merged.ageKnown&&d.ageKnown===true)merged.ageDays=d.ageDays;
 merged.publicPost=makePost(merged,sendSettings||DEFAULT_SEND_SETTINGS);
 return merged;
}
async function readPhoneFromListing(id){
 const state=await chrome.storage.local.get({queue:[]});const item=(state.queue||[]).find(x=>x.id===id);
 if(!item)throw new Error('آگهی در صف پیدا نشد.');
 if(!/^https:\/\/([a-z0-9-]+\.)?divar\.ir\//i.test(String(item.url||'')))throw new Error('پیوند منبع این آگهی ثبت نشده است.');
 const tab=await chrome.tabs.create({url:item.url,active:true});
 try{
  await waitForContentScript(tab.id,45000);
  // Refresh details while the public listing content is still clean, before clicking the reveal-phone control.
  // This avoids accidentally mixing the private phone number into publicDescription/publicPost.
  let detailResult=null,refreshError='';
  try{
   detailResult=await chrome.tabs.sendMessage(tab.id,{type:'DIVAR_EXTRACT_DETAIL_READY',expectedId:id});
   if(!detailResult?.ok||!detailResult?.item||String(detailResult.item.id)!==String(id))refreshError=detailResult?.error||'جزئیات کامل از صفحه دریافت نشد.';
  }catch(e){refreshError=e?.message||String(e);}
  const result=await chrome.tabs.sendMessage(tab.id,{type:'DIVAR_READ_PHONE'});
  const latest=await chrome.storage.local.get({queue:[],sendSettings:DEFAULT_SEND_SETTINGS});
  const queue=Array.isArray(latest.queue)?latest.queue:[];
  const index=queue.findIndex(x=>String(x.id)===String(id)||canonicalDivarListing(x.url)?.id===String(id));
  if(index<0)throw new Error('آگهی پس از بازخوانی در بانک ققنوس پیدا نشد.');
  const old=queue[index];
  const detail=(detailResult?.ok&&detailResult?.item&&String(detailResult.item.id)===String(id))?detailResult.item:null;
  let updated=detail?mergeFreshDetailIntoListing(old,detail,latest.sendSettings):{...old,lastFullRefreshAt:Date.now(),lastFullRefreshStatus:'failed',lastFullRefreshMessage:refreshError||'جزئیات آگهی تازه‌سازی نشد.'};
  const phones=result?.phones?.length?result.phones:(detail?.phones?.length?detail.phones:(old.phones||[]));
  updated={...updated,phones,phoneSource:result?.phones?.length?'page-visible':(detail?.phones?.length?'page-visible':(old.phoneSource||'')),phoneReadAt:Date.now(),phoneReadStatus:result?.found?'found':result?.ok?'not_visible':'error',phoneReadMessage:result?.message||result?.error||'',updatedAt:Date.now()};
  // Rebuild the post again after the phone/read operation, keeping the public post separate from private phone metadata.
  updated.publicPost=makePost(updated,latest.sendSettings||DEFAULT_SEND_SETTINGS);
  queue[index]=updated;
  await chrome.storage.local.set({queue:retainQueue(queue)});
  if(phones.length)await archiveListingPhones(updated).catch(()=>{});
  return {ok:!!result?.ok,found:!!result?.found,phones:result?.phones||[],refreshed:!!detail,refreshError:detail?'':refreshError,refreshedTitle:updated.title,imageCount:(updated.imageUrls||[]).length,detailLength:String(updated.detailText||'').length,message:[result?.message||result?.error||'نتیجه‌ای از صفحه دریافت نشد.',detail?'اطلاعات آگهی در بانک ققنوس به‌روزرسانی شد.':'اطلاعات کامل آگهی به‌روزرسانی نشد: '+(refreshError||'استخراج جزئیات ناموفق بود.')].join(' ')};
 }catch(e){
  const latest=await chrome.storage.local.get({queue:[]});await chrome.storage.local.set({queue:(latest.queue||[]).map(x=>x.id===id?{...x,phoneReadAt:Date.now(),phoneReadStatus:'error',phoneReadMessage:String(e.message||e)}:x)});
  throw e;
 }finally{
  // Close the helper tab whether refresh and phone extraction succeed or fail.
  if(Number.isInteger(tab?.id)) await chrome.tabs.remove(tab.id).catch(()=>{});
 }
}
function canonicalDivarListing(raw){
 try{const u=new URL(String(raw||''));if(!/(^|\.)divar\.ir$/i.test(u.hostname))return null;const m=u.pathname.match(/^\/v\/([^/?#]+)/);if(!m)return null;let id=m[1];try{id=decodeURIComponent(id)}catch{};return {id,url:u.origin+u.pathname};}catch{return null;}
}
chrome.alarms.onAlarm.addListener(async a=>{if(a.name==='rubika-send-pending')await processQueuedRubikaSends();});
function requestError(message, props={}){const err=new Error(String(message||'خطای نامشخص'));Object.assign(err,props);return err;}
function shouldStopSendFallback(err){const status=Number(err?.httpStatus||0);if(err?.ambiguous||[401,403,429].includes(status))return true;const hint=String([err?.apiStatus,err?.message,err?.responseHint].filter(Boolean).join(' ')).toLowerCase();return /unauthori[sz]ed|invalid token|access denied|too many requests|rate.?limit|too_requests|invalid.?auth|توکن.{0,20}(نامعتبر|اشتباه)|محدودیت.{0,20}درخواست/.test(hint);}
// A 403 on image/file methods can be method-specific: the same bot may still be allowed to send text.
// Keep ambiguous results and rate limits protected, but let the ad pipeline fall back to the text path.
function shouldStopImageSendFallback(err){const status=Number(err?.httpStatus||0);if(err?.ambiguous||status===401||status===429)return true;const hint=String([err?.apiStatus,err?.message,err?.responseHint].filter(Boolean).join(' ')).toLowerCase();return /unauthori[sz]ed|invalid token|invalid.?auth|توکن.{0,20}(نامعتبر|اشتباه)|too many requests|rate.?limit|too_requests|محدودیت.{0,20}درخواست/.test(hint);}
async function rubikaRequest(method,payload,token,options={}){
 const timeoutMs=Number(options.timeoutMs)||(['sendMessage','sendFile'].includes(method)?45000:15000);
 let resp,raw,data;
 try{
  resp=await fetch(`https://botapi.rubika.ir/v3/${encodeURIComponent(token)}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout?AbortSignal.timeout(timeoutMs):undefined});
 }catch(e){
  const ambiguous=['sendMessage','sendFile'].includes(method);
  throw requestError((e?.name==='TimeoutError'||e?.name==='AbortError'?'زمان انتظار پاسخ روبیکا تمام شد. ':'ارتباط با روبیکا برقرار نشد. ')+(e?.message||String(e)),{ambiguous,method,stage:'request',recoverable:!ambiguous});
 }
 try{raw=await resp.text();data=parseApiJson(raw);}catch(e){throw requestError('خواندن پاسخ روبیکا ناموفق بود: '+(e.message||e),{ambiguous:['sendMessage','sendFile'].includes(method),method,stage:'response'});}
 if(resp.ok&&String(data.status||'').toUpperCase()==='OK')return data;
 const ambiguousSendResponse=['sendMessage','sendFile'].includes(method)&&resp.status>=500;
 const error=requestError(data.description||data.message||`خطای روبیکا (${resp.status})`,{ambiguous:ambiguousSendResponse,method,httpStatus:resp.status,apiStatus:data.status,stage:'api',responseHint:String(raw||'').slice(0,260)});
 if([429].includes(resp.status))error.recoverable=true;
 throw error;
}
async function safeRubikaRequest(method,payload,token,attempts=2){
 let lastError;
 for(let attempt=1;attempt<=attempts;attempt++){
  try{return await rubikaRequest(method,payload,token);}
  catch(err){lastError=err;if(err.ambiguous||!err.recoverable||attempt===attempts)throw err;await new Promise(r=>setTimeout(r,350*attempt));}
 }
 throw lastError||new Error('درخواست روبیکا ناموفق بود.');
}
async function sendImageWithCaption(token,imageUrl,text,itemId,showActions=true){
 text=addRubikaAdCta(text,showActions);
 const formatted=rubikaFormattedPayload(text);
 if(itemId)await updateQueueItem(itemId,{sendProgress:'در حال دریافت تصویر آگهی…'});
 const imageResponse=await fetch(imageUrl,{method:'GET',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout?AbortSignal.timeout(18000):undefined});
 if(!imageResponse.ok)throw requestError(`دریافت تصویر آگهی ناموفق بود (${imageResponse.status})`,{stage:'image_fetch',httpStatus:imageResponse.status});
 const rawBlob=await imageResponse.blob();
 if(!rawBlob.size)throw requestError('فایل تصویر خالی است.',{stage:'image_fetch'});
 if(rawBlob.size>30*1024*1024)throw requestError('حجم تصویر اولیه بیش از ۳۰ مگابایت است.',{stage:'image_fetch'});
 const mime=(rawBlob.type||'image/jpeg').split(';')[0];
 if(!mime.startsWith('image/'))throw requestError('نشانی تصویر، فایل تصویری معتبر برنگرداند.',{stage:'image_fetch'});
 const compressedImage=await compressOutboundImageTo3MB(rawBlob);const blob=compressedImage.blob;
 if(itemId)await updateQueueItem(itemId,{sendProgress:`تصویر فشرده شد (${(blob.size/1024/1024).toFixed(2)} مگابایت)؛ در حال درخواست بارگذاری روبیکا…`});
 const req=await rubikaRequest('requestSendFile',{type:'Image'},token,{timeoutMs:18000});
 const uploadUrl=req?.data?.upload_url||req?.upload_url;
 if(!uploadUrl||!/^https:\/\//i.test(uploadUrl))throw requestError('روبیکا نشانی بارگذاری تصویر را برنگرداند.',{stage:'request_upload_url'});
 const form=new FormData();form.append('file',blob,compressedImage.name||'qoqnus-listing.jpg');
 if(itemId)await updateQueueItem(itemId,{sendProgress:'در حال بارگذاری تصویر در روبیکا…'});
 const uploadResponse=await fetch(uploadUrl,{method:'POST',body:form,signal:AbortSignal.timeout?AbortSignal.timeout(25000):undefined});
 const uploadRaw=await uploadResponse.text();let uploadData;
 try{uploadData=parseApiJson(uploadRaw)}catch(e){throw requestError('پاسخ بارگذاری تصویر روبیکا معتبر نبود: '+e.message,{stage:'upload_response',httpStatus:uploadResponse.status,responseHint:String(uploadRaw).slice(0,260)});}
 const fileId=uploadData?.data?.file_id||uploadData?.file_id;
 if(!uploadResponse.ok||!fileId)throw requestError(uploadData?.description||uploadData?.message||`بارگذاری تصویر در روبیکا کامل نشد (${uploadResponse.status}).`,{stage:'upload',httpStatus:uploadResponse.status,apiStatus:uploadData?.status,responseHint:String(uploadRaw).slice(0,260)});
 const base={chat_id:FIXED_RUBIKA_CHAT_ID,file_id:fileId,text:formatted.text};
 // Keep the primary payload minimal and progressively add optional link features.
 // The final plain variant is essential: a rejected optional link must not block the actual ad.
 const variants=[];
 // First try both clickable text links and the original call button in one request.
 if(formatted.metadata)variants.push({payload:{...base,metadata:formatted.metadata,inline_keypad:contactInlineKeypad()},link:'text_links_and_keypad'});
 // If combined metadata is explicitly rejected, try text links alone, then the keypad alone.
 if(formatted.metadata)variants.push({payload:{...base,metadata:formatted.metadata},link:'metadata_only'});
 variants.push({payload:{...base,inline_keypad:contactInlineKeypad()},link:'keypad_only'});
 variants.push({payload:base,link:'plain'});
 let lastError=null;
 for(let i=0;i<variants.length;i++){
  const variant=variants[i];
  if(itemId)await updateQueueItem(itemId,{sendProgress:i===0?'تصویر بارگذاری شد؛ در حال ارسال آگهی به روبیکا…':`قالب اختیاری رد شد؛ روش ارسال جایگزین ${i+1} از ${variants.length}…`});
  try{
   const sent=await rubikaRequest('sendFile',variant.payload,token,{timeoutMs:25000});
   const messageId=sent?.data?.message_id||sent?.message_id||'';
   if(!messageId)throw requestError('روبیکا پاسخ ارسال تصویر را بدون شناسه پیام برگرداند؛ نتیجه نامشخص است. کانال را بررسی کن.',{ambiguous:true,method:'sendFile',stage:'response'});
   return {messageId,fileId,contactLinkStatus:variant.link,contactLinkError:i?String(lastError?.message||'روبیکا قالب پیشرفته را نپذیرفت؛ از قالب جایگزین استفاده شد.'):''};
  }catch(err){
   lastError=err;
   if(err?.ambiguous||shouldStopImageSendFallback(err))throw err;
   if(i<variants.length-1&&itemId)await updateQueueItem(itemId,{sendProgress:`روبیکا قالب ارسال ${i+1} را رد کرد؛ علت: ${String(err.message||err).slice(0,100)}. در حال تلاش با قالب ساده‌تر…`});
  }
 }
 throw lastError||requestError('روبیکا هیچ‌یک از قالب‌های ارسال تصویر را نپذیرفت.',{stage:'sendFile'});
}
async function sendRubikaText(token,text,itemId,showActions=true){
 text=addRubikaAdCta(text,showActions);
 const formatted=rubikaFormattedPayload(text);
 const base={chat_id:FIXED_RUBIKA_CHAT_ID,text:formatted.text};
 const variants=[];
 // Restore the original call keypad; the two text-style actions remain in the caption.
 variants.push({payload:{...base,inline_keypad:contactInlineKeypad()},link:'keypad_only'});
 // Try clickable text metadata only if the keypad format is rejected.
 if(formatted.metadata)variants.push({payload:{...base,metadata:formatted.metadata},link:'metadata_only'});
 variants.push({payload:base,link:'plain'});
 let lastError=null;
 for(let i=0;i<variants.length;i++){
  const v=variants[i];
  if(itemId)await updateQueueItem(itemId,{sendProgress:i===0?'در حال ارسال متن آگهی به روبیکا…':`روبیکا قالب اختیاری را رد کرد؛ تلاش ${i+1} از ${variants.length} با قالب ساده‌تر…`});
  try{
   const data=await rubikaRequest('sendMessage',v.payload,token,{timeoutMs:25000});
   const messageId=data?.data?.message_id||data?.message_id||'';
   if(!messageId)throw requestError('روبیکا پاسخ ارسال متن را بدون شناسه پیام برگرداند؛ نتیجه نامشخص است. کانال را بررسی کن.',{ambiguous:true,method:'sendMessage',stage:'response'});
   return {...data,_sentMessageId:messageId,_contactLinkStatus:v.link,_contactLinkWarning:i?String(lastError?.message||'روبیکا قالب پیشرفتهٔ لینک را نپذیرفت؛ پیام با قالب ساده‌تر ارسال شد.'):''};
  }catch(err){
   lastError=err;
   if(err?.ambiguous||shouldStopSendFallback(err))throw err;
   if(i<variants.length-1&&itemId)await updateQueueItem(itemId,{sendProgress:`روبیکا قالب ${i+1} را رد کرد؛ در حال تلاش با درخواست ساده‌تر…`});
  }
 }
 throw lastError||requestError('روبیکا پیام را نپذیرفت.',{stage:'sendMessage'});
}

function platformError(message,props={}){const e=new Error(String(message||'خطای ارسال'));Object.assign(e,props);return e;}
function splitForMessage(text,max=3800){
 const source=String(text||'');if(!source)return [];
 const parts=[];let rest=source;
 while(rest.length>max){let cut=rest.lastIndexOf('\n',max);if(cut<Math.floor(max*.65))cut=max;parts.push(rest.slice(0,cut).trimEnd());rest=rest.slice(cut).replace(/^\n+/, '');}
 if(rest)parts.push(rest);return parts;
}
function textHash(text){let h=2166136261;for(const ch of String(text||'')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return (h>>>0).toString(16);}
async function parseExternalResponse(resp,platform,method){
 let raw='',data;
 try{raw=await resp.text();data=parseApiJson(raw);}catch(e){throw platformError(`${platform}: پاسخ ${method} قابل‌خواندن نبود.`,{ambiguous:resp.status>=500||['sendMessage','sendFile','sendPhoto'].includes(method),httpStatus:resp.status,stage:'response',responseHint:String(raw||'').slice(0,240)});}
 if(!resp.ok)throw platformError(data?.description||data?.message||`${platform}: خطای HTTP ${resp.status}`,{ambiguous:resp.status>=500,httpStatus:resp.status,apiStatus:data?.error_code||data?.status||'',stage:method,responseHint:String(raw).slice(0,240)});
 return data;
}
function normalizeEitaaChatId(value){
 let id=String(value||'').trim();
 id=id.replace(/^https?:\/\/(?:www\.)?eitaa\.com\//i,'').replace(/^\/+|\/+$/g,'').split(/[?#]/)[0];
 if(!id) return '';
 if(/^@/.test(id)||/^-?\d+$/.test(id)) return id;
 // EitaaYar bot API accepts channel usernames in @username form; keep numeric chat ids untouched.
 if(/^[A-Za-z0-9_]+$/.test(id)) return '@'+id;
 return id;
}
async function eitaaRequest(method,config,{text='',imageBlob=null,imageName='listing.jpg',title='',caption='',parseMode=''}={}){
 const token=String(config?.token||'').trim(),chatId=normalizeEitaaChatId(config?.chatId);if(!token||!chatId)throw platformError('توکن و شناسهٔ مقصد ایتا وارد نشده است.',{stage:'configuration'});if(!/^[A-Za-z0-9:_-]+$/.test(token))throw platformError('قالب توکن ایتا معتبر نیست؛ توکن را بدون فاصله وارد کن.',{stage:'configuration'});
 let url,resp;
 if(method==='sendMessage'){
  // Channel posting uses the token-scoped EitaaYar bot API, not /api/app/sendMessage
  // which is intended for app-to-user messages requiring the user's Eitaa ID/permission.
  url=`https://eitaayar.ir/api/${token}/sendMessage`;
  const body=new URLSearchParams({chat_id:chatId,text:String(text||'')});if(parseMode)body.set('parse_mode',parseMode);
  try{resp=await fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body,signal:AbortSignal.timeout?AbortSignal.timeout(35000):undefined});}
  catch(e){throw platformError('ارتباط با ایتا برقرار نشد: '+String(e?.message||e),{ambiguous:true,stage:'request'});}
 }else if(method==='sendFile'){
  url=`https://eitaayar.ir/api/${token}/sendFile`;
  const form=new FormData();form.append('chat_id',chatId);if(title)form.append('title',title);if(caption)form.append('caption',caption);if(parseMode)form.append('parse_mode',parseMode);if(imageBlob)form.append('file',imageBlob,imageName);
  try{resp=await fetch(url,{method:'POST',body:form,signal:AbortSignal.timeout?AbortSignal.timeout(60000):undefined});}
  catch(e){throw platformError('ارتباط با ایتا برای بارگذاری تصویر برقرار نشد: '+String(e?.message||e),{ambiguous:true,stage:'upload'});}
 }else throw platformError('متد ایتا پشتیبانی نمی‌شود.',{stage:'method'});
 const data=await parseExternalResponse(resp,'ایتا',method);
 const accepted=data?.ok===true||String(data?.result||'').toLowerCase()==='success'||String(data?.status||'').toUpperCase()==='OK';
 if(!accepted)throw platformError(data?.description||data?.message||data?.error||'ایتا درخواست را تأیید نکرد.',{ambiguous:false,httpStatus:resp.status,apiStatus:data?.error_code||data?.status||data?.result||'',stage:method,responseHint:JSON.stringify(data).slice(0,240)});
 return data;
}
async function blobIsWebP(blob,imageUrl=''){
 const mime=String(blob?.type||'').split(';')[0].toLowerCase();
 if(mime==='image/webp')return true;
 try{
  const head=new Uint8Array(await blob.slice(0,12).arrayBuffer());
  if(head.length>=12&&head[0]===0x52&&head[1]===0x49&&head[2]===0x46&&head[3]===0x46&&head[8]===0x57&&head[9]===0x45&&head[10]===0x42&&head[11]===0x50)return true;
 }catch(_){}
 return !mime&&/\.webp(?:[?#]|$)/i.test(String(imageUrl||''));
}
async function convertWebPToJpeg(blob){
 let bitmap=null;
 try{
  if(typeof createImageBitmap!=='function'||typeof OffscreenCanvas!=='function')throw new Error('مرورگر تبدیل تصویر WebP به JPEG را پشتیبانی نمی‌کند.');
  bitmap=await createImageBitmap(blob);
  if(!bitmap.width||!bitmap.height)throw new Error('ابعاد تصویر WebP معتبر نیست.');
  const canvas=new OffscreenCanvas(bitmap.width,bitmap.height);
  const ctx=canvas.getContext('2d',{alpha:false});
  if(!ctx)throw new Error('ساخت بوم تبدیل تصویر ناموفق بود.');
  ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0);
  const converted=await canvas.convertToBlob({type:'image/jpeg',quality:0.9});
  if(!converted||!converted.size||!String(converted.type).toLowerCase().includes('image/jpeg'))throw new Error('تبدیل تصویر WebP به JPEG خروجی معتبر نداد.');
  return converted;
 }catch(e){
  throw platformError('تصویر آگهی WebP است و برای ارسال کپشن‌دار به ایتا باید به JPEG تبدیل شود؛ تبدیل ناموفق بود: '+String(e?.message||e),{stage:'image_convert',cause:String(e?.message||e)});
 }finally{try{bitmap?.close?.();}catch(_){}}
}
async function compressOutboundImageTo3MB(blob){
 if(typeof createImageBitmap!=='function'||typeof OffscreenCanvas!=='function'){
  if(blob.size<=3*1024*1024){const mime=String(blob.type||'image/jpeg').split(';')[0].toLowerCase();const ext=mime.includes('png')?'png':mime.includes('webp')?'webp':'jpg';return {blob,name:`qoqnus-listing.${ext}`,mime};}
  throw platformError('برای فشرده‌سازی عکس تا حداکثر ۳ مگابایت، مرورگر را به‌روز کنید.',{stage:'image_compress'});
 }
 let bitmap=null;
 try{
  bitmap=await createImageBitmap(blob);
  if(!bitmap.width||!bitmap.height)throw new Error('ابعاد عکس معتبر نیست.');
  let scale=Math.min(1,1920/Math.max(bitmap.width,bitmap.height));
  for(let pass=0;pass<8;pass++){
   const canvas=new OffscreenCanvas(Math.max(1,Math.round(bitmap.width*scale)),Math.max(1,Math.round(bitmap.height*scale)));
   const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)throw new Error('ساخت بوم فشرده‌سازی ناموفق بود.');
   ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
   for(const quality of [0.82,0.74,0.66,0.58,0.50,0.42]){
    const out=await canvas.convertToBlob({type:'image/jpeg',quality});
    if(out&&out.size>0&&out.size<=2.8*1024*1024)return {blob:out,name:'qoqnus-listing.jpg',mime:'image/jpeg'};
   }
   scale*=0.78;
  }
  throw new Error('پس از فشرده‌سازی، حجم عکس هنوز بیش از ۳ مگابایت است.');
 }catch(e){throw platformError('فشرده‌سازی عکس ناموفق بود: '+String(e?.message||e),{stage:'image_compress'});}
 finally{try{bitmap?.close?.();}catch(_){}}
}
async function fetchAdImageBlob(imageUrl){
 const resp=await fetch(imageUrl,{method:'GET',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout?AbortSignal.timeout(25000):undefined});
 if(!resp.ok)throw platformError(`دریافت تصویر آگهی ناموفق بود (${resp.status}).`,{stage:'image_fetch',httpStatus:resp.status});
 let blob=await resp.blob();if(!blob.size)throw platformError('فایل تصویر خالی است.',{stage:'image_fetch'});if(blob.size>30*1024*1024)throw platformError('حجم تصویر اولیه بیش از ۳۰ مگابایت است.',{stage:'image_fetch'});
 const mime=(blob.type||'').split(';')[0].toLowerCase();if(mime&&!mime.startsWith('image/'))throw platformError('نشانی تصویر، فایل تصویری معتبر برنگرداند.',{stage:'image_fetch'});
 const compressed=await compressOutboundImageTo3MB(blob);
 return {blob:compressed.blob,name:compressed.name,convertedFrom:mime==='image/webp'?'webp':'compressed',mime:compressed.mime||'image/jpeg'};
}
function externalAmbiguous(err){return !!err?.ambiguous||['TimeoutError','AbortError'].includes(err?.name)||[502,503,504].includes(Number(err?.httpStatus||0));}
function eitaaHtmlFormattedText(value){
 const escapeHtml=value=>String(value||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 const lines=String(value||'').split('\n');let titleDone=false;
 const labelRx=/(?:قیمت کل|قیمت هر متر|قیمت هر متر مربع|رهن|اجاره|قابل تبدیل|موقعیت|خیابان|متراژ زمین|متراژ کل|متراژ ساخته.?شده|زیربنا|سال ساخت|تعداد خواب|تعداد اتاق|پارکینگ|انباری|بالکن|توضیحات بیشتر|دسته.?بندی|تماس)\s*[:：]/u;
 return lines.map(line=>{
  const trimmed=line.trim();
  if(!trimmed)return '';
  if(!titleDone&&!/^━{3,}$/.test(trimmed)&&!/^█.*ثبت آگهی رایگان/.test(trimmed)&&!/^░▒▓█ تماس با ما/.test(trimmed)){
   titleDone=true;const left=line.slice(0,line.indexOf(trimmed));return escapeHtml(left)+'<b>'+escapeHtml(trimmed)+'</b>';
  }
  const m=line.match(/^(\s*[^:：\n]{1,40}[:：])(?=\s|$)/u);
  if(m&&labelRx.test(m[1]))return escapeHtml(m[1])===m[1] ? '<b>'+escapeHtml(m[1])+'</b>'+escapeHtml(line.slice(m[1].length)) : '<b>'+escapeHtml(m[1])+'</b>'+escapeHtml(line.slice(m[1].length));
  return escapeHtml(line);
 }).join('\n');
}

function splitEitaaCaption(text,limit=1000){
 const chars=Array.from(String(text||''));if(chars.length<=limit)return {caption:chars.join(''),remainder:''};
 let cut=limit;for(let i=limit-1;i>=Math.floor(limit*0.72);i--){if(chars[i]==='\n'||chars[i]===' '){cut=i+1;break;}}
 return {caption:chars.slice(0,cut).join(''),remainder:chars.slice(cut).join('')};
}
async function sendExternalPlatform(platform,item,config,previous,cfg){
 const text=makePost(item,cfg);if(!text)return {status:'failed',error:'متن آگهی خالی است.',stage:'format',textPartsSent:0,imageStatus:'not_attempted'};
 const hash=textHash(text),same=previous?.textHash===hash;
 let textPartsSent=same?Math.max(0,Number(previous?.textPartsSent)||0):0;
 let imageStatus=same?(previous?.imageStatus||'not_attempted'):'not_attempted';
 let imageError=same?String(previous?.imageError||''):'';
 const imageUrl=resolveImageUrl(item,cfg);
 const sendText=async(part)=>{const formatted=eitaaHtmlFormattedText(part);try{return await eitaaRequest('sendMessage',config,{text:formatted,parseMode:'HTML'});}catch(err){if(externalAmbiguous(err))throw err;return eitaaRequest('sendMessage',config,{text:part});}};
 // If there is no picture, publish the ad as text using the established chunking logic.
 if(!imageUrl){
  const parts=splitForMessage(text,3800),resultBase={platform,textHash:hash,textPartsSent,textPartsTotal:parts.length,imageStatus:'not_available',imageError:'',lastAttemptAt:Date.now(),deliveryMode:'text_only'};
  for(let i=textPartsSent;i<parts.length;i++){
   try{const resp=await sendText(parts[i]);textPartsSent=i+1;resultBase.textPartsSent=textPartsSent;resultBase.lastMessageId=resp?.result?.message_id||resp?.result?.messageId||resp?.message_id||'';}
   catch(e){return {...resultBase,status:textPartsSent?'partial':(externalAmbiguous(e)?'unknown':'failed'),textPartsSent,error:String(e?.message||e),stage:e?.stage||'sendMessage',ambiguous:externalAmbiguous(e),httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',responseHint:e?.responseHint||''};}
  }
  return {...resultBase,status:'sent',textPartsSent,textPartsTotal:parts.length,imageStatus:'not_available',imageError:'',sentAt:Date.now()};
 }
 // EitaaYar sendFile supports a caption. Use one photo post with the ad text as caption,
 // instead of publishing the entire text first and a detached photo afterwards.
 const legacyTextAlreadySent=same&&!previous?.deliveryMode&&textPartsSent>0&&imageStatus!=='sent';
 const {caption,remainder}=legacyTextAlreadySent?{caption:'',remainder:''}:splitEitaaCaption(text,1000);
 const tailParts=remainder?splitForMessage(remainder,3800):[];
 let tailSent=(same&&previous?.deliveryMode==='photo_caption')?Math.max(0,Number(previous?.textPartsSent)||0):0;
 const resultBase={platform,textHash:hash,textPartsSent:tailSent,textPartsTotal:tailParts.length,imageStatus,imageError,lastAttemptAt:Date.now(),deliveryMode:legacyTextAlreadySent?'legacy_text_then_photo':'photo_caption',captionLength:Array.from(caption).length};
 // Upload the photo (with caption) first. On retries, do not re-upload a photo already confirmed.
 if(imageStatus!=='sent'){
  try{
   const {blob,name}=await fetchAdImageBlob(imageUrl);const shortTitle=String(item.title||'تصویر آگهی ققنوس').trim().slice(0,160);
   let resp;try{resp=await eitaaRequest('sendFile',config,{imageBlob:blob,imageName:name,title:shortTitle,caption:eitaaHtmlFormattedText(caption),parseMode:'HTML'});}catch(formatError){if(externalAmbiguous(formatError))throw formatError;resp=await eitaaRequest('sendFile',config,{imageBlob:blob,imageName:name,title:shortTitle,caption});}
   imageStatus='sent';imageError='';resultBase.imageStatus='sent';resultBase.imageUrl=imageUrl;resultBase.imageError='';resultBase.lastMediaId=resp?.result?.message_id||resp?.result?.messageId||resp?.message_id||'';
  }catch(e){imageStatus=externalAmbiguous(e)?'unknown':'failed';imageError=String(e?.message||e);return {...resultBase,status:externalAmbiguous(e)?'unknown':'failed',imageStatus,imageError,error:imageError,stage:e?.stage||'sendFile',ambiguous:externalAmbiguous(e),httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',responseHint:e?.responseHint||'',textSent:legacyTextAlreadySent};}
 }else resultBase.imageStatus='sent';
 // Eitaa captions have a finite size. Any remaining long text is sent after the photo;
 // keep progress so retries continue from the first unsent continuation part.
 for(let i=tailSent;i<tailParts.length;i++){
  try{const resp=await sendText(tailParts[i]);tailSent=i+1;resultBase.textPartsSent=tailSent;resultBase.lastMessageId=resp?.result?.message_id||resp?.result?.messageId||resp?.message_id||'';}
  catch(e){return {...resultBase,status:tailSent?'partial':(externalAmbiguous(e)?'unknown':'partial'),textPartsSent:tailSent,textPartsTotal:tailParts.length,imageStatus:'sent',imageError:'',error:String(e?.message||e),stage:e?.stage||'sendMessage',ambiguous:externalAmbiguous(e),httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',responseHint:e?.responseHint||'',textSent:true};}
 }
 return {...resultBase,status:'sent',textPartsSent:tailSent,textPartsTotal:tailParts.length,imageStatus:'sent',imageError:'',sentAt:previous?.imageStatus==='sent'&&previous?.sentAt?previous.sentAt:Date.now()};
}
async function testEitaaSend(configOverride=null){
 const st=await chrome.storage.local.get({eitaa:{}}),cfg=configOverride||st.eitaa||{};const stamp=new Date().toLocaleString('fa-IR');const data=await eitaaRequest('sendMessage',cfg,{text:`✅ آزمون ارسال ققنوس به ایتا\nزمان: ${stamp}\nاین یک پیام آزمایشی متنی واقعی است.`});return {ok:true,result:data?.result||data?.status||'success',method:'sendMessage'};
}
async function testEitaaMediaSend(configOverride=null){
 const st=await chrome.storage.local.get({eitaa:{}}),cfg=configOverride||st.eitaa||{};
 const stamp=new Date().toLocaleString('fa-IR');
 const url=chrome.runtime.getURL('eitaa-test.png');
 const resp=await fetch(url);if(!resp.ok)throw platformError('فایل تصویر آزمایشی افزونه خوانده نشد.',{stage:'test_image',httpStatus:resp.status});
 const blob=await resp.blob();
 const data=await eitaaRequest('sendFile',cfg,{imageBlob:blob,imageName:'eitaa-test.png',title:'آزمون ارسال تصویر ایتا',caption:`✅ آزمون ارسال تصویر همراه کپشن — املاک ققنوس\nزمان: ${stamp}`});
 return {ok:true,result:data?.result||data?.status||'success',method:'sendFile'};
}

async function sendConfiguredPlatforms(item,stored,cfg,opts={}){
 if(!listingHasPhone(item))throw platformError('ارسال مسدود شد: این آگهی شماره تماس معتبر ندارد. ابتدا از «خواندن شماره» یا «ذخیره شماره» استفاده کن؛ تا ثبت شماره، به روبیکا و ایتا ارسال نمی‌شود.',{stage:'missing_phone'});
 const rubika=stored.rubika||{},eitaa=stored.eitaa||{};
 const previous={...(item.platformResults||{})};
 const forceResend=!!opts.forceResend;
 const officeFile=item?.source==='office-file';
 const rubikaReady=!!String(rubika.token||'').trim();
 const eitaaReady=!!String(eitaa.token||'').trim()&&!!String(eitaa.chatId||'').trim();
 if(officeFile&&(!rubikaReady||!eitaaReady))throw platformError('برای انتشار فایل دفتری در هر دو کانال، اتصال روبیکا و اتصال ایتا (توکن و شناسهٔ مقصد) باید تنظیم شده باشند. ابتدا هر دو اتصال را ذخیره و آزمایش کن؛ هیچ کانالی در این تلاش ارسال نمی‌شود.',{stage:'configuration'});
 const startingInArchive=!!opts.fromArchive||['archived','published'].includes(item.status);
 // Older archived listings that predate multi-platform state are treated as already sent to Rubika on retry,
 // but an explicit "resend" intentionally bypasses all previous sent states.
 if(!forceResend&&item.sendStatus==='published'&&!previous.rubika&&rubika.token)previous.rubika={status:'sent',legacy:true,sentAt:item.publishedAt||Date.now(),imageStatus:item.imageSendStatus||'unknown'};
 const targets=[];
 if(String(rubika.token||'').trim())targets.push({key:'rubika',label:'روبیکا',config:rubika});
 if(eitaa.enabled||officeFile)targets.push({key:'eitaa',label:'ایتا',config:eitaa});
 const eitaaConfiguredButDisabled=!officeFile&&!eitaa.enabled&&!!String(eitaa.token||'').trim()&&!!String(eitaa.chatId||'').trim()&&previous.eitaa?.status!=='sent';
 if(!targets.length)throw platformError('هیچ مقصد فعالی آمادهٔ ارسال نیست. توکن روبیکا را وارد کن یا در تنظیمات اتصال ایتا، گزینهٔ «ارسال آگهی‌ها به ایتا فعال باشد» را روشن کن.',{stage:'configuration'});
 const platforms={...previous};
 const outcomes=[];
 for(const target of targets){
  const old=forceResend?{}:(platforms[target.key]||{});
  if(!forceResend&&old.status==='sent'){
   outcomes.push({key:target.key,label:target.label,...old});
   await updateQueueItem(item.id,{sendStatus:'sending',sendProgress:`${target.label}: قبلاً با موفقیت ارسال شده؛ از آن عبور شد.`,platformResults:{...platforms}});
   continue;
  }
  const inProgress={...old,status:'sending',progress:`در حال ارسال به ${target.label}…`,lastAttemptAt:Date.now()};
  platforms[target.key]=inProgress;
  await updateQueueItem(item.id,{sendStatus:'sending',sendProgress:`در حال ارسال مرحله‌ای: ${target.label} (${targets.findIndex(t=>t.key===target.key)+1} از ${targets.length})`,platformResults:{...platforms}});
  let resultRecord;
  const conf=target.config||{};
  try{
   if(target.key!=='rubika'&&(!String(conf.token||'').trim()||!String(conf.chatId||'').trim()))throw platformError('ایتا فعال است اما توکن یا شناسهٔ مقصد تکمیل نشده است.',{stage:'configuration'});
   let result;
   if(target.key==='rubika')result=await sendRubika(item);
   else result=await sendExternalPlatform(target.key,item,conf,old,cfg);
   if(target.key==='rubika')resultRecord={status:'sent',sentAt:Date.now(),textHash:textHash(makePost(item,cfg)),imageStatus:result.imageStatus||'not_available',imageError:result.imageError||'',messageId:result.messageId||result.rubikaMessageId||'',method:result.method||'',contactLinkStatus:result.contactLinkStatus||'',error:'',lastAttemptAt:Date.now()};
   else resultRecord={...result,status:result.status||'sent',error:result.error||'',sentAt:result.status==='sent'?(result.sentAt||Date.now()):old.sentAt||null,lastAttemptAt:Date.now()};
  }catch(e){
   resultRecord={...old,status:externalAmbiguous(e)?'unknown':'failed',error:String(e?.message||e),stage:e?.stage||e?.method||'send',ambiguous:externalAmbiguous(e),httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',responseHint:e?.responseHint||'',lastAttemptAt:Date.now()};
  }
  platforms[target.key]=resultRecord;
  outcomes.push({key:target.key,label:target.label,...resultRecord});
  const readable=resultRecord.status==='sent'?'موفق':resultRecord.status==='partial'?'ناقص':resultRecord.status==='unknown'?'نامشخص':resultRecord.status==='sending'?'در حال ارسال':'ناموفق';
  await updateQueueItem(item.id,{sendStatus:'sending',sendProgress:`نتیجهٔ ${target.label}: ${readable}${resultRecord.error?' — '+resultRecord.error:''}`,platformResults:{...platforms},lastPlatformAttempt:target.key,lastPlatformResult:resultRecord.status});
 }
 if(eitaaConfiguredButDisabled&&String(platforms.eitaa?.status||'')!=='sent'){platforms.eitaa={...(platforms.eitaa||{}),status:'disabled',error:'توکن ایتا ذخیره شده، اما گزینهٔ ارسال آگهی‌ها به ایتا خاموش است.'};}
 const visibleOutcomes=[...outcomes,...(eitaaConfiguredButDisabled?[{key:'eitaa',label:'ایتا',...platforms.eitaa}]:[])];
 const officeSource=['office-file','office-ad','manual-office-ad'].includes(String(item.source||''))||item.recordKind==='file'||item.bookKey==='office-files';
 const bothRequired=!officeSource&&(item.recordKind==='listing'||item.bookKey==='qoqnus-files'||!item.recordKind);
 const hasReceipt=p=>!!String(p?.messageId||p?.rubikaMessageId||p?.deliveryId||p?.postId||p?.lastMessageId||p?.lastMediaId||'').trim();
 const allSent=bothRequired?(['rubika','eitaa'].every(key=>String(platforms[key]?.status||'')==='sent'&&hasReceipt(platforms[key]))):(outcomes.length>0&&outcomes.every(x=>x.status==='sent')); // Qoqnus listings require confirmed success receipts on both channels, including prior successful attempts.
 const someDelivered=outcomes.some(x=>['sent','partial'].includes(x.status)||(x.textPartsSent||0)>0||x.textSent);
 const hasUnknown=outcomes.some(x=>x.status==='unknown');
 const overall=allSent?'published':(someDelivered||eitaaConfiguredButDisabled)?'partial':hasUnknown?'unknown':'failed';
 const summary=visibleOutcomes.map(x=>`${x.label}: ${x.status==='sent'?'موفق':x.status==='partial'?'ناقص':x.status==='unknown'?'نتیجه نامشخص':x.status==='disabled'?'غیرفعال':x.status==='sending'?'در حال ارسال':'ناموفق'}${x.error?` (${x.error})`:x.imageStatus==='failed'?' (تصویر ارسال نشد)':''}`).join(' | ');
 const failedMessages=outcomes.filter(x=>x.status!=='sent').map(x=>`${x.label}: ${x.error||x.imageError||x.status}${x.stage?' [مرحله: '+x.stage+']':''}${x.httpStatus?' [HTTP '+x.httpStatus+']':''}${x.apiStatus?' [API '+x.apiStatus+']':''}`).join('\n');
 // For centrally managed Qoqnus listings, the central office confirms eligibility only after both channels return real delivery receipts.
 const centralManagedListing=bothRequired&&!!(item.centralId||item.centralRecordId||item.centralStatus==='draft');
 let centralEligibleForMainOffice=!centralManagedListing;
 if(centralManagedListing){
  try{
   const centralSync=self.QoqnusCentralRecordSync;
   if(!centralSync)throw new Error('ماژول دفتر مرکزی در دسترس نیست.');
   const publicationPatch={};
   for(const key of ['rubika','eitaa']){
    const p=platforms[key];if(!p)continue;
    const state=String(p.status||'');
    const receipt=String(p.messageId||p.rubikaMessageId||p.deliveryId||p.postId||p.lastMessageId||p.lastMediaId||'');
    if(state==='sent'&&receipt)publicationPatch[key]={status:'published',attempted:true,confirmed:true,deliveryId:receipt};
    else if(['failed','partial'].includes(state))publicationPatch[key]={status:'failed',attempted:true,error:String(p.error||p.imageError||state)};
   }
   if(Object.keys(publicationPatch).length){
    const centralResult=await centralSync.updateListingStatus(item.id,publicationPatch);
    centralEligibleForMainOffice=centralResult?.eligibleForMainOffice===true;
   }
  }catch(error){
   centralEligibleForMainOffice=false;
   console.warn('[Qoqnus Central] publication status remains pending; listing stays in review:',error?.message||error);
  }
 }
 const finalStatus=centralManagedListing
  ? (centralEligibleForMainOffice?'archived':(item.status==='approved'?'approved':'pending'))
  : ((allSent||startingInArchive)?'archived':(item.status==='approved'?'approved':'pending'));
 const mainOfficeReady=allSent&&(!centralManagedListing||centralEligibleForMainOffice);
 const finalPatch={status:finalStatus,sendStatus:overall,platformResults:platforms,sendFailedAt:mainOfficeReady?null:Date.now(),publicPost:makePost(item,cfg),sendError:failedMessages,sendProgress:mainOfficeReady?'✅ آگهی تأیید شده و انتشار آن در روبیکا و ایتا با رسید موفق ثبت شد؛ به دفتر اصلی منتقل شد.':(centralManagedListing&&allSent?'انتشار دو پیام‌رسان انجام شده، اما تأیید نهایی دفتر مرکزی دریافت نشد؛ آگهی در صف بررسی باقی ماند.':(overall==='partial'?'ارسال ناقص است؛ آگهی در صف بررسی باقی می‌ماند. مقصدهای موفق در تلاش بعدی تکرار نمی‌شوند.':overall==='unknown'?'نتیجهٔ یک مقصد نامشخص است؛ آگهی در صف بررسی می‌ماند تا وضعیت بررسی شود.':'ارسال ناموفق بود؛ آگهی در صف بررسی باقی می‌ماند. '+summary))};
 if(finalStatus==='archived')finalPatch.archivedAt=item.archivedAt||Date.now();
 if(mainOfficeReady)finalPatch.publishedAt=Date.now();
 await updateQueueItem(item.id,finalPatch);
 return {ok:mainOfficeReady,done:true,id:item.id,status:overall,platforms,outcomes:visibleOutcomes,summary,error:mainOfficeReady?'':summary,archived:finalStatus==='archived',eligibleForMainOffice:centralEligibleForMainOffice};
}

async function sendRubika(item){
 const st=await chrome.storage.local.get({rubika:{},queue:[],sendSettings:DEFAULT_SEND_SETTINGS,rubikaTextActionsEnabled:true});
 const token=String(st.rubika?.token||'').trim();
 if(!token)throw requestError('توکن ربات را در تنظیمات وارد کنید.',{stage:'token'});
 const cfg=normalizeSendSettings(st.sendSettings||{});
 // Bookmark scans should never silently become text-only posts when an image was expected.

 const text=makePost(item,cfg);if(!text)throw requestError('متن عمومی آگهی خالی است.',{stage:'format'});const showTextActions=st.rubikaTextActionsEnabled!==false;
 await updateQueueItem(item.id,{sendProgress:'در حال آماده‌سازی پیام…',publicPost:text});
 const imageUrl=resolveImageUrl(item,cfg);
 let imageStatus='not_available',imageError='',method='sendMessage',messageId='',contactLinkStatus='not_attempted',contactLinkError='';
 if(imageUrl){
  try{
   const result=await sendImageWithCaption(token,imageUrl,text,item.id,showTextActions);
   imageStatus='sent';method='sendFile';messageId=result.messageId;contactLinkStatus=result.contactLinkStatus;contactLinkError=result.contactLinkError||'';
  }catch(err){
   // Never send a duplicate text post if Rubika might already have accepted sendFile.
   if(err?.ambiguous||shouldStopImageSendFallback(err))throw err;
   imageStatus='failed';imageError=String(err.message||err);
   if(!cfg.sendTextFallback)throw requestError('تصویر ارسال نشد و ارسال جایگزین متنی غیرفعال است: '+imageError,{stage:'image',imageError});
   await updateQueueItem(item.id,{sendProgress:'تصویر ارسال نشد؛ در حال ارسال متن آگهی…'});
   let data;try{data=await sendRubikaText(token,text,item.id,showTextActions);}catch(textErr){throw requestError('ارسال تصویر ناموفق بود: '+imageError+'؛ ارسال متن نیز شکست خورد: '+String(textErr?.message||textErr),{ambiguous:!!textErr?.ambiguous,stage:textErr?.stage||'text_fallback',method:textErr?.method||'sendMessage',httpStatus:textErr?.httpStatus,apiStatus:textErr?.apiStatus,responseHint:textErr?.responseHint,imageError});}
   messageId=data?._sentMessageId||data?.data?.message_id||data?.message_id||'';method='sendMessage_image_fallback';contactLinkStatus=data?._contactLinkStatus||'not_attempted';contactLinkError=data?._contactLinkWarning||'';
  }
 }else{
  const data=await sendRubikaText(token,text,item.id,showTextActions);messageId=data?._sentMessageId||data?.data?.message_id||data?.message_id||'';method='sendMessage';contactLinkStatus=data?._contactLinkStatus||'not_attempted';contactLinkError=data?._contactLinkWarning||'';
 }
 if(!messageId)throw requestError('روبیکا شناسهٔ پیام نداد؛ نتیجه نامشخص است. پیش از تلاش مجدد کانال را بررسی کن.',{ambiguous:true,method,stage:'response',imageError});
 const linkMessage=contactLinkStatus==='metadata_and_keypad'?'پیوند/دکمهٔ تماس همراه پیام درخواست شد؛ نمایش واقعی آن باید در روبیکا تأیید شود.':contactLinkStatus==='metadata_only'?'متادیتای پیوند تماس ارسال شد؛ کلیک‌پذیری باید در روبیکا بررسی شود.':contactLinkStatus==='keypad_only'?'دکمهٔ تماس همراه پیام درخواست شد؛ کلیک‌پذیری باید بررسی شود.':'روبیکا قالب پیوند را نپذیرفت یا پیوند قابل تأیید نیست؛ شماره به‌صورت متن باقی می‌ماند.';
 await updateQueueItem(item.id,{publicPost:text,publishedImageUrl:imageUrl,publishedImageIndex:imageUrl?resolveImageIndex(item,cfg,imageUrl):0,publicationMethod:method,imageSendStatus:imageStatus,sendProgress:imageStatus==='failed'?'متن آگهی در روبیکا ارسال شد، اما تصویر ارسال نشد.':`روبیکا: ارسال موفق. ${imageStatus==='sent'?'تصویر همراه آگهی ارسال شد.':'پیام متنی ارسال شد.'}`,imageSendError:imageError,contactLinkStatus,contactLinkError,contactLinkMessage:linkMessage,rubikaMessageId:messageId,sendError:''});
 return {ok:true,imageStatus,method,contactLinkStatus,messageId};
}

function resolveImageIndex(item,cfg,url){const images=Array.isArray(item.imageUrls)?item.imageUrls:[];const index=images.indexOf(url);return index>=0?index+1:(url?'default':0);}
const activeRubikaSendPromises=new Map();
async function queueRubikaSend(id,opts={}){
 const key=String(id);
 const existing=activeRubikaSendPromises.get(key);
 if(existing)return await existing;
 const job=(async()=>{
  const latest=await chrome.storage.local.get({queue:[],settings:{},sendSettings:DEFAULT_SEND_SETTINGS,rubika:{token:'',chatId:FIXED_RUBIKA_CHAT_ID},eitaa:{enabled:false,token:'',chatId:''}});
  const item=(latest.queue||[]).find(x=>String(x.id)===key);
  if(!item)throw new Error('آگهی پیدا نشد.');
  if(!listingHasPhone(item)){
   const error=new Error('ارسال مسدود شد: این آگهی شماره تماس معتبر ندارد. ابتدا «خواندن شماره» را بزن یا شماره معتبر را در بخش جزئیات ذخیره کن؛ تا آن زمان هیچ پیامی به روبیکا یا ایتا ارسال نمی‌شود.');
   error.stage='missing_phone';
   throw error;
  }
  if(opts.auto&&!(latest.settings?.autoPublish&&item.status==='pending'&&item.agencyCheck?.color==='green'))throw new Error('ارسال خودکار برای این آگهی مجاز نیست.');
  const isArchived=['archived','published'].includes(item.status);
  const forceResend=!!opts.forceResend;
  const previousPlatforms=item.platformResults||{};
  const configuredPending=[{key:'rubika',active:!!String((latest.rubika||{}).token||'').trim()},{key:'eitaa',active:!!(latest.eitaa||{}).enabled}].filter(x=>x.active&&previousPlatforms[x.key]?.status!=='sent');
  if(!forceResend&&(item.sendStatus==='published'||item.status==='published')&&!configuredPending.length)throw new Error('این آگهی قبلاً در همهٔ پیام‌رسان‌های فعال منتشر شده است. برای انتشار دوباره از دکمهٔ «ارسال مجدد» در بایگانی استفاده کن.');
  if(opts.retry){if(!isArchived||!['failed','unknown','partial'].includes(item.sendStatus))throw new Error('تلاش مجدد فقط برای آگهی بایگانی‌شدهٔ ناموفق، ناقص یا دارای نتیجهٔ نامشخص مجاز است.');}
  else if(opts.resend){if(!isArchived)throw new Error('ارسال دوباره فقط از بایگانی انجام می‌شود.');}
  else if(opts.fromQueue){if(!(isArchived&&item.sendStatus==='queued'))throw new Error('آگهی در صف ارسال پس‌زمینه نیست.');}
  else if(!opts.auto&&!isArchived&&!['pending','approved'].includes(item.status))throw new Error('این آگهی در صف فعال نیست؛ ابتدا آن را با ابزار ثبت ققنوس ذخیره کن.');
  if(item.sendStatus==='sending')throw new Error('این آگهی در حال ارسال است؛ برای جلوگیری از پیام تکراری درخواست تازه‌ای ساخته نشد.');
  const hasUncertainPlatformResult=Object.values(previousPlatforms).some(value=>value==='unknown'||value?.status==='unknown'||value?.ambiguous===true||value?.imageStatus==='unknown');
  const hasUncertainSendOutcome=item.sendStatus==='unknown'||item.imageSendStatus==='unknown'||hasUncertainPlatformResult;
  if(hasUncertainSendOutcome&&opts.confirmedAmbiguous!==true)throw new Error('نتیجهٔ ارسال قبلی نامشخص است؛ برای جلوگیری از ارسال تکراری، تأیید صریح از رابط کاربری لازم است.');
  const cfg=normalizeSendSettings(latest.sendSettings||{}),attempt=Number(item.sendAttempt||0)+1;
  const selectedImageIndex=Number.isInteger(Number(opts.imageIndex))&&Number(opts.imageIndex)>=0?Number(opts.imageIndex):Number(item.selectedImageIndex||0);
  item.selectedImageIndex=selectedImageIndex;
  await updateQueueItem(key,{selectedImageIndex,status:isArchived?'archived':item.status, ...(isArchived?{archivedAt:item.archivedAt||Date.now()}:{}),sendStatus:'sending',sendError:'',sendErrorStage:'',sendErrorDetails:'',sendErrorMethod:'',sendErrorHttpStatus:null,sendErrorApiStatus:'',sendErrorImage:'',sendStartedAt:Date.now(),sendAttempt:attempt,sendProgress:'ارسال ترتیبی آماده می‌شود؛ نتیجهٔ هر پیام‌رسان بلافاصله در همین کارت نمایش داده خواهد شد.',publicPost:makePost(item,cfg)});
  try{await archiveListingPhones(item);}catch(contactErr){console.warn('شمارهٔ آگهی در رکورد فایل حفظ می‌شود؛ دفتر مستقل شماره‌ها غیرفعال است.',contactErr);}
  try{
   const result=await sendConfiguredPlatforms(item,latest,cfg,{fromArchive:isArchived,forceResend});
   try{const latestState=await chrome.storage.local.get({queue:[]});const latestItem=(latestState.queue||[]).find(x=>String(x.id)===key);const anyPlatformSent=(result?.outcomes||[]).some(x=>x?.status==='sent'||x?.status==='partial'||(Number(x?.textPartsSent)||0)>0||!!x?.textSent||x?.imageStatus==='sent');if(latestItem)await archiveListingPhones(latestItem,{includeEmpty:anyPlatformSent});}catch(contactErr){console.warn('به‌روزرسانی سوابق شماره در پروندهٔ آگهی انجام نشد.',contactErr);}
   try{
    const facts=item.facts||{};const outcomes=Array.isArray(result?.outcomes)?result.outcomes:[];const rb=outcomes.find(x=>x?.key==='rubika'||x?.platform==='rubika');
    const rubikaStatus=String(rb?.status||'not_sent');const rubikaMessageId=String(rb?.messageId||rb?.rubikaMessageId||'');
    const latestSendState=await chrome.storage.local.get({rubika:{chatId:FIXED_RUBIKA_CHAT_ID},sendSettings:DEFAULT_SEND_SETTINGS,rubikaTextActionsEnabled:true});
    const normalizedBody=addRubikaAdCta(makePost(item,normalizeSendSettings(latestSendState.sendSettings||{})),latestSendState.rubikaTextActionsEnabled!==false);
    const hadPriorRubikaPublication=['sent','partial'].includes(String(previousPlatforms.rubika?.status||''))||(!previousPlatforms.rubika&&item.sendStatus==='published');
    const reportOperation=['sent','partial'].includes(rubikaStatus)?(hadPriorRubikaPublication?'updated':'created'):'error';
    await qoqnusQueueAuditEvent('listing.send.result','listing',key,{record:{
     id:key,title:String(item.title||''),code:String(item.code||''),phone:String((item.phones||[])[0]||item.phone||''),outcome:result?.ok===false?'ناموفق':'ارسال ثبت شد',
     summary:outcomes.map(x=>String(x?.platform||x?.key||'مقصد')+': '+String(x?.status||'نامشخص')).join('، ').slice(0,280),
     platform:outcomes.map(x=>String(x?.platform||x?.key||'')).filter(Boolean).join('، '),
     transaction_type:String(facts.transactionType||item.transactionType||''),transaction_label:String(facts.transactionLabel||''),
     property_type:String(facts.propertyType||item.propertyType||item.listingTypeLabel||''),city:String(facts.city||item.city||''),
     neighborhood:String(facts.neighborhood||item.neighborhood||''),street:String(facts.street||item.street||''),
     area_sqm:String(item.area_sqm||facts.landArea||facts.builtArea||item.landArea||item.buildingArea||''),
     land_area_sqm:String(item.landArea||facts.landArea||''),building_area_sqm:String(item.buildingArea||facts.builtArea||''),
     bedrooms:String(facts.rooms||''),sale_price_toman:String(facts.salePrice||item.salePrice||''),
     deposit_toman:String(facts.deposit||item.deposit||''),monthly_rent_toman:String(facts.monthlyRent||item.monthlyRent||''),
     channel_id:String(FIXED_RUBIKA_CHAT_ID),message_id:rubikaMessageId,
     rubika_message_id:rubikaMessageId,rubika_status:rubikaStatus,body_text:String(normalizedBody||item.publicPost||'').slice(0,3500),
     published_at:new Date(Number(rb?.sentAt||Date.now())).toISOString()
    },operation:reportOperation});
   }catch{}
   return result;
  }catch(err){
   const unknown=err?.ambiguous===true;const message=String(err?.message||err||'خطای نامشخص در ارسال پیام‌رسان‌ها');
   const diag={sendErrorDetails:String(err?.responseHint||''),sendErrorMethod:String(err?.method||''),sendErrorHttpStatus:err?.httpStatus??null,sendErrorApiStatus:String(err?.apiStatus||''),sendErrorStage:err?.stage||err?.method||'send',sendErrorImage:String(err?.imageError||'')};
   await updateQueueItem(key,{status:isArchived?'archived':item.status,sendStatus:unknown?'unknown':'failed',sendProgress:'ارسال ناموفق شد؛ آگهی در بخش بررسی باقی می‌ماند مگر اینکه از بایگانی ارسال دوباره انجام شود.',sendError:message,...diag,sendFailedAt:Date.now()});
   return {ok:false,done:true,id:key,status:unknown?'unknown':'failed',error:message,errorStage:err?.stage||err?.method||'send',ambiguous:unknown,archived:isArchived};
  }
 })();
 activeRubikaSendPromises.set(key,job);
 try{return await job;}finally{activeRubikaSendPromises.delete(key);}
}

let rubikaSendProcessorBusy=false;
async function recoverInterruptedSends(){
 const st=await chrome.storage.local.get({queue:[]}),now=Date.now();let changed=false;
 const queue=(st.queue||[]).map(item=>{
  if(item.sendStatus==='sending'&&!activeRubikaSendPromises.has(String(item.id))&&now-Number(item.sendStartedAt||0)>180000){changed=true;return {...item,sendStatus:'unknown',sendProgress:'ارسال قبلی متوقف شد؛ نتیجه قطعی نیست. وضعیت پیام‌رسان‌ها را بررسی کن.',sendError:'پاسخ نهایی ارسال ثبت نشد؛ پیش از ارسال مجدد مقصدها را بررسی کن.',sendFailedAt:now};}
  return item;
 });if(changed)await chrome.storage.local.set({queue});
}
async function processQueuedRubikaSends(){
 if(rubikaSendProcessorBusy)return;
 rubikaSendProcessorBusy=true;
 try{
  await recoverInterruptedSends();
  const st=await chrome.storage.local.get({queue:[]});
  const batch=(st.queue||[]).filter(x=>x.status==='archived'&&x.sendStatus==='queued');
  for(const item of batch){
   const key=String(item.id);if(activeRubikaSendPromises.has(key))continue;
   try{await queueRubikaSend(key,{fromQueue:true});}
   catch(err){try{await updateQueueItem(key,{status:'archived',sendStatus:err?.ambiguous?'unknown':'failed',sendProgress:'ارسال ناموفق شد؛ علت در جزئیات فنی کارت ثبت شده است.',sendError:String(err?.message||err),sendErrorStage:err?.stage||err?.method||'send',sendFailedAt:Date.now()});}catch{}}
  }
  const after=await chrome.storage.local.get({queue:[]});
  if((after.queue||[]).some(x=>x.status==='archived'&&x.sendStatus==='queued'))chrome.alarms.create('rubika-send-pending',{when:Date.now()+3000});
 }finally{rubikaSendProcessorBusy=false;}
}

async function getRubikaSendStatus(id){const st=await chrome.storage.local.get({queue:[]});const item=(st.queue||[]).find(x=>String(x.id)===String(id));if(!item)throw new Error('آگهی در بایگانی پیدا نشد.');return {ok:true,id:item.id,status:item.sendStatus||'idle',progress:item.sendProgress||'',error:item.sendError||'',errorStage:item.sendErrorStage||'',errorDetails:item.sendErrorDetails||'',errorMethod:item.sendErrorMethod||'',httpStatus:item.sendErrorHttpStatus??null,apiStatus:item.sendErrorApiStatus||'',imageErrorDetail:item.sendErrorImage||'',platformResults:item.platformResults||{},attempt:Number(item.sendAttempt||0),imageStatus:item.imageSendStatus||'not_available',imageError:item.imageSendError||'',contactLinkStatus:item.contactLinkStatus||'not_attempted',contactLinkMessage:item.contactLinkMessage||'',contactLinkError:item.contactLinkError||'',messageId:item.rubikaMessageId||''};}
async function waitForRubikaSend(id,timeoutMs=120000){const started=Date.now();processQueuedRubikaSends().catch(()=>{});while(Date.now()-started<timeoutMs){const result=await getRubikaSendStatus(id);if(['published','partial'].includes(result.status))return {...result,done:true,ok:result.status==='published'};if(['failed','unknown'].includes(result.status))return {...result,ok:false,done:true};await new Promise(r=>setTimeout(r,500));}return {...await getRubikaSendStatus(id),ok:true,done:false,timeout:true,message:'ارسال هنوز ادامه دارد؛ در بایگانی وضعیت را ببین و دوباره کلیک نکن.'};}
async function retryArchivedSend(id,imageIndex,confirmedAmbiguous=false){return await queueRubikaSend(id,{retry:true,imageIndex,confirmedAmbiguous:confirmedAmbiguous===true});}
async function deleteArchivedItem(id){const st=await chrome.storage.local.get({queue:[]});const item=(st.queue||[]).find(x=>String(x.id)===String(id));if(!item||!['archived','published'].includes(item.status))throw new Error('فقط کارت بایگانی را می‌توان حذف کرد.');await chrome.storage.local.set({queue:(st.queue||[]).filter(x=>String(x.id)!==String(id))});qoqnusQueueAuditEvent('listing.archive.delete','listing',String(item.id),{id:String(item.id),title:String(item.title||''),code:String(item.code||''),phone:String((item.phones||[])[0]||item.phone||''),deletedAt:Date.now()},{ }).catch(()=>{});return {ok:true};}
async function saveSendSettings(raw){const sendSettings=normalizeSendSettings(raw||{});const st=await chrome.storage.local.get({queue:[]});const queue=(st.queue||[]).map(item=>({...item,publicPost:makePost(item,sendSettings)}));await chrome.storage.local.set({sendSettings,queue});return {ok:true,sendSettings};}
async function previewPost(itemId,rawConfig){const st=await chrome.storage.local.get({queue:[],sendSettings:DEFAULT_SEND_SETTINGS});const item=(st.queue||[]).find(x=>String(x.id)===String(itemId))||(st.queue||[]).find(x=>x.source==='manual-save')||(st.queue||[])[0]||{title:'منزل ویلایی نمونه برای اجاره',url:'https://divar.ir/v/sample',categories:['اجارهٔ مسکونی','اجاره خانه و ویلا'],categoryLinks:[{text:'اجاره خانه و ویلا',href:'https://divar.ir/s/neyshabur/rent-villa'}],location:'نیشابور، سرآب کوشک، خیابان بهشتی ۱۴',description:'منزل نمونهٔ دو خواب، پارکینگ و انباری',detailText:'منزل ویلایی نمونه برای اجاره\nودیعه\n۳۰۰,۰۰۰,۰۰۰ تومان\nاجارهٔ ماهانه\n۱,۰۰۰,۰۰۰ تومان\nتعداد خواب\n۲\nتوضیحات\nمنزل نمونهٔ تمیز و دارای پارکینگ'};return {ok:true,post:makePost(item,normalizeSendSettings(rawConfig||st.sendSettings||{})),title:item.title||'نمونه'};}

function generateListingCode(){return 'AQ-'+Date.now().toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,6).toUpperCase();}

function summarizePropertyForContact(item){
 const facts=item.facts||extractListingFacts(item);let summary=cleanListingDescription(facts.description||item.description||'',facts.categories||[]);
 if(!summary){const parts=[];if(facts.listingTypeLabel)parts.push(facts.listingTypeLabel);if(facts.fullLocation||facts.location)parts.push('موقعیت '+(facts.fullLocation||facts.location));if(facts.landArea)parts.push('زمین '+facts.landArea);if(facts.builtArea)parts.push('زیربنا '+facts.builtArea);if(facts.rooms)parts.push('اتاق '+facts.rooms);if(facts.salePrice)parts.push('قیمت '+facts.salePrice);if(facts.deposit)parts.push('رهن '+facts.deposit);if(facts.monthlyRent)parts.push('اجاره '+facts.monthlyRent);summary=parts.join('؛ ');}
 return String(summary||'توضیحات ملک در آگهی کامل نشد.').replace(/\s+/g,' ').slice(0,500);
}
async function archiveListingPhones(item,options={}){
 // v4.5.78: the former phonebook is now the Office File Book. New Divar phone numbers
 // stay attached to their individual listing record; don't duplicate them into contactArchive.
 return {saved:0,listingSaved:false,phoneBookDisabled:true,source:String(item?.source||'')};
}

async function saveCurrentListing(payload,sender){
 const pageUrl=String(sender?.tab?.url||sender?.url||payload?.url||'');
 let u; try{u=new URL(pageUrl);}catch{throw new Error('نشانی صفحهٔ آگهی معتبر نیست.');}
 if(!/(^|\.)divar\.ir$/i.test(u.hostname)||!/^\/v\/[^/]+/.test(u.pathname))throw new Error('برای ثبت آگهی، صفحهٔ جزئیات همان آگهی را باز کن؛ صفحهٔ فهرست کافی نیست.');
 const match=u.pathname.match(/\/v\/([^/?#]+)/); const id=match?decodeURIComponent(match[1]):String(payload?.id||'');
 if(!id)throw new Error('شناسهٔ آگهی از نشانی صفحه پیدا نشد.');
 const state=await chrome.storage.local.get({queue:[],sendSettings:DEFAULT_SEND_SETTINGS});
 const queue=Array.isArray(state.queue)?state.queue:[];
 const index=queue.findIndex(x=>String(x.id)===id||String(x.url||'').split(/[?#]/)[0]===pageUrl.split(/[?#]/)[0]);
 const old=index>=0?queue[index]:null;
 const detailText=String(payload?.detailText||payload?.text||'').slice(0,10000);
 const title=String(payload?.title||'').trim().slice(0,300);
 if(!title||detailText.length<30)throw new Error('عنوان یا متن قابل‌مشاهدهٔ آگهی ناقص است.');
 const item={
  ...(old||{}), ...payload,
  id, url:u.origin+u.pathname, title,
  detailText,
  text:String(payload?.text||payload?.publicDescription||detailText).slice(0,8000),
  publicDescription:String(payload?.publicDescription||payload?.text||title).slice(0,7000),
  description:cleanListingDescription(String(payload?.description||old?.description||'').slice(0,5000),Array.isArray(payload?.categories)?payload.categories:[]),
  attributes:Array.isArray(payload?.attributes)?payload.attributes.slice(0,40):old?.attributes||[],
  imageUrls:Array.isArray(payload?.imageUrls)&&payload.imageUrls.length?[...new Set([...payload.imageUrls.filter(x=>/^https?:\/\//i.test(x)),...(old?.imageUrls||[])])].slice(0,35):(old?.imageUrls||[]),
  phones:Array.isArray(payload?.phones)&&payload.phones.length?payload.phones:(old?.phones||[]),
  phoneSource:Array.isArray(payload?.phones)&&payload.phones.length?'page-visible':(old?.phoneSource||''),
  phoneReadStatus:Array.isArray(payload?.phones)&&payload.phones.length?'found':(old?.phoneReadStatus||'not_visible'),
  phoneReadAt:Array.isArray(payload?.phones)&&payload.phones.length?Date.now():(old?.phoneReadAt||null),
  code:old?.code||generateListingCode(),
  source:'qoqnus-ad', sourceLabel:'آگهی ققنوس', centralStatus:old?.centralId?'synced':(old?.centralStatus||'draft'), manuallySavedAt:Date.now(), collectedAt:old?.collectedAt||Date.now(),
  status:old?.status==='published'?'published':old?.status==='archived'?'archived':'pending',
  tags:[...new Set([...(old?.tags||[]),...(payload?.tags||[]),...locationTags(payload,u.href)])],
  agencyCheck:classifyAgency({...payload,text:detailText+'\n'+String(payload?.description||''),sellerClass:payload?.sellerClass||old?.sellerClass||'unknown'}),
  ageKnown:payload?.ageKnown===true&&Number.isFinite(Number(payload?.ageDays)),
  updatedAt:Date.now(),
  publicPost:''
 };
 item.listingType=classifyListingType(item);item.listingTypeLabel=listingTypeLabel(item.listingType);
 item.facts=extractListingFacts(item);
 item.publicPost=makePost(item,state.sendSettings);
 if(index>=0)queue[index]=item; else queue.unshift(item);
 // Persist the listing record first. Optional contact-book and desktop-notification failures must not
 // turn a successful bank save into a misleading "save failed" message.
 const savedQueue=retainQueue(queue);
 await chrome.storage.local.set({queue:savedQueue});
 const verified=await chrome.storage.local.get({queue:[]});
 const savedRecord=(verified.queue||[]).find(x=>String(x.id)===String(id)||String(x.url||'').split(/[?#]/)[0]===String(item.url||'').split(/[?#]/)[0]);
 if(!savedRecord)throw new Error('ذخیره در بانک ققنوس تأیید نشد؛ دوباره تلاش کن. اگر فضای ذخیره‌سازی پر شده، از افزونه پشتیبان بگیر.');
 let contactResult={saved:0,listingSaved:false};let contactWarning='';
 try{contactResult=await archiveListingPhones(item,{includeEmpty:true});}
 catch(e){contactWarning='آگهی ذخیره شد، اما بررسی نگهداری شماره در همان پرونده نیاز به بازبینی دارد: '+String(e?.message||e);}
 try{const notice=chrome.notifications.create('qoqnus-saved-'+id+'-'+Date.now(),{type:'basic',iconUrl:'icon.png',title:'آگهی ققنوس ذخیره شد',message:`${title.slice(0,100)} — ${item.code}`});if(notice&&typeof notice.catch==='function')notice.catch(()=>{});}catch{}
 try{await qoqnusQueueAuditEvent(index>=0?'listing.archive.updated':'listing.archive.saved','listing',id,{record:{id,title,code:item.code,phone:String((item.phones||[])[0]||''),transaction_type:item.transactionType||item.facts?.transactionType||'',transaction_label:item.facts?.transactionLabel||'',property_type:item.propertyType||item.facts?.propertyType||'',city:item.city||item.facts?.city||'',neighborhood:item.neighborhood||item.facts?.neighborhood||'',street:item.street||item.facts?.street||''},operation:index>=0?'updated':'created'});}catch{}
 return {ok:true,verified:true,code:item.code,updated:index>=0,status:item.status,centralStatus:item.centralStatus||'draft',centralId:item.centralId||'',imageCount:item.imageUrls.length,phoneFound:item.phones.length>0,phonesArchived:contactResult.saved||0,contactListingSaved:!!contactResult.listingSaved,contactWarning,listingType:item.listingType,listingTypeLabel:item.listingTypeLabel};
}
async function saveManualPhone(id,raw){
 const state=await chrome.storage.local.get({queue:[]}); const queue=state.queue||[]; const item=queue.find(x=>x.id===id); if(!item)throw new Error('آگهی پیدا نشد.');
 const found=extractPhoneNumbers(String(raw||''));
 if(String(raw||'').trim()&&!found.length)throw new Error('شماره معتبر موبایل ایران پیدا نشد. مثال: 09123456789');
 const updatedItem={...item,phones:found,phoneSource:found.length?'manual':'',phoneReadStatus:found.length?'manual':'not_visible',phoneReadAt:found.length?Date.now():item.phoneReadAt,phoneManualAt:found.length?Date.now():null,listingType:item.listingType||classifyListingType(item),listingTypeLabel:item.listingTypeLabel||listingTypeLabel(item.listingType||classifyListingType(item))};
 await chrome.storage.local.set({queue:queue.map(x=>x.id===id?updatedItem:x)});const contactResult=await archiveListingPhones(updatedItem);return {ok:true,phones:found,phonesArchived:contactResult.saved};
}

async function saveOfficeFileEntry(entry={}){
 const name=String(entry.name||'').trim().slice(0,120);
 const phone=extractPhoneNumbers(String(entry.phone||''))[0]||'';
 if(!name)throw new Error('نام مشتری یا مالک را وارد کن.');
 if(!phone)throw new Error('شماره موبایل معتبر وارد کن؛ نمونه: 09123456789.');
 const transaction=String(entry.transactionType||'sale');
 const property=String(entry.propertyType||'');
 if(!['sale','rent'].includes(transaction))throw new Error('نوع معامله را انتخاب کن.');
 if(!(transaction==='sale'?['land','villa','commercial'].includes(property):['villa','commercial'].includes(property)))throw new Error('نوع ملک متناسب با فروش یا اجاره را انتخاب کن.');
 const clean=v=>cleanPublicValue(String(v??'').trim()).slice(0,240);
 const digits=v=>asciiDigits(String(v??'')).replace(/[^0-9]/g,'');
 const amount=v=>{const d=digits(v);return d&&Number(d)>0?String(Number(d)):'';};
 const area=amount(entry.area),builtArea=amount(entry.builtArea),salePrice=amount(entry.salePrice),deposit=amount(entry.deposit),monthlyRent=amount(entry.monthlyRent);const pricePerMeter=amount(entry.pricePerMeter)||(transaction==='sale'&&salePrice&&area?String(Math.round(Number(salePrice)/Number(area))):'');
 const neighborhood=clean(entry.neighborhood),street=clean(entry.street),city='نیشابور';
 const location=[city,neighborhood].filter(Boolean).join('، ');
 const landUse=clean(entry.landUse),deed=clean(entry.deed),access=clean(entry.access),frontage=amount(entry.frontage);
 const rooms=amount(entry.rooms),year=clean(entry.year),commercialKind=clean(entry.commercialKind),commercialUse=clean(entry.commercialUse);
 const kitchen=clean(entry.kitchen),flooring=clean(entry.flooring),heating=clean(entry.heating),cooling=clean(entry.cooling),convertible=String(entry.convertible||'unknown');
 const amenities=Array.isArray(entry.amenities)?[...new Set(entry.amenities.map(clean).filter(Boolean))].slice(0,25):[];
 const notes=clean(entry.notes).slice(0,900);
 const now=Date.now();
 const typeTitle=property==='land'?(landUse&&landUse!=='نامشخص'?`زمین ${landUse}`:'زمین'):property==='villa'?'ملک ویلایی':(commercialKind||'ملک تجاری');
 const actionTitle=transaction==='rent'?'برای اجاره':'برای فروش';
 const generatedTitle=[typeTitle,actionTitle,neighborhood?'در '+neighborhood:''].filter(Boolean).join(' ');
 const title=clean(entry.title)||generatedTitle;
 const propertyLabel=property==='land'?'زمین':property==='villa'?'ویلایی':'تجاری';
 const categories=transaction==='rent'?(property==='villa'?['اجاره','خانه و ویلا','مسکونی']:['اجاره','تجاری',commercialKind]):(property==='land'?['خرید و فروش','زمین و باغ',landUse]:property==='villa'?['خرید و فروش','خانه و ویلا','مسکونی']:['خرید و فروش','تجاری',commercialKind]);
 const descriptionParts=[];
 if(property==='land'){
  if(landUse)descriptionParts.push('کاربری: '+landUse);
  if(frontage)descriptionParts.push('عرض بر: '+frontage+' متر');
  if(access)descriptionParts.push('دسترسی: '+access);
  if(deed)descriptionParts.push('وضعیت سند: '+deed);
 }else if(property==='villa'){
  if(deed)descriptionParts.push('وضعیت سند: '+deed);
  if(year)descriptionParts.push('سال ساخت: '+year);
  if(kitchen&&kitchen!=='نامشخص')descriptionParts.push('کابینت: '+kitchen);
  if(flooring&&flooring!=='نامشخص')descriptionParts.push('کف: '+flooring);
  if(heating&&heating!=='نامشخص')descriptionParts.push('گرمایش: '+heating);
  if(cooling&&cooling!=='نامشخص')descriptionParts.push('سرمایش: '+cooling);
 }else{
  if(commercialKind)descriptionParts.push('نوع واحد: '+commercialKind);
  if(commercialUse)descriptionParts.push('کاربری: '+commercialUse);
  if(frontage)descriptionParts.push('عرض بر: '+frontage+' متر');
  if(deed)descriptionParts.push('وضعیت سند: '+deed);
 }
 if(amenities.length)descriptionParts.push('امکانات: '+amenities.join('، '));
 if(transaction==='rent'&&convertible!=='unknown')descriptionParts.push('قابل تبدیل: '+(convertible==='yes'?'بله':'خیر'));
 if(notes)descriptionParts.push(notes);
 const description=descriptionParts.join('؛ ');
 const detail=[];
 detail.push(title);
 if(salePrice)detail.push('قیمت کل: '+salePrice+' تومان');
 if(pricePerMeter)detail.push('قیمت هر متر: '+pricePerMeter+' تومان');
 else if(transaction==='sale'&&salePrice&&area)detail.push('قیمت هر متر: '+Math.round(Number(salePrice)/Number(area))+' تومان');
 if(deposit)detail.push('ودیعه: '+deposit+' تومان');
 if(monthlyRent)detail.push('اجاره ماهانه: '+monthlyRent+' تومان');
 if(convertible!=='unknown'&&transaction==='rent')detail.push('قابل تبدیل: '+(convertible==='yes'?'بله':'خیر'));
 if(location)detail.push('موقعیت: '+location);
 if(street)detail.push('خیابان: '+street);
 if(property==='land'&&area)detail.push('متراژ زمین: '+area+' مترمربع');
 if(property!=='land'&&area)detail.push('متراژ کل: '+area+' مترمربع');
 if(property==='villa'&&builtArea)detail.push('زیربنا: '+builtArea+' مترمربع');
 if(property==='villa'&&rooms)detail.push('تعداد خواب: '+rooms);
 if(property==='villa'&&year&&/^\d{4}$/.test(asciiDigits(year)))detail.push('سال ساخت: '+year);
 if(description)detail.push('توضیحات بیشتر: '+description);
 const text=detail.join('\n');
 const rawImages=Array.isArray(entry.images)?entry.images.slice(0,3):[];
 const images=rawImages.filter(x=>/^data:image\/(?:jpeg|png|webp);base64,/i.test(String(x||''))&&String(x).length<=1800000);
 const id='OF-'+now.toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,6).toUpperCase();
 const listingType=transaction==='rent'?(property==='villa'?'rent_residential':'rent_shop'):(property==='land'?'sale_land':property==='villa'?'sale_residential':'sale_shop');
 const record={
  id,code:'FILE-'+now.toString(36).slice(-6).toUpperCase(),title,detailText:text,text,publicDescription:description,description,
  categories:categories.filter(Boolean),categoryLinks:[],url:'',listingType,listingTypeLabel:listingTypeLabel(listingType),contactCategory:transaction==='rent'?(property==='villa'?'rent_home':'rent_commercial'):(property==='land'?'sale_land':property==='villa'?'sale_home':'sale_commercial'),
  transactionType:transaction,propertyType:property==='land'?'زمین/باغ':property==='villa'?'ویلا':'تجاری',location,city,neighborhood,street,
  area_sqm:area,landArea:(property==='land'||property==='villa')?area:'',buildingArea:property==='villa'?builtArea:area,salePrice,deposit,monthlyRent,pricePerMeter,rooms,year,amenities,convertible:convertible==='yes'?true:convertible==='no'?false:null,phones:[phone],phone,phoneSource:'office-file-private',phoneReadStatus:'found',phoneReadAt:now,
  ownerName:name,ownerSurname:name,customerName:name,customerPhone:phone,source:'office-file',sourceLabel:'فایل دفتری',recordKind:'file',sourceType:'office-file',bookKey:'office-files',centralStatus:'draft',officePropertyType:property,officeTransactionType:transaction,
  status:'archived',centralStatus:'draft',sendStatus:'not_sent',platformResults:{},createdAt:now,updatedAt:now,archivedAt:now,publishedAt:null,imagesProvided:images.length,
  imageUrls:images,imageDataUrls:[],selectedImageIndex:0,tags:['#آگهی',property==='land'?'#زمین':property==='villa'?'#ویلایی':'#تجاری'],facts:null
 };
 record.facts=officeFilePostFacts(record);
 const state=await chrome.storage.local.get({queue:[],sendSettings:DEFAULT_SEND_SETTINGS});
 record.publicPost=makePost(record,state.sendSettings||DEFAULT_SEND_SETTINGS);
 const queue=Array.isArray(state.queue)?state.queue:[];
 await chrome.storage.local.set({queue:retainQueue([record,...queue]),lastOfficeFileSavedAt:now});
 qoqnusQueueAuditEvent('office_file.created','listing',id,{record:{id,code:record.code,title,phone,name,transactionType:transaction,propertyType:property,location,area, salePrice,deposit,monthlyRent,source:'office-file'},operation:'created'}).catch(()=>{});
 return {ok:true,record:{...record,phone:'',phones:[],customerPhone:'',imageUrls:[],imageDataUrls:[]},id,code:record.code,title};
}


async function saveOfficeAdEntry(entry={}){
 const clean=v=>cleanPublicValue(String(v??'').trim()).slice(0,1200);
 const title=clean(entry.title).slice(0,240);
 const transaction=String(entry.transactionType||'sale');
 const property=String(entry.propertyType||'villa');
 if(!title)throw new Error('عنوان آگهی دفتری را وارد کن.');
 if(!['sale','rent'].includes(transaction))throw new Error('نوع معامله را انتخاب کن.');
 if(!['land','villa','commercial'].includes(property))throw new Error('نوع ملک را انتخاب کن.');
 const now=Date.now(),amount=v=>{const d=asciiDigits(String(v??'')).replace(/[^0-9]/g,'');return d&&Number(d)>0?String(Number(d)):'';};
 const area=amount(entry.area),builtArea=amount(entry.builtArea),salePrice=amount(entry.salePrice),deposit=amount(entry.deposit),monthlyRent=amount(entry.monthlyRent);
 const city=clean(entry.city||'نیشابور'),neighborhood=clean(entry.neighborhood),street=clean(entry.street),location=[city,neighborhood].filter(Boolean).join('، ');
 const ownerName=clean(entry.ownerName).slice(0,120),phone=extractPhoneNumbers(String(entry.phone||''))[0]||'';
 const description=clean(entry.description).slice(0,4000);
 const images=Array.isArray(entry.images)?entry.images.filter(x=>/^data:image\/webp;base64,/i.test(String(x||''))&&String(x).length<=2200000).slice(0,5):[];
 const id='OAD-'+now.toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,7).toUpperCase();
 const listingType=transaction==='rent'?(property==='villa'?'rent_residential':property==='land'?'rent_land':'rent_shop'):(property==='land'?'sale_land':property==='villa'?'sale_residential':'sale_shop');
 const facts={transactionType:transaction,transactionLabel:transaction==='sale'?'فروش':'اجاره',propertyType:property==='land'?'زمین/باغ':property==='villa'?'ویلایی':'تجاری',landArea:area,builtArea,location,fullLocation:location,neighborhood,street,salePrice,deposit,monthlyRent,description};
 const details=[title,`نوع معامله: ${transaction==='sale'?'فروش':'اجاره'}`,`نوع ملک: ${facts.propertyType}`,location?'موقعیت: '+location:'',area?'متراژ: '+area+' مترمربع':'',builtArea?'زیربنا: '+builtArea+' مترمربع':'',salePrice?'قیمت فروش: '+salePrice+' تومان':'',deposit?'ودیعه: '+deposit+' تومان':'',monthlyRent?'اجاره ماهانه: '+monthlyRent+' تومان':'',description].filter(Boolean);
 const record={id,code:'OAD-'+now.toString(36).slice(-7).toUpperCase(),title,detailText:details.join('\n'),text:details.join('\n'),description,publicDescription:description,url:'',source:'office-ad',sourceLabel:'آگهی دفتری',recordKind:'file',sourceType:'office-file',bookKey:'office-files',centralStatus:'draft',listingType,listingTypeLabel:listingTypeLabel(listingType),transactionType:transaction,propertyType:facts.propertyType,city,neighborhood,street,location,area_sqm:area,landArea:property==='land'?area:'',buildingArea:builtArea||area,salePrice,deposit,monthlyRent,ownerName,ownerSurname:ownerName,customerName:ownerName,phones:phone?[phone]:[],phone,phoneSource:phone?'manual-office-ad':'',phoneReadStatus:phone?'manual':'not_visible',imageUrls:images,imageDataUrls:[],imagesProvided:images.length,tags:['#آگهی_دفتری'],facts,status:'archived',sendStatus:'not_sent',platformResults:{},createdAt:now,updatedAt:now,archivedAt:now};
 const st=await chrome.storage.local.get({queue:[],sendSettings:DEFAULT_SEND_SETTINGS});record.publicPost=makePost(record,st.sendSettings||DEFAULT_SEND_SETTINGS);
 await chrome.storage.local.set({queue:retainQueue([record,...(Array.isArray(st.queue)?st.queue:[])])});
 qoqnusQueueAuditEvent('office_ad.created','listing',id,{record:{id,code:record.code,title,source:'office-ad',operation:'created'}}).catch(()=>{});
 return {ok:true,id,code:record.code,title};
}

async function saveContactArchiveEntry(entry={}){
 throw new Error('دفتر شماره‌ها با دفتر فایل جایگزین شده است. برای ذخیرهٔ نام و شمارهٔ مشتری، از فرم «ثبت فایل دفتری ملک» استفاده کن تا اطلاعات داخل پروندهٔ همان ملک بماند. رکوردهای قدیمی پاک نشده‌اند.');
}

async function deleteContactArchiveEntry(id){const st=await chrome.storage.local.get({contactArchive:[]});const before=st.contactArchive||[];const prior=before.find(x=>String(x.id)===String(id));const after=before.filter(x=>String(x.id)!==String(id));if(after.length===before.length)throw new Error('شماره در دفتر محلی پیدا نشد.');await chrome.storage.local.set({contactArchive:after});qoqnusQueueAuditEvent('contact.delete','contact',String(id),{id:String(id),name:String(prior?.name||''),phone:String(prior?.phone||''),listingTitle:String(prior?.listingTitle||''),deletedAt:Date.now()}).catch(()=>{});return {ok:true};}
async function exportContactArchive(){const st=await chrome.storage.local.get({contactArchive:[]});const old=Array.isArray(st.contactArchive)?st.contactArchive:[];let changed=false;const records=old.map(x=>{const category=x.contactCategory&&CONTACT_CATEGORY_LABELS[x.contactCategory]?x.contactCategory:classifyContactCategory({title:x.listingTitle||x.name||'',description:x.note||'',url:x.listingUrl||'',listingType:x.listingType||'unknown'});if(x.contactCategory!==category||x.contactCategoryLabel!==contactCategoryLabel(category)){changed=true;return {...x,contactCategory:category,contactCategoryLabel:contactCategoryLabel(category)};}return x;});if(changed)await chrome.storage.local.set({contactArchive:records});return {ok:true,records};}


// Qoqnus shared-host pull sync. No polling: it runs when the extension dashboard asks or the user clicks Sync.
let qoqnusSyncInFlight=null;
function validateQoqnusSyncPayload(payload, envelope){
 if(!payload||typeof payload!=='object'||payload.schema!=='qoqnus.archive.v1')throw new Error('ساختار پروندهٔ دریافتی از هاست شناخته‌شده نیست.');
 const sid=String(envelope?.sync_id||''),pid=String(payload.sync_id||''),lid=String(payload.listing_id||'');
 if(!/^[a-f0-9]{24}$/.test(sid)||sid!==pid||sid!==lid)throw new Error('شناسهٔ یکتای پرونده با پاسخ هاست سازگار نیست.');
 const hash=String(envelope?.payload_sha256||'').toLowerCase();if(!/^[a-f0-9]{64}$/.test(hash))throw new Error('هش پروندهٔ دریافتی معتبر نیست.');
 return {sid,hash};
}
async function qoqnusSha256Json(value){
 if(!crypto?.subtle)throw new Error('امکان بررسی صحت انتقال در مرورگر فراهم نیست.');
 const bytes=new TextEncoder().encode(JSON.stringify(value));const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('');
}
function qoqnusPayloadToArchiveRecord(payload,sid,hash){
 const imageDataUrls=Array.isArray(payload.image_data_urls)?payload.image_data_urls.slice(0,3):[];let imageChars=0;
 for(const src of imageDataUrls){if(typeof src!=='string'||!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(src)||src.length>4300000)throw new Error('یکی از تصاویر دریافتی قالب یا حجم مجاز ندارد.');imageChars+=src.length;}
 if(imageChars>4300000)throw new Error('حجم مجموع تصاویر از سقف انتقال افزونه بیشتر است.');
 const title=String(payload.title||'آگهی ملک').trim().slice(0,240),detail=String(payload.detail_text||payload.description||title).slice(0,12000);if(!title||!detail)throw new Error('عنوان یا توضیح آگهی خالی است.');
 const rawPhone=String(payload.phone||'');const phones=extractPhoneNumbers(rawPhone).slice(0,3);const tx=String(payload.transaction_type||'rent');
 const typeText=String(payload.property_type||'');const classifierInput={title:title+' '+(tx==='sale'?'فروش':'اجاره')+' '+typeText,description:detail,text:detail,url:''};let listingType=classifyListingType(classifierInput);if(!listingType||listingType==='unknown'){const t=norm(title+' '+typeText);listingType=/زمین|باغ/.test(t)?(tx==='sale'?'sale_land':'rent_land'):/مغازه|تجار|سوله|انبار|کارگاه/.test(t)?(tx==='sale'?'sale_shop':'rent_shop'):(tx==='sale'?'sale_residential':'rent_residential');}
 const stamp=Date.parse(String(payload.published_at||''));const now=Date.now();const publishedAt=Number.isFinite(stamp)?stamp:now;
 const facts={title,transactionType:tx,transactionLabel:String(payload.transaction_label||''),propertyType:typeText,location:[payload.city,payload.neighborhood].filter(Boolean).join('، '),city:String(payload.city||''),neighborhood:String(payload.neighborhood||''),deposit:payload.deposit_agreed?'توافقی':String(payload.deposit_toman||''),monthlyRent:payload.rent_agreed?'توافقی':String(payload.monthly_rent_toman||''),salePrice:payload.sale_price_agreed?'توافقی':String(payload.sale_price_toman||''),builtArea:String(payload.building_area_sqm||payload.area_sqm||''),landArea:String(payload.land_area_sqm||''),rooms:String(payload.bedrooms||''),amenities:Array.isArray(payload.amenities)?payload.amenities.slice(0,30):[]};
 const id='qoqnus-'+sid;
 return {id,qoqnusSyncId:sid,qoqnusPayloadHash:hash,importedFromQoqnus:true,code:String(payload.code||('QB-'+sid.slice(0,8).toUpperCase())).slice(0,40),title,url:'',detailText:detail,text:detail,publicDescription:String(payload.description||detail).slice(0,7000),description:String(payload.description||'').slice(0,5000),publicPost:detail,phones,phone:phones[0]||'',phoneReadStatus:phones.length?'found':'not_visible',phoneReadAt:phones.length?now:null,phoneSource:phones.length?'qoqnus-bot':'',imageUrls:[],imageDataUrls,facts,listingType,listingTypeLabel:listingTypeLabel(listingType),contactCategory:classifyContactCategory({title,description:detail,listingType}),contactCategoryLabel:contactCategoryLabel(classifyContactCategory({title,description:detail,listingType})),city:String(payload.city||''),neighborhood:String(payload.neighborhood||''),location:facts.location,transactionType:tx,propertyType:typeText,area_sqm:String(payload.area_sqm||''),landArea:String(payload.land_area_sqm||''),buildingArea:String(payload.building_area_sqm||''),salePrice:String(payload.sale_price_toman||''),deposit:String(payload.deposit_toman||''),monthlyRent:String(payload.monthly_rent_toman||''),tags:['#املاک_ققنوس'],status:'archived',sendStatus:'not_sent',source:'qoqnus-bot',createdAt:Number(payload.created_at_ms)||publishedAt,archivedAt:publishedAt,publishedAt,imageTransferNote:String(payload.image_transfer_note||''),imageSourceReferenceCount:Number(payload.image_source_reference_count)||0,importedAt:now};
}
async function qoqnusPersistPayload(envelope){
 const payload=envelope?.payload;const {sid,hash}=validateQoqnusSyncPayload(payload,envelope);const actualHash=await qoqnusSha256Json(payload);if(actualHash!==hash)throw new Error('صحت محتوای پرونده با هش سرور تأیید نشد؛ چیزی پاک‌سازی یا تأیید نشد.');
 const record=qoqnusPayloadToArchiveRecord(payload,sid,hash);const state=await chrome.storage.local.get({queue:[]});const oldQueue=Array.isArray(state.queue)?state.queue:[];const old=oldQueue.find(x=>String(x.qoqnusSyncId||'')===sid||String(x.id||'')===record.id);
 const merged=old?{...old,...record,createdAt:old.createdAt||record.createdAt,importedAt:old.importedAt||record.importedAt,status:'archived',sendStatus:old.sendStatus||'not_sent'}:record;
 const next=old?oldQueue.map(x=>(String(x.qoqnusSyncId||'')===sid||String(x.id||'')===record.id)?merged:x):[merged,...oldQueue];
 await chrome.storage.local.set({queue:retainQueue(next)});
 const verifyState=await chrome.storage.local.get({queue:[]});const verify=(verifyState.queue||[]).find(x=>String(x.qoqnusSyncId||'')===sid&&String(x.id||'')===record.id);
 if(!verify||verify.title!==record.title||verify.detailText!==record.detailText||verify.qoqnusPayloadHash!==hash||(verify.imageDataUrls||[]).length!==imageDataUrlsCount(record))throw new Error('ذخیرهٔ محلی کامل دوباره‌خوانی نشد؛ رسید ارسال نمی‌شود.');
 // Add phone to local contact book before ACK. This operation is idempotent by listing id + phone.
 if(verify.phones?.length)await archiveListingPhones(verify);
 return {sid,hash,duplicate:!!old,record:verify};
}
function imageDataUrlsCount(record){return Array.isArray(record.imageDataUrls)?record.imageDataUrls.length:0;}
async function qoqnusSyncRequest(action,body={}){
 const cfgState=await chrome.storage.local.get({qoqnusSync:{apiUrl:'',secret:''}});let cfg=cfgState.qoqnusSync||{};
 if((!cfg.apiUrl||!cfg.secret)&&chrome.storage.sync?.get){try{const synced=await chrome.storage.sync.get({qoqnusSync:{apiUrl:'',secret:''}});if(synced.qoqnusSync?.apiUrl&&synced.qoqnusSync?.secret){cfg=synced.qoqnusSync;await chrome.storage.local.set({qoqnusSync:cfg});}}catch{}}
 const rawUrl=String(cfg.apiUrl||QOQNUS_DEFAULT_SYNC_URL).trim();let u;try{u=new URL(rawUrl);}catch{throw new Error('نشانی API معتبر نیست. تنظیمات افزونه را باز کن و نشانی نمایش‌داده‌شده در پنل ققنوس را وارد کن.');}
 const secret=String(cfg.secret||'').trim();
 if(u.protocol!=='https:'||!u.pathname.endsWith('/extension-sync.php'))throw new Error('نشانی API باید HTTPS باشد و به extension-sync.php ختم شود. نشانی دقیق را از پنل ققنوس کپی کن.');
 if(secret.length<40)throw new Error('کلید امن همگام‌سازی هنوز در افزونه ذخیره نشده است. در پنل ققنوس ← همگام‌سازی افزونه، جداول را آماده و کلید امن را تولید کن؛ سپس کلید را در تنظیمات افزونه وارد و «ذخیره و بررسی اتصال» را بزن. نشانی پیشنهادی از قبل پر شده است؛ اگر با پنل فرق دارد، نشانی پنل را جایگزین کن.');
 const allowed=await chrome.permissions.contains({origins:[u.origin+'/*']});if(!allowed)throw new Error('مجوز اتصال به دامنهٔ هاست داده نشده است. تنظیمات افزونه را باز کن و «ذخیره و بررسی اتصال» را بزن تا مجوز HTTPS گرفته شود.');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),60000);try{const response=await fetch(u.href,{method:'POST',redirect:'error',cache:'no-store',credentials:'omit',signal:controller.signal,headers:{'Content-Type':'application/json','X-Qoqnus-Sync-Key':secret},body:JSON.stringify({action,...body})});let data;try{data=await response.json();}catch{throw new Error('پاسخ هاست JSON معتبر نیست.');}if(!response.ok||data?.ok!==true){const map={unauthorized:'کلید همگام‌سازی پذیرفته نشد.',sync_not_configured:'همگام‌سازی در پنل هاست فعال نیست.',migration_required:'جدول‌های همگام‌سازی در هاست آماده نشده‌اند.',internal_error:'خطای داخلی API همگام‌سازی.'};throw new Error(map[data?.error]||('خطای API هاست، HTTP '+response.status));}return data;}finally{clearTimeout(timer);}}
let qoqnusAuditWriteChain=Promise.resolve();
let qoqnusAuditFlushPromise=null;
function qoqnusNewEventId(){const b=new Uint8Array(16);crypto.getRandomValues(b);return [...b].map(x=>x.toString(16).padStart(2,'0')).join('');}
function qoqnusAuditItem(eventType,entityType,entityId,payload,eventId=null){
 const id=eventId||qoqnusNewEventId();
 if(!/^[a-f0-9]{32}$/i.test(id))throw new Error('شناسه رخداد محلی معتبر نیست.');
 return {event_id:id.toLowerCase(),event_type:String(eventType).slice(0,80),entity_type:String(entityType||'').slice(0,40),entity_id:String(entityId||'').slice(0,160),payload:payload&&typeof payload==='object'?payload:{},created_at_ms:Date.now()};
}
function qoqnusIsPrivateLocalBookEvent(eventOrType,entityType=''){
 const event=eventOrType&&typeof eventOrType==='object'?eventOrType:{event_type:eventOrType,entity_type:entityType};
 const type=String(event.event_type||event.type||'');
 const localEntity=String(event.entity_type||'')==='local_book';
 const privateActivityType=/^(contact|customer|office_file)\.activity$/.test(type);
 const privateRecordType=/^(contact|customer|office_file)\.(upsert|snapshot|delete)$/.test(type);
 const privateArchiveType=/^listing\.archive\.(saved|updated|delete)$/.test(type);
 return localEntity||privateActivityType||privateRecordType||privateArchiveType;
}
function qoqnusLocalOnlyAuditMeta(event){
 return {event_id:String(event?.event_id||qoqnusNewEventId()).toLowerCase(),event_type:String(event?.event_type||'local_book.activity').slice(0,80),entity_type:'local_book',entity_id:'private-local-record',payload:{source_detail:'local-device-only'},created_at_ms:Number(event?.created_at_ms)||Date.now(),local_status:'local_only'};
}
function qoqnusSafeAuditEvent(event){
 if(!event||typeof event!=='object')return null;
 const privateLocalBookEvent=qoqnusIsPrivateLocalBookEvent(event);
 if(privateLocalBookEvent)return null;
 if(!/^[a-f0-9]{32}$/.test(String(event.event_id||'')))return null;
 return event;
}
async function qoqnusStoreAuditBatch(events,markSeeded=false){
 const state=await chrome.storage.local.get({qoqnusAuditOutbox:[],qoqnusAuditEvents:[],qoqnusSyncSnapshotSeeded:false});
 const rawOutbox=Array.isArray(state.qoqnusAuditOutbox)?state.qoqnusAuditOutbox:[];
 const rawHistory=Array.isArray(state.qoqnusAuditEvents)?state.qoqnusAuditEvents:[];
 const outbox=[],history=[],legacyPrivateOutbox=[],knownOut=new Set(),knownHistory=new Set();
 // Purge any older private-book payloads already sitting in local queues/history.
 for(const e of rawOutbox){const safeEvent=qoqnusSafeAuditEvent(e);if(!safeEvent){if(qoqnusIsPrivateLocalBookEvent(e))legacyPrivateOutbox.push(e);continue;}if(!knownOut.has(String(safeEvent.event_id))){outbox.push(safeEvent);knownOut.add(String(safeEvent.event_id));}}
 for(const e of rawHistory){if(qoqnusIsPrivateLocalBookEvent(e)){const meta=qoqnusLocalOnlyAuditMeta(e);if(!knownHistory.has(meta.event_id)){history.push(meta);knownHistory.add(meta.event_id);}continue;}if(!e||typeof e!=='object')continue;const id=String(e.event_id||'');if(!id||knownHistory.has(id))continue;history.push(e);knownHistory.add(id);}
 for(const e of legacyPrivateOutbox){const meta=qoqnusLocalOnlyAuditMeta(e);if(!knownHistory.has(meta.event_id)){history.push(meta);knownHistory.add(meta.event_id);}}
 for(const e of events){
  const safeEvent=qoqnusSafeAuditEvent(e);
  if(!safeEvent){const meta=qoqnusLocalOnlyAuditMeta(e);if(!knownHistory.has(meta.event_id)){history.push(meta);knownHistory.add(meta.event_id);}continue;}
  const id=String(safeEvent.event_id||'');if(!knownOut.has(id)){outbox.push(safeEvent);knownOut.add(id);}if(!knownHistory.has(id)){history.push({...safeEvent,local_status:'queued'});knownHistory.add(id);}
 }
 if(outbox.length>10000)throw new Error('صف رخدادهای ارسال‌نشده بسیار بزرگ شده؛ اتصال همگام‌سازی را بررسی کن.');
 await chrome.storage.local.set({qoqnusAuditOutbox:outbox,qoqnusAuditEvents:history.slice(-3000),...(markSeeded?{qoqnusSyncSnapshotSeeded:true}:{})});
}
async function qoqnusQueueAuditEvent(eventType,entityType,entityId,payload={},options={}){
 const task=async()=>{const e=qoqnusAuditItem(eventType,entityType,entityId,payload,options.eventId||null);if(qoqnusIsPrivateLocalBookEvent(e)){await qoqnusStoreAuditBatch([e]);return {ok:true,local_only:true,event_id:e.event_id};}await qoqnusStoreAuditBatch([e]);qoqnusFlushAuditOutbox().catch(()=>{});return {ok:true,event_id:e.event_id};};
 const taskPromise=qoqnusAuditWriteChain.then(task,task);qoqnusAuditWriteChain=taskPromise.catch(()=>{});return taskPromise;
}
async function qoqnusFlushAuditOutbox(limit=10){
 if(qoqnusAuditFlushPromise)return qoqnusAuditFlushPromise;
 qoqnusAuditFlushPromise=(async()=>{await qoqnusStoreAuditBatch([]);let sent=0,unindexedNow=0;for(let n=0;n<Math.max(1,Math.min(20,limit));n++){
  const st=await chrome.storage.local.get({qoqnusAuditOutbox:[],qoqnusAuditEvents:[],qoqnusSyncIndexWarnings:[]});const out=Array.isArray(st.qoqnusAuditOutbox)?st.qoqnusAuditOutbox:[];if(!out.length)break;const current=out[0];
  try{
   const response=await qoqnusSyncRequest('event',{event:{event_id:current.event_id,event_type:current.event_type,entity_type:current.entity_type,entity_id:current.entity_id,payload:current.payload||{}}});
   const sourceRecord=current.payload?.record&&typeof current.payload.record==='object'?current.payload.record:(current.payload||{});
   const claimsRubikaPublished=current.event_type==='listing.send.result'&&String(sourceRecord.rubika_status||'')==='sent';
   const indexMiss=claimsRubikaPublished&&response?.channel_indexed!==true;
   const reason=String(response?.index_reason||'index_result_not_confirmed').slice(0,120);
   let warnings=Array.isArray(st.qoqnusSyncIndexWarnings)?st.qoqnusSyncIndexWarnings:[];
   if(indexMiss&&!warnings.some(w=>String(w.event_id||'')===String(current.event_id))){
    warnings=[...warnings,{event_id:String(current.event_id),listing_id:String(current.entity_id||sourceRecord.id||''),title:String(sourceRecord.title||sourceRecord.id||'آگهی بدون عنوان').slice(0,180),channel_id:String(sourceRecord.channel_id||''),message_id:String(sourceRecord.rubika_message_id||sourceRecord.message_id||''),reason,created_at_ms:Number(current.created_at_ms)||Date.now()}].slice(-100);
    unindexedNow++;
   }
   const left=out.filter(x=>String(x.event_id)!==String(current.event_id));
   const history=(st.qoqnusAuditEvents||[]).map(x=>String(x.event_id)===String(current.event_id)?{...x,local_status:indexMiss?'sent_not_indexed':'sent',server_indexed:claimsRubikaPublished?response?.channel_indexed===true:null,server_index_reason:indexMiss?reason:''}:x);
   await chrome.storage.local.set({qoqnusAuditOutbox:left,qoqnusAuditEvents:history.slice(-3000),qoqnusSyncIndexWarnings:warnings});sent++;
  }catch(e){break;}
 }
 const finalState=await chrome.storage.local.get({qoqnusAuditOutbox:[],qoqnusSyncIndexWarnings:[]});
 return {sent,unindexedNow,pending:(finalState.qoqnusAuditOutbox||[]).length,indexWarningCount:(finalState.qoqnusSyncIndexWarnings||[]).length};})().finally(()=>{qoqnusAuditFlushPromise=null;});return qoqnusAuditFlushPromise;
}
async function qoqnusEnsureLocalSnapshot(){
 const st=await chrome.storage.local.get({qoqnusSyncSnapshotSeeded:false});
 // Contact/customer books belong to this device. They are not snapshots for server upload.
 if(st.qoqnusSyncSnapshotSeeded){await qoqnusStoreAuditBatch([]);return 0;}
 await qoqnusStoreAuditBatch([],true);return 0;
}
function qoqnusEventUpsert(list,record){if(!record||!record.id)return Array.isArray(list)?list:[];const rows=Array.isArray(list)?list:[];const id=String(record.id);const i=rows.findIndex(x=>String(x.id)===id);return i<0?[record,...rows]:rows.map((x,n)=>n===i?{...x,...record}:x);}
async function qoqnusApplyRecoveredEvent(e,state){
 const type=String(e.event_type||''),p=e.payload&&typeof e.payload==='object'?e.payload:{};const privateBookEvent=/^(customer|office_file)\.activity$/.test(type)||qoqnusIsPrivateLocalBookEvent(e);if(privateBookEvent)return false;let changed=false;
 if(['contact.upsert','contact.snapshot'].includes(type)){if(p.id){state.contactArchive=qoqnusEventUpsert(state.contactArchive,p);changed=true;}}
 else if(type==='contact.delete'){state.contactArchive=(state.contactArchive||[]).filter(x=>String(x.id)!==String(p.id||''));changed=true;}
 else if(['customer.upsert','customer.snapshot'].includes(type)){if(p.id){state.qoqnusCustomers=qoqnusEventUpsert(state.qoqnusCustomers,p);changed=true;}}
 else if(type==='customer.delete'){state.qoqnusCustomers=(state.qoqnusCustomers||[]).filter(x=>String(x.id)!==String(p.id||''));changed=true;}
 else if(type==='listing.archive.delete'){state.queue=(state.queue||[]).filter(x=>String(x.id)!==String(p.id||'')&&String(x.qoqnusSyncId||'')!==String(p.id||''));changed=true;}
 return changed;
}
async function qoqnusRestoreFromServer(forceFull=false,maxPages=30){
 const before=await chrome.storage.local.get({qoqnusEventCursor:0,contactArchive:[],qoqnusCustomers:[],queue:[],qoqnusAuditEvents:[],qoqnusAuditOutbox:[]});
 const localBackup={qoqnusAuditEvents:before.qoqnusAuditEvents,qoqnusEventCursor:before.qoqnusEventCursor};
 let cursor=forceFull?0:Math.max(0,Number(before.qoqnusEventCursor)||0),restored=0,pages=0,hasMore=false;
 let state={contactArchive:Array.isArray(before.contactArchive)?before.contactArchive.slice():[],qoqnusCustomers:Array.isArray(before.qoqnusCustomers)?before.qoqnusCustomers.slice():[],queue:Array.isArray(before.queue)?before.queue.slice():[],qoqnusAuditEvents:Array.isArray(before.qoqnusAuditEvents)?before.qoqnusAuditEvents.slice():[]};
 if(forceFull){state.qoqnusAuditEvents=[];await chrome.storage.local.set({qoqnusRestoreBackup:localBackup,qoqnusAuditEvents:[],qoqnusEventCursor:0});}
 try{
  for(let i=0;i<Math.max(1,Math.min(100,maxPages));i++){
   const page=await qoqnusSyncRequest('restore',{after_id:cursor,limit:100});const events=Array.isArray(page.events)?page.events:[];pages++;
   const known=new Set(state.qoqnusAuditEvents.map(x=>String(x.event_id||'')));
   for(const e of events){const privateBookEvent=/^(customer|office_file)\.activity$/.test(String(e?.event_type||''))||qoqnusIsPrivateLocalBookEvent(e);if(privateBookEvent)continue;await qoqnusApplyRecoveredEvent(e,state);if(e.event_id&&!known.has(String(e.event_id))){state.qoqnusAuditEvents.push({...e,local_status:'restored'});known.add(String(e.event_id));}restored++;}
   cursor=Math.max(cursor,Number(page.next_after)||cursor);hasMore=!!page.has_more;
   await chrome.storage.local.set({contactArchive:state.contactArchive,qoqnusCustomers:state.qoqnusCustomers,queue:state.queue,qoqnusAuditEvents:state.qoqnusAuditEvents.slice(-3000),qoqnusEventCursor:cursor});
   if(!hasMore||!events.length)break;
  }
 }catch(e){if(forceFull){try{await chrome.storage.local.set(localBackup);}catch{}}throw e;}
 return {restored,pages,hasMore,cursor};
}
async function qoqnusFullRestore(){await qoqnusEnsureLocalSnapshot();await qoqnusFlushAuditOutbox(20);const result=await qoqnusRestoreFromServer(true,100);await qoqnusQueueAuditEvent('extension.restore.completed','extension','full-restore',{restored:result.restored,source_detail:'server-event-journal',operation:'restored'});await qoqnusFlushAuditOutbox(5);return {ok:true,...result};}

async function qoqnusRunSync(){
 if(qoqnusSyncInFlight)return qoqnusSyncInFlight;
 qoqnusSyncInFlight=(async()=>{let saved=0,duplicates=0,failed=0,processed=0,empty=false,lastError='',restored=0,pushed=0,indexWarningsAdded=0;
  try{
   await qoqnusEnsureLocalSnapshot();
   const pushedResult=await qoqnusFlushAuditOutbox(10);pushed=Number(pushedResult.sent)||0;indexWarningsAdded+=Number(pushedResult.unindexedNow)||0;
   const restoreResult=await qoqnusRestoreFromServer(false,20);restored=Number(restoreResult.restored)||0;
   for(let i=0;i<5;i++){
    const page=await qoqnusSyncRequest('pull',{limit:1});const entries=Array.isArray(page.items)?page.items:[];if(!entries.length){empty=true;break;}
    for(const entry of entries){try{const persisted=await qoqnusPersistPayload(entry);const ack=await qoqnusSyncRequest('ack',{items:[{sync_id:persisted.sid,payload_sha256:persisted.hash}]});if(Number(ack.acked||0)+Number(ack.already_acked||0)<1||Number(ack.invalid||0)>0)throw new Error('هاست رسید ذخیره‌شدن را نپذیرفت؛ رکورد برای تلاش بعدی باقی می‌ماند.');if(persisted.duplicate)duplicates++;else saved++;processed++;}catch(e){failed++;lastError=String(e?.message||'خطای نامشخص');break;}}
    if(failed)break;
   }
   if(processed||pushed||restored){try{await qoqnusQueueAuditEvent('extension.sync.completed','extension','sync',{saved,duplicates,failed,processed,restored,source_detail:'dashboard-open-or-manual',operation:'synced'});const f=await qoqnusFlushAuditOutbox(3);pushed+=Number(f.sent)||0;indexWarningsAdded+=Number(f.unindexedNow)||0;}catch{}}
   let serverStatus=null,statusError='';
   try{
    serverStatus=await qoqnusSyncRequest('status');
    if(serverStatus?.sync_contract&&serverStatus.sync_contract!=='qoqnus.sync.v2')throw new Error('قرارداد همگام‌سازی دو نرم‌افزار یکسان نیست؛ نسخهٔ هم‌خوان ربات و افزونه را نصب کن.');
   }catch(e){
    const msg=String(e?.message||e||'خطای وضعیت');
    if(msg.includes('قرارداد همگام‌سازی'))throw e;
    statusError=msg;
   }
   const ok=failed===0;
   const warningState=await chrome.storage.local.get({qoqnusSyncIndexWarnings:[]});const indexWarningCount=Array.isArray(warningState.qoqnusSyncIndexWarnings)?warningState.qoqnusSyncIndexWarnings.length:0;
   const indexWarningText=indexWarningsAdded?' هشدار: '+indexWarningsAdded+' آگهی ارسال‌شده در نمایه ثبت نشد.':'';
   return {ok,saved,duplicates,failed,processed,restored,pushed,indexWarningsAdded,indexWarningCount,restoreHasMore:!!restoreResult.hasMore,remainingMayExist:!empty,error:failed?lastError:'',message:failed?lastError:(processed||restored||pushed?'همگام‌سازی و بررسی دفتر رخداد انجام شد.'+indexWarningText:'اتصال موفق است؛ صف انتقال خالی است.'+indexWarningText),syncContract:String(serverStatus?.sync_contract||''),botBuild:String(serverStatus?.bot_build||''),serverPending:Number(serverStatus?.pending||0),matchingIndexCount:Number(serverStatus?.matching_index_count||0),channelAdsIndexCount:Number(serverStatus?.channel_ads_index_count||0),customerMatchPending:Number(serverStatus?.customer_match_pending||0),customerMatchSchemaReady:serverStatus?.customer_match_schema_ready===true,statusError};
  }catch(e){return {ok:false,saved,duplicates,failed:failed+1,processed,restored,pushed,remainingMayExist:true,error:String(e?.message||'خطای نامشخص')};}
  finally{qoqnusSyncInFlight=null;}
 })();return qoqnusSyncInFlight;
}
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
 if(msg?.type==='QOQNUS_OPEN_SYNC_SETTINGS'){
  chrome.runtime.openOptionsPage().then(()=>sendResponse({ok:true})).catch(e=>sendResponse({ok:false,error:String(e?.message||e||'بازکردن صفحهٔ گزینه‌های افزونه ناموفق بود.')}));return true;
 }
 if(msg?.type==='QOQNUS_SYNC_CHECK'){qoqnusSyncRequest('status').then(r=>sendResponse({ok:true,status:r.status||r})).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='QOQNUS_SYNC_NOW'){qoqnusRunSync().then(async r=>{try{await chrome.storage.local.set({qoqnusSyncLastResult:{...r,at:Date.now()}});}catch{}sendResponse(r);}).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='QOQNUS_AUDIT_EVENT'){qoqnusQueueAuditEvent(String(msg.eventType||''),String(msg.entityType||''),String(msg.entityId||''),msg.payload||{},{}).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='QOQNUS_RESTORE_NOW'){qoqnusFullRestore().then(async r=>{try{await chrome.storage.local.set({qoqnusRestoreLastResult:{...r,at:Date.now()}});}catch{}sendResponse(r);}).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='DIVAR_SAVE_CURRENT_LISTING'){saveCurrentListing(msg.item,sender).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e.message||e)}));return true;}
 if(msg?.type==='DIVAR_SAVE_MANUAL_PHONE'){saveManualPhone(String(msg.id||''),String(msg.phone||'')).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e.message||e)}));return true;}
 if(msg?.type==='DIVAR_REFRESH_POST'){chrome.storage.local.get({sendSettings:DEFAULT_SEND_SETTINGS}).then(s=>sendResponse({post:makePost(msg.item,s.sendSettings)}));return true;}
 if(msg?.type==='RUBIKA_SEND_SETTINGS_SAVE'){saveSendSettings(msg.settings||{}).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e.message||e)}));return true;}
 if(msg?.type==='RUBIKA_PREVIEW_POST'){previewPost(msg.id,msg.settings).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e.message||e)}));return true;}
 if(msg?.type==='RUBIKA_SEND_STATUS'){getRubikaSendStatus(msg.id).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e.message||e)}));return true;}
 if(msg?.type==='DIVAR_READ_PHONE'){readPhoneFromListing(msg.id).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e.message||e)}));return true;}
 if(msg?.type==='EITAA_SEND_TEST'){testEitaaSend(msg.config||null).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e),stage:e?.stage||'',httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',details:e?.responseHint||''}));return true;}
 if(msg?.type==='EITAA_SEND_MEDIA_TEST'){testEitaaMediaSend(msg.config||null).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e),stage:e?.stage||'',httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',details:e?.responseHint||''}));return true;}
 if(msg?.type==='RUBIKA_SEND_TEST'){
  (async()=>{
   const st=await chrome.storage.local.get({rubika:{}});const token=String(st.rubika?.token||'').trim();if(!token)throw new Error('توکن ربات در تنظیمات ذخیره نشده است.');
   const stamp=new Date().toLocaleString('fa-IR');const text=`✅ آزمون ارسال ققنوس\nزمان: ${stamp}\nاین پیام فقط برای آزمایش مستقیم ارسال متن به کانال است.`;
   const data=await rubikaRequest('sendMessage',{chat_id:FIXED_RUBIKA_CHAT_ID,text},token,{timeoutMs:25000});
   const messageId=data?.data?.message_id||data?.message_id||'';if(!messageId)throw requestError('روبیکا پاسخ داد اما شناسه پیام نداشت؛ کانال را بررسی کن.',{ambiguous:true,method:'sendMessage',stage:'response'});
   sendResponse({ok:true,messageId,channel:FIXED_RUBIKA_CHAT_ID});
  })().catch(e=>sendResponse({ok:false,error:String(e?.message||e),stage:e?.stage||e?.method||'test',method:e?.method||'',httpStatus:e?.httpStatus??null,apiStatus:e?.apiStatus||'',details:String(e?.responseHint||''),ambiguous:!!e?.ambiguous}));return true;
 }
 if(msg?.type==='RUBIKA_TEST'){(async()=>{const st=await chrome.storage.local.get({rubika:{}});const token=String(st.rubika?.token||'').trim();if(!token)throw new Error('ابتدا توکن ربات را ذخیره کنید.');const r=await fetch(`https://botapi.rubika.ir/v3/${encodeURIComponent(token)}/getMe`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});const raw=await r.text();const d=parseApiJson(raw);if(!r.ok||String(d.status||'').toUpperCase()!=='OK')throw new Error(d.description||d.message||'اتصال ناموفق');sendResponse({ok:true,result:d});})().catch(e=>sendResponse({ok:false,error:e.message}));return true;}
 if(msg?.type==='QOQNUS_SEND_INVITE_REPORT'){(async()=>{const chatId=String(msg.chatId||'').trim();if(!chatId)throw new Error('شناسهٔ کانال خصوصی گزارش در تنظیمات دعوت وارد نشده است.');const st=await chrome.storage.local.get({rubika:{}}),token=String(st.rubika?.token||'').trim();if(!token)throw new Error('توکن ربات روبیکا ذخیره نشده است.');const text=String(msg.text||'').trim();if(!text)throw new Error('متن گزارش خالی است.');const data=await rubikaRequest('sendMessage',{chat_id:chatId,text},token,{timeoutMs:25000});const messageId=data?.data?.message_id||data?.message_id||'';if(!messageId)throw requestError('پاسخ روبیکا شناسهٔ پیام گزارش را برنگرداند؛ کانال خصوصی را بررسی کن.',{ambiguous:true,method:'sendMessage',stage:'response'});sendResponse({ok:true,messageId,chatId});})().catch(e=>sendResponse({ok:false,error:String(e?.message||e),stage:e?.stage||e?.method||'invite-report',ambiguous:!!e?.ambiguous}));return true;}
 if(msg?.type==='RUBIKA_SEND_APPROVED'){
  queueRubikaSend(msg.id,{imageIndex:msg.imageIndex,confirmedAmbiguous:msg.confirmedAmbiguous===true}).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
  return true;
 }
 if(msg?.type==='RUBIKA_WAIT_SEND'){waitForRubikaSend(msg.id,Math.max(10000,Math.min(180000,Number(msg.timeoutMs)||120000))).then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
 if(msg?.type==='OFFICE_FILE_SAVE'){saveOfficeFileEntry(msg.entry||{}).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='OFFICE_AD_SAVE'){saveOfficeAdEntry(msg.entry||{}).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='CONTACT_ARCHIVE_SAVE'){saveContactArchiveEntry(msg.entry||{}).then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
 if(msg?.type==='CONTACT_ARCHIVE_LIST'){exportContactArchive().then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
 if(msg?.type==='CONTACT_ARCHIVE_DELETE'){deleteContactArchiveEntry(String(msg.id||'')).then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
 if(msg?.type==='RUBIKA_RETRY_ARCHIVED'){retryArchivedSend(msg.id,msg.imageIndex,msg.confirmedAmbiguous===true).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='RUBIKA_RESEND_ARCHIVED'){queueRubikaSend(msg.id,{resend:true,forceResend:true,imageIndex:msg.imageIndex,confirmedAmbiguous:msg.confirmedAmbiguous===true}).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));return true;}
 if(msg?.type==='ARCHIVE_DELETE_ITEM'){deleteArchivedItem(msg.id).then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
});

chrome.action.onClicked.addListener(()=>chrome.tabs.create({url:chrome.runtime.getURL('dashboard.html')}));
