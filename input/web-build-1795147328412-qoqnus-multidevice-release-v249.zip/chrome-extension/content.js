(() => {
  const clean = s => (s || '').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').replace(/\n\s*\n\s*\n+/g,'\n\n').trim();
  const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const normalize = s => clean(s).toLowerCase().replace(/[ي]/g,'ی').replace(/[ك]/g,'ک').replace(/\s+/g,' ');
  const toAsciiDigits = s => String(s||'').replace(/[۰-۹٠-٩]/g, d => {
    const fa='۰۱۲۳۴۵۶۷۸۹', ar='٠١٢٣٤٥٦٧٨٩';
    const fi=fa.indexOf(d); return String(fi>=0?fi:ar.indexOf(d));
  });
  function extractPhones(text) {
    const ascii=toAsciiDigits(text);
    const matches=ascii.match(/(?<![0-9])(?:(?:\+|00)?98[ .()\-]*)?0?9(?:[ .()\-]*[0-9]){9}(?![0-9])/g)||[];
    const phones=[];
    for (let candidate of matches) {
      let digits=candidate.replace(/\D/g,'');
      if(digits.startsWith('0098')) digits='0'+digits.slice(4);
      else if(digits.startsWith('98')&&digits.length===12) digits='0'+digits.slice(2);
      else if(digits.length===10&&digits[0]==='9') digits='0'+digits;
      if(/^09[0-9]{9}$/.test(digits)&&!phones.includes(digits)) phones.push(digits);
    }
    return phones;
  }
  // Read phone numbers only from content currently visible in the opened listing.
  // Divar may reveal the seller number in a dialog or a tel: link outside the main details card.
  function visiblePhoneNumbers() {
    const chunks=[];
    if (document.body) chunks.push(document.body.innerText || '');
    for (const el of [...document.querySelectorAll('a[href^="tel:"], [role="dialog"], [aria-live="polite"]')]) {
      if (!visible(el)) continue;
      chunks.push(el.innerText || el.textContent || '');
      const href=el.getAttribute('href') || '';
      if (/^tel:/i.test(href)) chunks.push(decodeURIComponent(href.slice(4)));
      const aria=el.getAttribute('aria-label') || '';
      if (aria) chunks.push(aria);
    }
    return [...new Set(chunks.flatMap(extractPhones))];
  }
  const wait = ms => new Promise(r=>setTimeout(r,ms));
  const phoneActionLabel = /^(?:مشاهده|نمایش|دیدن|دریافت)\s*(?:شماره|تلفن|شماره تماس|اطلاعات تماس)|^(?:شماره تماس|اطلاعات تماس)$/;
  function getCard(anchor) {
    let el = anchor;
    let best = null;
    for (let i=0; i<8 && el; i++, el=el.parentElement) {
      const txt = clean(el.innerText);
      if (txt.length >= 25 && txt.length <= 2600 && (/(تومان|میلیون|ودیعه|اجاره|اتاق|متر|قیمت توافقی|رهن کامل)/.test(txt))) {
        best = el;
        // Prefer the smallest suitable container, then stop before a large listing grid.
        if (txt.length < 1100) break;
      }
    }
    return best || anchor.closest('article') || anchor.parentElement;
  }
  function classify(text, pageUrl) {
    const t = normalize(text), u = (pageUrl || '').toLowerCase();
    const tags = [];
    if (/rent|اجاره|رهن/.test(u+' '+t)) tags.push('#اجاره');
    else if (/buy|sell|فروش|خرید/.test(u+' '+t)) tags.push('#فروش');
    if (/villa|ویلا/.test(u+' '+t)) tags.push('#ویلا');
    if (/apartment|آپارتمان|آپارتمانی/.test(u+' '+t)) tags.push('#آپارتمان');
    if (/زمین|باغ|کلنگی/.test(t)) tags.push('#زمین_و_باغ');
    if (/مغازه|تجاری|دفتر_کار|اداری/.test(t)) tags.push('#تجاری_اداری');
    if (/نیشابور|neyshabur/.test(u+' '+t)) tags.push('#نیشابور');
    if (/سراب.?کوشک|saraab-koushk/.test(u+' '+t)) tags.push('#سراب_کوشک');
    if (!tags.length) tags.push('#فایل_ملک');
    return [...new Set(tags)];
  }
  // Conservative, editable heuristic: only obvious broker/agency indicators are excluded.
  function looksLikeAgency(text) {
    const t = normalize(text);
    return /مشاور املاک|املاک\s+[آ-یa-z]|آژانس املاک|بنگاه املاک|دفتر املاک|مشاورین املاک|گروه املاک|کارشناس فروش املاک|املاک و مستغلات|مشاور مسکن/.test(t);
  }
  function inferAgeDays(text) {
    const t = normalize(text).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
    const patterns = [
      [/همین امروز|امروز/, 0], [/دیروز/, 1], [/پریروز/, 2],
      [/([0-9]+)\s*روز\s*پیش/, null], [/([0-9]+)\s*هفته\s*پیش/, null],
      [/([0-9]+)\s*ماه\s*پیش/, null], [/([0-9]+)\s*سال\s*پیش/, null]
    ];
    for (const [re, fixed] of patterns) {
      const m=t.match(re); if(!m) continue;
      if(fixed!==null) return fixed;
      const n=Number(m[1]); if(!Number.isFinite(n)) continue;
      if(re.source.includes('روز')) return n;
      if(re.source.includes('هفته')) return n*7;
      if(re.source.includes('ماه')) return n*30;
      if(re.source.includes('سال')) return n*365;
    }
    return null;
  }
  async function extractReadyDetail(expectedId) {
    const expected=String(expectedId||'');
    let best=null;
    const started=Date.now();
    let lastFingerprint='';
    let stableAtBottom=0;
    const mergeSnapshot=(prior,next)=>{
      if(!prior)return next;
      const out={...prior,...next};
      for(const key of ['detailText','text','publicDescription','description','title','priceText','location']){
        const a=String(prior[key]||''), b=String(next[key]||'');
        if(key==='title') out[key]=b.length>=a.length?b:a;
        else out[key]=b.length>a.length?b:a;
      }
      for(const key of ['imageUrls','phones','categories','categoryLinks','attributes','tags']){
        const a=Array.isArray(prior[key])?prior[key]:[], b=Array.isArray(next[key])?next[key]:[];
        const sig=v=>typeof v==='object'?JSON.stringify(v):String(v);
        out[key]=[...new Map([...a,...b].map(v=>[sig(v),v])).values()];
      }
      out.imageUrls=(out.imageUrls||[]).slice(0,35);
      out.phones=(out.phones||[]).slice(0,15);
      return out;
    };
    const deadline=Date.now()+26000;
    while(Date.now()<deadline) {
      const match=location.pathname.match(/^\/v\/([^/?#]+)/);
      let current=''; try{current=match?decodeURIComponent(match[1]):'';}catch{current=match?.[1]||'';}
      if(current && (!expected || current===expected)) {
        // Prompt every lazy <img> to load; keep the actual scrolling below to trigger IntersectionObservers too.
        for(const img of document.querySelectorAll('img[loading="lazy"]')) { try{img.loading='eager';}catch{} }
        for(const img of document.querySelectorAll('img[data-src],img[data-lazy-src],img[data-original]')){
          const src=img.getAttribute('data-src')||img.getAttribute('data-lazy-src')||img.getAttribute('data-original');
          if(src&&!img.getAttribute('src')){try{img.setAttribute('src',src);}catch{}}
        }
        const item=extractDetailPayload();
        if(item?.id===expected && item.title && String(item.detailText||'').length>=30) best=mergeSnapshot(best,item);
        const height=Math.max(document.documentElement.scrollHeight,document.body?.scrollHeight||0);
        const viewport=Math.max(450,window.innerHeight||750);
        const maxY=Math.max(0,height-viewport);
        const y=window.scrollY||document.documentElement.scrollTop||0;
        if(y<maxY-100){
          const step=Math.max(350,Math.floor(viewport*0.68));
          window.scrollTo({top:Math.min(maxY,y+step),behavior:'auto'});
          await wait(650);
          continue;
        }
        // At the bottom, give delayed image requests and SPA rendering time to settle, then take another snapshot.
        await wait(650);
        const again=extractDetailPayload();
        if(again?.id===expected && again.title && String(again.detailText||'').length>=30) best=mergeSnapshot(best,again);
        const fp=best?`${String(best.detailText||'').length}|${String(best.description||'').length}|${(best.imageUrls||[]).length}|${(best.phones||[]).length}|${String(best.title||'')}`:'';
        if(fp && fp===lastFingerprint)stableAtBottom++;else stableAtBottom=0;
        lastFingerprint=fp;
        if(Date.now()-started>=5500 && stableAtBottom>=3) break;
        // If the page is short and contains no gallery, still require multiple stable reads rather than returning the first DOM snapshot.
        if(Date.now()-started>=18000 && stableAtBottom>=1) break;
      }else{
        await wait(350);
      }
    }
    if(best) return {ok:true,item:best,warning:(best.imageUrls||[]).length?'':'صفحه پس از چند مرحله خوانده شد، اما تصویر قابل‌دسترسی از آگهی پیدا نشد.',readStats:{detailLength:String(best.detailText||'').length,descriptionLength:String(best.description||'').length,imageCount:(best.imageUrls||[]).length,stableAtBottom}};
    return {ok:false,error:'صفحهٔ جزئیات آگهی پس از تلاش چندمرحله‌ای کامل خوانده نشد یا شناسهٔ آگهی با لینک مطابقت نداشت.'};
  }
  async function readDetailPhone() {
    const visibleText=()=>clean(document.body?.innerText||'');
    let phones=visiblePhoneNumbers();
    let clicked=false;
    if(!phones.length) {
      const candidates=[...document.querySelectorAll('button,[role="button"],a,[tabindex]')].filter(visible);
      const target=candidates.find(el=>{
        const label=normalize(el.innerText||el.getAttribute('aria-label')||el.getAttribute('title')||'').replace(/[：:]/g,'').trim();
        const href=String(el.getAttribute('href')||'');
        return !/^tel:/i.test(href) && phoneActionLabel.test(label) && label.length<48;
      });
      if(target) {
        clicked=true;
        target.click();
        const started=Date.now();
        while(Date.now()-started<6500) {
          await wait(350);
          phones=visiblePhoneNumbers();
          if(phones.length)break;
        }
      }
    }
    const allText=visibleText();
    const title=(document.querySelector('h1')?.innerText||'').trim();
    return {ok:true,phones,title,found:phones.length>0,clickedReveal:clicked,pageUrl:location.href,
      message:phones.length?'شمارهٔ نمایش‌داده‌شده در صفحهٔ آگهی خوانده شد.':clicked?'دکمهٔ نمایش شماره فشرده شد، اما شماره در متن قابل‌خواندن صفحه ظاهر نشد.':'در صفحهٔ فعلی شمارهٔ عمومی یا دکمهٔ مشخص نمایش شماره پیدا نشد.',
      detailsLength:allText.length};
  }
  function isDetailPage() {
    return /^\/v\/[^/]+/.test(location.pathname);
  }
  function listingRoot() {
    const relevant = el => {
      if (!visible(el)) return null;
      const text = clean(el.innerText || '');
      if (text.length < 80 || text.length > 42000) return null;
      if (!/(تومان|ودیعه|اجاره|قیمت توافقی|متر|خواب|آگهی|توضیحات|مشخصات)/.test(text)) return null;
      const title = !!el.querySelector('h1');
      const description = /توضیحات|مشخصات|ویژگی.?ها/.test(text);
      const imageCount = el.querySelectorAll('img,picture source').length;
      // Favor a container that includes both the primary listing heading and its body, not a tiny nested card.
      const score = Math.min(text.length, 18000) + (title ? 9000 : 0) + (description ? 1800 : 0) + Math.min(imageCount, 12) * 90;
      return {el, text, score};
    };
    const primaries = [...document.querySelectorAll('main,[role="main"]')].map(relevant).filter(Boolean);
    if (primaries.length) {
      primaries.sort((a,b) => b.score-a.score);
      return primaries[0].el;
    }
    const articles = [...document.querySelectorAll('article')].map(relevant).filter(Boolean);
    if (articles.length) {
      articles.sort((a,b) => b.score-a.score);
      return articles[0].el;
    }
    return document.body || document.documentElement;
  }
  function extractDetailPayload() {
    const root = listingRoot();
    const rootText = clean(root?.innerText || '');
    const bodyLines = clean(document.body?.innerText || '').split('\n').map(clean).filter(Boolean);
    const detailText = (rootText || clean(document.body?.innerText || '')).slice(0, 10000);
    const allLines = [...new Set([...detailText.split('\n').map(clean).filter(Boolean), ...bodyLines])].slice(0,1200);
    const title = clean(root?.querySelector('h1')?.innerText || document.querySelector('h1')?.innerText || document.querySelector('meta[property="og:title"]')?.content || document.title || 'آگهی ملک');
    const idMatch = location.pathname.match(/\/v\/([^/?#]+)/);
    const id = idMatch ? decodeURIComponent(idMatch[1]) : '';
    const skip = /^(ذخیره|ذخیره آگهی|اشتراک.?گذاری|گزارش آگهی|مشاهده شماره|نمایش شماره|دیدن شماره|دریافت شماره|چت|تماس|تماس با آگهی.?دهنده|بستن|بازگشت|دیوار|نقشه|مشاهده نقشه|آگهی بعدی|آگهی قبلی)$/i;
    const publicLines = allLines.filter(line => !skip.test(normalize(line)) && line.length > 1 && line !== title);
    const publicDescription = [title, ...publicLines].join('\n').slice(0, 7000);
    const priceLines = allLines.filter(line => /(تومان|میلیون|ودیعه|اجاره|رهن کامل|قیمت توافقی)/.test(line));
    const locationLine = allLines.find(line => /^(?:محله|محدوده|موقعیت|آدرس)\s*[:：]/.test(line)) || allLines.find(line => /(?:دقیقه|ساعت|روز|هفته|ماه)\s*پیش\s+در\s+/.test(line)) || allLines.find(line => /^(?:نیشابور|مشهد|تهران|سرآب|سرآب).*[,،].*(?:خ\.?|خیابان|کوچه|بلوار|شهرک)/.test(line)) || '';
    const detectedLocation = locationLine
      .replace(/^(?:محله|محدوده|موقعیت|آدرس)\s*[:：]\s*/, '')
      .replace(/(?:^|[\s،,])(?:امروز|دیروز|پریروز|(?:نیم|یک|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*پیش)\s*(?:در\s*)?/gi, ' ')
      .replace(/\s+/g,' ').trim();
    const breadcrumbRows = [...document.querySelectorAll('a[href^="/s/"]')]
      .filter(visible)
      .map(a => ({text:clean(a.innerText || a.textContent || ''), href:(()=>{try{return new URL(a.href, location.href).pathname}catch{return ''}})()}))
      .filter(x => x.text && x.text.length < 70 && /(املاک|اجاره|خرید|فروش|زمین|خانه|ویلا|مسکونی)/.test(x.text))
      .filter((x,i,arr) => arr.findIndex(y => normalize(y.text)===normalize(x.text))===i)
      .slice(0,8);
    let description = '';
    const descHeader=/^(?:توضیحات(?:\s+(?:آگهی|بیشتر))?|شرح آگهی)\s*[:：]?\s*(.*)$/i;
    const descIndex = allLines.findIndex(line => descHeader.test(normalize(line)));
    if (descIndex >= 0) {
      const parts=[];
      const first=normalize(allLines[descIndex]).match(descHeader);
      if(first&&first[1])parts.push(first[1].trim());
      const stopDescription=/^(?:ویژگی.?ها و امکانات|سایر ویژگی.?ها و امکانات|مشخصات|جزئیات|موقعیت|آدرس|قیمت|اطلاعات تماس|مشخصات ملک|یادداشت تنها برای شما قابل دیدن است|گزارش آگهی|بررسی و کارشناسی|زنگ خطرهای قبل از معامله|دسته‌ها|برو به اطلاعات تماس)$/i;
      const inlineJunk=/(?:[۰-۹0-9]{1,3}\s*)?یادداشت تنها برای شما قابل دیدن است|برو به اطلاعات تماس|دسته‌ها\s+دیوار\s+من\s+چت|درباره[ٔ ]*دیوار|دریافت برنامه|اتاق خبر|دیواری شو|پشتیبانی و قو(?:ا|انین)|گزارش آگهی|تصویر\s*[۰-۹0-9]+\s*از\s*[۰-۹0-9]+/i;
      for(let i=descIndex+1;i<allLines.length;i++) {
        let line=allLines[i];
        if(stopDescription.test(normalize(line))) break;
        const marker=line.match(inlineJunk);
        if(marker){const before=line.slice(0,marker.index).trim();if(before)parts.push(before);break;}
        line=line.replace(/با تشکر از\s*(?:سایت\s*)?دیوار/ig,'با تشکر از ققنوس');
        if(/^(?:درباره[ٔ ]*دیوار|دریافت برنامه|اتاق خبر|دیواری شو|پشتیبانی و قو(?:ا|انین)|ثبت آگهی)/i.test(normalize(line)))break;
        if(line)parts.push(line);
      }
      description=parts.join('\n').slice(0,5000).trim();
    }
    const imageSet = new Set();
    const images = [];
    const addImage = raw => {
      if (!raw || typeof raw !== 'string' || raw.startsWith('data:') || raw.startsWith('blob:')) return;
      try {
        const u = new URL(raw, location.href);
        if (!/^https?:$/.test(u.protocol)) return;
        if (/avatar|profile|logo|icon|badge|emoji/i.test(u.href)) return;
        if (imageSet.has(u.href)) return;
        imageSet.add(u.href); images.push(u.href);
      } catch {}
    };
    addImage(document.querySelector('meta[property="og:image"]')?.content || '');
    addImage(document.querySelector('meta[name="twitter:image"]')?.content || '');
    addImage(document.querySelector('meta[itemprop="image"]')?.content || '');
    const imageRoot = root || document;
    const pageMatch=location.pathname.match(/^\/v\/([^/?#]+)/);const currentListingId=pageMatch?decodeURIComponent(pageMatch[1]):'';
    const imageNodes = [...new Set([...imageRoot.querySelectorAll('img'), ...document.querySelectorAll('img')])];
    for (const img of imageNodes) {
      const parentListing=img.closest('a[href*="/v/"]');
      if(parentListing&&currentListingId){
        const linkId=(parentListing.getAttribute('href')||'').match(/\/v\/([^/?#]+)/)?.[1]||'';
        let decoded=linkId;try{decoded=decodeURIComponent(linkId)}catch{}
        if(decoded&&decoded!==currentListingId)continue;
      }
      const width = img.naturalWidth || Number(img.getAttribute('width')) || img.clientWidth || 0;
      const height = img.naturalHeight || Number(img.getAttribute('height')) || img.clientHeight || 0;
      if (width && height && (width < 90 || height < 70)) continue;
      for(const raw of [img.currentSrc,img.src,img.getAttribute('src'),img.getAttribute('data-src'),img.getAttribute('data-lazy-src'),img.getAttribute('data-original'),img.getAttribute('data-full')])addImage(raw||'');
      for(const srcset of [img.getAttribute('srcset')||'',img.getAttribute('data-srcset')||'']) for(const candidate of srcset.split(',').map(v=>v.trim().split(/\s+/)[0]))addImage(candidate);
      const picture=img.closest('picture');if(picture)for(const source of picture.querySelectorAll('source[srcset]'))for(const candidate of String(source.getAttribute('srcset')||'').split(',').map(v=>v.trim().split(/\s+/)[0]))addImage(candidate);
      if (images.length >= 35) break;
    }
    // Some galleries expose photos through CSS background images rather than <img> elements.
    if(images.length<35){
      for(const node of imageRoot.querySelectorAll('[style*="background-image"]')){
        const listingLink=node.closest('a[href*="/v/"]');
        if(listingLink&&currentListingId){const linked=String(listingLink.getAttribute('href')||'').match(/\/v\/([^/?#]+)/)?.[1]||'';let decoded=linked;try{decoded=decodeURIComponent(linked)}catch{}if(decoded&&decoded!==currentListingId)continue;}
        const bg=node.style?.backgroundImage||node.getAttribute('style')||'';for(const m of bg.matchAll(/url\(["']?(.*?)["']?\)/g))addImage(m[1]);
        if(images.length>=35)break;
      }
    }
    // The revealed contact number can be outside listingRoot(), e.g. inside a dialog or tel: link.
    // Scan the currently visible page in addition to the main detail text.
    const phones = [...new Set([...extractPhones(detailText), ...visiblePhoneNumbers()])];
    const attrRows=[];
    for (const row of [...root.querySelectorAll('dl,table tr')]) {
      const txt=clean(row.innerText);
      if (txt && txt.length < 220 && txt.includes('\n')) attrRows.push(txt.replace(/\n+/g, ' — '));
      if (attrRows.length >= 40) break;
    }
    return {
      id, url: location.href.split('#')[0], title,
      location: detectedLocation,
      categories: breadcrumbRows.map(x=>x.text),
      categoryLinks: breadcrumbRows.map(x=>({text:x.text,href:x.href})),
      text: publicDescription, publicDescription, detailText,
      description, priceText: priceLines.join('\n'), attributes: [...new Set(attrRows)],
      imageUrls: images.slice(0,35), phones,
      sellerName: '', sellerClass: 'unknown', tags: classify(publicDescription, location.href),
      agency: looksLikeAgency(detailText), ageDays: inferAgeDays(detailText),
      ageKnown: Number.isFinite(inferAgeDays(detailText)),
      pageTitle: document.title, collectedFrom: 'detail_page', extractedAt: new Date().toISOString()
    };
  }
  let saveWidgetPath = '';
  function syncSaveWidget() {
    const path = location.pathname;
    const detail = isDetailPage();
    const existing = document.getElementById('qoqnus-save-listing-widget');
    if (!detail) { if (existing) existing.remove(); saveWidgetPath = path; return; }
    if (existing && saveWidgetPath === path) return;
    if (existing) existing.remove();
    saveWidgetPath = path;
    const host = document.createElement('div');
    host.id = 'qoqnus-save-listing-widget';
    const shadow = host.attachShadow({mode:'open'});
    shadow.innerHTML = `<style>
      .wrap{font-family:Tahoma,Arial,sans-serif;direction:rtl;position:fixed;z-index:2147483647;bottom:22px;left:22px;width:min(330px,calc(100vw - 36px));box-sizing:border-box}
      .btn{width:100%;border:0;border-radius:12px;background:#176b45;color:#fff;font:700 14px Tahoma,Arial,sans-serif;padding:14px 16px;box-shadow:0 5px 22px #0003;cursor:pointer}
      .btn:disabled{opacity:.65;cursor:wait}.status{display:none;margin-top:7px;padding:9px 11px;border-radius:9px;background:#fff;color:#263238;font:12px/1.8 Tahoma,Arial,sans-serif;box-shadow:0 2px 12px #0002;white-space:pre-wrap}.status.show{display:block}.status.err{color:#a32121}.status.running{display:flex;align-items:center;gap:8px}.status.running:before{content:'';width:10px;height:10px;display:inline-block;border-radius:50%;background:#0284c7;animation:qbeacon 1s infinite;flex:0 0 auto}@keyframes qbeacon{0%{box-shadow:0 0 0 0 #7dd3fc}70%{box-shadow:0 0 0 7px #7dd3fc00}100%{box-shadow:0 0 0 0 #7dd3fc00}}
    </style><div class="wrap"><button type="button" class="btn">ذخیره آگهی در بانک ققنوس</button><div class="status" role="status" aria-live="polite"></div></div>`;
    const btn=shadow.querySelector('button'), status=shadow.querySelector('.status');
    btn.addEventListener('click', async () => {
      btn.disabled=true; btn.textContent='در حال خواندن اطلاعات آگهی…'; status.className='status show running'; status.textContent='در حال استخراج اطلاعات قابل‌مشاهده و ذخیره در پنل…';
      try {
        // Allow the page to finish rendering a number revealed moments before Save was clicked.
        await wait(500);
        const payload=extractDetailPayload();
        if (!payload.id || !payload.title || payload.detailText.length < 30) throw new Error('جزئیات کافی از صفحه خوانده نشد. صفحه آگهی را کامل بارگذاری کن و دوباره بزن.');
        const result=await chrome.runtime.sendMessage({type:'DIVAR_SAVE_CURRENT_LISTING',item:payload});
        if (!result?.ok) throw new Error(result?.error || 'ذخیره آگهی انجام نشد.');
        btn.textContent='✓ ذخیره شد — '+result.code;
        status.className='status show';
        status.textContent=(result.updated?'اطلاعات آگهی در حافظه محلی ققنوس به‌روزرسانی شد.':'آگهی در حافظه محلی ققنوس ذخیره شد.')+'\nکد محلی: '+result.code+'\n'+(result.centralStatus==='synced'&&result.centralId?`شناسه دفتر مرکزی: ${result.centralId}`:'پیش‌نویس: در صف ارسال به دفتر مرکزی است و پس از دریافت شناسه رسمی، به وضعیت عادی تغییر می‌کند.')+'\n'+(result.phoneFound?`شمارهٔ تماس داخل پروندهٔ همین آگهی نگهداری شد؛ دفتر شمارهٔ جداگانه ساخته نشد.`:'شماره هنوز در صفحه قابل‌خواندن نبود؛ پرونده در بایگانی ثبت شد و تا دریافت شماره برای ارسال قابل استفاده نیست.')+'\nدسته‌بندی: '+(result.listingTypeLabel||'نوع نامشخص')+'\nتصاویر پس از تبدیل به WebP به دفتر مرکزی فرستاده می‌شوند.'+(result.contactWarning?'\n'+result.contactWarning:'');
      } catch (err) {
        btn.textContent='ذخیره آگهی در بانک ققنوس'; status.className='status show err'; status.textContent=String(err?.message || err);
      } finally { btn.disabled=false; }
    });
    document.documentElement.appendChild(host);
  }
  try {
    let syncScheduled=false;
    const scheduleSync=()=>{if(syncScheduled)return;syncScheduled=true;setTimeout(()=>{syncScheduled=false;syncSaveWidget();},140);};
    const observer = new MutationObserver(scheduleSync);
    observer.observe(document.documentElement, {childList:true,subtree:true});
    window.addEventListener('popstate',scheduleSync);window.addEventListener('hashchange',scheduleSync);
    for(const method of ['pushState','replaceState']){const original=history[method];history[method]=function(...args){const value=original.apply(this,args);scheduleSync();return value;};}
    syncSaveWidget();
  } catch {}
  chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
    if(msg?.type==='DIVAR_PING') { sendResponse({ok:true,url:location.href}); return; }
    if(msg?.type==='DIVAR_READ_PHONE') { readDetailPhone().then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message||String(e)})); return true; }
    if(msg?.type==='DIVAR_EXTRACT_CURRENT_DETAIL') { try { sendResponse({ok:true,item:extractDetailPayload()}); } catch(e) { sendResponse({ok:false,error:e.message||String(e)}); } return; }
    if(msg?.type==='DIVAR_EXTRACT_DETAIL_READY') { extractReadyDetail(msg.expectedId).then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message||String(e)})); return true; }
  });
})();
