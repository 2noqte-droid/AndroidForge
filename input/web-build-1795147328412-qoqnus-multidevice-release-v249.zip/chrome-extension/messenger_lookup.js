(() => {
  'use strict';
  const normalizeDigits = value => String(value || '').replace(/[۰-۹٠-٩]/g, ch => {
    const fa = '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch);
    return String(fa >= 0 ? fa : '٠١٢٣٤٥٦٧٨٩'.indexOf(ch));
  }).replace(/\D/g, '');
  const normalizeText = value => String(value || '').toLocaleLowerCase('fa-IR')
    .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .replace(/\s+/g, ' ').trim();
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  function findSearchInput() {
    const selectors = [
      'input[type="search"]', 'input[placeholder*="جستجو"]',
      'input[aria-label*="جستجو"]', 'input[aria-label*="Search"]',
      'input[placeholder*="Search"]', 'input[placeholder*="search"]',
      'input[placeholder*="مخاطب"]', 'input[aria-label*="مخاطب"]',
      'input[placeholder*="شماره"]', 'input[aria-label*="شماره"]',
      '[role="search"] input'
    ];
    for (const selector of selectors) {
      try {
        const found = [...document.querySelectorAll(selector)].find(el => visible(el) && !el.disabled && !el.readOnly);
        if (found) return found;
      } catch {}
    }
    return null;
  }
  function setInputValue(input, value) {
    const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function submitSearch(input) {
    const form = input.closest('form');
    if (form) { try { form.requestSubmit(); return; } catch {} }
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
  }
  async function lookup({ phone, name }) {
    const normalizedPhone = normalizeDigits(phone), normalizedName = normalizeText(name);
    if (!/^09\d{9}$/.test(normalizedPhone)) return { ok: false, status: 'lookup-failed', message: 'شماره موبایل معتبر نیست.' };
    let input = findSearchInput();
    if (!input) {
      const searchButton = [...document.querySelectorAll('button,[role="button"]')].find(el => visible(el) && /جستجو|search|مخاطب|شماره/i.test([el.getAttribute('aria-label'), el.getAttribute('title'), el.innerText].filter(Boolean).join(' ')));
      if (searchButton) { searchButton.click(); await wait(500); input = findSearchInput(); }
    }
    if (!input) return { ok: false, status: 'lookup-failed', message: 'کادر جست‌وجوی شماره/مخاطب در این پیام‌رسان پیدا نشد.' };
    try { input.focus(); setInputValue(input, normalizedPhone); submitSearch(input); }
    catch (e) { return { ok: false, status: 'lookup-failed', message: 'شروع جست‌وجو ناموفق بود: ' + String(e?.message || e) }; }
    await wait(1900);
    const bodyText = document.body?.innerText || '', body = normalizeText(bodyText), digits = normalizeDigits(bodyText);
    const emptyPhrases = ['موردی یافت نشد','نتیجه ای یافت نشد','نتیجه‌ای یافت نشد','کاربری پیدا نشد','مخاطبی پیدا نشد','مخاطبی یافت نشد','هیچ نتیجه ای','هیچ نتیجه‌ای','no results','no users found','not found'];
    if (emptyPhrases.some(phrase => body.includes(normalizeText(phrase)))) return { ok: true, status: 'no-account', evidence: 'explicit-empty-state', message: 'پیام‌رسان صریحاً اعلام کرد نتیجه‌ای پیدا نشد.' };
    if (digits.includes(normalizedPhone)) return { ok: true, status: 'has-account', evidence: 'exact-phone-visible', message: 'شمارهٔ دقیق در نتیجهٔ قابل‌مشاهده پیدا شد.' };
    if (normalizedName.length >= 4) {
      const candidates = [...document.querySelectorAll('[role="listitem"], [role="option"], li, article, [class*="contact"], [class*="user"], [class*="search-result"], [class*="SearchResult"]')]
        .filter(el => visible(el) && normalizeText(el.innerText || '').includes(normalizedName));
      if (candidates.length) return { ok: true, status: 'candidate-found', evidence: 'name-match-only', message: 'نام مشابه پیدا شد؛ تطبیق شماره قطعی نیست.' };
    }
    return { ok: false, status: 'lookup-failed', evidence: 'no-conclusive-dom-result', message: 'نتیجه قطعی تشخیص داده نشد؛ این به معنی نداشتن حساب نیست.' };
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type !== 'QOQNUS_MESSENGER_WEB_LOOKUP') return;
    lookup({ phone: msg.phone, name: msg.name }).then(sendResponse).catch(error => sendResponse({ ok: false, status: 'lookup-failed', message: String(error?.message || error) }));
    return true;
  });
})();
