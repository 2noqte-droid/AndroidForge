/* Qoqnus Central Office record uploader. New records use one grouped POST per batch;
 * interrupted legacy staged transfers resume through the original V16 phases.
 * Durable outbox and stable operation IDs preserve retry safety.
 */
(() => {
  'use strict';
  const OUTBOX_KEY = 'qoqnusCentralOutbox';
  const MAP_KEY = 'qoqnusCentralIdMap';
  const ALARM = 'qoqnus-central-record-upload';
  const IMAGE_ALARM = 'qoqnus-central-image-upload';
  const RECEIVE_KEY = 'qoqnusCentralReceiveEnabled';
  const STAGING_KEY = 'qoqnusCentralIncomingStaging';
  const MAX_BATCH = 100;
  const MAX_IMAGE_EDGE = 500;
  const MAX_IMAGE_BYTES = 299999;
  let draining = false;
  // Serialize local outbox mutations so a new save cannot be overwritten by a batch finishing.
  let outboxMutationChain = Promise.resolve();
  function mutateOutbox(fn) { const run = outboxMutationChain.then(fn, fn); outboxMutationChain = run.catch(() => {}); return run; }

  const now = () => Date.now();
  function retryDelay(attempts, base = 15000, cap = 6 * 60 * 60 * 1000) {
    const raw = Math.min(cap, base * Math.pow(2, Math.min(Math.max(0, Number(attempts) || 0), 8)));
    return Math.max(1000, Math.round(raw * (0.8 + Math.random() * 0.4)));
  }
  function isPermanentSyncError(message) {
    return /unauthorized|invalid[_ -]?(device|token|auth|permission)|forbidden|owner_device_only|record_owner|invalid_record|invalid_(title|data|reserve)|version_conflict|operation_id_conflict|image_(must_be_webp|dimensions_limit|size_limit)|webp_image_required|GIF متحرک|GIF معتبر نیست|قالب تصویر پشتیبانی نمی‌شود|حجم تصویر WebP|تصویر محلی قالب معتبر|منبع تصویر قابل تبدیل نیست/i.test(String(message || ''));
  }
  const makeId = () => (crypto.randomUUID ? crypto.randomUUID() : 'qci-' + now().toString(36) + '-' + Math.random().toString(36).slice(2));
  const normalizeKind = value => value === 'customer' ? 'customer' : value === 'file' ? 'file' : 'listing';
  const localKey = (kind, id) => `${normalizeKind(kind)}:${String(id || '')}`;
  const watcherEpochReady = (async () => {
    const state = await chrome.storage.local.get({ qoqnusCentralWatcherSince: 0 });
    const since = Number(state.qoqnusCentralWatcherSince || now());
    if (!state.qoqnusCentralWatcherSince) await chrome.storage.local.set({ qoqnusCentralWatcherSince: since });
    return since;
  })();

  async function getConfig() {
    const s = await chrome.storage.local.get({ qoqnusCentralOffice: null });
    const c = s.qoqnusCentralOffice || {};
    const apiUrl = String(c.apiUrl || c.webAppUrl || c.url || '').trim();
    const token = String(c.deviceToken || c.token || c.accessToken || '').trim();
    const deviceId = String(c.deviceId || c.id || '').trim();
    if (!apiUrl || !token || !deviceId) throw new Error('اتصال دفتر مرکزی گوگل کامل نیست؛ ابتدا دستگاه را جفت‌سازی و اتصال را آزمایش کن.');
    let u; try { u = new URL(apiUrl); } catch { throw new Error('نشانی دفتر مرکزی معتبر نیست.'); }
    if (u.protocol !== 'https:') throw new Error('دفتر مرکزی فقط با HTTPS قابل استفاده است.');
    return { ...c, apiUrl, token, deviceId };
  }

  const SAFE_REPLAY_READ_ACTIONS = new Set([
    'status_public', 'status', 'check_ids', 'get_record_titles',
    'fetch_selected_records', 'get_record_image', 'get_record', 'get_record_transfer_status',
    'get_history', 'get_image', 'sync_state', 'sync_initialize'
  ]);
  const SAFE_REPLAY_OPERATION_ACTIONS = new Set([
    'update_listing_status', 'primary_update', 'approve_field_report', 'delete_record'
  ]);
  const TRANSPORT_RETRY_DELAYS = [1000, 3000]; // 3 total attempts, with jitter.

  function hasStableReplayKey(action, payload) {
    if (SAFE_REPLAY_READ_ACTIONS.has(String(action))) return true;
    if (['reserve_record_ids', 'save_record_titles', 'save_record_data'].includes(String(action))) {
      return Array.isArray(payload?.items) && payload.items.length > 0 &&
        payload.items.every(item => /^[a-zA-Z0-9:_-]{12,180}$/.test(String(item?.operationId || '')));
    }
    if (String(action) === 'save_records_batch') {
      return Array.isArray(payload?.items) && payload.items.length > 0 && payload.items.length <= 20 &&
        payload.items.every(item => /^[a-zA-Z0-9:_-]{12,180}$/.test(String(item?.operationId || '')));
    }
    if (String(action) === 'upload_record_image') {
      return /^[a-zA-Z0-9:_-]{12,180}$/.test(String(payload?.uploadKey || ''));
    }
    if (SAFE_REPLAY_OPERATION_ACTIONS.has(String(action))) {
      return /^[a-zA-Z0-9:_-]{12,180}$/.test(String(payload?.operationId || ''));
    }
    // Pair is replay-safe only when the same persistent clientInstallId is reused.
    // ShitaChi pairDevice_ recovers an active installation by clientInstallId and
    // preserves its deviceId while rotating the token. Never replay Pair without it.
    if (String(action) === 'pair') {
      return /^[a-zA-Z0-9_-]{12,100}$/.test(String(payload?.clientInstallId || '')) &&
        String(payload?.pairingCode || '').trim().length >= 4 &&
        ['chrome-extension', 'android'].includes(String(payload?.deviceType || ''));
    }
    return false;
  }

  function isTransientFetchFailure(error) {
    const message = String(error?.message || error || '');
    return error?.name === 'TypeError' || /Failed to fetch|Load failed|NetworkError|ERR_(NETWORK|CONNECTION|TUNNEL|HTTP2|QUIC)/i.test(message);
  }

  function isTransientHttpStatus(status) {
    return [404, 405, 408, 425, 429, 500, 502, 503, 504].includes(Number(status));
  }

  function isTransientContentBody(raw) {
    const value = String(raw || '');
    return /Sorry, unable to open the file|temporarily unavailable|too many redirects|script\.googleusercontent\.com.*(?:404|not found)|Script function not found|Google Docs encountered an error/i.test(value);
  }

  function transportBackoff(attemptIndex) {
    const base = TRANSPORT_RETRY_DELAYS[Math.min(attemptIndex, TRANSPORT_RETRY_DELAYS.length - 1)];
    return Math.round(base * (0.85 + Math.random() * 0.3));
  }

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  async function api(action, payload = {}, cfg = null, timeoutMs = 90000) {
    const c = cfg || await getConfig();
    const body = { action, deviceId: c.deviceId, deviceToken: c.token, token: c.token, ...payload };
    const serializedBody = JSON.stringify(body);
    const replaySafe = hasStableReplayKey(action, payload);
    const maxAttempts = replaySafe ? TRANSPORT_RETRY_DELAYS.length + 1 : 1;
    let lastTransportError = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), Math.max(5000, Number(timeoutMs) || 90000));
      try {
        const response = await fetch(c.apiUrl, {
          method: 'POST', redirect: 'follow', cache: 'no-store', credentials: 'omit',
          signal: controller.signal,
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: serializedBody
        });
        const raw = await response.text();
        let data;
        try { data = JSON.parse(raw.replace(/^\uFEFF/, '').trim()); }
        catch {
          if (replaySafe && attempt < maxAttempts && (isTransientHttpStatus(response.status) || isTransientContentBody(raw))) {
            lastTransportError = new Error(`پاسخ موقت Google قابل خواندن نبود (HTTP ${response.status || 0}).`);
            await sleep(transportBackoff(attempt - 1));
            continue;
          }
          const finalHost = (() => { try { return new URL(response.url || c.apiUrl).host; } catch { return 'نامشخص'; } })();
          throw new Error(`پاسخ شیتاچی JSON معتبر نیست (HTTP ${response.status || 0}، میزبان پاسخ: ${finalHost}). اگر doPost در Executions با Completed ثبت شده، احتمال اختلال در تحویل پاسخ ContentService وجود دارد؛ پیش‌نویس با همان کلید عملیات حفظ شده است.`);
        }
        if (replaySafe && isTransientHttpStatus(response.status) && attempt < maxAttempts) {
          lastTransportError = new Error(`پاسخ موقت HTTP ${response.status} از مسیر Google.`);
          await sleep(transportBackoff(attempt - 1));
          continue;
        }
        if (!response.ok || data?.ok === false || data?.success === false) {
          const e = String(data?.error || data?.message || `HTTP ${response.status}`);
          throw new Error(e);
        }
        if (attempt > 1) {
          chrome.storage.local.set({ qoqnusCentralLastTransportRecovery: {
            at: now(), action: String(action), attempts: attempt,
            responseHost: (() => { try { return new URL(response.url || c.apiUrl).host; } catch { return ''; } })()
          } }).catch(() => {});
        }
        return data;
      } catch (networkError) {
        if (networkError?.name === 'AbortError') {
          if (replaySafe && attempt < maxAttempts) {
            lastTransportError = new Error(
              `مهلت پاسخ در تلاش ${attempt} از ${maxAttempts} تمام شد.`
            );
            await sleep(transportBackoff(attempt - 1));
            continue;
          }
          if (replaySafe && maxAttempts > 1) {
            const actionName = String(action);
            const detail = actionName === 'pair'
              ? 'همان clientInstallId برای بازیابی همان دستگاه استفاده شد.'
              : 'همان operationId/uploadKey برای جلوگیری از ثبت تکراری حفظ شده است.';
            throw new Error(
              `پاسخ ${actionName} پس از ${attempt} تلاش و پایان مهلت دریافت نشد؛ ${detail} پیش‌نویس و صف محلی حفظ شده‌اند.`
            );
          }
          throw new Error('مهلت پاسخ شیتاچی تمام شد؛ اتصال اینترنت و در دسترس بودن Web App را بررسی کن. پیش‌نویس در صف باقی می‌ماند.');
        }
        const retryable = replaySafe && isTransientFetchFailure(networkError) && attempt < maxAttempts;
        if (retryable) {
          lastTransportError = networkError;
          await sleep(transportBackoff(attempt - 1));
          continue;
        }
        if (isTransientFetchFailure(networkError)) {
          if (replaySafe && maxAttempts > 1) {
            throw new Error(`پاسخ عملیات ${String(action)} پس از ${attempt} تلاش شبکه دریافت نشد (Failed to fetch). ممکن است شیتاچی عملیات را انجام داده باشد؛ تلاش بعدی صف با همان operationId/uploadKey ثابت تکرار می‌شود و رکورد یا تصویر جدید نمی‌سازد. پیش‌نویس محلی حفظ شد.`);
          }
          if (String(action) === 'pair') {
            throw new Error('پاسخ جفت‌سازی دریافت نشد (Failed to fetch). ممکن است دستگاه در شیتاچی ساخته شده باشد؛ برای جلوگیری از دستگاه تکراری، Pair را پشت‌سرهم تکرار نکن و ابتدا برگه Devices را با clientInstallId بررسی کن.');
          }
          throw new Error('درخواست POST به Web App به پاسخ نرسید (Failed to fetch). خطا پیش از دریافت پاسخ شیتاچی رخ داده است؛ اگر doPost در Executions با Completed ثبت شده، احتمالاً پاسخ ContentService در مسیر تغییرمسیر Google از دست رفته است.');
        }
        throw networkError;
      } finally {
        clearTimeout(timer);
      }
    }
    const detail = String(lastTransportError?.message || 'خطای موقت مسیر پاسخ Google');
    throw new Error(`پاسخ ${String(action)} پس از ${maxAttempts} تلاش دریافت نشد: ${detail}. عملیات با شناسه ثابت در صف باقی می‌ماند و بعداً قابل تکرار امن است.`);
  }

  async function probePublicWebApp(apiUrl) {
    const url = String(apiUrl || '').trim();
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[^\s]+\/exec$/i.test(url)) throw new Error('URL باید نشانی کامل Web App و پایان‌یافته به /exec باشد.');
    // Probe through the exact POST transport used by pairing and sync. Apps Script
    // ContentService redirects its output to script.googleusercontent.com; a GET-only
    // preflight can fail independently and must not block a valid POST pairing flow.
    const data = await api('status_public', {}, { apiUrl: url }, 20000);
    if (data?.ok !== true || data?.service !== 'Qoqnus Central') {
      throw new Error(String(data?.message || data?.error || 'پاسخ POST آزمایشی، سرویس رسمی Qoqnus Central را تأیید نکرد.'));
    }
    return { ok: true, version: String(data.version || 'نامشخص'), service: data.service };
  }

  function dataUrlToBlob(dataUrl) {
    const m = String(dataUrl || '').match(/^data:([^;,]+);base64,([\s\S]+)$/i);
    if (!m) throw new Error('تصویر محلی قالب معتبر ندارد.');
    const raw = atob(m[2]);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return new Blob([bytes], { type: m[1] || 'image/jpeg' });
  }

  function countGifFrames(bytes) {
    if (!(bytes instanceof Uint8Array) || bytes.length < 14) return 0;
    const header = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5]);
    if (header !== 'GIF87a' && header !== 'GIF89a') return 0;
    let pos = 13;
    const packed = bytes[10];
    if (packed & 0x80) pos += 3 * (1 << ((packed & 7) + 1));
    if (pos > bytes.length) return 0;
    let frames = 0, blocks = 0;
    const skipSubBlocks = () => {
      while (pos < bytes.length) {
        const size = bytes[pos++];
        if (size === 0) return true;
        pos += size;
        if (pos > bytes.length) return false;
      }
      return false;
    };
    while (pos < bytes.length && blocks++ < 100000) {
      const marker = bytes[pos++];
      if (marker === 0x3B) return frames;
      if (marker === 0x21) {
        if (pos >= bytes.length) return 0;
        pos++; // extension label
        if (!skipSubBlocks()) return 0;
      } else if (marker === 0x2C) {
        frames++;
        if (pos + 9 > bytes.length) return 0;
        const imagePacked = bytes[pos + 8];
        pos += 9;
        if (imagePacked & 0x80) pos += 3 * (1 << ((imagePacked & 7) + 1));
        if (pos >= bytes.length) return 0;
        pos++; // LZW minimum code size
        if (!skipSubBlocks()) return 0;
      } else return 0;
      if (pos > bytes.length) return 0;
    }
    return 0;
  }

  async function toWebpBlob(source) {
    let blob;
    if (typeof source === 'string' && source.startsWith('data:image/')) blob = dataUrlToBlob(source);
    else if (typeof source === 'string' && /^https?:\/\//i.test(source)) {
      const r = await fetch(source, { method: 'GET', credentials: 'omit', cache: 'force-cache' });
      if (!r.ok) throw new Error(`دریافت تصویر ناموفق بود (${r.status}).`);
      blob = await r.blob();
    } else return null;
    if (!/^image\/(jpeg|jpg|png|webp|gif)$/i.test(String(blob.type || ''))) {
      throw new Error('قالب تصویر پشتیبانی نمی‌شود؛ فقط JPG، JPEG، PNG، WebP و GIF مجاز است.');
    }
    if (/^image\/gif$/i.test(String(blob.type || ''))) {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      const frames = countGifFrames(bytes);
      if (frames < 1) throw new Error('فایل GIF معتبر نیست؛ تصویر ارسال نشد.');
      if (frames > 1) throw new Error('GIF متحرک در این نسخه به WebP متحرک تبدیل نمی‌شود؛ برای جلوگیری از حذف فریم‌ها، این تصویر ارسال نشد.');
    }
    const bitmap = await createImageBitmap(blob);
    try {
      const sourceScale = Math.min(1, MAX_IMAGE_EDGE / Math.max(bitmap.width, bitmap.height));
      let w = Math.max(1, Math.round(bitmap.width * sourceScale));
      let h = Math.max(1, Math.round(bitmap.height * sourceScale));
      const qualities = [0.84, 0.76, 0.68, 0.60, 0.52, 0.44, 0.36, 0.30];
      const ctxCanvas = new OffscreenCanvas(w, h);
      let canvas = ctxCanvas;
      let ctx = canvas.getContext('2d', { alpha: true });
      if (!ctx) throw new Error('بوم تبدیل تصویر در دسترس نیست.');
      // Keep the original aspect ratio. If quality reduction is insufficient, progressively
      // reduce both dimensions; never crop, stretch, or create a forced square canvas.
      for (let pass = 0; pass < 7; pass++) {
        if (pass > 0) {
          w = Math.max(1, Math.round(w * 0.85));
          h = Math.max(1, Math.round(h * 0.85));
          canvas = new OffscreenCanvas(w, h);
          ctx = canvas.getContext('2d', { alpha: true });
          if (!ctx) throw new Error('بوم تبدیل تصویر در دسترس نیست.');
        }
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(bitmap, 0, 0, w, h);
        for (const quality of qualities) {
          const out = await canvas.convertToBlob({ type: 'image/webp', quality });
          if (out && out.type === 'image/webp' && out.size > 0 && out.size < 300000) return out;
        }
      }
      throw new Error('حجم تصویر WebP حتی پس از کاهش متناسب ابعاد به کمتر از ۳۰۰٬۰۰۰ بایت نرسید.');
    } finally { try { bitmap.close(); } catch {} }
  }

  async function digestHex(blob) {
    const hash = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
    return [...new Uint8Array(hash)].map(b => b.toString(16).padStart(2, '0')).join('');
  }

  function collectImageSources(record) {
    const out = [];
    const add = v => { if (typeof v === 'string' && (v.startsWith('data:image/') || /^https?:\/\//i.test(v)) && !out.includes(v)) out.push(v); };
    for (const v of (Array.isArray(record.imageDataUrls) ? record.imageDataUrls : [])) add(v);
    for (const v of (Array.isArray(record.images) ? record.images : [])) add(v);
    if (!out.length) for (const v of (Array.isArray(record.imageUrls) ? record.imageUrls : [])) add(v);
    return out.slice(0, 20);
  }

  async function prepareRecord(kind, item) {
    const record = { ...(item.record || {}) };
    const sources = collectImageSources(record);
    const images = [];
    for (const source of sources) {
      try {
        const blob = await toWebpBlob(source);
        if (!blob) throw new Error('منبع تصویر قابل تبدیل نیست؛ تصویر برای بررسی نگه داشته شد.');
        images.push({ blob, sha256: await digestHex(blob), fileName: `qoqnus-${String(item.localId).slice(0, 32)}-${images.length + 1}.webp` });
      } catch (error) {
        // Never omit a failed image silently: do not let the record metadata claim
        // the image was delivered. Keep the durable record draft for user action.
        throw new Error(String(error?.message || error || 'تبدیل تصویر ناموفق بود؛ رکورد ارسال نشد.'));
      }
    }
    delete record.images;
    delete record.imageDataUrls;
    // Keep original public URLs as references; binary payloads are uploaded separately to Drive.
    record.imageUrls = (Array.isArray(record.imageUrls) ? record.imageUrls : []).filter(x => /^https?:\/\//i.test(String(x || ''))).slice(0, 20);
    record.imagesProvided = Math.max(Number(record.imagesProvided || 0), images.length);
    record.sourceKind = kind;
    record.localId = String(item.localId);
    return { kind, localId: String(item.localId), expectedImages: images.length, record, images };
  }

  function extractServerId(response, localId) {
    const r = response || {};
    const candidates = [
      r.idMap?.[localId], r.recordIds?.[localId], r.ids?.[localId], r.mappings?.[localId],
      r.saved?.[localId], r.records?.[localId], r.results?.[localId]
    ];
    for (const v of candidates) {
      const id = typeof v === 'string' ? v : (v?.recordId || v?.serverId || v?.id || v?.record?.id);
      if (id && String(id).trim()) return String(id);
    }
    for (const key of ['items', 'results', 'records', 'savedRecords', 'accepted', 'created']) {
      const list = Array.isArray(r[key]) ? r[key] : [];
      const hit = list.find(x => String(x?.localId || x?.local_id || x?.clientId || '') === String(localId));
      const id = hit?.recordId || hit?.serverId || hit?.centralId || hit?.id || hit?.record?.id;
      if (id && String(id).trim()) return String(id);
    }
    const single = r.recordId || r.serverId || r.centralId;
    return single ? String(single) : '';
  }

  async function updateLocalStatus(kind, id, patch) {
    const key = normalizeKind(kind);
    const data = await chrome.storage.local.get({ queue: [], qoqnusCustomers: [], qoqnusCentralIdMap: {} });
    const map = { ...(data.qoqnusCentralIdMap || {}) };
    const k = localKey(key, id);
    if (patch.centralId) map[k] = String(patch.centralId);
    if (patch.centralId && !patch.centralRecordId) patch = { ...patch, centralRecordId: String(patch.centralId) };
    if (key === 'customer') {
      const arr = Array.isArray(data.qoqnusCustomers) ? data.qoqnusCustomers : [];
      await chrome.storage.local.set({ qoqnusCustomers: arr.map(x => String(x.id) === String(id) ? { ...x, ...patch } : x), qoqnusCentralIdMap: map });
    } else {
      const arr = Array.isArray(data.queue) ? data.queue : [];
      await chrome.storage.local.set({ queue: arr.map(x => String(x.id) === String(id) ? { ...x, ...patch } : x), qoqnusCentralIdMap: map });
    }
  }

  async function enqueue(kind, record, source = 'new-record', options = {}) {
    const normalized = normalizeKind(kind);
    const id = String(record?.id || '').trim();
    if (!id) throw new Error('شناسهٔ محلی رکورد خالی است.');
    const prepared = await mutateOutbox(async () => {
      const st = await chrome.storage.local.get({ qoqnusCentralOutbox: [], qoqnusCentralIdMap: {} });
      const mapKey = localKey(normalized, id);
      const knownId = st.qoqnusCentralIdMap?.[mapKey] || record.centralId || record.centralRecordId;
      if (knownId && !record.centralError) {
        await updateLocalStatus(normalized, id, { centralId: String(knownId), centralStatus: 'synced', centralError: '' });
        return { alreadySynced: true, centralId: String(knownId) };
      }
      const outbox = Array.isArray(st.qoqnusCentralOutbox) ? st.qoqnusCentralOutbox : [];
      const existing = outbox.find(x => x.kind === normalized && String(x.localId) === id);
      const stamp = now();
      const changed = existing && JSON.stringify(existing.record || {}) !== JSON.stringify(record || {});
      const entry = existing ? {
        ...existing,
        opId: changed ? makeId() : existing.opId,
        record,
        updatedAt: stamp,
        attempts: changed ? 0 : Number(existing.attempts || 0),
        nextAttemptAt: 0,
        lastError: changed ? '' : String(existing.lastError || ''),
        status: 'pending',
        // A changed payload reuses the already-reserved central ID but must run title/data again.
        centralRecordId: existing.centralRecordId || existing.centralId || knownId || '',
        lastSuccessfulStage: (changed && (existing.centralRecordId || existing.centralId || knownId)) ? 'id_reserved' : (changed ? 'local_draft' : (existing.lastSuccessfulStage || 'local_draft')),
        stageStatus: changed ? { id: 'success' } : (existing.stageStatus || {})
      } : {
        opId: makeId(), kind: normalized, localId: id, record,
        entityType: normalized,
        destination: normalized === 'customer' ? 'customers' : normalized === 'file' ? 'office-files' : 'qoqnus-files',
        centralRecordId: String(knownId || ''),
        version: Number(record.version || 0),
        lastSuccessfulStage: knownId ? 'id_reserved' : 'local_draft',
        stageStatus: knownId ? { id: 'success' } : {},
        createdAt: stamp, updatedAt: stamp, attempts: 0,
        nextAttemptAt: 0, lastError: '', status: 'pending', source
      };
      const next = existing
        ? outbox.map(x => x.opId === existing.opId ? entry : x)
        : [...outbox, entry];
      await chrome.storage.local.set({ qoqnusCentralOutbox: next });
      await updateLocalStatus(normalized, id, { centralStatus: 'sending', centralError: '', centralQueuedAt: stamp });
      return { entry };
    });
    if (prepared.alreadySynced) return { ok: true, alreadySynced: true, centralId: prepared.centralId };

    // A manager bulk migration commits each item first and drains once at the end.
    // Ordinary record saves attempt ShitaChi immediately after the durable outbox commit.
    if (options.deferDrain === true) return { ok: true, queued: true, deferred: true, opId: prepared.entry?.opId };
    // Do not call drain while holding the outbox mutation lock: drain also mutates that queue.
    // The durable journal is committed first, then ShitaChi is attempted immediately.
    const immediate = await drain();
    const latest = await chrome.storage.local.get({ qoqnusCentralOutbox: [], qoqnusCentralImageOutbox: [] });
    const stillQueued = (latest.qoqnusCentralOutbox || []).some(x => x.kind === normalized && String(x.localId) === id);
    const imagePending = (latest.qoqnusCentralImageOutbox || []).some(x => x.kind === normalized && String(x.localId) === id);
    if (stillQueued) {
      const pendingItem = (latest.qoqnusCentralOutbox || []).find(x => x.kind === normalized && String(x.localId) === id);
      const permanent = pendingItem?.status === 'needs_action';
      await updateLocalStatus(normalized, id, { centralStatus: permanent ? 'needs_action' : 'draft', syncStatus: permanent ? 'needs_action' : 'draft', centralError: String(pendingItem?.lastError || immediate.error || ''), centralQueuedAt: now() });
      if (!permanent) schedule(15000);
      return { ok: true, queued: true, draft: !permanent, needsAction: permanent, opId: prepared.entry?.opId, localOnly: true, centralAttempt: immediate };
    }
    if (imagePending) {
      await updateLocalStatus(normalized, id, { centralStatus: 'text_synced_images_pending', syncStatus: 'pending_images', centralError: '' });
      return { ok: true, queued: true, textSynced: true, imagesPending: true, opId: prepared.entry?.opId, centralAttempt: immediate };
    }
    return { ok: true, queued: false, synced: true, opId: prepared.entry?.opId, centralAttempt: immediate };
  }

  async function persistOutboxStage(opId, patch) {
    return mutateOutbox(async () => {
      const state = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
      const queue = Array.isArray(state.qoqnusCentralOutbox) ? state.qoqnusCentralOutbox : [];
      const next = queue.map(item => String(item.opId) === String(opId) ? { ...item, ...patch, stageStatus: { ...(item.stageStatus || {}), ...(patch.stageStatus || {}) } } : item);
      await chrome.storage.local.set({ qoqnusCentralOutbox: next });
      return next.find(item => String(item.opId) === String(opId)) || null;
    });
  }

  function schedule(delayMs = 15000) {
    try { chrome.alarms.create(ALARM, { when: now() + Math.max(1000, Number(delayMs) || 15000) }); return true; }
    catch { return false; }
  }

  async function receiveEnabled() {
    const state = await chrome.storage.local.get({ [RECEIVE_KEY]: false });
    return state[RECEIVE_KEY] === true;
  }
  async function requireReceiveEnabled() {
    if (!(await receiveEnabled())) throw new Error('دریافت از دفتر مرکزی خاموش است؛ ابتدا کلید «اجازه دریافت» را روشن کن.');
  }

  // Ordinary record creation uses the dedicated save_record action.
  // Initial import remains a separate, user-authorized workflow.
  function prepareTextRecord(kind, item) {
    const record = { ...(item.record || {}) };
    const images = [];
    for (const key of ['images', 'imageDataUrls']) {
      if (Array.isArray(record[key])) images.push(...record[key]);
      delete record[key];
    }
    // Binary images are intentionally deferred to the independent image queue phase.
    // Keep only stable remote references in the central JSON payload.
    record.imageUrls = (Array.isArray(record.imageUrls) ? record.imageUrls : [])
      .filter(x => /^https?:\/\//i.test(String(x || ''))).slice(0, 20);
    record.imagesProvided = Math.max(Number(record.imagesProvided || 0), images.length);
    record.recordKind = kind;
    record.sourceType = kind === 'customer' ? 'manual_customer' : kind === 'file' ? 'office_file' : 'manual_divar_capture';
    record.bookKey = kind === 'customer' ? 'customers' : kind === 'file' ? 'office-files' : 'qoqnus-files';
    record.localId = String(item.localId);
    record.id = String(item.localId);
    delete record.centralId;
    delete record.centralRecordId;
    return record;
  }

  function hasAmbiguousPriorTransport(task) {
    const message = String(task?.lastError || '');
    return /operation_id_conflict|Failed to fetch|Load failed|NetworkError|ERR_(NETWORK|CONNECTION|TUNNEL|HTTP2|QUIC)|پاسخ عملیات .* دریافت نشد|پاسخ .* پس از .* تلاش دریافت نشد|مهلت پاسخ شیتاچی تمام شد|پاسخ شیتاچی JSON معتبر نیست/i.test(message);
  }

  async function reconcileUncertainTransfers(prepared, cfg) {
    const uncertain = prepared.filter(({ task }) => hasAmbiguousPriorTransport(task));
    if (!uncertain.length) return { checked: 0, recovered: 0 };
    let recovered = 0;
    for (let offset = 0; offset < uncertain.length; offset += 20) {
      const chunk = uncertain.slice(offset, offset + 20);
      let response;
      try {
        response = await api('get_record_transfer_status', {
          items: chunk.map(({ task }) => ({
            operationId: String(task.opId), singleOperationId: String(task.opId) + ':single', kind: normalizeKind(task.kind), localId: String(task.localId)
          }))
        }, cfg, 30000);
      } catch (error) {
        // A failed read must never block the existing idempotent write path. The
        // next phase still uses the same operationId and the same local identity.
        if (isTransientFetchFailure(error) || /Failed to fetch|مهلت پاسخ|NetworkError|Load failed/i.test(String(error?.message || error))) {
          continue;
        }
        throw error;
      }
      const results = Array.isArray(response?.results) ? response.results : [];
      for (const { task } of chunk) {
        const result = results.find(item => String(item.localId || '') === String(task.localId) && String(item.kind || '') === normalizeKind(task.kind));
        if (!result || result.ok !== true || result.found !== true) continue;
        const centralId = String(result.centralId || result.recordId || '');
        if (!centralId) continue;
        if (task.centralRecordId && String(task.centralRecordId) !== centralId) {
          throw new Error('central_record_id_mismatch');
        }
        const serverStage = String(result.stage || '');
        if (serverStage === 'save_effects_pending') {
          // The one-shot record payload is already present, but one or more
          // audit/sync/operation effects need replay with the SAME operationId.
          task.centralRecordId = centralId;
          task.transferMode = 'single';
          task.lastSuccessfulStage = 'local_draft';
          task.stageStatus = {};
          await persistOutboxStage(task.opId, {
            centralRecordId: centralId,
            transferMode: 'single',
            lastSuccessfulStage: 'local_draft',
            stageStatus: {},
            reconciledAt: now()
          });
          recovered++;
          continue;
        }
        const serverStageRank = ({ id_reserved: 1, title_saved: 2, data_effects_pending: 2, complete: 3 }[serverStage] ?? 0);
        const localStageRank = ({ local_draft: 0, id_reserved: 1, title_saved: 2, data_saved: 3 }[String(task.lastSuccessfulStage || 'local_draft')] || 0);
        if (serverStage === 'not_reserved') {
          // The local row exists from an older transfer, but this operation has
          // not reserved it yet. Re-run only the reservation, reusing that ID.
          task.centralRecordId = centralId;
          task.lastSuccessfulStage = 'local_draft';
          task.stageStatus = {};
          await persistOutboxStage(task.opId, {
            centralRecordId: centralId,
            lastSuccessfulStage: 'local_draft',
            stageStatus: {},
            reconciledAt: now()
          });
          recovered++;
          continue;
        }
        if (!serverStageRank) continue;
        const chosenRank = Math.max(localStageRank, serverStageRank);
        const chosenStage = ({ 0: 'local_draft', 1: 'id_reserved', 2: 'title_saved', 3: 'data_saved' })[chosenRank];
        const stageStatus = {
          ...(task.stageStatus || {}),
          ...(chosenRank >= 1 ? { id: 'success' } : {}),
          ...(chosenRank >= 2 ? { title: 'success' } : {}),
          ...(chosenRank >= 3 ? { data: 'success' } : {})
        };
        task.centralRecordId = centralId;
        task.lastSuccessfulStage = chosenStage;
        task.stageStatus = stageStatus;
        task.version = Math.max(Number(task.version || 0), Number(result.version || 0));
        task.serverImageManifest = Array.isArray(result.images) ? result.images : [];
        await persistOutboxStage(task.opId, {
          centralRecordId: centralId,
          lastSuccessfulStage: chosenStage,
          version: task.version,
          stageStatus,
          serverExpectedImages: Number(result.expectedImages || 0),
          serverStoredImages: Number(result.storedImages || 0),
          serverImageManifest: task.serverImageManifest,
          reconciledAt: now()
        });
        recovered++;
      }
    }
    return { checked: uncertain.length, recovered };
  }

  async function writeBatch(batch, cfg) {
    const prepared = batch.map(task => ({ task, record: prepareTextRecord(task.kind, task) }));
    await reconcileUncertainTransfers(prepared, cfg);
    const idMap = new Map();
    for (const { task } of prepared) {
      const id = String(task.centralRecordId || task.centralId || '');
      if (id) idMap.set(localKey(task.kind, task.localId), id);
    }
    const rank = stage => ({ local_draft: 0, id_reserved: 1, title_saved: 2, data_saved: 3 }[String(stage || 'local_draft')] || 0);
    const chunksOf = items => { const chunks=[]; for(let i=0;i<items.length;i+=20) chunks.push(items.slice(i,i+20)); return chunks; };

    // New/untouched records use one grouped request instead of three network phases.
    // A task with a known server-side ID or acknowledged V16 phase stays on the
    // staged compatibility path so that partially transferred rows are completed safely.
    const singleTasks = prepared.filter(({task}) =>
      String(task.transferMode || '') === 'single' ||
      (rank(task.lastSuccessfulStage) === 0 && !idMap.get(localKey(task.kind, task.localId)))
    );
    let singleBatchUnsupported = false;
    for (const chunk of chunksOf(singleTasks)) {
      let response;
      try {
        response = await api('save_records_batch', {
          items: chunk.map(({task,record}) => ({
            operationId: String(task.opId) + ':single',
            kind: normalizeKind(task.kind),
            localId: String(task.localId),
            expectedImages: collectImageSources(task.record || {}).length,
            record
          }))
        }, cfg);
      } catch (error) {
        // A 1.6.4 deployment predating this optional batch route returns
        // unknown_action without changing data. Fall back to the compatible V16
        // phases instead of stranding the user's outbox.
        if (/unknown_action/i.test(String(error?.message || error))) {
          singleBatchUnsupported = true;
          break;
        }
        throw error;
      }
      const results = Array.isArray(response.results) ? response.results : [];
      if (results.length !== chunk.length) throw new Error('پاسخ ثبت گروهی آگهی‌ها با تعداد رکوردهای ارسالی مطابقت ندارد.');
      let failed = false;
      for (const entry of chunk) {
        const task = entry.task;
        const result = results.find(x =>
          String(x.operationId || '') === String(task.opId) ||
          (String(x.localId || '') === String(task.localId) && String(x.kind || '') === normalizeKind(task.kind))
        );
        const centralId = String(result?.centralId || result?.recordId || '');
        if (!result || result.ok !== true || !centralId) {
          failed = true;
          continue;
        }
        task.centralRecordId = centralId;
        task.transferMode = 'single';
        task.lastSuccessfulStage = 'data_saved';
        task.version = Number(result.version || 1);
        task.saveResponse = result;
        task.stageStatus = { id: 'success', title: 'success', data: 'success' };
        idMap.set(localKey(task.kind, task.localId), centralId);
        await persistOutboxStage(task.opId, {
          centralRecordId: centralId,
          transferMode: 'single',
          lastSuccessfulStage: 'data_saved',
          version: task.version,
          stageStatus: task.stageStatus
        });
      }
      if (failed) {
        const failedMessages = results.filter(x => x && x.ok === false).map(x => String(x.message || x.error || '')).filter(Boolean);
        throw new Error(failedMessages[0] || 'ثبت یک یا چند آگهی در درخواست گروهی تأیید نشد؛ موارد موفق با همان operationId قابل بازیابی هستند.');
      }
    }

    const staged = singleBatchUnsupported ? prepared : prepared.filter(({task}) => !singleTasks.some(x => x.task === task));
    // Legacy V16 in-progress tasks keep the strict ID -> title -> full-data sequence.
    const needsIds = staged.filter(({task}) => rank(task.lastSuccessfulStage) < 1 || !idMap.get(localKey(task.kind,task.localId)));
    for (const chunk of chunksOf(needsIds)) {
      const response = await api('reserve_record_ids', { items: chunk.map(({task}) => ({ operationId:String(task.opId), kind:normalizeKind(task.kind), localId:String(task.localId), expectedImages:collectImageSources(task.record||{}).length })) }, cfg);
      const results = Array.isArray(response.results) ? response.results : [];
      if (results.length !== chunk.length) throw new Error('پاسخ مرحله رزرو شناسه با تعداد رکوردها مطابقت ندارد.');
      let failed = false;
      for (const result of results) {
        const localId = String(result.localId || ''), task = chunk.find(x => String(x.task.localId) === localId);
        const centralId = String(result.centralId || result.recordId || '');
        if (!task || result.ok !== true || !centralId) { failed = true; continue; }
        idMap.set(localKey(task.task.kind, task.task.localId), centralId);
        task.task.centralRecordId = centralId;
        task.task.lastSuccessfulStage = 'id_reserved';
        task.task.stageStatus = { ...(task.task.stageStatus || {}), id: 'success' };
        await persistOutboxStage(task.task.opId, { centralRecordId: centralId, lastSuccessfulStage: 'id_reserved', stageStatus: { id: 'success' } });
      }
      if (failed) throw new Error('بخشی از شناسه‌ها رزرو نشد؛ موارد موفق با همان شناسه حفظ شدند و مرحله‌های بعدی برای موارد ناموفق متوقف ماند.');
    }

    const needsTitles = staged.filter(({task}) => rank(task.lastSuccessfulStage) < 2);
    for (const chunk of chunksOf(needsTitles)) {
      const response = await api('save_record_titles', { items: chunk.map(({task,record}) => ({ operationId:String(task.opId)+':title', recordId:idMap.get(localKey(task.kind,task.localId)), title:String(record.title||record.subject||record.name||record.address||record.fileTitle||record.customerName||''), subtitle:String(record.city||record.neighborhood||record.phone||record.mobile||record.propertyType||'') })) }, cfg);
      const results = Array.isArray(response.results) ? response.results : [];
      if (results.length !== chunk.length) throw new Error('پاسخ مرحله عنوان با تعداد رکوردها مطابقت ندارد.');
      let failed = false;
      for (const result of results) {
        const task = result.recordId ? chunk.find(x => idMap.get(localKey(x.task.kind, x.task.localId)) === String(result.recordId)) : (results.length === 1 ? chunk[0] : null);
        if (!task || result.ok !== true) { failed = true; continue; }
        task.task.lastSuccessfulStage = 'title_saved';
        task.task.stageStatus = { ...(task.task.stageStatus || {}), title: 'success' };
        await persistOutboxStage(task.task.opId, { lastSuccessfulStage: 'title_saved', stageStatus: { title: 'success' } });
      }
      if (failed) throw new Error('بخشی از عنوان‌ها تأیید نشد؛ مرحله اطلاعات کامل برای موارد ناموفق متوقف شد.');
    }

    const needsData = staged.filter(({task}) => rank(task.lastSuccessfulStage) < 3);
    for (const chunk of chunksOf(needsData)) {
      const response = await api('save_record_data', { items: chunk.map(({task,record}) => ({ operationId:String(task.opId)+':data', recordId:idMap.get(localKey(task.kind,task.localId)), kind:normalizeKind(task.kind), localId:String(task.localId), expectedImages:collectImageSources(task.record||{}).length, record })) }, cfg);
      const results = Array.isArray(response.results) ? response.results : [];
      if (results.length !== chunk.length) throw new Error('پاسخ مرحله اطلاعات کامل با تعداد رکوردها مطابقت ندارد.');
      let failed = false;
      for (const result of results) {
        const task = chunk.find(x => String(x.task.localId) === String(result.localId || ''));
        if (!task || result.ok !== true) { failed = true; continue; }
        task.task.lastSuccessfulStage = 'data_saved';
        task.task.version = Number(result.version || 1);
        task.task.stageStatus = { ...(task.task.stageStatus || {}), data: 'success' };
        await persistOutboxStage(task.task.opId, { lastSuccessfulStage: 'data_saved', version: Number(result.version || 1), stageStatus: { data: 'success' } });
      }
      if (failed) throw new Error('بخشی از اطلاعات کامل رکوردها تأیید نشد؛ تصاویر برای آن موارد ارسال نمی‌شوند.');
    }

    return prepared.map(({task}) => ({
      task,
      centralId: String(task.centralRecordId || idMap.get(localKey(task.kind,task.localId)) || ''),
      version: Number(task.version || 1),
      response: { ownerDeviceId: task.saveResponse?.ownerDeviceId || task.ownerDeviceId || '' }
    }));
  }

  function blobToDataUrl(blob) {
    return blob.arrayBuffer().then(buffer => {
      const bytes = new Uint8Array(buffer);
      let binary = '';
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
      return 'data:' + (blob.type || 'image/webp') + ';base64,' + btoa(binary);
    });
  }
  async function queueImagesForSavedRecord(task, centralId) {
    const sources = collectImageSources(task.record || {});
    if (!sources.length) return 0;
    const state = await chrome.storage.local.get({ qoqnusCentralImageOutbox: [], qoqnusCentralImageDownloadQueue: [] });
    const queue = Array.isArray(state.qoqnusCentralImageOutbox) ? state.qoqnusCentralImageOutbox : [];
    const known = new Set(queue.map(x => String(x.uploadKey || '')));
    const additions = [];
    sources.forEach((source, index) => {
      const uploadKey = `${String(task.opId)}:image:${index + 1}`;
      if (known.has(uploadKey)) return;
      additions.push({ uploadKey, kind: normalizeKind(task.kind), localId: String(task.localId), recordId: String(centralId), imageIndex: index + 1, source, fileName: `qoqnus-${String(task.localId).slice(0, 24)}-${index + 1}.webp`, attempts: 0, nextAttemptAt: 0, status: 'pending', createdAt: now() });
    });
    if (additions.length) {
      await chrome.storage.local.set({ qoqnusCentralImageOutbox: [...queue, ...additions] });
      try { chrome.alarms.create(IMAGE_ALARM, { when: now() + 1200 }); } catch {}
    }
    return additions.length;
  }
  async function updateLocalImageMetadata(task, metadata) {
    const kind = normalizeKind(task.kind);
    const state = await chrome.storage.local.get(kind === 'customer' ? { qoqnusCustomers: [] } : { queue: [] });
    const key = kind === 'customer' ? 'qoqnusCustomers' : 'queue';
    const rows = Array.isArray(state[key]) ? state[key] : [];
    const next = rows.map(row => {
      if (String(row.id) !== String(task.localId)) return row;
      const images = Array.isArray(row.centralImages) ? row.centralImages : [];
      const merged = [...images.filter(x => String(x.uploadKey || '') !== String(metadata.uploadKey)), metadata].sort((a,b)=>Number(a.imageIndex||0)-Number(b.imageIndex||0));
      return { ...row, centralImages: merged, centralImageStatus: 'uploaded', centralImageCount: merged.length,
        version:Math.max(Number(row.version||1),Number(metadata.version||0)),
        centralLastAppliedSeq:Math.max(Number(row.centralLastAppliedSeq||0),Number(metadata.seq||0)),
        centralStatus:'synced', syncStatus:'synced' };
    });
    markRemoteMutation(kind, task.localId);
    await chrome.storage.local.set({ [key]: next });
  }
  async function queueRemoteImageDownloads(kind, localId, recordId, snapshot) {
    const images = Array.isArray(snapshot?.centralImages) ? snapshot.centralImages : [];
    if (!images.length) return 0;
    const state = await chrome.storage.local.get(kind === 'customer' ? { qoqnusCentralImageDownloadQueue: [], qoqnusCustomers: [] } : { qoqnusCentralImageDownloadQueue: [], queue: [] });
    const queue = Array.isArray(state.qoqnusCentralImageDownloadQueue) ? state.qoqnusCentralImageDownloadQueue : [];
    const rows = kind === 'customer' ? state.qoqnusCustomers : state.queue;
    const local = (Array.isArray(rows) ? rows : []).find(x => String(x.id) === String(localId));
    const localImages = Array.isArray(local?.imageDataUrls) ? local.imageDataUrls : [];
    const additions = [];
    let nextQueue = queue.slice();
    for (const image of images) {
      const imageIndex = Number(image.imageIndex || 0), sha256 = String(image.sha256 || '').toLowerCase();
      if (imageIndex < 1 || imageIndex > 20) continue;
      const localData = String(localImages[imageIndex - 1] || (kind === 'customer' && imageIndex === 1 ? local?.profilePhotoWebp || '' : ''));
      let alreadyLocal = false;
      if (localData && sha256) {
        try { alreadyLocal = await digestHex(dataUrlToBlob(localData)) === sha256; } catch { alreadyLocal = false; }
      }
      nextQueue = nextQueue.filter(x => !(String(x.recordId) === String(recordId) && Number(x.imageIndex) === imageIndex && String(x.sha256 || '').toLowerCase() !== sha256));
      if (alreadyLocal) {
        nextQueue = nextQueue.filter(x => !(String(x.recordId) === String(recordId) && Number(x.imageIndex) === imageIndex));
        continue;
      }
      const exists = nextQueue.some(x => String(x.recordId) === String(recordId) && Number(x.imageIndex) === imageIndex && String(x.sha256 || '').toLowerCase() === sha256);
      if (!exists) additions.push({
        kind: normalizeKind(kind), localId: String(localId), recordId: String(recordId), imageIndex,
        sha256, fileName: String(image.fileName || ''), attempts: 0, nextAttemptAt: 0, createdAt: now()
      });
    }
    nextQueue = [...nextQueue, ...additions];
    if (additions.length || nextQueue.length !== queue.length) {
      await chrome.storage.local.set({ qoqnusCentralImageDownloadQueue: nextQueue });
      const phase = await chrome.storage.local.get({ qoqnusCentralReceiveDataPhaseComplete: false });
      if (phase.qoqnusCentralReceiveDataPhaseComplete === true) {
        try { chrome.alarms.create(IMAGE_ALARM, { when: now() + 1800 }); } catch {}
      }
    }
    return additions.length;
  }
  async function saveDownloadedImage(task, dataUrl) {
    const kind = normalizeKind(task.kind);
    const state = await chrome.storage.local.get(kind === 'customer' ? { qoqnusCustomers: [] } : { queue: [] });
    const key = kind === 'customer' ? 'qoqnusCustomers' : 'queue';
    const rows = Array.isArray(state[key]) ? state[key] : [];
    const next = rows.map(row => {
      if (String(row.id) !== String(task.localId)) return row;
      const images = Array.isArray(row.imageDataUrls) ? row.imageDataUrls.slice() : [];
      images[Number(task.imageIndex) - 1] = dataUrl;
      return { ...row, imageDataUrls: images.filter(Boolean), centralImageStatus: 'downloaded' };
    });
    markRemoteMutation(kind, task.localId);
    await chrome.storage.local.set({ [key]: next });
  }

  let imageDraining = false;
  async function drainImages(allowDownloads = false) {
    const receiveAllowed = allowDownloads && await receiveEnabled();
    if (imageDraining) return { ok: true, busy: true };
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return { ok: false, offline: true };
    imageDraining = true;
    let uploaded = 0;
    try {
      const cfg = await getConfig();
      const state = await chrome.storage.local.get({ qoqnusCentralImageOutbox: [], qoqnusCentralImageDownloadQueue: [] });
      let queue = Array.isArray(state.qoqnusCentralImageOutbox) ? state.qoqnusCentralImageOutbox : [];
      const outgoingState = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
      const allRecordDataSent = !Array.isArray(outgoingState.qoqnusCentralOutbox) || outgoingState.qoqnusCentralOutbox.length === 0;
      // Image uploads are a strict final phase: never start while any record payload is pending.
      const pending = allRecordDataSent ? queue.filter(x => x.status !== 'needs_action' && Number(x.nextAttemptAt || 0) <= now()).slice(0, 2) : [];
      for (const task of pending) {
        try {
          const blob = await toWebpBlob(task.source);
          if (!blob) throw new Error('منبع تصویر قابل تبدیل نیست.');
          const sha256 = await digestHex(blob);
          const dataUrl = await blobToDataUrl(blob);
          const response = await api('upload_record_image', {
            recordId: String(task.recordId), imageIndex: Number(task.imageIndex), fileName: String(task.fileName || 'qoqnus-image.webp'),
            uploadKey: String(task.uploadKey), sha256, dataUrl
          }, cfg);
          const metadata = { uploadKey: String(task.uploadKey), imageId: String(response.imageId || response.id || ''), fileId: String(response.fileId || ''), imageIndex: Number(task.imageIndex), fileName: String(response.fileName || task.fileName), mimeType: 'image/webp', sizeBytes: Number(response.sizeBytes || blob.size), sha256, version:Number(response.version||0), seq:Number(response.seq||0), uploadedAt: now() };
          await updateLocalImageMetadata(task, metadata);
          queue = queue.filter(x => x.uploadKey !== task.uploadKey);
          await chrome.storage.local.set({ qoqnusCentralImageOutbox: queue });
          const sameRecordPending = queue.some(x => String(x.recordId) === String(task.recordId));
          if (!sameRecordPending) {
            await updateLocalStatus(task.kind, task.localId, { centralStatus: 'synced', syncStatus: 'synced', centralSyncedAt: now(), centralError: '' });
          }
          uploaded++;
        } catch (error) {
          const message = String(error?.message || error || 'بارگذاری تصویر ناموفق بود.');
          if (/record_deleted|record_not_found|record_not_available/i.test(message)) {
            await applyRemoteTombstones([{ recordId:String(task.recordId), kind:normalizeKind(task.kind), status:'deleted', version:1, seq:0 }]);
            queue = queue.filter(x => String(x.recordId) !== String(task.recordId));
            await chrome.storage.local.set({ qoqnusCentralImageOutbox:queue });
            continue;
          }
          const attempts = Number(task.attempts || 0) + 1;
          const needsAction = /GIF متحرک|قالب تصویر پشتیبانی|منبع تصویر قابل تبدیل|GIF معتبر نیست/i.test(message);
          queue = queue.map(x => x.uploadKey === task.uploadKey ? { ...x, attempts, lastError: message, status: needsAction ? 'needs_action' : 'pending', nextAttemptAt: needsAction ? 0 : now() + retryDelay(attempts, 30000) } : x);
          await chrome.storage.local.set({ qoqnusCentralImageOutbox: queue });
          if (needsAction) await updateLocalStatus(task.kind, task.localId, { centralStatus: 'needs_action', syncStatus: 'needs_action', centralError: message });
        }
      }
      const downloadsState = await chrome.storage.local.get({ qoqnusCentralImageDownloadQueue: [] });
      let downloads = Array.isArray(downloadsState.qoqnusCentralImageDownloadQueue) ? downloadsState.qoqnusCentralImageDownloadQueue : [];
      const receivePhase = await chrome.storage.local.get({ qoqnusCentralReceiveDataPhaseComplete: false });
      const canDownloadImages = receiveAllowed && receivePhase.qoqnusCentralReceiveDataPhaseComplete === true;
      for (const task of (canDownloadImages ? downloads.filter(x => Number(x.nextAttemptAt || 0) <= now()).slice(0, 2) : [])) {
        try {
          const result = await api('get_record_image', { recordId: String(task.recordId), imageIndex: Number(task.imageIndex) }, cfg);
          const dataUrl = String(result.dataUrl || '');
          if (!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/i.test(dataUrl)) throw new Error('پاسخ تصویر مرکزی معتبر نیست.');
          await saveDownloadedImage(task, dataUrl);
          downloads = downloads.filter(x => !(String(x.recordId) === String(task.recordId) && Number(x.imageIndex) === Number(task.imageIndex)));
          await chrome.storage.local.set({ qoqnusCentralImageDownloadQueue: downloads });
        } catch (error) {
          const message = String(error?.message || error || 'دریافت تصویر مرکزی ناموفق بود.');
          if (/record_deleted|record_not_found|record_not_available/i.test(message)) {
            await applyRemoteTombstones([{ recordId:String(task.recordId), kind:normalizeKind(task.kind), status:'deleted', version:1, seq:0 }]);
            downloads = downloads.filter(x => String(x.recordId) !== String(task.recordId));
            await chrome.storage.local.set({ qoqnusCentralImageDownloadQueue:downloads });
            continue;
          }
          const attempts = Number(task.attempts || 0) + 1;
          downloads = downloads.map(x => String(x.recordId) === String(task.recordId) && Number(x.imageIndex) === Number(task.imageIndex) ? { ...x, attempts, lastError: message, nextAttemptAt: now() + Math.min(6 * 60 * 60 * 1000, 30000 * Math.pow(2, Math.min(attempts, 7))) } : x);
          await chrome.storage.local.set({ qoqnusCentralImageDownloadQueue: downloads });
        }
      }
      if (queue.length || downloads.length) {
        const nextAt = [...queue, ...downloads].reduce((min, x) => Math.min(min, Number(x.nextAttemptAt || now() + 30000)), Infinity);
        try { chrome.alarms.create(IMAGE_ALARM, { when: Math.max(now() + 15000, nextAt) }); } catch {}
      }
      await chrome.storage.local.set({ qoqnusCentralLastImageSync: { at: now(), status: (queue.length || downloads.length) ? 'pending' : 'success', uploaded, pending: queue.length + downloads.length, uploadsPending: queue.length, downloadsPending: downloads.length } });
      return { ok: true, uploaded, pending: queue.length + downloads.length, uploadsPending: queue.length, downloadsPending: downloads.length };
    } catch (error) {
      const message = String(error?.message || error || 'اتصال بارگذاری تصاویر برقرار نشد.');
      await chrome.storage.local.set({ qoqnusCentralLastImageSync: { at: now(), status: 'error', error: message } });
      return { ok: false, error: message };
    } finally { imageDraining = false; }
  }

  async function drain() {
    if (draining) return { ok: true, busy: true };
    draining = true;
    try {
      const cfg = await getConfig();
      await drainDeleteOutbox().catch(error => console.warn('Central delete outbox:', error));
      const state = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
      let outbox = Array.isArray(state.qoqnusCentralOutbox) ? state.qoqnusCentralOutbox : [];
      const eligible = outbox.filter(x => x.status !== 'needs_action' && Number(x.nextAttemptAt || 0) <= now());
      // Ordinary saves are independent operations; legacy importId values do not
      // couple their retries or route them through the initial-import workflow.
      const pending = eligible.slice(0, MAX_BATCH);
      if (!pending.length) {
        const nextAt = outbox.reduce((min, x) => Math.min(min, Number(x.nextAttemptAt || Infinity)), Infinity);
        if (Number.isFinite(nextAt)) schedule(Math.max(15000, nextAt - now()));
        const imageResult = outbox.length ? { uploaded: 0, pending: (await chrome.storage.local.get({qoqnusCentralImageOutbox:[]})).qoqnusCentralImageOutbox.length } : await drainImages(false);
        return { ok: true, processed: 0, pending: outbox.length, imagesUploaded: imageResult.uploaded || 0, imagesPending: imageResult.pending || 0 };
      }
      try {
        const saved = await writeBatch(pending, cfg);
        const savedKeys = new Set(saved.map(x => x.task?.opId).filter(Boolean));
        for (const x of saved) {
          const imageCount = collectImageSources(x.task.record || {}).length;
          await queueImagesForSavedRecord(x.task, x.centralId);
          await updateLocalStatus(x.task.kind, x.task.localId, {
            centralId: x.centralId,
            centralStatus: imageCount ? 'text_synced_images_pending' : 'synced',
            centralSyncedAt: imageCount ? 0 : now(),
            centralError: '',
            version: x.version || 1,
            ownerDeviceId: String(x.response?.ownerDeviceId || cfg.deviceId),
            syncStatus: imageCount ? 'pending_images' : 'synced'
          });
        }
        // Re-read the durable queue before writing: a user may have edited/queued records while this batch was in flight.
        outbox = await mutateOutbox(async () => {
          const latestQueueState = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
          const latestQueue = Array.isArray(latestQueueState.qoqnusCentralOutbox) ? latestQueueState.qoqnusCentralOutbox : [];
          const sentByOp = new Map(saved.map(x => [String(x.task?.opId || ''), x.task]));
          const next = latestQueue.map(item => {
            const sentTask = sentByOp.get(String(item.opId || ''));
            if (!sentTask) return item;
            // If the local payload changed during upload, retain it as a new idempotent operation.
            if (Number(item.updatedAt || 0) > Number(sentTask.updatedAt || 0) || JSON.stringify(item.record || {}) !== JSON.stringify(sentTask.record || {})) {
              return { ...item, opId: makeId(), attempts: 0, nextAttemptAt: 0, lastError: '', source: 'changed-during-transfer' };
            }
            return null;
          }).filter(Boolean);
          await chrome.storage.local.set({ qoqnusCentralOutbox: next });
          return next;
        });
        await chrome.storage.local.set({ qoqnusCentralLastSync: { at: now(), status: 'success', saved: saved.length, pending: outbox.length } });
        if (outbox.length) schedule(2500);
        // Finish every record's ID/title/data transfer before starting image uploads.
        const imageResult = outbox.length ? { uploaded: 0, pending: (await chrome.storage.local.get({qoqnusCentralImageOutbox:[]})).qoqnusCentralImageOutbox.length } : await drainImages(false);
        return { ok: true, processed: saved.length, pending: outbox.length, imagesUploaded: imageResult.uploaded || 0, imagesPending: imageResult.pending || 0 };
      } catch (error) {
        const message = String(error?.message || error || 'ارسال به دفتر مرکزی ناموفق بود.');
        const failedKeys = new Set(pending.map(x => x.opId));
        outbox = await mutateOutbox(async () => {
          const latestQueueState = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
          const next = (Array.isArray(latestQueueState.qoqnusCentralOutbox) ? latestQueueState.qoqnusCentralOutbox : []).map(x => {
            if (!failedKeys.has(x.opId)) return x;
            const attempts = Number(x.attempts || 0) + 1;
            const permanent = isPermanentSyncError(message);
            return { ...x, attempts, lastError: message, status: permanent ? 'needs_action' : 'pending', nextAttemptAt: permanent ? 0 : now() + retryDelay(attempts) };
          });
          await chrome.storage.local.set({ qoqnusCentralOutbox: next });
          return next;
        });
        await chrome.storage.local.set({ qoqnusCentralLastSync: { at: now(), status: 'error', error: message, pending: outbox.length } });
        for (const x of pending) {
          const current = outbox.find(item => String(item.opId) === String(x.opId));
          const permanent = current?.status === 'needs_action';
          await updateLocalStatus(x.kind, x.localId, { centralStatus: permanent ? 'needs_action' : 'draft', syncStatus: permanent ? 'needs_action' : 'draft', centralError: message });
        }
        const retryable = outbox.filter(x => pending.some(p => String(p.opId) === String(x.opId)) && x.status !== 'needs_action');
        if (retryable.length) schedule(Math.max(15000, Math.min(...retryable.map(x => Number(x.nextAttemptAt || now() + 30000))) - now()));
        return { ok: false, processed: 0, pending: outbox.length, error: message };
      }
    } catch (error) {
      const message = String(error?.message || error || 'اتصال دفتر مرکزی آماده نیست.');
      const state = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
      if ((state.qoqnusCentralOutbox || []).length) schedule(60000);
      await chrome.storage.local.set({ qoqnusCentralLastSync: { at: now(), status: 'error', error: message, pending: (state.qoqnusCentralOutbox || []).length } });
      return { ok: false, error: message, pending: (state.qoqnusCentralOutbox || []).length };
    } finally { draining = false; }
  }

  async function pair(apiUrl, pairingCode, deviceName = 'افزونه کروم ققنوس') {
    const install = await chrome.storage.local.get({ qoqnusCentralInstallId: '' });
    const clientInstallId = install.qoqnusCentralInstallId || makeId();
    await chrome.storage.local.set({ qoqnusCentralInstallId: clientInstallId });
    const cfg = { apiUrl: String(apiUrl || '').trim() };
    const data = await api('pair', { pairingCode: String(pairingCode || '').trim(), clientInstallId, deviceName: String(deviceName || '').trim(), deviceType: 'chrome-extension' }, cfg);
    const token = String(data.deviceToken || data.token || data.accessToken || data.device?.token || '').trim();
    const deviceId = String(data.deviceId || data.id || data.device?.id || '').trim();
    if (!token || !deviceId) throw new Error('سرور جفت‌سازی را پذیرفت اما شناسه یا توکن دستگاه را برنگرداند.');
    const saved = { apiUrl: cfg.apiUrl, token, deviceToken: token, deviceId, deviceName: String(deviceName || 'افزونه کروم ققنوس'), deviceType: 'chrome-extension', pairedAt: now(), active: true };
    await chrome.storage.local.set({ qoqnusCentralOffice: saved });
    const pending = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
    if ((pending.qoqnusCentralOutbox || []).length) schedule(1200);
    return { ok: true, deviceId, deviceName: saved.deviceName };
  }

  async function status() {
    const cfg = await getConfig();
    const result = await api('status', {}, cfg);
    return { ok: true, status: result };
  }

  const CENTRAL_ONLY_FIELDS = new Set(['centralId','centralRecordId','centralStatus','centralError','centralQueuedAt','centralSyncedAt','ownerDeviceId','version','updatedAt','syncStatus','centralDeleted','centralDeletedAt','centralApplyingRemote','centralConflictId','centralConflictState','centralReportedFingerprint','localImageData','images','imageDataUrls','status','sendStatus','sendProgress','sendError','sendAttempt','lastPlatformAttempt','lastPlatformResult','publishedAt','archivedAt','platformResults','reviewStatus','publicationStatus','approvedAt','rejectedAt']);
  const DELETED_ACK_KEY = 'qoqnusCentralDeletedAck';
  const DELETE_OUTBOX_KEY = 'qoqnusCentralDeleteOutbox';
  const remoteMutationKeys = new Set();
  async function stableOperationId(prefix, value) {
    const bytes = new TextEncoder().encode(String(value || ''));
    const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
    const hex = [...digest].map(x => x.toString(16).padStart(2, '0')).join('');
    return String(prefix || 'op') + ':' + hex;
  }
  async function rememberDeletedCentralId(item) {
    const id = String(item?.recordId || item?.centralId || '').trim();
    if (!id) return;
    const state = await chrome.storage.local.get({ [DELETED_ACK_KEY]: [] });
    const old = Array.isArray(state[DELETED_ACK_KEY]) ? state[DELETED_ACK_KEY] : [];
    const next = old.filter(x => String(x.recordId) !== id);
    next.push({ recordId:id, kind:String(item.kind || ''), version:Math.max(1, Number(item.version || 1)), seq:Math.max(0, Number(item.seq || 0)), status:'deleted', acknowledgedAt:now() });
    await chrome.storage.local.set({ [DELETED_ACK_KEY]: next.slice(-10000) });
  }
  async function removeLocalCentralRecord(kind, localId, centralId = '', acknowledge = false, version = 1, seq = 0) {
    const normalized = normalizeKind(kind), key = normalized === 'customer' ? 'qoqnusCustomers' : 'queue';
    const state = await chrome.storage.local.get({ [key]: [] });
    const rows = Array.isArray(state[key]) ? state[key] : [];
    const found = rows.find(x => String(x.id) === String(localId) || (centralId && String(x.centralId || x.centralRecordId || '') === String(centralId)));
    if (found) markRemoteMutation(normalized, found.id);
    const next = rows.filter(x => !(String(x.id) === String(localId) || (centralId && String(x.centralId || x.centralRecordId || '') === String(centralId))));
    if (next.length !== rows.length) await chrome.storage.local.set({ [key]: next });
    if (centralId && acknowledge === true) await rememberDeletedCentralId({ recordId:centralId, kind:normalized, version, seq });
    return !!found;
  }
  async function applyRemoteTombstones(items = []) {
    const unique = new Map();
    for (const item of items) {
      const id = String(item?.recordId || '').trim();
      if (id && String(item?.status || '') === 'deleted') unique.set(id, item);
    }
    if (!unique.size) return 0;
    const state = await chrome.storage.local.get({ queue:[], qoqnusCustomers:[], qoqnusCentralIncomingStaging:[], qoqnusCentralImageDownloadQueue:[], qoqnusCentralImageOutbox:[], qoqnusCentralOutbox:[] });
    let removed = 0;
    for (const [centralId, item] of unique) {
      const kind = normalizeKind(item.kind);
      const localId = (kind === 'customer' ? state.qoqnusCustomers : state.queue).find(x => String(x.centralId || x.centralRecordId || '') === centralId)?.id;
      if (localId !== undefined) { await removeLocalCentralRecord(kind, localId, centralId, true, item.version, item.seq); removed++; }
      else await rememberDeletedCentralId({ recordId:centralId, kind, version:item.version, seq:item.seq });
    }
    const deletedIds = new Set(unique.keys());
    await chrome.storage.local.set({
      qoqnusCentralIncomingStaging:(state.qoqnusCentralIncomingStaging || []).filter(x => !deletedIds.has(String(x.centralId || ''))),
      qoqnusCentralImageDownloadQueue:(state.qoqnusCentralImageDownloadQueue || []).filter(x => !deletedIds.has(String(x.recordId || ''))),
      qoqnusCentralImageOutbox:(state.qoqnusCentralImageOutbox || []).filter(x => !deletedIds.has(String(x.recordId || ''))),
      qoqnusCentralOutbox:(state.qoqnusCentralOutbox || []).filter(x => !deletedIds.has(String(x.centralRecordId || x.centralId || '')))
    });
    const check = await chrome.storage.local.get({ qoqnusCentralIdCheck:null });
    if (check.qoqnusCentralIdCheck?.changes) {
      const filtered = check.qoqnusCentralIdCheck.changes.filter(x => !deletedIds.has(String(x.recordId || '')));
      await chrome.storage.local.set({ qoqnusCentralIdCheck:{ ...check.qoqnusCentralIdCheck, changes:filtered, count:filtered.length } });
    }
    return removed;
  }
  function markRemoteMutation(kind, id) { const k = localKey(kind, id); remoteMutationKeys.add(k); setTimeout(() => remoteMutationKeys.delete(k), 1200); }
  function businessSignature(record) {
    if (!record || typeof record !== 'object') return '';
    const copy = { ...record };
    for (const key of CENTRAL_ONLY_FIELDS) delete copy[key];
    return JSON.stringify(copy);
  }
  async function watchChangedCollection(kind, oldRows, newRows, idMap, watcherSince) {
    const before = new Map((Array.isArray(oldRows) ? oldRows : []).map(row => [String(row?.id || ''), row]));
    for (const row of (Array.isArray(newRows) ? newRows : [])) {
      const id = String(row?.id || '').trim();
      if (!id) continue;
      const mapKey = localKey(kind, id);
      // A central tombstone is already synchronized state, not a new local edit.
      if (row.centralDeleted === true || row.centralStatus === 'deleted' || row.centralStatus === 'conflict') continue;
      const known = row.centralId || idMap?.[mapKey];
      const previous = before.get(id);
      if (remoteMutationKeys.has(mapKey)) continue;
      if (known) {
        if (row.centralStatus !== 'synced' || String(row.centralId || '') !== String(known)) {
          markRemoteMutation(kind, id);
          await updateLocalStatus(kind, id, { centralId: String(known), centralStatus: 'synced', centralError: '' });
        }
        if (!previous || businessSignature(previous) === businessSignature(row)) continue;
        const changes = {};
        const keys = new Set([...Object.keys(previous || {}), ...Object.keys(row || {})]);
        for (const field of keys) {
          if (CENTRAL_ONLY_FIELDS.has(field)) continue;
          if (JSON.stringify(previous?.[field]) !== JSON.stringify(row?.[field])) changes[field] = row?.[field] === undefined ? null : row[field];
        }
        if (!Object.keys(changes).length) continue;
        try {
          // Every paired active device is allowed to edit; optimistic version checks
          // on ShitaChi prevent a stale offline copy from silently overwriting newer data.
          await submitPrimaryUpdate(kind, id, changes, 'اصلاح اطلاعات از دستگاه مجاز');
        } catch (error) {
          await updateLocalStatus(kind, id, { centralError: String(error?.message || error), centralStatus: 'synced' });
          const oldState = await chrome.storage.local.get({ qoqnusCentralLastOwnershipError: null });
          await chrome.storage.local.set({ qoqnusCentralLastOwnershipError: { at: now(), kind, id, error: String(error?.message || error) } });
        }
        continue;
      }
      if (previous && businessSignature(previous) === businessSignature(row)) continue;
      const recordTime = Math.max(Number(row.createdAt || 0), Number(row.updatedAt || 0), Number(row.manuallySavedAt || 0), Number(row.archivedAt || 0));
      if (recordTime && recordTime < watcherSince) continue;
      // Existing locally stored records are not bulk-uploaded on install. Only a real storage change
      // after this listener is active enters the outbox. Initial migration remains user-authorized.
      await enqueue(kind, row, previous ? 'local-record-update' : 'new-local-record');
    }
  }
  async function getRecordHistory(id) {
    const cfg = await getConfig();
    const found = await getLocalRecord('listing', id).catch(async () => {
      for (const kind of ['file','customer']) { try { return await getLocalRecord(kind, id); } catch {} }
      throw new Error('رکورد مرکزی برای دریافت تاریخچه پیدا نشد.');
    });
    const response = await api('get_history', { recordId: found.centralId }, cfg);
    const items = response.history || response.items || response.records || response.data || [];
    return { ok: true, recordId: found.centralId, history: Array.isArray(items) ? items : [] };
  }

  async function updateListingStatus(id, changes = {}) {
    const cfg = await getConfig();
    const found = await getLocalRecord('listing', id);
    if (Object.prototype.hasOwnProperty.call(changes, 'reviewStatus') && String(found.record.ownerDeviceId || '') !== cfg.deviceId) {
      throw new Error('تأیید یا رد آگهی فقط توسط دستگاه مالک یا مدیر مجاز است.');
    }
    const operationId = 'listing-status:' + makeId();
    const payload = { operationId, recordId: found.centralId, expectedVersion: Number(found.record.version || 1) };
    if (Object.prototype.hasOwnProperty.call(changes, 'reviewStatus')) payload.reviewStatus = String(changes.reviewStatus);
    if (changes.rubika) payload.rubika = changes.rubika;
    if (changes.eitaa) payload.eitaa = changes.eitaa;
    const response = await api('update_listing_status', payload, cfg);
    const publication = { ...(found.record.publication || {}) };
    for (const provider of ['rubika','eitaa']) {
      if (changes[provider]) publication[provider] = {
        ...(publication[provider] || {}), status: String(changes[provider].status || 'pending'),
        deliveryId: String(changes[provider].deliveryId || changes[provider].messageId || changes[provider].postId || ''),
        error: String(changes[provider].error || '')
      };
    }
    const patch = {
      version: Number(response.version || found.record.version || 1),
      reviewStatus: response.reviewStatus || found.record.reviewStatus || 'pending',
      publicationStatus: response.publicationStatus || found.record.publicationStatus || 'pending',
      publication, centralStatus: 'synced', centralError: ''
    };
    await saveLocalRecordPatch('listing', found.record.id, patch);
    return { ok: true, response, eligibleForMainOffice: response.eligibleForMainOffice === true };
  }

  async function handleRemovedCentralRows(kind, oldRows, newRows) {
    const present = new Set((Array.isArray(newRows) ? newRows : []).map(x => String(x?.id || '')));
    const removed = (Array.isArray(oldRows) ? oldRows : []).filter(row => row?.id && !present.has(String(row.id)) && (row.centralId || row.centralRecordId));
    if (!removed.length) return;
    const cfg = await getConfig();
    const normalized = normalizeKind(kind);
    const key = normalized === 'customer' ? 'qoqnusCustomers' : 'queue';
    const current = await chrome.storage.local.get({ [key]: [] });
    let rows = Array.isArray(current[key]) ? current[key] : [];
    for (const row of removed) {
      const id = String(row.id);
      const mapKey = localKey(normalized, id);
      if (remoteMutationKeys.has(mapKey) || rows.some(x => String(x.id) === id)) continue;
      // Temporarily restore while the server confirms or durably queues the tombstone.
      markRemoteMutation(normalized, id);
      rows = [...rows, row];
      await chrome.storage.local.set({ [key]: rows });
      try { await deleteCentralRecord(normalized, id, 'حذف از رابط افزونه توسط دستگاه مجاز'); }
      catch (error) {
        await chrome.storage.local.set({ qoqnusCentralLastDeleteError: { at: now(), kind: normalized, id, error: String(error?.message || error) } });
      }
    }
  }

  async function drainDeleteOutbox() {
    const cfg = await getConfig();
    const state = await chrome.storage.local.get({ [DELETE_OUTBOX_KEY]: [] });
    let queue = Array.isArray(state[DELETE_OUTBOX_KEY]) ? state[DELETE_OUTBOX_KEY] : [];
    let deleted = 0;
    for (const task of queue.filter(x => Number(x.nextAttemptAt || 0) <= now()).slice(0, 25)) {
      try {
        let response;
        try {
          response = await api('delete_record', {
            operationId:String(task.operationId), recordId:String(task.recordId),
            expectedVersion:Math.max(1, Number(task.expectedVersion || 1)),
            description:String(task.reason || 'حذف از دستگاه مجاز')
          }, cfg);
        } catch(error) {
          if(!/record_not_found|record_deleted/i.test(String(error?.message || error))) throw error;
          response={ok:true,recordId:task.recordId,status:'deleted',version:Math.max(1,Number(task.expectedVersion||1)+1),seq:0,alreadyAbsent:true};
        }
        await rememberDeletedCentralId({ recordId:task.recordId, kind:task.kind, version:response.version || task.expectedVersion, seq:response.seq || 0 });
        await removeLocalCentralRecord(task.kind, task.localId, task.recordId, true, response.version || task.expectedVersion + 1, response.seq || 0);
        queue = queue.filter(x => String(x.operationId) !== String(task.operationId));
        deleted++;
      } catch (error) {
        const message = String(error?.message || error || 'حذف مرکزی ناموفق بود.');
        const attempts = Number(task.attempts || 0) + 1;
        const conflict = /version_conflict/i.test(message);
        queue = queue.map(x => String(x.operationId) === String(task.operationId) ? {
          ...x, attempts, lastError:message, status:conflict ? 'conflict' : 'pending',
          nextAttemptAt:conflict ? 0 : now() + retryDelay(attempts, 30000)
        } : x);
        if (conflict) await chrome.storage.local.set({ qoqnusCentralLastDeleteError:{ at:now(), kind:task.kind, localId:task.localId, recordId:task.recordId, error:message, status:'conflict' } });
      }
    }
    await chrome.storage.local.set({ [DELETE_OUTBOX_KEY]:queue });
    if (queue.some(x => x.status !== 'conflict')) schedule(30000);
    return { deleted, pending:queue.length };
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    (async () => {
      const watcherSince = await watcherEpochReady;
      const mapState = await chrome.storage.local.get({ qoqnusCentralIdMap: {} });
      const idMap = mapState.qoqnusCentralIdMap || {};
      if (changes.queue) {
        const oldRows = Array.isArray(changes.queue.oldValue) ? changes.queue.oldValue : [];
        const newRows = Array.isArray(changes.queue.newValue) ? changes.queue.newValue : [];
        await handleRemovedCentralRows('file', oldRows.filter(x => x?.recordKind === 'file' || x?.bookKey === 'office-files' || x?.source === 'office-file'), newRows.filter(x => x?.recordKind === 'file' || x?.bookKey === 'office-files' || x?.source === 'office-file'));
        await handleRemovedCentralRows('listing', oldRows.filter(x => !(x?.recordKind === 'file' || x?.bookKey === 'office-files' || x?.source === 'office-file')), newRows.filter(x => !(x?.recordKind === 'file' || x?.bookKey === 'office-files' || x?.source === 'office-file')));
        for (const row of newRows) {
          const kind = row?.recordKind === 'file' || row?.bookKey === 'office-files' || row?.source === 'office-file' ? 'file' : 'listing';
          await watchChangedCollection(kind, oldRows.filter(x => (x?.recordKind === 'file' || x?.bookKey === 'office-files' || x?.source === 'office-file' ? 'file' : 'listing') === kind), newRows.filter(x => (x?.recordKind === 'file' || x?.bookKey === 'office-files' || x?.source === 'office-file' ? 'file' : 'listing') === kind), idMap, watcherSince);
        }
      }
      if (changes.qoqnusCustomers) {
        await handleRemovedCentralRows('customer', changes.qoqnusCustomers.oldValue, changes.qoqnusCustomers.newValue);
        await watchChangedCollection('customer', changes.qoqnusCustomers.oldValue, changes.qoqnusCustomers.newValue, idMap, watcherSince);
      }
    })().catch(error => {
      const message = String(error?.message || error || 'خطا در صف‌بندی ذخیرهٔ محلی');
      chrome.storage.local.set({ qoqnusCentralLastSync: { at: now(), status: 'error', error: message } }).catch(() => {});
    });
  });


  const isObject = value => !!value && typeof value === 'object' && !Array.isArray(value);
  function parsePayload(value) {
    if (isObject(value)) return value;
    if (typeof value === 'string') {
      try { const parsed = JSON.parse(value); return isObject(parsed) ? parsed : {}; } catch {}
    }
    return {};
  }
  function centralRecordId(change, payload) {
    return String(change?.recordId || payload?.recordId || payload?.centralId ||
      payload?.centralRecordId || payload?.record?.centralId || payload?.current?.centralId || '').trim();
  }
  function changeKind(change, payload) {
    const raw = String(change?.kind || payload?.kind || payload?.recordKind ||
      payload?.record?.recordKind || payload?.current?.recordKind || '').toLowerCase();
    if (raw === 'customer') return 'customer';
    if (raw === 'file' || raw === 'office-file' || raw === 'office_file') return 'file';
    if (raw === 'listing' || raw === 'ad' || raw === 'qoqnus-file' || raw === 'qoqnus-files') return 'listing';
    throw new Error('نوع رکورد در تغییر مرکزی مشخص نیست؛ ACK انجام نشد.');
  }
  function eventIsDelete(change) {
    const event = String(change?.eventType || '').toLowerCase();
    return /delete|deleted|tombstone/.test(event);
  }
  function snapshotFrom(payload) {
    const candidates = [payload.current, payload.record, payload.snapshot, payload.after,
      payload.recordData, payload.data?.current, payload.data?.record];
    return candidates.find(isObject) || null;
  }
  function findLocalByCentral(rows, centralId) {
    return (Array.isArray(rows) ? rows : []).find(row =>
      String(row?.centralId || row?.centralRecordId || '') === String(centralId));
  }
  function stableRemoteLocalId(centralId, rows) {
    let id = `central_${String(centralId).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 100)}`;
    const collision = (Array.isArray(rows) ? rows : []).find(row =>
      String(row?.id || '') === id && String(row?.centralId || row?.centralRecordId || '') !== String(centralId));
    if (collision) id += '_remote';
    return id;
  }
  function decorateRemoteRecord(snapshot, kind, centralId, change, existing, rows) {
    const original = { ...snapshot };
    const sourceLocalId = String(original.localId || original.id || '');
    const localId = existing?.id || stableRemoteLocalId(centralId, rows);
    const version = Math.max(1, Number(change?.version || 0), Number(original.version || 0));
    const merged = { ...(existing || {}), ...original };
    // Preserve local-only image bytes and fields when the server snapshot omits them.
    for (const key of ['images', 'imageDataUrls', 'localImageData', 'localNotes']) {
      if (existing && !Object.prototype.hasOwnProperty.call(original, key) && existing[key] !== undefined) merged[key] = existing[key];
    }
    merged.id = localId;
    merged.localId = existing?.localId || sourceLocalId || localId;
    merged.originLocalId = merged.originLocalId || sourceLocalId || '';
    merged.centralId = centralId;
    merged.centralRecordId = centralId;
    merged.recordKind = kind;
    merged.bookKey = kind === 'customer' ? 'customers' : kind === 'file' ? 'office-files' : 'qoqnus-files';
    merged.ownerDeviceId = String(original.ownerDeviceId || change?.ownerDeviceId || change?.actorDeviceId || '');
    merged.version = version;
    merged.centralLastAppliedSeq = Math.max(Number(existing?.centralLastAppliedSeq || 0), Number(change?.seq || 0));
    merged.updatedAt = original.updatedAt || change?.createdAt || now();
    merged.centralStatus = 'synced';
    merged.syncStatus = 'synced';
    merged.centralError = '';
    if (kind === 'customer') {
      merged.source = merged.source || 'central-customer';
    } else if (kind === 'file') {
      merged.source = 'office-file';
      merged.sourceLabel = merged.sourceLabel || 'فایل دفتری';
    } else {
      merged.source = 'qoqnus-ad';
      merged.sourceLabel = 'آگهی ققنوس';
    }
    return merged;
  }
  // The central Records.status vocabulary is active/deleted. Local sync flags
  // (synced, sending, pending_images, draft...) are transport state, not record state.
  function centralManifestStatus(record) {
    return record?.centralDeleted === true || String(record?.centralStatus || '').toLowerCase() === 'deleted' || String(record?.syncStatus || '').toLowerCase() === 'deleted'
      ? 'deleted' : 'active';
  }

  // Phase 1: exchange only central IDs + versions/status. Never fetch record JSON or images here.
  async function buildLocalIdManifest() {
    const s = await chrome.storage.local.get({ queue: [], qoqnusCustomers: [], qoqnusCentralIdMap: {}, [DELETED_ACK_KEY]: [] });
    const rows = [];
    const seen = new Set();
    const add = (kind, r) => {
      const id = String(r?.centralId || r?.centralRecordId || s.qoqnusCentralIdMap?.[localKey(kind, r?.id)] || '').trim();
      if (!id) return;
      const key = `${kind}:${id}`;
      if (seen.has(key)) return;
      seen.add(key);
      rows.push({ recordId: id, kind, version: Math.max(1, Number(r?.version || 1)), status: centralManifestStatus(r), seq:Math.max(0, Number(r?.centralLastAppliedSeq || 0)) });
    };
    for (const r of (s.queue || [])) add((r?.recordKind === 'file' || r?.bookKey === 'office-files' || r?.source === 'office-file') ? 'file' : 'listing', r);
    for (const r of (s.qoqnusCustomers || [])) add('customer', r);
    for (const tomb of (s[DELETED_ACK_KEY] || [])) {
      const id = String(tomb?.recordId || '').trim();
      if (!id || seen.has(String(tomb.kind || '') + ':' + id)) continue;
      seen.add(String(tomb.kind || '') + ':' + id);
      rows.push({ recordId:id, kind:normalizeKind(tomb.kind), version:Math.max(1,Number(tomb.version||1)), status:'deleted', seq:Math.max(0,Number(tomb.seq||0)) });
    }
    return rows;
  }

  const SYNC_RECORD_EVENT_TYPES = new Set([
    'initial_import', 'record_created', 'record_updated', 'primary_update',
    'field_report_approved', 'delete', 'record_deleted', 'ownership_transferred',
    'listing_status_updated', 'listing_status_changed', 'record_image_added', 'image_uploaded'
  ]);

  async function pullIncrementalChangeLog(cfg) {
    const syncState = await api('sync_state', {}, cfg);
    if (syncState?.initialized !== true) return { initialized:false, syncState };

    const stored = await chrome.storage.local.get({ qoqnusCentralDeltaInbox: {} });
    const pending = stored.qoqnusCentralDeltaInbox && typeof stored.qoqnusCentralDeltaInbox === 'object'
      ? { ...stored.qoqnusCentralDeltaInbox } : {};
    let afterSeq = Math.max(0, Number(syncState.ackedSeq) || 0);
    let pages = 0;
    let hasMore = false;
    let lastServerSeq = Math.max(0, Number(syncState.serverSeq) || 0);

    // Persist each page locally BEFORE acknowledging it. If the browser closes or
    // the ACK response is lost, replaying the page is harmless because seq is stable.
    do {
      const page = await api('pull_changes', { afterSeq, limit:200, metadataOnly:true, clientVersion:'4.5.190-incremental' }, cfg);
      if (!Array.isArray(page?.changes) || !Number.isSafeInteger(Number(page?.nextSeq))) {
        throw new Error('پاسخ دفتر تغییرات شیتاچی معتبر نیست.');
      }
      for (const change of page.changes) {
        const recordId = String(change?.recordId || '').trim();
        const kind = String(change?.kind || '');
        const eventType = String(change?.eventType || '');
        if (!recordId || !['customer','file','listing'].includes(kind) || !SYNC_RECORD_EVENT_TYPES.has(eventType)) continue;
        const seq = Math.max(0, Number(change.seq) || 0);
        const status = String(change.status || (eventType === 'delete' || eventType === 'record_deleted' ? 'deleted' : 'active')) === 'deleted' ? 'deleted' : 'active';
        const next = {
          recordId, kind, version:Math.max(1, Number(change.version) || 1), status,
          updatedAt:String(change.createdAt || ''), ownerDeviceId:String(change.ownerDeviceId || ''),
          changeType:status === 'deleted' ? 'deleted' : 'updated', eventType, seq,
          forceChanged:eventType === 'record_image_added' || eventType === 'image_uploaded'
        };
        const prior = pending[recordId];
        if (!prior || seq >= Number(prior.seq || 0)) pending[recordId] = next;
      }
      await chrome.storage.local.set({ qoqnusCentralDeltaInbox:pending });
      const nextSeq = Number(page.nextSeq);
      if (page.changes.length) {
        const ack = await api('ack_changes', { ackSeq:nextSeq, clientVersion:'4.5.190-incremental' }, cfg);
        if (ack?.ok !== true) throw new Error(String(ack?.error || 'تأیید دریافت تغییرات ناموفق بود.'));
        afterSeq = nextSeq;
      } else if (nextSeq > afterSeq) {
        throw new Error('دفتر تغییرات پاسخ خالی با شماره توالی جلوتر برگرداند؛ برای جلوگیری از رد شدن تغییرات، تأیید متوقف شد.');
      }
      pages++;
      hasMore = page.hasMore === true;
      lastServerSeq = Math.max(lastServerSeq, Number(page.serverSeq) || 0);
      if (hasMore && !page.changes.length) throw new Error('صفحه‌بندی دفتر تغییرات پیشرفت نکرد؛ تغییرات تأیید نشدند.');
    } while (hasMore && pages < 100);

    return { initialized:true, pending, pages, hasMore, afterSeq, serverSeq:lastServerSeq };
  }

  function changeIsStillPending(item, knownMap, ignoredMap, stagedMap) {
    const known = knownMap.get(String(item.recordId));
    const ignoredVersion = Number(ignoredMap.get(String(item.recordId)) || 0);
    if (ignoredVersion >= Number(item.version || 0)) return false;
    const stagedVersion = Number(stagedMap.get(String(item.recordId)) || 0);
    if (stagedVersion >= Number(item.version || 0)) return false;
    if (!known) return true;
    const version = Number(item.version || 1);
    const status = String(item.status || 'active');
    if (Number(item.seq || 0) > 0 && Number(item.seq || 0) <= Number(known.seq || 0)) return false;
    if (version !== Number(known.version || 1) || status !== String(known.status || 'active')) return true;
    return item.forceChanged === true;
  }

  async function centralReviewDecisionOperationId(cfg, item, decision) {
    return stableOperationId('review', String(cfg.deviceId) + ':' + String(item.recordId || item.centralId) + ':' + Number(item.version || 1) + ':' + String(decision));
  }
  async function setAccountReviewDecision(cfg, item, decision) {
    const normalized = decision === 'save' ? 'approved' : decision === 'discard' ? 'rejected' : decision === 'finalArchive' ? 'finalArchived' : String(decision || '');
    const operationId = await centralReviewDecisionOperationId(cfg, item, normalized);
    return api('set_review_decision', { recordId:String(item.recordId || item.centralId), version:Math.max(1, Number(item.version || 1)), decision:normalized, operationId }, cfg);
  }
  async function getAccountReviewDecisions(cfg, recordIds) {
    const ids = [...new Set((recordIds || []).map(x => String(x || '').trim()).filter(Boolean))];
    const decisions = [];
    for (let i = 0; i < ids.length; i += 200) {
      const result = await api('get_review_decisions', { recordIds:ids.slice(i, i + 200), clientVersion:'extension-4.5.190-review' }, cfg);
      if (!Array.isArray(result?.decisions)) throw new Error('فهرست تصمیم‌های مشترک مدیر معتبر نیست.');
      decisions.push(...result.decisions);
    }
    return decisions;
  }
  async function applyAccountReviewDecisions(summary, cfg) {
    const original = Array.isArray(summary?.changes) ? summary.changes : [];
    if (!original.length) return summary;
    const decisions = await getAccountReviewDecisions(cfg, original.map(x => x.recordId));
    const byVersion = new Map(decisions.map(x => [String(x.recordId) + ':' + Number(x.version || 0), x]));
    const rejected = [], approved = [];
    for (const item of original) {
      const decision = byVersion.get(String(item.recordId) + ':' + Number(item.version || 0));
      if (!decision) continue;
      if (decision.decision === 'rejected') rejected.push(item);
      else if (decision.decision === 'approved' || decision.decision === 'finalArchived') approved.push({ ...item, accountDecision:decision.decision });
    }
    if (!rejected.length && !approved.length) return summary;
    if (rejected.length) {
      const state = await chrome.storage.local.get({ qoqnusCentralIgnoredIncoming:[] });
      const rows = [...(state.qoqnusCentralIgnoredIncoming || [])];
      for (const item of rejected) {
        const prior = rows.find(x => String(x.centralId) === String(item.recordId) && Number(x.version || 0) >= Number(item.version || 0));
        if (!prior) rows.push({ centralId:String(item.recordId), kind:String(item.kind), version:Number(item.version || 1), ignoredAt:now(), accountDecision:'rejected' });
      }
      await chrome.storage.local.set({ qoqnusCentralIgnoredIncoming:rows.slice(-5000) });
    }
    const appliedKeys = new Set([...rejected, ...approved].map(x => String(x.recordId) + ':' + Number(x.version || 0)));
    // Keep approved IDs in the persisted permission summary until their full data
    // has been fetched and applied. If the fetch fails, the next check can resume.
    if (approved.length) {
      await fetchSelected(approved.map(x => x.recordId));
      const stagedState = await chrome.storage.local.get({ [STAGING_KEY]:[] });
      const staged = Array.isArray(stagedState[STAGING_KEY]) ? stagedState[STAGING_KEY] : [];
      for (const decision of approved) {
        const item = staged.find(x => String(x.centralId) === String(decision.recordId) && Number(x.version || 0) === Number(decision.version || 0));
        if (item) await decideIncoming(item.stagingId, decision.accountDecision === 'finalArchived' ? 'finalArchive' : 'save', { skipServerDecision:true });
      }
    }
    const next = { ...summary, changes:original.filter(x => !appliedKeys.has(String(x.recordId) + ':' + Number(x.version || 0))) };
    next.count = next.changes.length;
    await chrome.storage.local.set({ qoqnusCentralIdCheck:next });
    return next;
  }

  async function checkIds() {
    await requireReceiveEnabled();
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return { ok:false, offline:true, error:'این دستگاه به اینترنت متصل نیست.' };
    const cfg = await getConfig();
    const knownRecords = await buildLocalIdManifest();
    const knownMap = new Map(knownRecords.map(x => [String(x.recordId), x]));
    const priorState = await chrome.storage.local.get({
      qoqnusCentralIdCheck:null, qoqnusCentralIgnoredIncoming:[],
      qoqnusCentralIncomingStaging:[], qoqnusCentralDeltaInbox:{}
    });
    const ignoredMap = new Map((priorState.qoqnusCentralIgnoredIncoming || []).map(x => [String(x.centralId), Number(x.version || 0)]));
    const stagedMap = new Map((priorState.qoqnusCentralIncomingStaging || []).map(x => [String(x.centralId), Number(x.version || 0)]));
    const sync = await pullIncrementalChangeLog(cfg);
    let mapped = [];
    let bootstrapSeq = null;
    let incremental = sync.initialized === true;

    if (!incremental) {
      // One ID-only baseline scan when this device has never initialized its cursor.
      // Full record JSON and images are still withheld until the manager selects IDs.
      const result = await api('check_ids', { knownRecords, clientVersion:'4.5.186-baseline' }, cfg);
      if (!Array.isArray(result?.changes)) throw new Error('پاسخ فهرست شناسه‌ها معتبر نیست؛ هیچ رکوردی دریافت نشد.');
      bootstrapSeq = Number.isSafeInteger(Number(result.baselineSeq)) ? Number(result.baselineSeq) : 0;
      mapped = result.changes.map(x => ({
        recordId:String(x.recordId || x.id || ''), kind:String(x.kind || ''),
        version:Number(x.version || 1), status:String(x.status || 'active'),
        updatedAt:String(x.updatedAt || ''), ownerDeviceId:String(x.ownerDeviceId || ''),
        changeType:String(x.changeType || 'new'), seq:Math.max(0,Number(x.seq||bootstrapSeq||0)), title:'', subtitle:''
      })).filter(x => x.recordId);
    } else {
      const pending = sync.pending || {};
      for (const item of Object.values(pending)) {
        if (!item?.recordId || !changeIsStillPending(item, knownMap, ignoredMap, stagedMap)) continue;
        mapped.push({
          recordId:String(item.recordId), kind:String(item.kind), version:Number(item.version || 1),
          status:String(item.status || 'active'), updatedAt:String(item.updatedAt || ''),
          ownerDeviceId:String(item.ownerDeviceId || ''),
          changeType:String(item.changeType || 'updated'), eventType:String(item.eventType || ''),
          forceChanged:item.forceChanged === true, seq:Math.max(0,Number(item.seq||0)), title:'', subtitle:''
        });
      }
    }

    // Deletion is not a manager download candidate: it is an authoritative server
    // tombstone and is applied automatically on every authorized device.
    const priorPending = priorState.qoqnusCentralIdCheck?.changes || [];
    const tombstones = [...mapped, ...priorPending].filter(item => String(item?.status || '') === 'deleted');
    await applyRemoteTombstones(tombstones);
    const deletedIds = new Set(tombstones.map(x => String(x.recordId || '')).filter(Boolean));
    mapped = mapped.filter(item => String(item.status || '') !== 'deleted' && !deletedIds.has(String(item.recordId || '')));

    // Apply the same suppression rules to both the bootstrap snapshot and the
    // incremental log: a locally known version, an already staged version, or a
    // manager-discarded version must not be prompted again.
    mapped = mapped.filter(item => changeIsStillPending(item, knownMap, ignoredMap, stagedMap));

    // Keep unprocessed items from the previous manager list. Selecting/fetching a
    // record stages it; accepting it updates the local manifest; discarding it is
    // recorded in qoqnusCentralIgnoredIncoming. Those three states remove it here.
    const combined = new Map();
    for (const item of (priorState.qoqnusCentralIdCheck?.changes || [])) {
      if (!item?.recordId || !changeIsStillPending(item, knownMap, ignoredMap, stagedMap)) continue;
      combined.set(String(item.recordId), { ...item });
    }
    for (const item of mapped) {
      const key = String(item.recordId);
      const old = combined.get(key);
      if (!old || Number(item.version || 0) >= Number(old.version || 0) || item.forceChanged) combined.set(key, item);
    }
    mapped = [...combined.values()];

    // Phase 2: fetch compact titles only; full record JSON remains untouched until manager approval.
    const needTitles = mapped.filter(x => !x.title || !x.subtitle);
    for (let i = 0; i < needTitles.length; i += 100) {
      const chunk = needTitles.slice(i, i + 100);
      const titleResult = await api('get_record_titles', { recordIds:chunk.map(x => x.recordId), clientVersion:'4.5.187-titles' }, cfg);
      const titleMap = new Map((titleResult.titles || []).map(x => [String(x.recordId), x]));
      for (const item of chunk) {
        const title = titleMap.get(item.recordId);
        if (title) { item.title = String(title.title || ''); item.subtitle = String(title.subtitle || ''); }
      }
    }

    const summary = {
      at:now(), status:sync.hasMore ? 'partial' : 'checked', count:mapped.length,
      ignoredCount:Math.max(0, (sync.pending ? Object.keys(sync.pending).length : mapped.length) - mapped.length),
      changes:mapped, knownCount:knownRecords.length, incremental,
      cursor:sync.initialized ? Number(sync.afterSeq || 0) : null,
      pages:sync.pages || 0
    };
    await chrome.storage.local.set({ qoqnusCentralIdCheck:summary });

    if (incremental) {
      // The summary is durable now; the delta inbox can be cleared safely.
      await chrome.storage.local.set({ qoqnusCentralDeltaInbox:{} });
    } else {
      // Bootstrap cursor only after the ID-only baseline and titles were persisted.
      // baselineSeq was sampled before the server's record scan, so concurrent newer
      // edits stay above the cursor and will arrive in the next incremental pull.
      const initialized = await api('sync_initialize', { baselineSeq:bootstrapSeq, clientVersion:'4.5.187-incremental-review' }, cfg);
      if (initialized?.ok !== true) throw new Error(String(initialized?.error || 'آغاز دفتر تغییرات این دستگاه ناموفق بود.'));
    }
    const accountAwareSummary = await applyAccountReviewDecisions(summary, cfg);
    return { ok:true, ...accountAwareSummary, autoApplied:Math.max(0, summary.count-accountAwareSummary.count) };
  }
  async function fetchSelected(recordIds) {
    await requireReceiveEnabled();
    const ids = [...new Set((Array.isArray(recordIds)?recordIds:[]).map(x=>String(x||'').trim()).filter(Boolean))];
    if (!ids.length) return { ok:true, fetched:0, staged:0 };
    if (ids.length > 500) throw new Error('در هر نوبت حداکثر ۵۰۰ رکورد قابل دریافت است.');
    const checkState=await chrome.storage.local.get({qoqnusCentralIdCheck:null});
    const permittedChanges=Array.isArray(checkState.qoqnusCentralIdCheck?.changes)?checkState.qoqnusCentralIdCheck.changes:[];const permitted=new Set(permittedChanges.map(x=>String(x.recordId||'')));const changeById=new Map(permittedChanges.map(x=>[String(x.recordId||''),x]));
    const unauthorized=ids.filter(id=>!permitted.has(id));
    if(unauthorized.length) throw new Error('فقط شناسه‌هایی که در آخرین بررسی دستی نمایش داده شده‌اند قابل دریافت هستند. ابتدا شناسه‌ها را دوباره بررسی کن.');
    const cfg = await getConfig();
    // A fresh incoming data phase invalidates any previous image-phase permission.
    await chrome.storage.local.set({ qoqnusCentralReceiveDataPhaseComplete:false, qoqnusCentralReceiveBatch:{startedAt:now(),requested:ids.length,completed:0,status:'fetching-record-data'} });
    const records=[];
    // Server limit is 20 records per request. Finish every selected record's text data before images.
    for(let i=0;i<ids.length;i+=20){
      const chunk=ids.slice(i,i+20);
      const result=await api('fetch_selected_records',{recordIds:chunk,confirmedByManager:true,clientVersion:'4.5.172-staged-incoming'},cfg);
      if(!Array.isArray(result?.records)) throw new Error('پاسخ اطلاعات رکوردها معتبر نیست؛ مرحله دریافت تصاویر آغاز نشد.');
      records.push(...result.records);
      await chrome.storage.local.set({qoqnusCentralReceiveBatch:{startedAt:now(),requested:ids.length,completed:records.length,status:'fetching-record-data'}});
    }
    const state = await chrome.storage.local.get({ [STAGING_KEY]: [] });
    const staging = Array.isArray(state[STAGING_KEY]) ? state[STAGING_KEY] : [];
    const byId = new Map(staging.map(x => [String(x.centralId), x]));
    let staged = 0;
    for (const item of records) {
      const centralId=String(item.recordId || item.id || '');
      const kind=String(item.kind || '');
      if (!centralId || !['customer','file','listing'].includes(kind)) continue;
      const record=item.record && typeof item.record==='object' ? item.record : {};
      const existing=byId.get(centralId), manifestChange=changeById.get(centralId)||{};
      byId.set(centralId, {
        ...(existing || {}), stagingId: existing?.stagingId || makeId(), centralId, kind,
        version:Number(item.version||record.version||1), status:String(item.status||'active'), seq:Math.max(Number(existing?.seq||0),Number(manifestChange.seq||0)),
        ownerDeviceId:String(item.ownerDeviceId||record.ownerDeviceId||''),
        updatedAt:item.updatedAt||now(), record, stagedAt:existing?.stagedAt||now(), decision:'pending'
      });
      staged++;
    }
    const next=[...byId.values()];
    await chrome.storage.local.set({ [STAGING_KEY]:next, qoqnusCentralLastSelectedFetch:{at:now(),status:'staged',requested:ids.length,fetched:records.length,staged}, qoqnusCentralReceiveDataPhaseComplete:true, qoqnusCentralReceiveBatch:{startedAt:now(),completedAt:now(),requested:ids.length,completed:records.length,status:'record-data-complete-images-deferred'} });
    const imageState=await chrome.storage.local.get({qoqnusCentralImageDownloadQueue:[]});
    if((imageState.qoqnusCentralImageDownloadQueue||[]).length) { try { chrome.alarms.create(IMAGE_ALARM,{when:now()+3000}); } catch {} }
    return {ok:true,requested:ids.length,fetched:records.length,staged,pending:next.length,imagesDeferred:true};
  }

  async function bulkQueueLegacy() {
    const state=await chrome.storage.local.get({queue:[],qoqnusCustomers:[],qoqnusCentralOutbox:[],qoqnusCentralIdMap:{}});
    const queued=new Set((state.qoqnusCentralOutbox||[]).map(x=>localKey(x.kind,x.localId)));
    let added=0,already=0;
    const candidates=[];
    for(const row of (state.queue||[])) {
      const kind=(row?.recordKind==='file'||row?.bookKey==='office-files'||row?.source==='office-file')?'file':'listing';
      const known=row?.centralId||row?.centralRecordId||state.qoqnusCentralIdMap?.[localKey(kind,row?.id)];
      if(!row?.id||known){already++;continue;}
      candidates.push({kind,row});
    }
    for(const row of (state.qoqnusCustomers||[])) {
      const known=row?.centralId||row?.centralRecordId||state.qoqnusCentralIdMap?.[localKey('customer',row?.id)];
      if(!row?.id||known){already++;continue;}
      candidates.push({kind:'customer',row});
    }
    for(const item of candidates) {
      const key=localKey(item.kind,item.row.id);
      if(queued.has(key)){already++;continue;}
      await enqueue(item.kind,item.row,'manager-legacy-bulk',{deferDrain:true});queued.add(key);added++;
    }
    const transfer=added?await drain():{ok:true,processed:0,pending:0};
    return {ok:true,queued:added,already,pending:(await chrome.storage.local.get({qoqnusCentralOutbox:[]})).qoqnusCentralOutbox.length,transfer};
  }

  async function listFinalArchive() {
    const s=await chrome.storage.local.get({queue:[],qoqnusCustomers:[]});
    const queue=(s.queue||[]).filter(x=>x?.finalArchived===true).map(x=>({...x,_kind:x.recordKind==='file'||x.bookKey==='office-files'?'file':'listing'}));
    const customers=(s.qoqnusCustomers||[]).filter(x=>x?.finalArchived===true).map(x=>({...x,_kind:'customer'}));
    return [...queue,...customers].sort((a,b)=>Number(b.centralReceivedAt||b.updatedAt||b.createdAt||0)-Number(a.centralReceivedAt||a.updatedAt||a.createdAt||0));
  }
  async function restoreFinalArchive(id,kind) {
    const normalized=normalizeKind(kind),key=normalized==='customer'?'qoqnusCustomers':'queue';
    const s=await chrome.storage.local.get({[key]:[]});
    const rows=Array.isArray(s[key])?s[key]:[];let found=false;
    const next=rows.map(x=>{if(String(x.id)!==String(id))return x;found=true;return {...x,finalArchived:false,finalArchiveRestoredAt:now()};});
    if(!found)throw new Error('رکورد بایگانی نهایی پیدا نشد.');
    await chrome.storage.local.set({[key]:next});
    return {ok:true,restored:true};
  }

  async function decideIncoming(stagingId, decision, options = {}) {
    const state=await chrome.storage.local.get({ [STAGING_KEY]:[], queue:[], qoqnusCustomers:[], qoqnusCentralIdMap:{} });
    const staging=Array.isArray(state[STAGING_KEY])?state[STAGING_KEY]:[];
    const item=staging.find(x=>String(x.stagingId)===String(stagingId));
    if(!item) throw new Error('رکورد دریافتی در صندوق بررسی پیدا نشد.');
    if(!['save','discard','finalArchive'].includes(decision)) throw new Error('تصمیم مدیر معتبر نیست.');
    if(options.skipServerDecision!==true){const cfg=await getConfig();await setAccountReviewDecision(cfg,{recordId:item.centralId,version:item.version},decision);}
    const rest=staging.filter(x=>String(x.stagingId)!==String(stagingId));
    if(decision==='discard') {
      const ignoredState=await chrome.storage.local.get({qoqnusCentralIgnoredIncoming:[]});
      const ignored=[...(ignoredState.qoqnusCentralIgnoredIncoming||[]).filter(x=>String(x.centralId)!==String(item.centralId)),{centralId:item.centralId,kind:item.kind,ignoredAt:now(),version:item.version}].slice(-1000);
      await chrome.storage.local.set({[STAGING_KEY]:rest,qoqnusCentralIgnoredIncoming:ignored});
      return {ok:true,decision:'discarded'};
    }
    const kind=normalizeKind(item.kind), customer=kind==='customer';
    const key=customer?'qoqnusCustomers':'queue';
    const rows=Array.isArray(state[key])?state[key]:[];
    const existing=rows.find(x=>String(x.centralId||x.centralRecordId||'')===String(item.centralId));
    // If this central ID already exists locally, apply the accepted newer snapshot
    // in place and preserve its local ID. Never create a second row for the same ID.
    const decorated=decorateRemoteRecord(item.record,kind,item.centralId,{version:item.version,ownerDeviceId:item.ownerDeviceId,createdAt:item.updatedAt,seq:item.seq},existing,rows);
    if(decision==='finalArchive') decorated.finalArchived=true;
    else decorated.finalArchived=false;
    decorated.centralReceivedAt=now();
    decorated.centralReceiveDecision=decision;
    const nextRows=existing?rows.map(x=>String(x.id)===String(existing.id)?decorated:x):[...rows,decorated];
    const map={...(state.qoqnusCentralIdMap||{}),[localKey(kind,decorated.id)]:String(item.centralId)};
    markRemoteMutation(kind,decorated.id);
    await chrome.storage.local.set({[key]:nextRows,qoqnusCentralIdMap:map,[STAGING_KEY]:rest});
    await queueRemoteImageDownloads(kind,decorated.id,String(item.centralId),decorated);
    return {ok:true,decision:decision==='save'?'saved':'finalArchived',localId:decorated.id};
  }

  async function syncNow() {
    return drain(); // Outgoing only. Incoming is a separate, manager-authorized workflow.
  }

  // Stage 5: explicit ownership-aware mutation workflow. The server remains authoritative.
  function normalizePatchObject(value) {
    if (!isObject(value)) throw new Error('تغییرات ارسالی باید یک شیء معتبر باشند.');
    const entries = Object.entries(value).filter(([key]) => !['id','localId','centralId','centralRecordId','ownerDeviceId','version','createdAt','recordKind','syncStatus','centralStatus'].includes(key));
    if (!entries.length) throw new Error('هیچ فیلد قابل‌اصلاحی ارسال نشده است.');
    if (entries.length > 80) throw new Error('تعداد فیلدهای اصلاحی بیش از حد مجاز است.');
    return Object.fromEntries(entries);
  }
  async function getLocalRecord(kind, id) {
    const normalized = normalizeKind(kind);
    const state = await chrome.storage.local.get(normalized === 'customer' ? { qoqnusCustomers: [] } : { queue: [] });
    const rows = normalized === 'customer' ? state.qoqnusCustomers : state.queue;
    const record = (Array.isArray(rows) ? rows : []).find(x => String(x.id) === String(id) || String(x.centralId || x.centralRecordId || '') === String(id));
    if (!record) throw new Error('رکورد محلی پیدا نشد.');
    const centralId = String(record.centralId || record.centralRecordId || '');
    if (!centralId) throw new Error('این رکورد هنوز شناسه مرکزی ندارد؛ ابتدا ثبت مرکزی آن تکمیل شود.');
    return { normalized, record, centralId };
  }
  async function saveLocalRecordPatch(kind, localId, patch) {
    const normalized = normalizeKind(kind);
    const state = await chrome.storage.local.get(normalized === 'customer' ? { qoqnusCustomers: [] } : { queue: [] });
    const key = normalized === 'customer' ? 'qoqnusCustomers' : 'queue';
    const rows = Array.isArray(state[key]) ? state[key] : [];
    let found = false;
    const next = rows.map(row => {
      if (String(row.id) !== String(localId)) return row;
      found = true;
      return { ...row, ...patch };
    });
    if (!found) throw new Error('رکورد برای ذخیره تغییرات محلی پیدا نشد.');
    markRemoteMutation(normalized, localId);
    await chrome.storage.local.set({ [key]: next });
  }
  async function submitPrimaryUpdate(kind, id, changes, reason = '') {
    const cfg = await getConfig();
    const found = await getLocalRecord(kind, id);
    if (found.record.centralDeleted || found.record.centralStatus === 'deleted') throw new Error('رکورد حذف‌شده قابل اصلاح نیست.');
    const patch = normalizePatchObject(changes);
    const baseVersion = Number(found.record.version || 1);
    const operationId = await stableOperationId('primary', cfg.deviceId + ':' + found.centralId + ':' + baseVersion + ':' + JSON.stringify(patch));
    let response;
    try {
      response = await api('primary_update', {
        operationId, recordId: found.centralId, expectedVersion: Number(found.record.version || 1),
        changes: patch, fields: patch, changedFields: Object.keys(patch),
        record: { ...found.record, ...patch }, reason: String(reason || '').slice(0, 1000)
      }, cfg);
    } catch (error) {
      const message=String(error?.message||error);
      if (/record_deleted|record_not_found/i.test(message)) {
        await applyRemoteTombstones([{ recordId:found.centralId, kind:found.normalized, status:'deleted', version:Number(found.record.version || 1) + 1, seq:0 }]);
        return { ok:true, deleted:true, recordId:found.centralId, message:'این رکورد قبلاً از دستگاه دیگری حذف شده بود؛ نسخه محلی و صف‌های آن پاک شد.' };
      }
      if (/version_conflict/i.test(message)) {
        const reportOperationId=await stableOperationId('conflict-report',cfg.deviceId+':'+found.centralId+':'+baseVersion+':'+JSON.stringify(patch));
        const updates=Object.entries(patch).map(([fieldName,newValue])=>({fieldName,newValue}));
        const report=await api('add_field_report',{recordId:found.centralId,operationId:reportOperationId,updates,actorName:cfg.deviceName||'افزونه ققنوس',description:'تغییر هم‌زمان یا ویرایش بر مبنای نسخه قدیمی؛ نیازمند تأیید مدیر'},cfg);
        const reportsState=await chrome.storage.local.get({qoqnusCentralFieldReports:[]});
        const reports=Array.isArray(reportsState.qoqnusCentralFieldReports)?reportsState.qoqnusCentralFieldReports:[];
        await chrome.storage.local.set({qoqnusCentralFieldReports:[...reports.filter(x=>String(x.reportId)!==reportOperationId),{reportId:reportOperationId,serverReportId:report.reports?.[0]?.historyId||report.reportId||reportOperationId,recordId:found.centralId,kind:found.normalized,localId:found.record.id,ownerDeviceId:String(found.record.ownerDeviceId||''),baseVersion,updates,status:'pending',submittedAt:now(),reason:'version_conflict'}]});
        await saveLocalRecordPatch(found.normalized,found.record.id,{centralStatus:'reported',centralError:'version_conflict_reported',centralReportedFingerprint:JSON.stringify(patch)});
        return {ok:true,reported:true,recordId:found.centralId,reportId:reportOperationId,message:'نسخه مرکزی هم‌زمان تغییر کرده بود؛ تغییرات این دستگاه به‌صورت درخواست اصلاح ثبت شد و برای جلوگیری از ارسال تکراری متوقف شد.'};
      }
      throw error;
    }
    const version = Number(response.version || response.currentVersion || (Number(found.record.version || 1) + 1));
    await saveLocalRecordPatch(found.normalized, found.record.id, { ...patch, version, updatedAt: now(), centralLastAppliedSeq:Math.max(Number(found.record.centralLastAppliedSeq||0),Number(response.seq||0)), centralStatus: 'synced', centralError: '' });
    return { ok: true, operationId, recordId: found.centralId, version, response };
  }
  async function submitFieldReport(kind, id, changes, reason = '') {
    const cfg = await getConfig();
    const found = await getLocalRecord(kind, id);
    const owner = String(found.record.ownerDeviceId || '');
    if (!owner) throw new Error('مالک این رکورد در اطلاعات محلی مشخص نیست؛ دریافت snapshot مرکزی لازم است.');
    if (owner === cfg.deviceId) throw new Error('این دستگاه مالک رکورد است؛ از مسیر اصلاح مستقیم مالک استفاده کن.');
    const patch = normalizePatchObject(changes);
    const reportId = 'field:' + makeId();
    const request = {
      reportId, recordId: found.centralId, baseVersion: Number(found.record.version || 1),
      changedFields: patch, proposedChanges: patch, changes: patch, fields: patch, reason: String(reason || '').slice(0, 1000),
      actorDeviceId: cfg.deviceId, ownerDeviceId: owner, createdAt: now()
    };
    const response = await api('add_field_report', request, cfg);
    const reportsState = await chrome.storage.local.get({ qoqnusCentralFieldReports: [] });
    const reports = Array.isArray(reportsState.qoqnusCentralFieldReports) ? reportsState.qoqnusCentralFieldReports : [];
    await chrome.storage.local.set({ qoqnusCentralFieldReports: [...reports.filter(x => x.reportId !== reportId), { ...request, serverReportId: response.reportId || response.id || reportId, status: response.status || 'pending', submittedAt: now() }] });
    return { ok: true, reportId: response.reportId || response.id || reportId, status: response.status || 'pending', response };
  }
  async function reviewFieldReport(reportId, approved, note = '') {
    const cfg = await getConfig();
    const state = await chrome.storage.local.get({ qoqnusCentralFieldReports: [] });
    const local = (state.qoqnusCentralFieldReports || []).find(x => String(x.serverReportId || x.reportId) === String(reportId));
    if (local && String(local.ownerDeviceId || '') && String(local.ownerDeviceId) !== cfg.deviceId) throw new Error('فقط مالک رکورد یا مدیر مجاز به بررسی درخواست است.');
    const response = await api('approve_field_report', {
      reportId: String(reportId), approved: !!approved, decision: approved ? 'approve' : 'reject',
      operationId: 'review:' + makeId(), note: String(note || '').slice(0, 1000)
    }, cfg);
    const reports = (state.qoqnusCentralFieldReports || []).map(x => String(x.serverReportId || x.reportId) === String(reportId) ? { ...x, status: approved ? 'approved' : 'rejected', reviewedAt: now(), reviewResponse: response } : x);
    await chrome.storage.local.set({ qoqnusCentralFieldReports: reports });
    return { ok: true, response };
  }
  async function deleteCentralRecord(kind, id, reason = '') {
    const cfg = await getConfig();
    const found = await getLocalRecord(kind, id);
    if (found.record.centralDeleted || found.record.centralStatus === 'deleted') return { ok:true, duplicate:true };
    const expectedVersion = Math.max(1, Number(found.record.version || 1));
    const operationId = await stableOperationId('delete', cfg.deviceId + ':' + found.centralId + ':' + expectedVersion);
    const task = { operationId, kind:found.normalized, localId:String(found.record.id), recordId:found.centralId, expectedVersion, reason:String(reason || 'حذف از دستگاه مجاز').slice(0,1000), attempts:0, nextAttemptAt:0, status:'pending', createdAt:now() };
    try {
      let response;
      try { response = await api('delete_record', { operationId, recordId:found.centralId, expectedVersion, reason:task.reason }, cfg); }
      catch(error) { if(!/record_not_found|record_deleted/i.test(String(error?.message||error)))throw error; response={ok:true,recordId:found.centralId,status:'deleted',version:expectedVersion+1,seq:0,alreadyAbsent:true}; }
      await rememberDeletedCentralId({ recordId:found.centralId, kind:found.normalized, version:response.version || expectedVersion + 1, seq:response.seq || 0 });
      await removeLocalCentralRecord(found.normalized, found.record.id, found.centralId, true, response.version || expectedVersion + 1, response.seq || 0);
      return { ok:true, operationId, response };
    } catch (error) {
      if (/version_conflict|record_deleted|record_not_found|operation_id_conflict/i.test(String(error?.message || error))) throw error;
      const state = await chrome.storage.local.get({ [DELETE_OUTBOX_KEY]:[] });
      const queue = Array.isArray(state[DELETE_OUTBOX_KEY]) ? state[DELETE_OUTBOX_KEY] : [];
      if (!queue.some(x => String(x.operationId) === operationId)) await chrome.storage.local.set({ [DELETE_OUTBOX_KEY]:[...queue, task] });
      await removeLocalCentralRecord(found.normalized, found.record.id, found.centralId);
      schedule(15000);
      return { ok:true, queued:true, operationId, error:String(error?.message || error) };
    }
  }


  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === 'QOQNUS_CENTRAL_GET_HISTORY') { getRecordHistory(msg.id).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_UPDATE_LISTING_STATUS') { updateListingStatus(msg.id, msg.changes || {}).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_RETRY_IMAGES') { drainImages(true).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_PRIMARY_UPDATE') { submitPrimaryUpdate(msg.kind, msg.id, msg.changes, msg.reason).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_FIELD_REPORT') { submitFieldReport(msg.kind, msg.id, msg.changes, msg.reason).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_REVIEW_FIELD_REPORT') { reviewFieldReport(msg.reportId, msg.approved, msg.note).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_DELETE_RECORD') { deleteCentralRecord(msg.kind, msg.id, msg.reason).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_PROBE') { probePublicWebApp(msg.apiUrl).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_PAIR') { pair(msg.apiUrl, msg.pairingCode, msg.deviceName).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_STATUS') { status().then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_BULK_QUEUE_LEGACY') { bulkQueueLegacy().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_SAVE_RECORD') { enqueue(msg.kind, msg.record, msg.source).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_RETRY_RECORD') {
      (async () => {
        const kind = normalizeKind(msg.kind), id = String(msg.id || '');
        const key = localKey(kind, id);
        const state = await chrome.storage.local.get({ queue: [], qoqnusCustomers: [], qoqnusCentralOutbox: [] });
        const record = kind === 'customer' ? (state.qoqnusCustomers || []).find(x => String(x.id) === id) : (state.queue || []).find(x => String(x.id) === id);
        if (!record) throw new Error('پیش‌نویس موردنظر پیدا نشد.');
        const existing = (state.qoqnusCentralOutbox || []).find(x => x.kind === kind && String(x.localId) === id);
        if (existing) await chrome.storage.local.set({ qoqnusCentralOutbox: (state.qoqnusCentralOutbox || []).map(x => x.opId === existing.opId ? { ...x, nextAttemptAt: 0, status: 'pending', manualRetryRequestedAt: now() } : x) });
        else await enqueue(kind, record, 'manual-retry');
        const result = await drain();
        sendResponse(result);
      })().catch(e => sendResponse({ ok: false, error: String(e?.message || e) }));
      return true;
    }
    if (msg?.type === 'QOQNUS_CENTRAL_RETRY_ALL') {
      (async () => {
        const state = await chrome.storage.local.get({ queue: [], qoqnusCustomers: [], qoqnusCentralOutbox: [] });
        const queued = new Set((state.qoqnusCentralOutbox || []).map(x => localKey(x.kind, x.localId)));
        for (const record of (state.queue || [])) {
          if (record?.centralStatus !== 'draft') continue;
          const kind = record.recordKind === 'file' || record.bookKey === 'office-files' || record.source === 'office-file' ? 'file' : 'listing';
          const key = localKey(kind, record.id);
          if (!queued.has(key)) {
            await enqueue(kind, record, 'manual-retry-all', { deferDrain: true });
            queued.add(key);
          }
        }
        for (const record of (state.qoqnusCustomers || [])) {
          if (record?.centralStatus !== 'draft') continue;
          const key = localKey('customer', record.id);
          if (!queued.has(key)) {
            await enqueue('customer', record, 'manual-retry-all', { deferDrain: true });
            queued.add(key);
          }
        }
        // A manual "retry all" is an explicit wake-up: cancel every backoff,
        // including quarantined items. Never rotate operationId or uploadKey here.
        await mutateOutbox(async () => {
          const latest = await chrome.storage.local.get({ qoqnusCentralOutbox: [] });
          const items = Array.isArray(latest.qoqnusCentralOutbox) ? latest.qoqnusCentralOutbox : [];
          const stamp = now();
          await chrome.storage.local.set({ qoqnusCentralOutbox: items.map(item => ({
            ...item,
            nextAttemptAt: 0,
            status: 'pending',
            manualRetryRequestedAt: stamp
          })) });
        });
        const result = await drain();
        sendResponse(result);
      })().catch(e => sendResponse({ ok: false, error: String(e?.message || e) }));
      return true;
    }
    if (msg?.type === 'QOQNUS_CENTRAL_PULL') { sendResponse({ ok:false, error:'دریافت خودکار/قدیمی غیرفعال است؛ از بررسی شناسه‌ها و صندوق دریافت مدیر استفاده کن.' }); return false; }
    if (msg?.type === 'QOQNUS_CENTRAL_RECEIVE_TOGGLE') { (async()=>{const enabled=msg.enabled===true;await chrome.storage.local.set({[RECEIVE_KEY]:enabled});if(enabled){const s=await chrome.storage.local.get({qoqnusCentralReceiveDataPhaseComplete:false,qoqnusCentralImageDownloadQueue:[]});if(s.qoqnusCentralReceiveDataPhaseComplete&&(s.qoqnusCentralImageDownloadQueue||[]).length)try{chrome.alarms.create(IMAGE_ALARM,{when:now()+1500});}catch{}}sendResponse({ok:true,enabled});})().catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_INCOMING_DECIDE') { decideIncoming(msg.stagingId,msg.decision).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_FINAL_ARCHIVE_LIST') { listFinalArchive().then(items=>sendResponse({ok:true,items})).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_FINAL_ARCHIVE_RESTORE') { restoreFinalArchive(msg.id,msg.kind).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_INCOMING_LIST') { chrome.storage.local.get({[STAGING_KEY]:[]}).then(s=>sendResponse({ok:true,items:s[STAGING_KEY]||[]})).catch(e=>sendResponse({ok:false,error:String(e?.message||e)})); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_SYNC_NOW') { checkIds().then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_FETCH_SELECTED') { fetchSelected(msg.recordIds || []).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
    if (msg?.type === 'QOQNUS_CENTRAL_SYNC_STATUS') {
      chrome.storage.local.get({ qoqnusCentralOutbox: [], qoqnusCentralImageOutbox: [], qoqnusCentralImageDownloadQueue: [], qoqnusCentralLastSync: null, qoqnusCentralLastPull: null, qoqnusCentralLastImageSync: null, qoqnusCentralPullState: null })
        .then(s => sendResponse({ ok: true, drafts: (s.qoqnusCentralOutbox || []).length, imagesPending: (s.qoqnusCentralImageOutbox || []).length + (s.qoqnusCentralImageDownloadQueue || []).length, imageSync: s.qoqnusCentralLastImageSync, outgoing: s.qoqnusCentralLastSync, incoming: s.qoqnusCentralLastPull, cursor: s.qoqnusCentralPullState?.ackedSeq || 0 }))
        .catch(e => sendResponse({ ok: false, error: String(e?.message || e) }));
      return true;
    }
    if (msg?.type === 'QOQNUS_CENTRAL_DRAIN') { drain().then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e?.message || e) })); return true; }
  });

  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm?.name === ALARM) drain().catch(()=>{});
    else if (alarm?.name === IMAGE_ALARM) drainImages(true).catch(()=>{});
    // No alarm is allowed to check IDs, pull records, or download remote images.
  });
  chrome.runtime.onStartup?.addListener?.(() => {
    chrome.storage.local.get({qoqnusCentralOutbox:[]}).then(s=>{ if((s.qoqnusCentralOutbox||[]).length) schedule(3000); }).catch(()=>{});
  });
  self.QoqnusCentralRecordSync = { enqueue, drain, drainImages, checkIds, fetchSelected, decideIncoming, bulkQueueLegacy, listFinalArchive, restoreFinalArchive, syncNow, schedule, submitPrimaryUpdate, submitFieldReport, reviewFieldReport, deleteCentralRecord, updateListingStatus, getRecordHistory };
})();
