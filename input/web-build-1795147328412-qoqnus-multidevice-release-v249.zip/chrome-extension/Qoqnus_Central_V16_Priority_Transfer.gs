/** Qoqnus V16 — strict outbound ID -> title -> full record data phases. */
'use strict';
function qoqnusReserveRecordIdsV16_(device, body) {
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length || items.length > 20) return { ok:false, error:'invalid_reserve_batch' };
  const results = [];
  for (const item of items) {
    try {
      const operationId=String(item.operationId||'').trim(), kind=String(item.kind||''), localId=String(item.localId||'').trim();
      if (!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId) || !['customer','file','listing'].includes(kind) || !localId || localId.length>180) throw new Error('invalid_reserve_item');
      const prior=findExact_('Operations',1,operationId);
      if(prior){if(String(prior.values[1])!==device.deviceId||String(prior.values[2])!=='reserve_record_id')throw new Error('operation_id_conflict');results.push(replayOperation_(prior));continue;}
      const existing=findRecordByOrigin_(device.deviceId,kind,localId);
      if(existing){
        if(String(existing.values[9])==='deleted')throw new Error('local_record_already_deleted');
        if(String(existing.values[4])!==device.deviceId)throw new Error('record_owner_device_only');
        const id=String(existing.values[0]);
        const response={ok:true,recordId:id,centralId:id,localId,kind,version:Number(existing.values[8])||0,ownerDeviceId:device.deviceId,stage:String(existing.values[9])==='staging'?'id_reserved':'existing_record'};
        saveOperation_(operationId,device.deviceId,'reserve_record_id',id,response);results.push(response);continue;
      }
      const id=Utilities.getUuid().replace(/-/g,'').toLowerCase(), now=new Date().toISOString();
      const shell={id:localId,localId,recordKind:kind,centralId:id,centralRecordId:id,ownerDeviceId:device.deviceId,ownerDeviceName:device.name,transferStage:'id_reserved'};
      sheet_('Records').appendRow([id,kind,localId,device.deviceId,device.deviceId,device.name,now,now,0,'staging','{}',JSON.stringify(shell),Math.max(0,Math.min(20,Number(item.expectedImages)||0)),0,0,'']);
      const response={ok:true,recordId:id,centralId:id,localId,kind,version:0,ownerDeviceId:device.deviceId,stage:'id_reserved'};
      saveOperation_(operationId,device.deviceId,'reserve_record_id',id,response);results.push(response);
    } catch(e) { results.push({ok:false,localId:String(item&&item.localId||''),error:safeErrorCode_(e),message:String(e&&e.message||'').slice(0,180)}); }
  }
  return {ok:true,phase:'ids',results,accepted:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length};
}
function qoqnusSaveRecordTitlesV16_(device, body) {
  const items=Array.isArray(body.items)?body.items:[];
  if(!items.length||items.length>20)return{ok:false,error:'invalid_title_batch'};
  const results=[];
  for(const item of items){
    try{
      const operationId=String(item.operationId||'').trim(),recordId=String(item.recordId||'').trim();
      if(!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)||!recordId)throw new Error('invalid_title_item');
      const prior=findExact_('Operations',1,operationId);
      if(prior){if(String(prior.values[1])!==device.deviceId||String(prior.values[2])!=='save_record_title')throw new Error('operation_id_conflict');results.push(replayOperation_(prior));continue;}
      const rec=findRecordById_(recordId);
      if(!rec||String(rec.values[9])==='deleted')throw new Error('record_not_found');
      if(String(rec.values[4])!==device.deviceId)throw new Error('record_owner_device_only');
      const current=safeParse_(rec.values[11],{});
      current.title=cleanText_(item.title||'',180);
      current.titleSubtitle=cleanText_(item.subtitle||'',120);
      current.transferStage='title_saved';
      sheet_('Records').getRange(rec.row,12).setValue(JSON.stringify(current));
      const response={ok:true,recordId,phase:'title',title:current.title};
      saveOperation_(operationId,device.deviceId,'save_record_title',recordId,response);results.push(response);
    }catch(e){results.push({ok:false,recordId:String(item&&item.recordId||''),error:safeErrorCode_(e),message:String(e&&e.message||'').slice(0,180)});}
  }
  return{ok:true,phase:'titles',results,accepted:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length};
}
function qoqnusSaveRecordDataV16_(device, body) {
  const items=Array.isArray(body.items)?body.items:[];
  if(!items.length||items.length>20)return{ok:false,error:'invalid_data_batch'};
  const results=[];
  for(const item of items){
    try{
      const operationId=String(item.operationId||'').trim(),recordId=String(item.recordId||'').trim(),kind=String(item.kind||''),localId=String(item.localId||'').trim();
      const source=item.record&&typeof item.record==='object'&&!Array.isArray(item.record)?item.record:null;
      if(!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)||!recordId||!['customer','file','listing'].includes(kind)||!localId||!source)throw new Error('invalid_record_data_item');
      const prior=findExact_('Operations',1,operationId);
      if(prior){if(String(prior.values[1])!==device.deviceId||String(prior.values[2])!=='save_record_data')throw new Error('operation_id_conflict');results.push(replayOperation_(prior));continue;}
      const rec=findRecordById_(recordId);
      if(!rec||String(rec.values[9])==='deleted')throw new Error('record_not_found');
      if(String(rec.values[4])!==device.deviceId||String(rec.values[1])!==kind||String(rec.values[2])!==localId)throw new Error('record_owner_or_identity_mismatch');
      const now=new Date().toISOString(), oldCurrent=safeParse_(rec.values[11],{}), isNew=String(rec.values[9])==='staging';
      const version=isNew?1:(Math.max(1,Number(rec.values[8])||1)+1);
      const createdAt=safeDate_(source.createdAt||source.created_at,String(rec.values[6]||now));
      const fullSource={...source,centralImages:Array.isArray(source.centralImages)?source.centralImages:(Array.isArray(oldCurrent.centralImages)?oldCurrent.centralImages:[])};
      const cleanRecord=qoqnusNormalizeRecordV13_(fullSource,kind,localId,recordId,device,createdAt,now,version,false);
      cleanRecord.transferStage='complete';
      const json=JSON.stringify(cleanRecord);
      if(json.length>QOQNUS.MAX_RECORD_JSON_CHARS)throw new Error('record_too_large_for_sheet_cell');
      const sh=sheet_('Records');
      sh.getRange(rec.row,8).setValue(now);sh.getRange(rec.row,9).setValue(version);sh.getRange(rec.row,10).setValue('active');
      if(isNew)sh.getRange(rec.row,11).setValue(json);
      sh.getRange(rec.row,12).setValue(json);
      sh.getRange(rec.row,13).setValue(Math.max(0,Math.min(20,Number(item.expectedImages)||0)));
      appendHistory_({recordId,kind,eventType:isNew?'record_created':'record_updated',actor:device,eventAt:now,description:isNew?'ثبت رکورد پس از تکمیل مرحله شناسه و عنوان':'به‌روزرسانی رکورد پس از تکمیل مرحله شناسه و عنوان',operationId,status:'applied'});
      appendChange_(recordId,kind,isNew?'record_created':'record_updated',version,device.deviceId,{recordId,centralId:recordId,localId,kind,record:cleanRecord,version});
      const response={ok:true,recordId,centralId:recordId,localId,kind,version,ownerDeviceId:device.deviceId,stage:'data_complete',expectedImages:Number(item.expectedImages)||0};
      saveOperation_(operationId,device.deviceId,'save_record_data',recordId,response);results.push(response);
    }catch(e){results.push({ok:false,recordId:String(item&&item.recordId||''),localId:String(item&&item.localId||''),error:safeErrorCode_(e),message:String(e&&e.message||'').slice(0,180)});}
  }
  return{ok:true,phase:'data',results,accepted:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length};
}
