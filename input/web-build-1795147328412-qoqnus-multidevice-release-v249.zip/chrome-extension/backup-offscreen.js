chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
 if(message?.type!=='QOQNUS_OFFSCREEN_WRITE_BACKUP')return;
 (async()=>{
  let url='';
  try{
   const blob=new Blob([String(message.json||'')],{type:'application/json;charset=utf-8'});
   url=URL.createObjectURL(blob);
   const id=await chrome.downloads.download({url,filename:'Qoqnus/backup-auto.json',conflictAction:'overwrite',saveAs:false});
   sendResponse({ok:true,downloadId:id});
  }catch(e){sendResponse({ok:false,error:String(e?.message||e)});}
  finally{if(url)setTimeout(()=>URL.revokeObjectURL(url),60000);}
 })();
 return true;
});
