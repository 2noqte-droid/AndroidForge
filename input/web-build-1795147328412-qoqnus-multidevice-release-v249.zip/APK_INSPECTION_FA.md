# گزارش بررسی APK ارسالی

- فایل بررسی‌شده: `AndroidForge-app-debug.apk`
- نسخهٔ موجود در assets/app.js و manifest.webmanifest: `V243`
- APK از نظر ساختار ZIP سالم است.
- بسته شامل `classes.dex`, `classes2.dex`, `classes3.dex` و دارایی‌های WebView در `assets/` است.
- سورس Gradle/Kotlin/Java و keystore امضا داخل APK موجود نیست.
- رشته‌های کلاس native شامل `FileProvider`, `getCacheDir`, `pendingCameraFile`, `pendingCameraUri` و پیام `Cannot create camera output` هستند. این نشان می‌دهد مسیر انتخاب عکس دوربین در WebView از فایل موقت خصوصی برنامه استفاده می‌کند، نه مسیر مستقیم MediaStore عمومی.
- چون سورس native ارائه نشده، نمی‌توان پاک‌سازی قطعی فایل موقت را پس از callback تأیید یا تغییر داد.

نسخهٔ V249 در این بسته یک **overlay از Web assets** برای پروژهٔ اصلی Android است؛ این فایل، APK امضاشده نیست.
