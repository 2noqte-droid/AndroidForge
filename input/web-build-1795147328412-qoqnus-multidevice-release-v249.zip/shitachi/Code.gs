
/**
 * QOQNUS CENTRAL OFFICE
 * Version: 1.6.4-transfer-recovery
 * Runtime: Google Apps Script V8
 *
 * Central Google Sheets + private Drive images
 * Device pairing and authorization
 * Initial import
 * Immutable initial record snapshot
 * Current record snapshot
 * Structured field reports from every authorized device
 * Owner approval of reported field changes
 * Textual file history
 * Incremental sync and per-device acknowledgements
 * WebP image upload and retrieval
 *
 * Replace the entire Code.gs with this file.
 */

'use strict';

const QOQNUS = Object.freeze({
  VERSION: '1.6.13-multidevice-tombstone-v249',
  MAX_DEVICES: 5,
  MAX_BATCH_RECORDS: 20,
  MAX_RECORD_JSON_CHARS: 44000,
  MAX_IMAGE_BYTES: 299999,
  MAX_PULL_LIMIT: 200,
  SHEETS: {
    Records: ['record_id','kind','local_id','origin_device_id','owner_device_id','owner_device_name','created_at','updated_at','version','status','initial_json','current_json','expected_images','stored_images','last_seq','import_id'],
    History: ['history_id','record_id','kind','event_type','field_name','old_value','new_value','actor_device_id','actor_name','event_at','description','status','operation_id'],
    Devices: ['device_id','client_install_id','device_name','device_type','token_hash','status','created_at','last_seen_at','revoked_at'],
    Images: ['image_id','record_id','image_index','file_name','mime_type','drive_file_id','sha256','bytes','width','height','uploaded_at','owner_device_id','upload_key'],
    Operations: ['operation_id','device_id','action','record_id','response_json','created_at'],
    SyncChanges: ['seq','record_id','kind','event_type','version','actor_device_id','created_at','payload_json'],
    ImportJobs: ['import_id','device_id','total_records','total_images','processed_records','processed_images','failed_items','status','started_at','updated_at','completed_at'],
    SyncAcks: ['device_id','acked_seq','updated_at','last_pull_at','last_delivered_seq','client_version']
  }
});

function doGet() {
  return jsonOut_({
    ok: true,
    service: 'Qoqnus Central',
    version: QOQNUS.VERSION,
    message: 'POST JSON requests to this endpoint.'
  });
}

function doPost(e) {
  try {
    const body = parseBody_(e);
    const action = String(body.action || '').trim();

    if (!action) {
      return jsonOut_({ ok: false, error: 'missing_action' });
    }

    if (action === 'pair') {
      return jsonOut_(pairDevice_(body));
    }

    if (action === 'status_public') {
      return jsonOut_({
        ok: true,
        service: 'Qoqnus Central',
        version: QOQNUS.VERSION
      });
    }

    if ([
      'admin_list_devices',
      'admin_revoke_device',
      'admin_transfer_owner'
    ].includes(action)) {
      if (!adminAuthorized_(body.adminCode)) {
        return jsonOut_({ ok: false, error: 'unauthorized_admin' });
      }

      if (action === 'admin_list_devices') {
        return jsonOut_(listDevices_());
      }

      if (action === 'admin_revoke_device') {
        return jsonOut_(revokeDevice_(String(body.deviceId || '')));
      }

      return jsonOut_(
        transferRecordOwner_(
          String(body.recordId || ''),
          String(body.targetDeviceId || '')
        )
      );
    }

    const device = authenticateDevice_(body.token);

    if (!device) {
      return jsonOut_({ ok: false, error: 'unauthorized_device' });
    }

    touchDevice_(device.row);

    let result;

    switch (action) {
      case 'status':
        result = statusForDevice_(device);
        break;

      // Strict phased outbound transfer: reserve IDs -> full record data -> images.
      case 'reserve_record_ids': result = qoqnusReserveRecordIdsV16_(device, body); break;
      case 'save_record_titles': result = qoqnusSaveRecordTitlesV16_(device, body); break;
      case 'save_record_data': result = qoqnusSaveRecordDataV16_(device, body); break;
      case 'get_record_transfer_status': result = qoqnusGetRecordTransferStatusV16_(device, body); break;
      case 'save_record': result = qoqnusSaveRecordV13_(device, body); break;
      case 'save_records_batch': result = qoqnusSaveRecordsBatchV16_(device, body); break;
      case 'update_listing_status': result = qoqnusUpdateListingStatusV13_(device, body); break;
      case 'check_ids': result = qoqnusCheckIdsV15_(device, body); break;
      case 'get_record_titles': result = qoqnusGetRecordTitlesV15_(device, body); break;
      case 'fetch_selected_records': result = qoqnusFetchSelectedV15_(device, body); break;
      case 'upload_record_image': result = qoqnusUploadRecordImageV14_(device, body); break;
      case 'get_record_image': result = qoqnusGetRecordImageV14_(device, body); break;

      case 'get_review_decisions':
        result = qoqnusGetReviewDecisions_(device, body);
        break;

      case 'set_review_decision':
        result = qoqnusSetReviewDecision_(device, body);
        break;

      case 'sync_state':
        result = qoqnusSyncState_(device);
        break;

      case 'sync_initialize':
        result = qoqnusSyncInitialize_(device, body);
        break;

      case 'begin_import':
        result = beginImport_(device, body);
        break;

      case 'import_records':
        result = importRecords_(device, body);
        break;

      case 'upload_image':
        result = uploadImage_(device, body);
        break;

      case 'finish_import':
        result = finishImport_(device, body);
        break;

      case 'import_status':
        result = importStatus_(device, body);
        break;

      case 'add_report':
        result = addReport_(device, body);
        break;

      case 'add_field_report':
        result = addFieldReport_(device, body);
        break;

      case 'approve_field_report':
        result = approveFieldReport_(device, body);
        break;

      case 'primary_update':
        result = primaryUpdate_(device, body);
        break;

      case 'delete_record':
        result = deleteRecord_(device, body);
        break;

      case 'pull_changes':
        result = qoqnusSyncPull_(device, body);
        break;

      case 'ack_changes':
        result = qoqnusSyncAck_(device, body);
        break;

      case 'get_record':
        result = getRecord_(device, body);
        break;

      case 'get_history':
        result = qoqnusGetHistory_(device, body);
        break;

      case 'get_image':
        result = qoqnusGetImage_(device, body);
        break;

      case 'remove_history_entry':
        result = removeHistoryEntry_(device, body);
        break;

      default:
        result = { ok: false, error: 'unknown_action' };
    }

    return jsonOut_(result);

  } catch (err) {
    console.error(
      'Qoqnus Central error:',
      err && err.stack ? err.stack : err
    );

    return jsonOut_({
      ok: false,
      error: safeErrorCode_(err),
      message: String(
        err && err.message || 'خطای داخلی دفتر مرکزی'
      ).slice(0, 300)
    });
  }
}

// ============================================================================
// SETUP
// ============================================================================

function setupQoqnusCentral() {
  const props = PropertiesService.getScriptProperties();

  let spreadsheetId = props.getProperty(
    'QOQNUS_SPREADSHEET_ID'
  );

  let folderId = props.getProperty(
    'QOQNUS_DRIVE_FOLDER_ID'
  );

  let ss;

  if (spreadsheetId) {
    try {
      ss = SpreadsheetApp.openById(spreadsheetId);
    } catch (_) {
      ss = null;
    }
  }

  if (!ss) {
    ss = SpreadsheetApp.create('دفتر مرکزی ققنوس');
    spreadsheetId = ss.getId();

    props.setProperty(
      'QOQNUS_SPREADSHEET_ID',
      spreadsheetId
    );
  }

  if (!folderId) {
    const folder = DriveApp.createFolder(
      'Qoqnus Central Private Images'
    );

    folderId = folder.getId();

    props.setProperty(
      'QOQNUS_DRIVE_FOLDER_ID',
      folderId
    );

    // Spreadsheet remains in its normal Drive location.
    // This folder is only for images.
  }

  Object.keys(QOQNUS.SHEETS).forEach(name => {
    ensureSheet_(name);
  });

  let pairingCode = '';

  if (!props.getProperty('QOQNUS_PAIR_CODE_HASH')) {
    pairingCode = randomSecret_();

    props.setProperty(
      'QOQNUS_PAIR_CODE_HASH',
      sha256_(pairingCode)
    );
  }

  let adminCode = '';

  if (!props.getProperty('QOQNUS_ADMIN_CODE_HASH')) {
    adminCode = randomSecret_();

    props.setProperty(
      'QOQNUS_ADMIN_CODE_HASH',
      sha256_(adminCode)
    );
  }

  const info = {
    ok: true,
    version: QOQNUS.VERSION,
    spreadsheetUrl: ss.getUrl(),
    imageFolderId: folderId,
    pairingCodeCreated: !!pairingCode,
    adminCodeCreated: !!adminCode,
    tables: Object.keys(QOQNUS.SHEETS),
    note: 'کدهای خام فقط یک‌بار در Execution Log چاپ می‌شوند.'
  };

  if (pairingCode) {
    console.log(
      'QOQNUS_ONE_TIME_PAIRING_CODE=' + pairingCode
    );
  }

  if (adminCode) {
    console.log(
      'QOQNUS_ONE_TIME_ADMIN_CODE=' + adminCode
    );
  }

  console.log(JSON.stringify(info));

  return info;
}

function rotateQoqnusPairingCode() {
  const code = randomSecret_();

  PropertiesService
    .getScriptProperties()
    .setProperty(
      'QOQNUS_PAIR_CODE_HASH',
      sha256_(code)
    );

  console.log('QOQNUS_NEW_PAIRING_CODE=' + code);

  return 'کد جدید فقط در Execution Log نمایش داده شد.';
}

function rotateQoqnusAdminCode() {
  const code = randomSecret_();

  PropertiesService
    .getScriptProperties()
    .setProperty(
      'QOQNUS_ADMIN_CODE_HASH',
      sha256_(code)
    );

  console.log('QOQNUS_NEW_ADMIN_CODE=' + code);

  return 'کد جدید فقط در Execution Log نمایش داده شد.';
}

function listQoqnusDevices() {
  return listDevices_();
}

function revokeQoqnusDevice(deviceId) {
  return revokeDevice_(String(deviceId || ''));
}

// ============================================================================
// DEVICE PAIRING
// ============================================================================

function pairDevice_(body) {
  const props = PropertiesService.getScriptProperties();

  const supplied = String(body.pairingCode || '');

  const expected = String(
    props.getProperty('QOQNUS_PAIR_CODE_HASH') || ''
  );

  if (
    !expected ||
    !supplied ||
    !constantTimeEqual_(sha256_(supplied), expected)
  ) {
    return {
      ok: false,
      error: 'invalid_pairing_code'
    };
  }

  const installId = String(
    body.clientInstallId || ''
  ).trim();

  const name = cleanText_(
    body.deviceName || 'دستگاه ققنوس',
    80
  );

  const type = String(
    body.deviceType || 'chrome-extension'
  );

  if (!/^[a-zA-Z0-9_-]{12,100}$/.test(installId)) {
    return {
      ok: false,
      error: 'invalid_install_id'
    };
  }

  if (!['chrome-extension', 'android'].includes(type)) {
    return {
      ok: false,
      error: 'invalid_device_type'
    };
  }

  return withLock_(() => {
    const sh = sheet_('Devices');

    const values = sh.getDataRange().getValues();

    const idx = headerMap_(values[0]);

    // Recover the existing installation instead of creating a duplicate device.
    // A valid pairing code is required above; keep deviceId and record ownership stable.
    for (let i = 1; i < values.length; i++) {
      if (String(values[i][idx.client_install_id]) !== installId) continue;
      if (String(values[i][idx.status]) !== 'active') {
        return { ok: false, error: 'install_id_revoked', message: 'این نصب قبلاً لغو شده است؛ مدیر باید وضعیت دستگاه را بررسی کند.' };
      }
      const oldType = String(values[i][idx.device_type] || '');
      if (oldType && oldType !== type) {
        return { ok: false, error: 'device_type_mismatch' };
      }
      const deviceId = String(values[i][idx.device_id]);
      const token = randomSecret_() + randomSecret_();
      const now = new Date().toISOString();
      sh.getRange(i + 1, idx.device_name + 1).setValue(name);
      sh.getRange(i + 1, idx.token_hash + 1).setValue(sha256_(token));
      sh.getRange(i + 1, idx.last_seen_at + 1).setValue(now);
      return {
        ok: true, recovered: true, deviceId, token,
        deviceName: name, deviceType: type, pairedAt: now,
        maxDevices: QOQNUS.MAX_DEVICES,
        message: 'اتصال دستگاه قبلی بازیابی شد؛ شناسه و مالکیت رکوردها حفظ شدند.'
      };
    }

    const active = values
      .slice(1)
      .filter(r => String(r[idx.status]) === 'active')
      .length;

    if (active >= QOQNUS.MAX_DEVICES) {
      return {
        ok: false,
        error: 'device_limit_reached',
        message: 'ظرفیت ۵ دستگاه فعال تکمیل شده است.'
      };
    }

    // New device IDs are explicitly namespaced by client type.
    // Preserve legacy IDs on recovery to avoid breaking existing record ownership.
    const devicePrefix = type === 'android' ? 'Mobile' : 'Chrome';
    const deviceId = devicePrefix + Utilities
      .getUuid()
      .replace(/-/g, '')
      .toLowerCase();

    const token = randomSecret_() + randomSecret_();

    const now = new Date().toISOString();

    sh.appendRow([
      deviceId,
      installId,
      name,
      type,
      sha256_(token),
      'active',
      now,
      now,
      ''
    ]);

    return {
      ok: true,
      deviceId,
      token,
      deviceName: name,
      deviceType: type,
      pairedAt: now,
      maxDevices: QOQNUS.MAX_DEVICES
    };
  });
}

function authenticateDevice_(token) {
  const value = String(token || '');

  if (value.length < 40 || value.length > 300) {
    return null;
  }

  const hash = sha256_(value);

  const sh = sheet_('Devices');

  const values = sh.getDataRange().getValues();

  const idx = headerMap_(values[0]);

  for (let i = 1; i < values.length; i++) {
    if (
      String(values[i][idx.token_hash]) === hash &&
      String(values[i][idx.status]) === 'active'
    ) {
      return {
        row: i + 1,
        deviceId: String(values[i][idx.device_id]),
        name: String(values[i][idx.device_name]),
        type: String(values[i][idx.device_type])
      };
    }
  }

  return null;
}

function touchDevice_(row) {
  try {
    sheet_('Devices')
      .getRange(row, 8)
      .setValue(new Date().toISOString());
  } catch (_) {}
}

function adminAuthorized_(code) {
  const expected = String(
    PropertiesService
      .getScriptProperties()
      .getProperty('QOQNUS_ADMIN_CODE_HASH') || ''
  );

  return !!expected &&
    constantTimeEqual_(sha256_(String(code || '')), expected);
}

function listDevices_() {
  const sh = sheet_('Devices');

  const values = sh.getDataRange().getValues();

  const idx = headerMap_(values[0]);

  return {
    ok: true,

    devices: values.slice(1).map(r => ({
      deviceId: String(r[idx.device_id]),
      name: String(r[idx.device_name]),
      type: String(r[idx.device_type]),
      status: String(r[idx.status]),
      createdAt: String(r[idx.created_at]),
      lastSeenAt: String(r[idx.last_seen_at]),
      revokedAt: String(r[idx.revoked_at])
    })).filter(x => x.deviceId)
  };
}

function isValidQoqnusDeviceId_(deviceId) {
  const value = String(deviceId || '').trim();
  // The unprefixed 32-hex form remains accepted for already-paired legacy devices.
  return /^(?:[a-f0-9]{32}|(?:Mobile|Chrome|Corom)[a-f0-9]{32})$/i.test(value);
}

function revokeDevice_(deviceId) {
  if (!isValidQoqnusDeviceId_(deviceId)) {
    return {
      ok: false,
      error: 'invalid_device_id'
    };
  }

  const sh = sheet_('Devices');

  const values = sh.getDataRange().getValues();

  const idx = headerMap_(values[0]);

  for (let i = 1; i < values.length; i++) {
    if (String(values[i][idx.device_id]) === deviceId) {
      sh.getRange(i + 1, idx.status + 1)
        .setValue('revoked');

      sh.getRange(i + 1, idx.revoked_at + 1)
        .setValue(new Date().toISOString());

      return {
        ok: true,
        deviceId,
        status: 'revoked'
      };
    }
  }

  return {
    ok: false,
    error: 'device_not_found'
  };
}

// ============================================================================
// INITIAL IMPORT
// ============================================================================

function beginImport_(device, body) {
  const importId = String(body.importId || '');

  if (!/^[a-zA-Z0-9:_-]{12,180}$/.test(importId)) {
    return {
      ok: false,
      error: 'invalid_import_id'
    };
  }

  const existing = findExact_(
    'ImportJobs',
    1,
    importId
  );

  if (existing) {
    const row = existing.values;

    if (String(row[1]) !== device.deviceId) {
      return {
        ok: false,
        error: 'import_id_owner_mismatch'
      };
    }

    const currentStatus = String(row[7]);

    if (currentStatus !== 'completed') {
      const now = new Date().toISOString();

      const sh = sheet_('ImportJobs');

      sh.getRange(existing.row, 7).setValue(0);
      sh.getRange(existing.row, 8).setValue('running');
      sh.getRange(existing.row, 10).setValue(now);
      sh.getRange(existing.row, 11).setValue('');
    }

    return {
      ok: true,
      importId,
      resumed: true,
      status: currentStatus === 'completed'
        ? 'completed'
        : 'running',
      processedRecords: Number(row[4]) || 0,
      processedImages: Number(row[5]) || 0
    };
  }

  const now = new Date().toISOString();

  sheet_('ImportJobs').appendRow([
    importId,
    device.deviceId,
    Math.max(0, Number(body.totalRecords) || 0),
    Math.max(0, Number(body.totalImages) || 0),
    0,
    0,
    0,
    'running',
    now,
    now,
    ''
  ]);

  return {
    ok: true,
    importId,
    resumed: false,
    status: 'running'
  };
}

function importRecords_(device, body) {
  const importId = String(body.importId || '');

  const items = Array.isArray(body.items)
    ? body.items
    : [];

  if (
    !importId ||
    items.length < 1 ||
    items.length > QOQNUS.MAX_BATCH_RECORDS
  ) {
    return {
      ok: false,
      error: 'invalid_import_batch'
    };
  }

  const job = findExact_(
    'ImportJobs',
    1,
    importId
  );

  if (!job || String(job.values[1]) !== device.deviceId) {
    return {
      ok: false,
      error: 'import_job_not_found'
    };
  }

  return withLock_(() => {
    const results = [];

    for (const item of items) {
      try {
        results.push(
          importOneRecord_(device, item, importId)
        );
      } catch (err) {
        results.push({
          ok: false,
          localId: String(item && item.localId || ''),
          error: safeErrorCode_(err),
          message: String(err.message || '').slice(0, 200)
        });
      }
    }

    const newlyAdded = results.filter(
      x => x.ok && !x.duplicate
    ).length;

    const failed = results.filter(
      x => !x.ok
    ).length;

    updateImportJob_(importId, {
      processedRecordsDelta: newlyAdded,
      failedDelta: failed
    });

    const good = results.filter(x => x.ok).length;

    return {
      ok: true,
      importId,
      results,
      accepted: good,
      failed
    };
  });
}

function importOneRecord_(device, item, importId) {
  if (
    !item ||
    !['customer', 'file', 'listing'].includes(String(item.kind || ''))
  ) {
    throw new Error('invalid_record_kind');
  }

  const kind = String(item.kind);

  const localId = String(
    item.localId ||
    (item.record && item.record.id) ||
    ''
  ).trim();

  if (!localId || localId.length > 180) {
    throw new Error('invalid_local_id');
  }

  const source = item.record &&
    typeof item.record === 'object'
      ? item.record
      : null;

  if (!source) {
    throw new Error('missing_record_payload');
  }

  const record = stripInlineMedia_(source);

  record.id = localId;

  const json = JSON.stringify(record);

  if (json.length > QOQNUS.MAX_RECORD_JSON_CHARS) {
    throw new Error('record_too_large_for_sheet_cell');
  }

  const expectedImages = Math.max(
    0,
    Math.min(20, Number(item.expectedImages) || 0)
  );

  const existing = findRecordByOrigin_(
    device.deviceId,
    kind,
    localId
  );

  if (existing) {
    return {
      ok: true,
      kind,
      duplicate: true,
      localId,
      recordId: String(existing.values[0]),
      expectedImages: Number(existing.values[12]) || expectedImages,
      storedImages: Number(existing.values[13]) || 0
    };
  }

  const recordId = Utilities
    .getUuid()
    .replace(/-/g, '')
    .toLowerCase();

  const now = new Date().toISOString();

  const ownerName = device.name;

  const createdAt = safeDate_(
    record.createdAt || record.created_at,
    now
  );

  const cleanRecord = {
    ...record,
    centralRecordId: recordId,
    ownerDeviceId: device.deviceId,
    ownerDeviceName: ownerName
  };

  const cleanJson = JSON.stringify(cleanRecord);

  if (cleanJson.length > QOQNUS.MAX_RECORD_JSON_CHARS) {
    throw new Error('record_too_large_for_sheet_cell');
  }

  sheet_('Records').appendRow([
    recordId,
    kind,
    localId,
    device.deviceId,
    device.deviceId,
    ownerName,
    createdAt,
    now,
    1,
    'active',
    cleanJson,
    cleanJson,
    expectedImages,
    0,
    0,
    importId
  ]);

  appendHistory_({
    recordId,
    kind,
    eventType: 'initial_import',
    actor: device,
    eventAt: now,
    description: 'انتقال اولیه اطلاعات موجود از دستگاه به دفتر مرکزی',
    operationId: importId + ':' + kind + ':' + localId
  });

  appendChange_(
    recordId,
    kind,
    'initial_import',
    1,
    device.deviceId,
    {
      recordId,
      kind,
      record: cleanRecord,
      version: 1
    }
  );

  return {
    ok: true,
    kind,
    duplicate: false,
    localId,
    recordId,
    expectedImages,
    storedImages: 0
  };
}

// ============================================================================
// IMAGE UPLOAD
// ============================================================================

function uploadImage_(device, body) {
  const recordId = String(body.recordId || '');

  const index = Number(body.imageIndex);

  const dataUrl = String(body.dataUrl || '');

  const uploadKey = String(body.uploadKey || '');

  if (
    !/^[a-f0-9]{32}$/i.test(recordId) ||
    !Number.isInteger(index) ||
    index < 0 ||
    index > 19
  ) {
    return {
      ok: false,
      error: 'invalid_image_target'
    };
  }

  if (!/^image:[a-f0-9]{32}:[0-9]{1,2}:[a-f0-9]{64}$/i.test(uploadKey)) {
    return {
      ok: false,
      error: 'invalid_upload_key'
    };
  }

  const match = /^data:image\/webp;base64,([A-Za-z0-9+/]+={0,2})$/i.exec(dataUrl);

  if (!match) {
    return {
      ok: false,
      error: 'image_must_be_webp'
    };
  }

  const bytes = Utilities.base64Decode(match[1]);

  if (
    !bytes.length ||
    bytes.length > QOQNUS.MAX_IMAGE_BYTES
  ) {
    return {
      ok: false,
      error: 'image_size_limit'
    };
  }

  if (!isWebpBytes_(bytes)) {
    return {
      ok: false,
      error: 'invalid_webp_signature'
    };
  }

  const dimensions = webpDimensions_(bytes);

  if (
    !dimensions ||
    dimensions.width < 1 ||
    dimensions.height < 1 ||
    dimensions.width > 500 ||
    dimensions.height > 500
  ) {
    return {
      ok: false,
      error: 'image_dimensions_limit'
    };
  }

  const width = dimensions.width;
  const height = dimensions.height;

  const digest = sha256Bytes_(bytes);

  if (
    body.sha256 &&
    String(body.sha256).toLowerCase() !== digest
  ) {
    return {
      ok: false,
      error: 'image_hash_mismatch'
    };
  }

  return withLock_(() => {
    const rec = findRecordById_(recordId);

    if (!rec || String(rec.values[9]) === 'deleted') {
      return {
        ok: false,
        error: 'record_not_found'
      };
    }

    if (
      String(rec.values[3]) !== device.deviceId &&
      String(rec.values[4]) !== device.deviceId
    ) {
      return {
        ok: false,
        error: 'image_permission_denied'
      };
    }

    const old = findExact_(
      'Images',
      13,
      uploadKey
    );

    if (old) {
      return {
        ok: true,
        duplicate: true,
        imageId: String(old.values[0]),
        driveFileId: String(old.values[5])
      };
    }

    const folderId = PropertiesService
      .getScriptProperties()
      .getProperty('QOQNUS_DRIVE_FOLDER_ID');

    if (!folderId) {
      throw new Error('drive_folder_not_configured');
    }

    const folder = DriveApp.getFolderById(folderId);

    const filename = cleanFileName_(
      body.fileName ||
      ('qoqnus-' + recordId + '-' + index + '.webp')
    );

    const blob = Utilities.newBlob(
      bytes,
      'image/webp',
      filename
    );

    const file = folder.createFile(blob);

    const imageId = Utilities
      .getUuid()
      .replace(/-/g, '')
      .toLowerCase();

    const now = new Date().toISOString();

    sheet_('Images').appendRow([
      imageId,
      recordId,
      index,
      filename,
      'image/webp',
      file.getId(),
      digest,
      bytes.length,
      width,
      height,
      now,
      device.deviceId,
      uploadKey
    ]);

    const stored = Number(rec.values[13]) || 0;

    sheet_('Records')
      .getRange(rec.row, 14)
      .setValue(stored + 1);

    appendChange_(
      recordId,
      String(rec.values[1]),
      'image_uploaded',
      Number(rec.values[8]) || 1,
      device.deviceId,
      {
        recordId,
        imageId,
        imageIndex: index,
        mimeType: 'image/webp',
        sha256: digest,
        width,
        height,
        bytes: bytes.length
      }
    );

    if (body.importId) {
      updateImportJob_(
        String(body.importId),
        { processedImagesDelta: 1 }
      );
    }

    return {
      ok: true,
      duplicate: false,
      imageId,
      driveFileId: file.getId(),
      bytes: bytes.length,
      width,
      height,
      mimeType: 'image/webp'
    };
  });
}

// ============================================================================
// IMPORT FINISH AND STATUS
// ============================================================================

function finishImport_(device, body) {
  const importId = String(body.importId || '');

  const job = findExact_(
    'ImportJobs',
    1,
    importId
  );

  if (!job || String(job.values[1]) !== device.deviceId) {
    return {
      ok: false,
      error: 'import_job_not_found'
    };
  }

  const summary = body.summary &&
    typeof body.summary === 'object'
      ? body.summary
      : {};

  const now = new Date().toISOString();

  const sh = sheet_('ImportJobs');

  const row = job.row;

  const previousFailed = Number(job.values[6]) || 0;

  const failed = Math.max(
    previousFailed,
    Number(summary.failedItems) || 0
  );

  const recordsSh = sheet_('Records');

  const recordRows = recordsSh
    .getDataRange()
    .getValues()
    .slice(1)
    .filter(r =>
      String(r[3]) === device.deviceId &&
      String(r[15]) === importId &&
      String(r[9]) !== 'deleted'
    );

  const incompleteImages = recordRows.filter(r =>
    (Number(r[12]) || 0) > (Number(r[13]) || 0)
  ).length;

  const status =
    failed > 0 || incompleteImages > 0
      ? 'completed_with_errors'
      : 'completed';

  sh.getRange(row, 7).setValue(failed);
  sh.getRange(row, 8).setValue(status);
  sh.getRange(row, 10).setValue(now);
  sh.getRange(row, 11).setValue(now);

  return {
    ok: true,
    importId,
    status,
    processedRecords: Number(job.values[4]) || 0,
    processedImages: Number(job.values[5]) || 0,
    failedItems: failed,
    recordsWithPendingImages: incompleteImages
  };
}

function importStatus_(device, body) {
  const job = findExact_(
    'ImportJobs',
    1,
    String(body.importId || '')
  );

  if (!job || String(job.values[1]) !== device.deviceId) {
    return {
      ok: false,
      error: 'import_job_not_found'
    };
  }

  const v = job.values;

  return {
    ok: true,
    importId: String(v[0]),
    totalRecords: Number(v[2]) || 0,
    totalImages: Number(v[3]) || 0,
    processedRecords: Number(v[4]) || 0,
    processedImages: Number(v[5]) || 0,
    failedItems: Number(v[6]) || 0,
    status: String(v[7])
  };
}

function updateImportJob_(importId, delta) {
  const found = findExact_(
    'ImportJobs',
    1,
    importId
  );

  if (!found) return;

  const sh = sheet_('ImportJobs');

  if (delta.processedRecordsDelta) {
    sh.getRange(found.row, 5).setValue(
      (Number(found.values[4]) || 0) +
      delta.processedRecordsDelta
    );
  }

  if (delta.processedImagesDelta) {
    sh.getRange(found.row, 6).setValue(
      (Number(found.values[5]) || 0) +
      delta.processedImagesDelta
    );
  }

  if (delta.failedDelta) {
    sh.getRange(found.row, 7).setValue(
      (Number(found.values[6]) || 0) +
      delta.failedDelta
    );
  }

  sh.getRange(found.row, 10)
    .setValue(new Date().toISOString());
}

// ============================================================================
// REPORTS AND FIELD HISTORY
// ============================================================================

function addReport_(device, body) {
  const recordId = String(body.recordId || '');

  const text = cleanText_(
    body.text || body.description || '',
    3000
  );

  const operationId = String(body.operationId || '');

  if (!recordId || !text) {
    return {
      ok: false,
      error: 'missing_record_or_report'
    };
  }

  if (!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)) {
    return {
      ok: false,
      error: 'invalid_operation_id'
    };
  }

  return withLock_(() => {
    const duplicate = findExact_(
      'Operations',
      1,
      operationId
    );

    if (duplicate) {
      return replayOperation_(duplicate);
    }

    const rec = findRecordById_(recordId);

    if (!rec || String(rec.values[9]) === 'deleted') {
      return {
        ok: false,
        error: 'record_not_found'
      };
    }

    const now = new Date().toISOString();

    const actor = {
      deviceId: device.deviceId,
      name: cleanText_(body.actorName || device.name, 80)
    };

    const historyId = appendHistory_({
      recordId,
      kind: String(rec.values[1]),
      eventType: 'manual_report',
      actor,
      eventAt: now,
      description: text,
      operationId,
      status: 'accepted'
    });

    appendChange_(
      recordId,
      String(rec.values[1]),
      'report_added',
      Number(rec.values[8]) || 1,
      device.deviceId,
      {
        recordId,
        historyId,
        eventType: 'manual_report',
        actorName: actor.name,
        actorDeviceId: device.deviceId,
        eventAt: now,
        description: text,
        status: 'accepted'
      }
    );

    const response = {
      ok: true,
      recordId,
      historyId,
      duplicate: false
    };

    saveOperation_(
      operationId,
      device.deviceId,
      'add_report',
      recordId,
      response
    );

    return response;
  });
}

/**
 * Any active device may append a structured field report.
 * It NEVER overwrites initial_json or current_json.
 * The record owner may later approve it into current_json.
 */
function addFieldReport_(device, body) {
  const recordId = String(body.recordId || '');

  const operationId = String(body.operationId || '');

  const updates = Array.isArray(body.updates)
    ? body.updates
    : [body.update || body];

  if (
    !recordId ||
    !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)
  ) {
    return {
      ok: false,
      error: 'invalid_field_report_request'
    };
  }

  if (!updates.length || updates.length > 20) {
    return {
      ok: false,
      error: 'invalid_field_report_count'
    };
  }

  return withLock_(() => {
    const duplicate = findExact_(
      'Operations',
      1,
      operationId
    );

    if (duplicate) {
      return replayOperation_(duplicate);
    }

    const rec = findRecordById_(recordId);

    if (!rec || String(rec.values[9]) === 'deleted') {
      return {
        ok: false,
        error: 'record_not_found'
      };
    }

    const current = safeParse_(rec.values[11], {});

    const now = new Date().toISOString();

    const actor = {
      deviceId: device.deviceId,
      name: cleanText_(body.actorName || device.name, 80)
    };

    const created = [];

    for (const item of updates) {
      if (!item || typeof item !== 'object') continue;

      const fieldName = String(
        item.fieldName || item.field || ''
      ).trim();

      const hasValue =
        Object.prototype.hasOwnProperty.call(item, 'newValue') ||
        Object.prototype.hasOwnProperty.call(item, 'value');

      if (!hasValue || !isSafeFieldPath_(fieldName)) {
        continue;
      }

      const newValue =
        Object.prototype.hasOwnProperty.call(item, 'newValue')
          ? item.newValue
          : item.value;

      const oldValue = getPathValue_(
        current,
        fieldName
      );

      const oldJson = JSON.stringify(
        oldValue === undefined ? null : oldValue
      );

      const newJson = JSON.stringify(newValue);

      if (newJson === undefined || newJson.length > 3000) {
        continue;
      }

      if (oldJson === newJson) {
        continue;
      }

      const description = cleanText_(
        item.description || body.description || '',
        1500
      );

      const historyId = appendHistory_({
        recordId,
        kind: String(rec.values[1]),
        eventType: 'field_report',
        fieldName,
        oldValue: oldJson,
        newValue: newJson,
        actor,
        eventAt: now,
        description,
        operationId,
        status: 'pending'
      });

      appendChange_(
        recordId,
        String(rec.values[1]),
        'field_report_added',
        Number(rec.values[8]) || 1,
        device.deviceId,
        {
          recordId,
          historyId,
          fieldName,
          oldValue: oldValue === undefined ? null : oldValue,
          newValue,
          actorDeviceId: device.deviceId,
          actorName: actor.name,
          eventAt: now,
          description,
          status: 'pending'
        }
      );

      created.push({
        historyId,
        fieldName,
        oldValue: oldValue === undefined ? null : oldValue,
        newValue,
        status: 'pending'
      });
    }

    if (!created.length) {
      return {
        ok: false,
        error: 'no_valid_field_updates'
      };
    }

    const response = {
      ok: true,
      recordId,
      reports: created,
      duplicate: false
    };

    saveOperation_(
      operationId,
      device.deviceId,
      'add_field_report',
      recordId,
      response
    );

    return response;
  });
}

/**
 * Only the record-owner device can approve a reported value into current_json.
 * initial_json remains immutable.
 */
function approveFieldReport_(device, body) {
  const recordId = String(body.recordId || '');

  const historyId = String(body.historyId || '');

  const operationId = String(body.operationId || '');

  if (
    !recordId ||
    !historyId ||
    !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)
  ) {
    return {
      ok: false,
      error: 'invalid_field_report_approval'
    };
  }

  return withLock_(() => {
    const duplicate = findExact_(
      'Operations',
      1,
      operationId
    );

    if (duplicate) {
      return replayOperation_(duplicate);
    }

    const rec = findRecordById_(recordId);

    if (!rec || String(rec.values[9]) === 'deleted') {
      return {
        ok: false,
        error: 'record_not_found'
      };
    }

    if (String(rec.values[4]) !== device.deviceId) {
      return {
        ok: false,
        error: 'owner_device_only'
      };
    }

    const historySheet = sheet_('History');

    const rows = historySheet.getDataRange().getValues();

    let reportRow = 0;
    let report = null;

    for (let i = 1; i < rows.length; i++) {
      if (
        String(rows[i][0]) === historyId &&
        String(rows[i][1]) === recordId
      ) {
        reportRow = i + 1;
        report = rows[i];
        break;
      }
    }

    if (!report || String(report[3]) !== 'field_report') {
      return {
        ok: false,
        error: 'field_report_not_found'
      };
    }

    if (String(report[11]) !== 'pending') {
      return {
        ok: false,
        error: 'field_report_not_pending',
        status: String(report[11])
      };
    }

    const fieldName = String(report[4]);

    if (!isSafeFieldPath_(fieldName)) {
      return {
        ok: false,
        error: 'invalid_field_path'
      };
    }

    const newValue = safeParse_(report[6], null);

    const current = safeParse_(rec.values[11], {});

    const oldValue = getPathValue_(
      current,
      fieldName
    );

    const currentBaseJson = JSON.stringify(
      oldValue === undefined ? null : oldValue
    );

    if (currentBaseJson !== String(report[5])) {
      return {
        ok: false,
        error: 'field_report_stale',
        message: 'اطلاعات این فیلد بعد از ثبت گزارش تغییر کرده است؛ گزارش را دوباره بررسی کنید.'
      };
    }

    setPathValue_(
      current,
      fieldName,
      newValue
    );

    const now = new Date().toISOString();

    current.updatedAt = now;

    const currentJson = JSON.stringify(current);

    if (currentJson.length > QOQNUS.MAX_RECORD_JSON_CHARS) {
      return {
        ok: false,
        error: 'record_too_large_for_sheet_cell'
      };
    }

    const version = (Number(rec.values[8]) || 1) + 1;

    const recordSheet = sheet_('Records');

    recordSheet.getRange(rec.row, 8).setValue(now);
    recordSheet.getRange(rec.row, 9).setValue(version);
    recordSheet.getRange(rec.row, 12).setValue(currentJson);

    historySheet
      .getRange(reportRow, 12)
      .setValue('applied');

    appendHistory_({
      recordId,
      kind: String(rec.values[1]),
      eventType: 'field_report_approved',
      fieldName,
      oldValue: JSON.stringify(
        oldValue === undefined ? null : oldValue
      ),
      newValue: String(report[6]),
      actor: device,
      eventAt: now,
      description: 'گزارش اصلاحی توسط دستگاه سازنده تأیید و در اطلاعات جاری اعمال شد.',
      operationId,
      status: 'applied'
    });

    appendChange_(
      recordId,
      String(rec.values[1]),
      'field_report_approved',
      version,
      device.deviceId,
      {
        recordId,
        historyId,
        fieldName,
        oldValue: oldValue === undefined ? null : oldValue,
        newValue,
        current,
        version,
        actorDeviceId: device.deviceId,
        actorName: device.name,
        eventAt: now
      }
    );

    const response = {
      ok: true,
      recordId,
      historyId,
      fieldName,
      oldValue: oldValue === undefined ? null : oldValue,
      newValue,
      version,
      status: 'applied'
    };

    saveOperation_(
      operationId,
      device.deviceId,
      'approve_field_report',
      recordId,
      response
    );

    return response;
  });
}

function isSafeFieldPath_(path) {
  if (!path || path.length > 140) return false;

  const parts = path.split('.');

  if (parts.length > 5) return false;

  const blocked = new Set([
    '__proto__',
    'prototype',
    'constructor',
    'id',
    'recordId',
    'centralRecordId',
    'ownerDeviceId',
    'ownerDeviceName',
    'createdAt',
    'created_at'
  ]);

  return parts.every(part =>
    /^[A-Za-z0-9_\u0600-\u06FF-]{1,60}$/.test(part) &&
    !blocked.has(part)
  );
}

function getPathValue_(obj, path) {
  let value = obj;

  for (const part of path.split('.')) {
    if (
      !value ||
      typeof value !== 'object' ||
      !Object.prototype.hasOwnProperty.call(value, part)
    ) {
      return undefined;
    }

    value = value[part];
  }

  return value;
}

function setPathValue_(obj, path, value) {
  const parts = path.split('.');

  let target = obj;

  for (let i = 0; i < parts.length - 1; i++) {
    if (
      !target[parts[i]] ||
      typeof target[parts[i]] !== 'object' ||
      Array.isArray(target[parts[i]])
    ) {
      target[parts[i]] = {};
    }

    target = target[parts[i]];
  }

  target[parts[parts.length - 1]] = value;
}

// ============================================================================
// PRIMARY UPDATE — OWNER DEVICE ONLY
// ============================================================================

function primaryUpdate_(device, body) {
  const recordId = String(body.recordId || '').trim();
  const operationId = String(body.operationId || '').trim();
  // Chrome sends `changes` + `record`; Android sends `newCurrent`.
  // Accept all three wire shapes so both clients share one mutation endpoint.
  const proposed = body.changes && typeof body.changes === 'object' && !Array.isArray(body.changes)
    ? body.changes
    : body.fields && typeof body.fields === 'object' && !Array.isArray(body.fields)
      ? body.fields
      : body.newCurrent && typeof body.newCurrent === 'object' && !Array.isArray(body.newCurrent)
        ? body.newCurrent
        : body.record && typeof body.record === 'object' && !Array.isArray(body.record)
          ? body.record
          : null;

  if (!recordId || !proposed || !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)) {
    return { ok:false, error:'invalid_primary_update' };
  }

  return withLock_(() => {
    const duplicate = findExact_('Operations', 1, operationId);
    if (duplicate) {
      if (String(duplicate.values[1]) !== String(device.deviceId) || String(duplicate.values[2]) !== 'primary_update') {
        return { ok:false, error:'operation_id_conflict' };
      }
      return replayOperation_(duplicate);
    }

    const rec = findRecordById_(recordId);
    if (!rec || String(rec.values[9]) === 'deleted') return { ok:false, error:'record_deleted' };

    const currentVersion = Math.max(1, Number(rec.values[8]) || 1);
    const expectedRaw = body.expectedVersion !== undefined ? body.expectedVersion : body.baseVersion;
    if (expectedRaw !== undefined && expectedRaw !== null && expectedRaw !== '') {
      const expectedVersion = Number(expectedRaw);
      if (!Number.isSafeInteger(expectedVersion) || expectedVersion !== currentVersion) {
        return { ok:false, error:'version_conflict', currentVersion, recordId, ownerDeviceId:String(rec.values[4]||'') };
      }
    }

    // Any authenticated active device may edit a live record. The ownerDeviceId
    // remains immutable: editing from another device never transfers ownership.
    const oldCurrent = safeParse_(rec.values[11], {});
    const protectedKeys = new Set([
      'id','recordId','localId','centralId','centralRecordId',
      'ownerDeviceId','ownerDeviceName','createdAt','created_at',
      'recordKind','sourceType','transferStage','transferNewRecordPending',
      'transferWasNewRecord','transferDataOperationId'
    ]);
    const next = { ...oldCurrent };
    for (const [key, value] of Object.entries(proposed)) {
      if (!protectedKeys.has(key)) next[key] = value;
    }

    const changes = diffFlat_(oldCurrent, next).slice(0, 150);
    if (!changes.length) {
      const response = { ok:true, recordId, version:currentVersion, unchanged:true, ownerDeviceId:String(rec.values[4] || '') };
      saveOperation_(operationId, device.deviceId, 'primary_update', recordId, response);
      return response;
    }

    const version = currentVersion + 1;
    const now = new Date().toISOString();
    next.updatedAt = now;
    next.version = version;
    next.syncStatus = 'synced';
    const json = JSON.stringify(next);
    if (json.length > QOQNUS.MAX_RECORD_JSON_CHARS) return { ok:false, error:'record_too_large_for_sheet_cell' };

    const sh = sheet_('Records');
    sh.getRange(rec.row, 8).setValue(now);
    sh.getRange(rec.row, 9).setValue(version);
    sh.getRange(rec.row, 12).setValue(json);

    const description = cleanText_(body.description || body.reason || 'ویرایش رکورد از دستگاه مجاز', 1200);
    changes.forEach(change => appendHistory_({
      recordId, kind:String(rec.values[1]), eventType:'field_change',
      fieldName:change.field, oldValue:change.oldValue, newValue:change.newValue,
      actor:device, eventAt:now, description, operationId, status:'applied'
    }));

    const seq = appendChange_(recordId, String(rec.values[1]), 'primary_update', version, device.deviceId, {
      recordId, kind:String(rec.values[1]), version, status:'active', current:next,
      changes, operationId, sourceDeviceId:device.deviceId
    });

    const response = { ok:true, recordId, version, seq, changedFields:changes.length, ownerDeviceId:String(rec.values[4] || '') };
    saveOperation_(operationId, device.deviceId, 'primary_update', recordId, response);
    return response;
  });
}

// ============================================================================
// DELETE RECORD — ANY AUTHORIZED DEVICE; KEEP A SERVER TOMBSTONE
// ============================================================================

function deleteRecord_(device, body) {
  const recordId = String(body.recordId || '').trim();
  const operationId = String(body.operationId || '').trim();
  if (!recordId || !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)) {
    return { ok:false, error:'invalid_delete_request' };
  }

  return withLock_(() => {
    const duplicate = findExact_('Operations', 1, operationId);
    if (duplicate) {
      if (String(duplicate.values[1]) !== String(device.deviceId) || String(duplicate.values[2]) !== 'delete_record') {
        return { ok:false, error:'operation_id_conflict' };
      }
      return replayOperation_(duplicate);
    }

    const rec = findRecordById_(recordId);
    if (!rec) return { ok:false, error:'record_not_found' };
    const currentVersion = Math.max(1, Number(rec.values[8]) || 1);
    if (String(rec.values[9]) === 'deleted') {
      const response = { ok:true, recordId, version:currentVersion, status:'deleted', duplicate:true };
      saveOperation_(operationId, device.deviceId, 'delete_record', recordId, response);
      return response;
    }

    // An explicit delete from any authenticated paired device is authoritative for
    // the latest server version. We intentionally do not reject a stale local base
    // version here: otherwise an offline device would retry the same delete forever.
    // Edits still use optimistic concurrency in primaryUpdate_ and cannot overwrite
    // a newer version without conflict resolution.

    // Do not physically remove the row/ID. This tombstone is how offline devices
    // learn about deletion and how the server prevents an old backup from resurrecting it.
    const version = currentVersion + 1;
    const now = new Date().toISOString();
    const kind = String(rec.values[1]);
    const localId = String(rec.values[2]);
    // Retain the immutable initial snapshot for audit/recovery, but remove the live
    // payload and image references from the active record. The record_id remains as
    // a minimal tombstone until every device has had a chance to consume the delete.
    const tombstone = {
      id:localId, localId, centralId:recordId, centralRecordId:recordId,
      recordKind:kind, version, syncStatus:'deleted', status:'deleted',
      deletedAt:now, deletedByDeviceId:device.deviceId
    };
    const sh = sheet_('Records');
    sh.getRange(rec.row, 8).setValue(now);
    sh.getRange(rec.row, 9).setValue(version);
    sh.getRange(rec.row, 10).setValue('deleted');
    sh.getRange(rec.row, 12).setValue(JSON.stringify(tombstone));
    sh.getRange(rec.row, 13).setValue(0);
    sh.getRange(rec.row, 14).setValue(0);
    // Mark image references inactive. Private Drive blobs are retained for recovery,
    // but no authenticated image endpoint serves them after a record tombstone.
    try {
      const imageTable = qoqnusImageSheetV14_();
      const imageRows = qoqnusImageRowsV14_(imageTable);
      for (let i = 0; i < imageRows.length; i++) {
        if (String(imageRows[i][imageTable.col('recordId') - 1]) === recordId && String(imageRows[i][imageTable.col('status') - 1] || 'active') === 'active') {
          imageTable.sh.getRange(i + 2, imageTable.col('status')).setValue('deleted');
        }
      }
    } catch (imageError) {
      console.warn('Could not mark deleted record images inactive:', imageError);
    }
    appendHistory_({
      recordId, kind, eventType:'record_deleted', actor:device, eventAt:now,
      description:cleanText_(body.description || body.reason || 'حذف از دستگاه مجاز', 1200),
      operationId, status:'applied'
    });
    const seq = appendChange_(recordId, kind, 'delete', version, device.deviceId, {
      recordId, localId, kind, version, status:'deleted', deletedAt:now,
      sourceDeviceId:device.deviceId, operationId
    });

    const response = { ok:true, recordId, localId, kind, version, seq, status:'deleted', deletedAt:now };
    saveOperation_(operationId, device.deviceId, 'delete_record', recordId, response);
    return response;
  });
}

// ============================================================================
// RECORD RETRIEVAL
// ============================================================================

function getRecord_(device, body) {
  const found = findRecordById_(
    String(body.recordId || '')
  );

  if (!found) {
    return {
      ok: false,
      error: 'record_not_found'
    };
  }

  const v = found.values;
  if (String(v[9] || '') === 'deleted') return { ok:false, error:'record_deleted' };

  const images = getImagesForRecord_(
    String(v[0])
  );

  return {
    ok: true,
    record: {
      recordId: String(v[0]),
      kind: String(v[1]),
      ownerDeviceId: String(v[4]),
      ownerDeviceName: String(v[5]),
      createdAt: String(v[6]),
      updatedAt: String(v[7]),
      version: Number(v[8]) || 1,
      status: String(v[9]),
      initial: safeParse_(v[10], {}),
      current: safeParse_(v[11], {})
    },
    images
  };
}

function removeHistoryEntry_(device, body) {
  const recordId = String(body.recordId || '');

  const historyId = String(body.historyId || '');

  const operationId = String(body.operationId || '');

  if (
    !recordId ||
    !historyId ||
    !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)
  ) {
    return {
      ok: false,
      error: 'invalid_history_removal'
    };
  }

  const duplicate = findExact_(
    'Operations',
    1,
    operationId
  );

  if (duplicate) {
    return replayOperation_(duplicate);
  }

  return withLock_(() => {
    const duplicateInsideLock = findExact_(
      'Operations',
      1,
      operationId
    );

    if (duplicateInsideLock) {
      return replayOperation_(duplicateInsideLock);
    }

    const rec = findRecordById_(recordId);

    if (!rec) {
      return {
        ok: false,
        error: 'record_not_found'
      };
    }

    if (String(rec.values[4]) !== device.deviceId) {
      return {
        ok: false,
        error: 'owner_device_only'
      };
    }

    const sh = sheet_('History');

    const values = sh.getDataRange().getValues();

    for (let i = 1; i < values.length; i++) {
      if (
        String(values[i][0]) !== historyId ||
        String(values[i][1]) !== recordId
      ) {
        continue;
      }

      const eventType = String(values[i][3]);

      if (![
        'manual_report',
        'field_change',
        'field_report'
      ].includes(eventType)) {
        return {
          ok: false,
          error: 'history_entry_protected'
        };
      }

      if (String(values[i][11]) === 'hidden') {
        return {
          ok: true,
          duplicate: true,
          historyId
        };
      }

      // Hide from normal display; retain audit trace.
      sh.getRange(i + 1, 12).setValue('hidden');

      const now = new Date().toISOString();

      appendHistory_({
        recordId,
        kind: String(rec.values[1]),
        eventType: 'history_entry_hidden',
        actor: device,
        eventAt: now,
        description: 'سابقه با درخواست دستگاه سازنده از نمایش عادی خارج شد؛ ردپای ممیزی حفظ شده است.',
        operationId,
        status: 'audit'
      });

      appendChange_(
        recordId,
        String(rec.values[1]),
        'history_hidden',
        Number(rec.values[8]) || 1,
        device.deviceId,
        {
          recordId,
          historyId,
          hidden: true,
          actorName: device.name,
          actorDeviceId: device.deviceId,
          eventAt: now
        }
      );

      const response = {
        ok: true,
        historyId,
        hidden: true
      };

      saveOperation_(
        operationId,
        device.deviceId,
        'remove_history_entry',
        recordId,
        response
      );

      return response;
    }

    return {
      ok: false,
      error: 'history_entry_not_found'
    };
  });
}

// ============================================================================
// TRANSFER RECORD OWNERSHIP — ADMIN ONLY
// ============================================================================

function transferRecordOwner_(recordId, targetDeviceId) {
  if (
    !recordId ||
    !isValidQoqnusDeviceId_(targetDeviceId)
  ) {
    return {
      ok: false,
      error: 'invalid_owner_transfer'
    };
  }

  return withLock_(() => {
    const rec = findRecordById_(recordId);

    if (!rec) {
      return {
        ok: false,
        error: 'record_not_found'
      };
    }

    const target = findExact_(
      'Devices',
      1,
      targetDeviceId
    );

    if (!target || String(target.values[5]) !== 'active') {
      return {
        ok: false,
        error: 'target_device_not_active'
      };
    }

    const now = new Date().toISOString();

    const sh = sheet_('Records');

    sh.getRange(rec.row, 5).setValue(targetDeviceId);

    sh.getRange(rec.row, 6).setValue(
      String(target.values[2])
    );

    const version = (Number(rec.values[8]) || 1) + 1;

    sh.getRange(rec.row, 8).setValue(now);
    sh.getRange(rec.row, 9).setValue(version);

    const adminActor = {
      deviceId: 'admin',
      name: 'مدیر مرکزی'
    };

    appendHistory_({
      recordId,
      kind: String(rec.values[1]),
      eventType: 'ownership_transferred',
      actor: adminActor,
      eventAt: now,
      description:
        'مالکیت ویرایش مشخصات اصلی با تأیید مدیر به دستگاه «' +
        String(target.values[2]) +
        '» منتقل شد.',
      status: 'applied'
    });

    appendChange_(
      recordId,
      String(rec.values[1]),
      'ownership_transferred',
      version,
      'admin',
      {
        recordId,
        ownerDeviceId: targetDeviceId,
        ownerDeviceName: String(target.values[2]),
        version
      }
    );

    return {
      ok: true,
      recordId,
      ownerDeviceId: targetDeviceId,
      ownerDeviceName: String(target.values[2]),
      version
    };
  });
}

// ============================================================================
// INCREMENTAL SYNC ENGINE
// ============================================================================

function qoqnusSyncEnsureAckSheet_() {
  return ensureSheet_('SyncAcks');
}

function qoqnusSyncFindAck_(deviceId) {
  const sh = qoqnusSyncEnsureAckSheet_();

  if (sh.getLastRow() < 2) {
    return null;
  }

  const cell = sh
    .getRange(2, 1, sh.getLastRow() - 1, 1)
    .createTextFinder(String(deviceId))
    .matchEntireCell(true)
    .findNext();

  if (!cell) {
    return null;
  }

  const row = cell.getRow();

  return {
    row,
    values: sh.getRange(
      row,
      1,
      1,
      QOQNUS.SHEETS.SyncAcks.length
    ).getValues()[0]
  };
}

function qoqnusSyncEnsureAckRow_(deviceId) {
  let found = qoqnusSyncFindAck_(deviceId);

  if (found) {
    return found;
  }

  const sh = qoqnusSyncEnsureAckSheet_();

  const now = new Date().toISOString();

  sh.appendRow([
    deviceId,
    0,
    now,
    '',
    0,
    ''
  ]);

  return qoqnusSyncFindAck_(deviceId);
}

function qoqnusSyncMaxSeq_() {
  const sh = sheet_('SyncChanges');

  if (sh.getLastRow() < 2) {
    return 0;
  }

  return Number(
    sh.getRange(sh.getLastRow(), 1).getValue()
  ) || 0;
}

function qoqnusSyncInitialize_(device, body) {
  if (!device || !device.deviceId) return { ok:false, error:'unauthorized_device' };
  const baselineSeq = Number(body.baselineSeq);
  if (!Number.isSafeInteger(baselineSeq) || baselineSeq < 0) return { ok:false, error:'invalid_sync_baseline' };
  return withLock_(() => {
    const existing = qoqnusSyncFindAck_(device.deviceId);
    if (existing) {
      return {
        ok:true, initialized:true, alreadyInitialized:true,
        deviceId:device.deviceId, ackedSeq:Math.max(0, Number(existing.values[1]) || 0),
        serverSeq:qoqnusSyncMaxSeq_()
      };
    }
    const serverSeq = qoqnusSyncMaxSeq_();
    if (baselineSeq > serverSeq) return { ok:false, error:'sync_baseline_ahead_of_server', serverSeq };
    const now = new Date().toISOString();
    qoqnusSyncEnsureAckSheet_().appendRow([
      device.deviceId, baselineSeq, now, now, baselineSeq,
      cleanText_(body.clientVersion || '', 80)
    ]);
    return {
      ok:true, initialized:true, deviceId:device.deviceId,
      ackedSeq:baselineSeq, serverSeq,
      pendingChanges:Math.max(0, serverSeq - baselineSeq)
    };
  });
}

function qoqnusSyncPull_(device, body) {
  return withLock_(() => {
    const ack = qoqnusSyncEnsureAckRow_(
      device.deviceId
    );

    const storedAck = Math.max(
      0,
      Number(ack.values[1]) || 0
    );

    const hasCursor =
      body.afterSeq !== undefined &&
      body.afterSeq !== null &&
      body.afterSeq !== '';

    const afterSeq = hasCursor
      ? Number(body.afterSeq)
      : storedAck;

    const limit = Math.max(
      1,
      Math.min(
        QOQNUS.MAX_PULL_LIMIT,
        Math.floor(Number(body.limit) || 100)
      )
    );

    if (
      !Number.isSafeInteger(afterSeq) ||
      afterSeq < 0
    ) {
      return {
        ok: false,
        error: 'invalid_sync_cursor'
      };
    }

    if (afterSeq !== storedAck) {
      return {
        ok: false,
        error: 'cursor_mismatch',
        expectedAfterSeq: storedAck
      };
    }

    const sh = sheet_('SyncChanges');

    const values = sh.getDataRange().getValues();

    const serverSeq = qoqnusSyncMaxSeq_();

    const changes = [];

    for (let i = 1; i < values.length; i++) {
      const r = values[i];

      const seq = Number(r[0]) || 0;

      if (seq <= afterSeq) {
        continue;
      }

      const eventType = String(r[3]);
      const payload = safeParse_(r[7], {});
      const metadataOnly = body.metadataOnly === true;
      const status = payload && String(payload.status || '') === 'deleted' || ['delete','record_deleted'].includes(eventType)
        ? 'deleted' : 'active';
      const change = {
        seq,
        recordId: String(r[1]),
        kind: String(r[2]),
        eventType,
        version: Number(r[4]) || 0,
        actorDeviceId: String(r[5]),
        createdAt: String(r[6]),
        status
      };
      if (metadataOnly !== true) change.payload = payload;
      changes.push(change);

      if (changes.length >= limit) {
        break;
      }
    }

    changes.sort((a, b) => a.seq - b.seq);

    const nextSeq = changes.length
      ? changes[changes.length - 1].seq
      : afterSeq;

    const hasMore = serverSeq > nextSeq;

    const latestAck = qoqnusSyncFindAck_(
      device.deviceId
    );

    if (latestAck) {
      const now = new Date().toISOString();

      const ackSheet = qoqnusSyncEnsureAckSheet_();

      ackSheet
        .getRange(latestAck.row, 4)
        .setValue(now);

      if (changes.length) {
        ackSheet
          .getRange(latestAck.row, 5)
          .setValue(
            Math.max(
              Number(latestAck.values[4]) || 0,
              nextSeq
            )
          );
      }
    }

    return {
      ok: true,
      changes,
      fromSeq: afterSeq,
      nextSeq,
      serverSeq,
      hasMore,
      requiresAck: changes.length > 0
    };
  });
}

function qoqnusSyncAck_(device, body) {
  const ackSeq = Number(body.ackSeq);

  if (
    !Number.isSafeInteger(ackSeq) ||
    ackSeq < 0
  ) {
    return {
      ok: false,
      error: 'invalid_ack_cursor'
    };
  }

  return withLock_(() => {
    const serverSeq = qoqnusSyncMaxSeq_();

    if (ackSeq > serverSeq) {
      return {
        ok: false,
        error: 'ack_ahead_of_server',
        serverSeq
      };
    }

    const sh = qoqnusSyncEnsureAckSheet_();

    const found = qoqnusSyncEnsureAckRow_(
      device.deviceId
    );

    const now = new Date().toISOString();

    const oldAck = Math.max(
      0,
      Number(found.values[1]) || 0
    );

    const lastDelivered = Math.max(
      0,
      Number(found.values[4]) || 0
    );

    if (ackSeq < oldAck) {
      return {
        ok: false,
        error: 'ack_cursor_cannot_move_backwards',
        ackedSeq: oldAck
      };
    }

    if (ackSeq > lastDelivered) {
      return {
        ok: false,
        error: 'ack_not_delivered_to_device',
        lastDeliveredSeq: lastDelivered
      };
    }

    const clientVersion = String(
      body.clientVersion || ''
    ).trim().slice(0, 80);

    sh.getRange(found.row, 2).setValue(ackSeq);
    sh.getRange(found.row, 3).setValue(now);

    if (clientVersion) {
      sh.getRange(found.row, 6).setValue(clientVersion);
    }

    return {
      ok: true,
      deviceId: device.deviceId,
      ackedSeq: ackSeq,
      serverSeq,
      pendingChanges: Math.max(0, serverSeq - ackSeq)
    };
  });
}

function qoqnusSyncState_(device) {
  const found = qoqnusSyncFindAck_(
    device.deviceId
  );

  const ackedSeq = found
    ? Math.max(0, Number(found.values[1]) || 0)
    : 0;

  const lastDeliveredSeq = found
    ? Math.max(0, Number(found.values[4]) || 0)
    : 0;

  const serverSeq = qoqnusSyncMaxSeq_();

  return {
    ok: true,
    deviceId: device.deviceId,
    initialized: !!found,
    ackedSeq,
    lastDeliveredSeq,
    serverSeq,
    pendingChanges: Math.max(0, serverSeq - ackedSeq),
    syncVersion: QOQNUS.VERSION
  };
}

// ============================================================================
// ACCOUNT-WIDE REVIEW DECISIONS (stored in the existing History/Operations sheets)
// ============================================================================
function qoqnusReviewDecisionValue_(row) {
  const parsed = safeParse_(row[6], {});
  const version = Math.max(1, Number(parsed.version) || 0);
  const decision = String(parsed.decision || row[11] || '');
  if (!version || !['approved','rejected','finalArchived'].includes(decision)) return null;
  return { recordId:String(row[1] || ''), kind:String(row[2] || ''), version, decision, decidedAt:String(row[9] || ''), actorDeviceId:String(row[7] || '') };
}

function qoqnusGetReviewDecisions_(device, body) {
  if (!device || !device.deviceId) return { ok:false, error:'unauthorized_device' };
  const ids = Array.isArray(body.recordIds) ? [...new Set(body.recordIds.map(x => String(x || '').trim()).filter(Boolean))] : [];
  if (!ids.length || ids.length > 500) return { ok:false, error:'invalid_review_record_ids' };
  const wanted = Object.create(null); ids.forEach(id => { if (id.length <= 180) wanted[id] = true; });
  const sh = sheet_('History');
  const last = sh.getLastRow();
  if (last < 2) return { ok:true, decisions:[] };
  const values = sh.getRange(2, 1, last - 1, 13).getValues();
  const map = new Map();
  for (const row of values) {
    if (String(row[3] || '') !== 'central_review_decision') continue;
    const recordId = String(row[1] || ''); if (!wanted[recordId]) continue;
    const decision = qoqnusReviewDecisionValue_(row); if (!decision) continue;
    map.set(recordId + ':' + decision.version, decision);
  }
  return { ok:true, decisions:[...map.values()] };
}

function qoqnusSetReviewDecision_(device, body) {
  if (!device || !device.deviceId) return { ok:false, error:'unauthorized_device' };
  const recordId = String(body.recordId || '').trim();
  const version = Number(body.version);
  const operationId = String(body.operationId || '').trim();
  const raw = String(body.decision || '').trim();
  const decision = raw === 'save' ? 'approved' : raw === 'discard' ? 'rejected' : raw === 'finalArchive' ? 'finalArchived' : raw;
  if (!recordId || !Number.isSafeInteger(version) || version < 1 || !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId) || !['approved','rejected','finalArchived'].includes(decision)) {
    return { ok:false, error:'invalid_review_decision' };
  }
  return withLock_(() => {
    const priorOperation = findExact_('Operations', 1, operationId);
    if (priorOperation) {
      if (String(priorOperation.values[1]) !== String(device.deviceId) || String(priorOperation.values[2]) !== 'set_review_decision') return { ok:false, error:'operation_id_conflict' };
      return replayOperation_(priorOperation);
    }
    const rec = findRecordById_(recordId);
    if (!rec) return { ok:false, error:'record_not_found' };
    if (String(rec.values[9]) === 'deleted') return { ok:false, error:'record_deleted' };
    const currentVersion = Math.max(1, Number(rec.values[8]) || 1);
    if (currentVersion !== version) return { ok:false, error:'version_conflict', currentVersion, recordId, ownerDeviceId:String(rec.values[4]||'') };
    const history = sheet_('History');
    const all = history.getDataRange().getValues();
    for (let i=1; i<all.length; i++) {
      const row = all[i];
      if (String(row[1]) !== recordId || String(row[3]) !== 'central_review_decision') continue;
      const prior = qoqnusReviewDecisionValue_(row);
      if (!prior || prior.version !== version) continue;
      if (prior.decision !== decision) return { ok:false, error:'decision_already_recorded', decision:prior.decision, version };
      const response = { ok:true, duplicate:true, recordId, version, decision, decidedAt:prior.decidedAt };
      saveOperation_(operationId, device.deviceId, 'set_review_decision', recordId, response);
      return response;
    }
    const now = new Date().toISOString();
    const historyId = appendHistory_({
      recordId, kind:String(rec.values[1]), eventType:'central_review_decision', fieldName:'version',
      oldValue:'', newValue:JSON.stringify({version,decision}), actor:device, eventAt:now,
      description:'تصمیم مشترک حساب برای نسخه ' + version, operationId, status:decision
    });
    const response = { ok:true, duplicate:false, recordId, historyId, version, decision, decidedAt:now };
    saveOperation_(operationId, device.deviceId, 'set_review_decision', recordId, response);
    return response;
  });
}

// ============================================================================
// PRIVATE IMAGE RETRIEVAL
// ============================================================================

function qoqnusGetImage_(device, body) {
  const imageId = String(body.imageId || '');

  if (!/^[a-f0-9]{32}$/i.test(imageId)) {
    return {
      ok: false,
      error: 'invalid_image_id'
    };
  }

  const found = findExact_(
    'Images',
    1,
    imageId
  );

  if (!found) {
    return {
      ok: false,
      error: 'image_not_found'
    };
  }

  const recordId = String(found.values[1]);

  const record = findRecordById_(recordId);

  if (
    !record ||
    String(record.values[9]) === 'deleted'
  ) {
    return {
      ok: false,
      error: 'record_not_available'
    };
  }

  const bytes = DriveApp
    .getFileById(String(found.values[5]))
    .getBlob()
    .getBytes();

  if (
    !bytes.length ||
    bytes.length > QOQNUS.MAX_IMAGE_BYTES ||
    !isWebpBytes_(bytes)
  ) {
    return {
      ok: false,
      error: 'stored_image_invalid'
    };
  }

  return {
    ok: true,
    imageId,
    recordId,
    mimeType: 'image/webp',
    dataUrl: 'data:image/webp;base64,' +
      Utilities.base64Encode(bytes),
    sha256: String(found.values[6]),
    bytes: bytes.length
  };
}

// ============================================================================
// HISTORY RETRIEVAL
// ============================================================================

function qoqnusGetHistory_(device, body) {
  const recordId = String(body.recordId || '');

  const record = findRecordById_(recordId);

  if (!record) {
    return {
      ok: false,
      error: 'record_not_found'
    };
  }

  const includeHidden =
    body.includeHidden === true &&
    String(record.values[4]) === device.deviceId;

  const values = sheet_('History')
    .getDataRange()
    .getValues();

  const history = values
    .slice(1)
    .filter(r =>
      String(r[1]) === recordId &&
      (includeHidden || String(r[11]) !== 'hidden')
    )
    .map(r => ({
      historyId: String(r[0]),
      eventType: String(r[3]),
      fieldName: String(r[4]),
      oldValue: String(r[5]),
      newValue: String(r[6]),
      actorDeviceId: String(r[7]),
      actorName: String(r[8]),
      eventAt: String(r[9]),
      description: String(r[10]),
      status: String(r[11])
    }));

  return {
    ok: true,
    history,
    hiddenIncluded: includeHidden
  };
}

// ============================================================================
// CENTRAL STATUS
// ============================================================================

function statusForDevice_(device) {
  const records = sheet_('Records')
    .getDataRange()
    .getValues();

  const images = sheet_('Images').getLastRow();

  const devices = sheet_('Devices')
    .getDataRange()
    .getValues();

  return {
    ok: true,
    service: 'Qoqnus Central',
    version: QOQNUS.VERSION,

    device: {
      deviceId: device.deviceId,
      name: device.name,
      type: device.type
    },

    counts: {
      records: Math.max(0, records.length - 1),

      customers: records.slice(1).filter(r =>
        String(r[1]) === 'customer' &&
        String(r[9]) !== 'deleted'
      ).length,

      files: records.slice(1).filter(r =>
        String(r[1]) === 'file' &&
        String(r[9]) !== 'deleted'
      ).length,

      listings: records.slice(1).filter(r =>
        String(r[1]) === 'listing' &&
        String(r[9]) !== 'deleted'
      ).length,

      images: Math.max(0, images - 1),

      activeDevices: devices.slice(1).filter(r =>
        String(r[5]) === 'active'
      ).length
    },

    sync: qoqnusSyncState_(device)
  };
}

// ============================================================================
// COMMON UTILITIES
// ============================================================================

function parseBody_(e) {
  const raw =
    e &&
    e.postData &&
    e.postData.contents
      ? e.postData.contents
      : '';

  if (!raw || raw.length > 7000000) {
    throw new Error('invalid_request_body');
  }

  try {
    return JSON.parse(raw);
  } catch (_) {
    throw new Error('invalid_json');
  }
}

function jsonOut_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function ensureSheet_(name) {
  const ss = SpreadsheetApp.openById(
    PropertiesService
      .getScriptProperties()
      .getProperty('QOQNUS_SPREADSHEET_ID')
  );

  let sh = ss.getSheetByName(name);

  if (!sh) {
    sh = ss.insertSheet(name);
  }

  const expected = QOQNUS.SHEETS[name];

  const lastCol = Math.max(
    1,
    sh.getLastColumn()
  );

  const first = sh
    .getRange(
      1,
      1,
      1,
      Math.max(lastCol, expected.length)
    )
    .getValues()[0];

  const empty = first.every(
    x => x === '' || x === null
  );

  if (empty) {
    sh.getRange(
      1,
      1,
      1,
      expected.length
    ).setValues([expected]);

  } else {
    const actual = first
      .slice(0, expected.length)
      .map(String);

    if (actual.join('|') !== expected.join('|')) {
      throw new Error('sheet_header_mismatch_' + name);
    }
  }

  sh.setFrozenRows(1);

  return sh;
}

function sheet_(name) {
  return ensureSheet_(name);
}

function headerMap_(headers) {
  const out = {};

  headers.forEach((x, i) => {
    out[String(x)] = i;
  });

  return out;
}

function findExact_(sheetName, column1Based, value) {
  const sh = sheet_(sheetName);

  if (sh.getLastRow() < 2) {
    return null;
  }

  const cell = sh
    .getRange(
      2,
      column1Based,
      sh.getLastRow() - 1,
      1
    )
    .createTextFinder(String(value))
    .matchEntireCell(true)
    .findNext();

  if (!cell) {
    return null;
  }

  const row = cell.getRow();

  return {
    row,
    values: sh
      .getRange(row, 1, 1, sh.getLastColumn())
      .getValues()[0]
  };
}

function findRecordByOrigin_(deviceId, kind, localId) {
  const sh = sheet_('Records');

  if (sh.getLastRow() < 2) {
    return null;
  }

  const values = sh.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (
      String(values[i][3]) === deviceId &&
      String(values[i][1]) === kind &&
      String(values[i][2]) === localId
    ) {
      return {
        row: i + 1,
        values: values[i]
      };
    }
  }

  return null;
}

function findRecordById_(recordId) {
  return findExact_('Records', 1, recordId);
}

function appendHistory_(event) {
  const historyId = Utilities
    .getUuid()
    .replace(/-/g, '')
    .toLowerCase();

  const actor = event.actor || {};

  sheet_('History').appendRow([
    historyId,
    event.recordId || '',
    event.kind || '',
    event.eventType || 'note',
    event.fieldName || '',
    cellSafe_(event.oldValue),
    cellSafe_(event.newValue),
    actor.deviceId || '',
    actor.name || '',
    event.eventAt || new Date().toISOString(),
    cleanText_(event.description || '', 3000),
    event.status || 'recorded',
    event.operationId || ''
  ]);

  return historyId;
}

function appendChange_(
  recordId,
  kind,
  eventType,
  version,
  actorDeviceId,
  payload
) {
  const sh = sheet_('SyncChanges');

  const seq = qoqnusSyncMaxSeq_() + 1;

  sh.appendRow([
    seq,
    recordId,
    kind,
    eventType,
    version,
    actorDeviceId,
    new Date().toISOString(),
    JSON.stringify(payload || {})
  ]);

  return seq;
}

function saveOperation_(
  operationId,
  deviceId,
  action,
  recordId,
  response
) {
  sheet_('Operations').appendRow([
    operationId,
    deviceId,
    action,
    recordId,
    JSON.stringify(response),
    new Date().toISOString()
  ]);
}

function replayOperation_(row) {
  const prior = safeParse_(
    row && row.values ? row.values[4] : '',
    { ok: true }
  );

  return {
    ...prior,
    duplicate: true
  };
}

function getImagesForRecord_(recordId) {
  const sh = sheet_('Images');

  if (sh.getLastRow() < 2) {
    return [];
  }

  const values = sh.getDataRange().getValues();

  return values
    .slice(1)
    .filter(r => String(r[1]) === recordId)
    .map(r => ({
      imageId: String(r[0]),
      index: Number(r[2]) || 0,
      mimeType: String(r[4]),
      driveFileId: String(r[5]),
      sha256: String(r[6]),
      bytes: Number(r[7]) || 0
    }));
}

function stripInlineMedia_(value) {
  if (Array.isArray(value)) {
    return value
      .map(stripInlineMedia_)
      .filter(v => v !== undefined);
  }

  if (!value || typeof value !== 'object') {
    if (
      typeof value === 'string' &&
      /^data:image\//i.test(value)
    ) {
      return undefined;
    }

    return value;
  }

  const out = {};

  Object.keys(value).forEach(key => {
    const v = value[key];

    if (
      /^(imageDataUrls?|localImageDataUrls|photoDataUrls?|localPhotos|imageBlob|photoBlob|images)$/i.test(key)
    ) {
      if (Array.isArray(v)) {
        const links = v.filter(x =>
          typeof x === 'string' &&
          /^https?:\/\//i.test(x)
        );

        if (links.length) {
          out.sourceImageUrls = links.slice(0, 20);
        }

      } else if (
        typeof v === 'string' &&
        /^https?:\/\//i.test(v)
      ) {
        out.sourceImageUrls = [v];
      }

      return;
    }

    const cleaned = stripInlineMedia_(v);

    if (cleaned !== undefined) {
      out[key] = cleaned;
    }
  });

  return out;
}

function diffFlat_(before, after) {
  const flatten = (obj, prefix, out) => {
    Object.keys(obj || {}).forEach(k => {
      if (
        /^(imageDataUrls?|images|imageUrls|sourceImageUrls|centralRecordId|ownerDeviceId|ownerDeviceName)$/i.test(k)
      ) {
        return;
      }

      const value = obj[k];

      const path = prefix
        ? prefix + '.' + k
        : k;

      if (
        value &&
        typeof value === 'object' &&
        !Array.isArray(value)
      ) {
        flatten(value, path, out);
      } else {
        out[path] = JSON.stringify(value);
      }
    });

    return out;
  };

  const a = flatten(before || {}, '', {});
  const b = flatten(after || {}, '', {});

  const keys = new Set([
    ...Object.keys(a),
    ...Object.keys(b)
  ]);

  const changes = [];

  keys.forEach(k => {
    if (a[k] !== b[k]) {
      changes.push({
        field: k,
        oldValue: a[k] === undefined ? '' : a[k],
        newValue: b[k] === undefined ? '' : b[k]
      });
    }
  });

  return changes;
}

function updateImportImageCount_(recordId) {
  return getImagesForRecord_(recordId).length;
}

function withLock_(fn) {
  const lock = LockService.getScriptLock();

  if (!lock.tryLock(20000)) {
    return {
      ok: false,
      error: 'server_busy_retry'
    };
  }

  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}

// ============================================================================
// WEBP VALIDATION
// ============================================================================

function isWebpBytes_(bytes) {
  if (!bytes || bytes.length < 12) {
    return false;
  }

  const ascii = bytes
    .slice(0, 12)
    .map(b =>
      String.fromCharCode((b + 256) % 256)
    )
    .join('');

  return (
    ascii.slice(0, 4) === 'RIFF' &&
    ascii.slice(8, 12) === 'WEBP'
  );
}

function webpDimensions_(bytes) {
  if (!isWebpBytes_(bytes)) {
    return null;
  }

  const u = i =>
    (Number(bytes[i]) + 256) % 256;

  const text = (start, count) =>
    bytes
      .slice(start, start + count)
      .map(b =>
        String.fromCharCode((Number(b) + 256) % 256)
      )
      .join('');

  let offset = 12;

  while (offset + 8 <= bytes.length) {
    const type = text(offset, 4);

    const size =
      u(offset + 4) |
      (u(offset + 5) << 8) |
      (u(offset + 6) << 16) |
      (u(offset + 7) << 24);

    const data = offset + 8;

    if (size < 0 || data + size > bytes.length) {
      return null;
    }

    if (type === 'VP8X' && size >= 10) {
      const width =
        1 +
        u(data + 4) +
        (u(data + 5) << 8) +
        (u(data + 6) << 16);

      const height =
        1 +
        u(data + 7) +
        (u(data + 8) << 8) +
        (u(data + 9) << 16);

      return {
        width,
        height
      };
    }

    if (
      type === 'VP8L' &&
      size >= 5 &&
      u(data) === 0x2f
    ) {
      const width =
        1 +
        ((u(data + 2) & 0x3f) << 8) +
        u(data + 1);

      const height =
        1 +
        ((u(data + 4) & 0x0f) << 10) +
        (u(data + 3) << 2) +
        ((u(data + 2) & 0xc0) >> 6);

      return {
        width,
        height
      };
    }

    if (
      type === 'VP8 ' &&
      size >= 10 &&
      u(data + 3) === 0x9d &&
      u(data + 4) === 0x01 &&
      u(data + 5) === 0x2a
    ) {
      const width =
        ((u(data + 7) << 8) | u(data + 6)) & 0x3fff;

      const height =
        ((u(data + 9) << 8) | u(data + 8)) & 0x3fff;

      return {
        width,
        height
      };
    }

    offset = data + size + (size % 2);
  }

  return null;
}

// ============================================================================
// CRYPTOGRAPHIC AND TEXT UTILITIES
// ============================================================================

function sha256_(value) {
  return sha256Bytes_(
    Utilities
      .newBlob(String(value), 'text/plain')
      .getBytes()
  );
}

function sha256Bytes_(bytes) {
  const digest = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    bytes
  );

  return digest.map(b =>
    ('0' + ((b + 256) % 256).toString(16)).slice(-2)
  ).join('');
}

function randomSecret_() {
  return (
    Utilities.getUuid().replace(/-/g, '') +
    Utilities.getUuid().replace(/-/g, '')
  );
}

function constantTimeEqual_(a, b) {
  a = String(a || '');
  b = String(b || '');

  if (a.length !== b.length) {
    return false;
  }

  let diff = 0;

  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }

  return diff === 0;
}

function cleanText_(value, max) {
  return String(value == null ? '' : value)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max || 1000);
}

function cleanFileName_(value) {
  return cleanText_(value, 100)
    .replace(/[\\/:*?"<>|]/g, '_') ||
    'qoqnus-image.webp';
}

function safeDate_(value, fallback) {
  const n = Number(value);

  if (Number.isFinite(n) && n > 0) {
    return new Date(n).toISOString();
  }

  const d = new Date(value);

  return isNaN(d.getTime())
    ? fallback
    : d.toISOString();
}

function cellSafe_(value) {
  const s = value == null
    ? ''
    : String(value);

  return s.length > 40000
    ? s.slice(0, 40000)
    : s;
}

function safeParse_(value, fallback) {
  try {
    return JSON.parse(String(value || ''));
  } catch (_) {
    return fallback;
  }
}

function safeErrorCode_(err) {
  const s = String(
    err && err.message || 'internal_error'
  );

  return /^[a-zA-Z0-9_-]{2,80}$/.test(s)
    ? s
    : 'internal_error';
}


// ===== Integrated Qoqnus_Central_V13_Registration_Patch.gs =====
/**
 * QOQNUS CENTRAL OFFICE - V1.3.0 compatibility patch
 * Add this file to the existing Apps Script project.
 * Do NOT replace Code.gs with this file.
 *
 * Required doPost switch additions are documented in INSTALL_FA.md.
 * Uses existing v1.2 helpers: withLock_, findExact_, findRecordByOrigin_,
 * findRecordById_, sheet_, stripInlineMedia_, safeDate_, cleanText_,
 * appendHistory_, appendChange_, saveOperation_, replayOperation_,
 * safeParse_, QOQNUS, MAX_RECORD_JSON_CHARS.
 */
'use strict';

/** Complete the audit, sync-change and operation rows for the one-request save path.
 * The record JSON carries transferDataOperationId first, so a retry can repair any
 * side effects missing after an Apps Script execution was interrupted.
 */
function qoqnusEnsureSaveRecordEffectsV16_(device, recordId, kind, localId, record, version, operationId, expectedImages, isNew, recovered, storedImages) {
  const response = {
    ok: true,
    duplicate: !!recovered,
    recovered: !!recovered,
    operationId,
    kind,
    localId,
    recordId,
    centralId: recordId,
    version,
    ownerDeviceId: device.deviceId,
    syncStatus: 'synced',
    stage: 'complete',
    reviewStatus: record.reviewStatus,
    publicationStatus: record.publicationStatus,
    expectedImages,
    storedImages: Math.max(0, Number(storedImages) || 0)
  };

  if (!qoqnusHasHistoryOperationV16_(operationId)) {
    appendHistory_({
      recordId, kind,
      eventType: isNew ? 'record_created' : 'record_updated',
      actor: device,
      eventAt: new Date().toISOString(),
      description: isNew
        ? 'ثبت رکورد جدید در دفتر مرکزی با انتقال یک‌درخواستی'
        : 'به‌روزرسانی رکورد در دفتر مرکزی با انتقال یک‌درخواستی',
      operationId,
      status: 'applied'
    });
  }

  if (!qoqnusHasSyncChangeOperationV16_(operationId, recordId, '')) {
    appendChange_(recordId, kind, isNew ? 'record_created' : 'record_updated', version, device.deviceId, {
      recordId, centralId: recordId, localId, kind, recordKind: kind,
      sourceType: record.sourceType, record, version, syncStatus: 'synced', operationId
    });
  }

  const prior = findExact_('Operations', 1, operationId);
  if (prior) {
    if (String(prior.values[1]) !== String(device.deviceId) || String(prior.values[2]) !== 'save_record') {
      throw new Error('operation_id_conflict');
    }
    return replayOperation_(prior);
  }
  saveOperation_(operationId, device.deviceId, 'save_record', recordId, response);
  return response;
}

/** One web request may carry up to 20 records. Each row retains its own stable
 * operationId, and the underlying single-record handler locks each mutation.
 */
function qoqnusSaveRecordsBatchV16_(device, body) {
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length || items.length > 20) return { ok: false, error: 'invalid_save_batch' };
  const results = [];
  for (const item of items) {
    try {
      const result = qoqnusSaveRecordV13_(device, item || {});
      results.push({
        ...result,
        kind: String(result && result.kind || item && item.kind || ''),
        localId: String(result && result.localId || item && item.localId || ''),
        operationId: String(result && result.operationId || item && item.operationId || '')
      });
    } catch (error) {
      results.push({
        ok: false,
        kind: String(item && item.kind || ''),
        localId: String(item && item.localId || ''),
        operationId: String(item && item.operationId || ''),
        error: safeErrorCode_(error),
        message: String(error && error.message || '').slice(0, 180)
      });
    }
  }
  return {
    ok: true,
    phase: 'records',
    results,
    accepted: results.filter(x => x && x.ok === true).length,
    failed: results.filter(x => !x || x.ok !== true).length
  };
}

function qoqnusSaveRecordV13_(device, body) {
  const operationId = String(body.operationId || '').trim();
  const kind = String(body.kind || body.recordKind || '').trim();
  const localId = String(body.localId || (body.record && body.record.id) || '').trim();
  const source = body.record && typeof body.record === 'object' && !Array.isArray(body.record)
    ? body.record
    : null;

  if (!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)) return { ok: false, error: 'invalid_operation_id' };
  if (!['customer', 'file', 'listing'].includes(kind)) return { ok: false, error: 'invalid_record_kind' };
  if (!localId || localId.length > 180) return { ok: false, error: 'invalid_local_id' };
  if (!source) return { ok: false, error: 'missing_record_payload' };

  const expectedImages = Math.max(0, Math.min(20, Math.floor(Number(body.expectedImages) || 0)));

  return withLock_(() => {
    const priorOperation = findExact_('Operations', 1, operationId);
    if (priorOperation) {
      if (String(priorOperation.values[1]) !== device.deviceId || String(priorOperation.values[2]) !== 'save_record') {
        return { ok: false, error: 'operation_id_conflict' };
      }
      return replayOperation_(priorOperation);
    }

    const existing = findRecordByOrigin_(device.deviceId, kind, localId);
    if (existing) {
      if (String(existing.values[9]) === 'deleted') return { ok: false, error: 'local_record_already_deleted' };
      const existingId = String(existing.values[0]);
      const ownerId = String(existing.values[4] || '');
      if (ownerId !== String(device.deviceId)) return { ok: false, error: 'record_owner_device_only' };

      const oldCurrent = safeParse_(existing.values[11], {});
      const isStaging = String(existing.values[9]) === 'staging' || oldCurrent.transferNewRecordPending === true;
      const alreadyApplied = String(oldCurrent.transferDataOperationId || '') === operationId && String(oldCurrent.transferStage || '') === 'complete';
      const createdAt = safeDate_(source.createdAt || source.created_at, String(existing.values[6] || new Date().toISOString()));
      const currentVersion = Math.max(0, Number(existing.values[8]) || 0);

      if (alreadyApplied) {
        const version = Math.max(1, currentVersion, Number(oldCurrent.version) || 0);
        const repairSheet = sheet_('Records');
        // Finish any metadata writes that may have been interrupted after the
        // marked payload reached current_json. For a newly reserved row, also
        // complete the immutable initial snapshot before making it visible.
        if (oldCurrent.transferWasNewRecord === true) {
          repairSheet.getRange(existing.row, 11).setValue(JSON.stringify(oldCurrent));
        }
        repairSheet.getRange(existing.row, 8).setValue(String(oldCurrent.updatedAt || new Date().toISOString()));
        repairSheet.getRange(existing.row, 9).setValue(version);
        repairSheet.getRange(existing.row, 10).setValue('active');
        const repairedExpectedImages = Math.max(Number(existing.values[12]) || 0, expectedImages);
        repairSheet.getRange(existing.row, 13).setValue(repairedExpectedImages);
        return qoqnusEnsureSaveRecordEffectsV16_(
          device, existingId, kind, localId, oldCurrent, version, operationId,
          repairedExpectedImages, oldCurrent.transferWasNewRecord === true, true, Number(existing.values[13]) || 0
        );
      }

      const nextVersion = isStaging ? 1 : Math.max(1, currentVersion) + 1;
      const normalizedSource = {
        ...source,
        centralImages: Array.isArray(source.centralImages)
          ? source.centralImages
          : (Array.isArray(oldCurrent.centralImages) ? oldCurrent.centralImages : [])
      };
      const cleanRecord = qoqnusNormalizeRecordV13_(
        normalizedSource, kind, localId, existingId, device,
        createdAt, new Date().toISOString(), nextVersion, false
      );
      cleanRecord.transferStage = 'complete';
      cleanRecord.transferNewRecordPending = false;
      cleanRecord.transferWasNewRecord = isStaging;
      cleanRecord.transferDataOperationId = operationId;
      const cleanJson = JSON.stringify(cleanRecord);
      if (cleanJson.length > QOQNUS.MAX_RECORD_JSON_CHARS) return { ok: false, error: 'record_too_large_for_sheet_cell' };

      const recordsSheet = sheet_('Records');
      // The operation marker is written with the full payload first. A retry can
      // then distinguish a committed row from a transfer that never reached Sheets.
      recordsSheet.getRange(existing.row, 12).setValue(cleanJson);
      if (isStaging) recordsSheet.getRange(existing.row, 11).setValue(cleanJson);
      recordsSheet.getRange(existing.row, 8).setValue(new Date().toISOString());
      recordsSheet.getRange(existing.row, 9).setValue(nextVersion);
      recordsSheet.getRange(existing.row, 10).setValue('active');
      const nextExpectedImages = Math.max(Number(existing.values[12]) || 0, expectedImages);
      recordsSheet.getRange(existing.row, 13).setValue(nextExpectedImages);

      return qoqnusEnsureSaveRecordEffectsV16_(
        device, existingId, kind, localId, cleanRecord, nextVersion, operationId,
        nextExpectedImages, isStaging, false, Number(existing.values[13]) || 0
      );
    }

    const stripped = stripInlineMedia_(source);
    const nowIso = new Date().toISOString();
    const createdAt = safeDate_(source.createdAt || source.created_at, nowIso);
    const recordId = Utilities.getUuid().replace(/-/g, '').toLowerCase();
    const cleanRecord = qoqnusNormalizeRecordV13_(stripped, kind, localId, recordId, device, createdAt, nowIso, 1, false);
    cleanRecord.transferStage = 'complete';
    cleanRecord.transferNewRecordPending = false;
    cleanRecord.transferWasNewRecord = true;
    cleanRecord.transferDataOperationId = operationId;
    const cleanJson = JSON.stringify(cleanRecord);
    if (cleanJson.length > QOQNUS.MAX_RECORD_JSON_CHARS) return { ok: false, error: 'record_too_large_for_sheet_cell' };

    sheet_('Records').appendRow([
      recordId, kind, localId, device.deviceId, device.deviceId, device.name,
      createdAt, nowIso, 1, 'active', cleanJson, cleanJson,
      expectedImages, 0, 0, ''
    ]);

    return qoqnusEnsureSaveRecordEffectsV16_(
      device, recordId, kind, localId, cleanRecord, 1, operationId,
      expectedImages, true, false
    );
  });
}

function qoqnusUpdateListingStatusV13_(device, body) {
  const recordId = String(body.recordId || '').trim();
  const operationId = String(body.operationId || '').trim();
  const hasReview = Object.prototype.hasOwnProperty.call(body, 'reviewStatus');
  const hasRubika = body.rubika && typeof body.rubika === 'object';
  const hasEitaa = body.eitaa && typeof body.eitaa === 'object';

  if (!recordId || !/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)) {
    return { ok: false, error: 'invalid_listing_status_request' };
  }
  if (!hasReview && !hasRubika && !hasEitaa) {
    return { ok: false, error: 'no_listing_status_changes' };
  }
  if (hasReview && !['pending', 'approved', 'rejected', 'needs_revision'].includes(String(body.reviewStatus || ''))) {
    return { ok: false, error: 'invalid_review_status' };
  }
  for (const [provider, input] of [['rubika', hasRubika ? body.rubika : null], ['eitaa', hasEitaa ? body.eitaa : null]]) {
    if (!input) continue;
    const status = String(input.status || '');
    if (!['pending', 'published', 'failed'].includes(status)) {
      return { ok: false, error: 'invalid_' + provider + '_publication_status' };
    }
    if (status !== 'pending' && input.attempted !== true) {
      return { ok: false, error: provider + '_publication_attempt_not_confirmed' };
    }
    const receiptId = cleanText_(input.deliveryId || input.messageId || input.postId || '', 180);
    if (status === 'published' && (input.confirmed !== true || !receiptId)) {
      return { ok: false, error: provider + '_success_requires_confirmed_delivery_id' };
    }
  }

  return withLock_(() => {
    const priorOperation = findExact_('Operations', 1, operationId);
    if (priorOperation) {
      if (
        String(priorOperation.values[1]) !== device.deviceId ||
        String(priorOperation.values[2]) !== 'update_listing_status'
      ) {
        return { ok: false, error: 'operation_id_conflict' };
      }
      return replayOperation_(priorOperation);
    }

    const rec = findRecordById_(recordId);
    if (!rec || String(rec.values[9]) === 'deleted') {
      return { ok: false, error: 'record_not_found' };
    }
    if (String(rec.values[1]) !== 'listing') {
      return { ok: false, error: 'listing_record_required' };
    }

    const currentVersion = Number(rec.values[8]) || 1;
    const expectedVersion = Number(body.expectedVersion);
    if (!Number.isSafeInteger(expectedVersion) || expectedVersion !== currentVersion) {
      return { ok: false, error: 'version_conflict', currentVersion };
    }
    if (hasReview && String(rec.values[4]) !== device.deviceId) {
      return { ok: false, error: 'owner_device_only_review' };
    }

    const current = safeParse_(rec.values[11], {});
    const next = { ...current };
    const now = new Date().toISOString();
    const historyChanges = [];

    if (hasReview) {
      const reviewStatus = String(body.reviewStatus || '');
      const old = String(next.reviewStatus || 'pending');
      if (old !== reviewStatus) {
        next.reviewStatus = reviewStatus;
        historyChanges.push({ field: 'reviewStatus', oldValue: old, newValue: reviewStatus });
      }
    }

    const publication = next.publication && typeof next.publication === 'object'
      ? { ...next.publication }
      : {};
    publication.rubika = publication.rubika && typeof publication.rubika === 'object'
      ? { ...publication.rubika }
      : { status: 'pending', deliveryId: '', confirmedAt: '', error: '' };
    publication.eitaa = publication.eitaa && typeof publication.eitaa === 'object'
      ? { ...publication.eitaa }
      : { status: 'pending', deliveryId: '', confirmedAt: '', error: '' };

    [['rubika', hasRubika ? body.rubika : null], ['eitaa', hasEitaa ? body.eitaa : null]].forEach(([provider, input]) => {
      if (!input) return;
      const status = String(input.status || '');
      const deliveryId = cleanText_(input.deliveryId || input.messageId || input.postId || '', 180);
      const oldState = publication[provider] || { status: 'pending', deliveryId: '', confirmedAt: '', error: '' };
      const newState = {
        status,
        deliveryId: status === 'published' ? deliveryId : '',
        confirmedAt: status === 'published'
          ? (String(oldState.status || '') === 'published' && String(oldState.deliveryId || '') === deliveryId
              ? String(oldState.confirmedAt || now)
              : now)
          : '',
        error: status === 'failed' ? cleanText_(input.error || input.message || 'خطا در انتشار', 500) : ''
      };
      if (JSON.stringify(oldState) !== JSON.stringify(newState)) {
        publication[provider] = newState;
        historyChanges.push({
          field: 'publication.' + provider,
          oldValue: JSON.stringify(oldState),
          newValue: JSON.stringify(newState)
        });
      }
    });

    next.publication = publication;
    const rubikaStatus = String(publication.rubika.status || 'pending');
    const eitaaStatus = String(publication.eitaa.status || 'pending');
    next.publicationStatus = rubikaStatus === 'published' && eitaaStatus === 'published'
      ? 'published'
      : (rubikaStatus === 'failed' || eitaaStatus === 'failed')
        ? 'failed'
        : (rubikaStatus === 'published' || eitaaStatus === 'published')
          ? 'partial'
          : 'pending';

    if (!historyChanges.length) {
      const unchanged = {
        ok: true,
        recordId,
        version: currentVersion,
        unchanged: true,
        reviewStatus: next.reviewStatus || 'pending',
        publicationStatus: next.publicationStatus
      };
      saveOperation_(operationId, device.deviceId, 'update_listing_status', recordId, unchanged);
      return unchanged;
    }

    const version = currentVersion + 1;
    next.updatedAt = now;
    next.version = version;
    next.syncStatus = 'synced';
    const json = JSON.stringify(next);
    if (json.length > QOQNUS.MAX_RECORD_JSON_CHARS) {
      return { ok: false, error: 'record_too_large_for_sheet_cell' };
    }

    const recordsSheet = sheet_('Records');
    recordsSheet.getRange(rec.row, 8).setValue(now);
    recordsSheet.getRange(rec.row, 9).setValue(version);
    recordsSheet.getRange(rec.row, 12).setValue(json);

    historyChanges.forEach(change => {
      appendHistory_({
        recordId,
        kind: 'listing',
        eventType: 'listing_status_changed',
        fieldName: change.field,
        oldValue: change.oldValue,
        newValue: change.newValue,
        actor: device,
        eventAt: now,
        description: cleanText_(body.description || 'به‌روزرسانی وضعیت بررسی یا انتشار آگهی ققنوس', 1200),
        operationId,
        status: 'applied'
      });
    });

    appendChange_(recordId, 'listing', 'listing_status_updated', version, device.deviceId, {
      recordId,
      version,
      current: next,
      changedFields: historyChanges.map(x => x.field)
    });

    const response = {
      ok: true,
      recordId,
      version,
      reviewStatus: next.reviewStatus || 'pending',
      publicationStatus: next.publicationStatus,
      rubikaStatus,
      eitaaStatus,
      eligibleForMainOffice: next.reviewStatus === 'approved' && rubikaStatus === 'published' && eitaaStatus === 'published',
      changedFields: historyChanges.map(x => x.field)
    };
    saveOperation_(operationId, device.deviceId, 'update_listing_status', recordId, response);
    return response;
  });
}

function qoqnusNormalizeRecordV13_(record, kind, localId, centralId, device, createdAt, updatedAt, version, imported) {
  const out = record && typeof record === 'object' && !Array.isArray(record) ? { ...record } : {};
  const sourceType = kind === 'customer'
    ? 'manual_customer'
    : kind === 'file'
      ? 'office_file'
      : 'manual_divar_capture';

  out.id = localId;
  out.recordKind = kind;
  out.sourceType = sourceType;
  out.localId = localId;
  out.centralId = centralId;
  out.centralRecordId = centralId; // preserve compatibility with v1.2 clients
  out.ownerDeviceId = device.deviceId;
  out.ownerDeviceName = device.name;
  out.createdAt = createdAt;
  out.updatedAt = updatedAt;
  out.version = version;
  out.syncStatus = 'synced';

  if (kind === 'listing') {
    const allowedReview = ['pending', 'approved', 'rejected', 'needs_revision'];
    out.reviewStatus = allowedReview.includes(String(out.reviewStatus || ''))
      ? String(out.reviewStatus)
      : 'pending';
    const pub = out.publication && typeof out.publication === 'object' ? out.publication : {};
    const normalizeProvider = p => {
      const x = p && typeof p === 'object' ? p : {};
      const status = ['pending', 'published', 'failed'].includes(String(x.status || '')) ? String(x.status) : 'pending';
      return {
        status,
        deliveryId: status === 'published' ? cleanText_(x.deliveryId || x.messageId || '', 180) : '',
        confirmedAt: status === 'published' ? cleanText_(x.confirmedAt || '', 50) : '',
        error: status === 'failed' ? cleanText_(x.error || '', 500) : ''
      };
    };
    out.publication = {
      rubika: normalizeProvider(pub.rubika),
      eitaa: normalizeProvider(pub.eitaa)
    };
    const r = out.publication.rubika.status;
    const e = out.publication.eitaa.status;
    out.publicationStatus = r === 'published' && e === 'published'
      ? 'published'
      : (r === 'failed' || e === 'failed')
        ? 'failed'
        : (r === 'published' || e === 'published')
          ? 'partial'
          : 'pending';
  } else {
    out.reviewStatus = 'not_applicable';
    out.publicationStatus = 'not_applicable';
  }
  if (imported) out.importedAt = updatedAt;
  return out;
}

/**
 * Helper for the extension's main-office listing filter.
 * Only approved listings with successful delivery to BOTH channels belong
 * to the main Qoqnus files office. Everything else stays in review queue.
 */
function qoqnusListingEligibleForMainOfficeV13_(record) {
  const r = record || {};
  const p = r.publication || {};
  return String(r.recordKind || r.kind || '') === 'listing' &&
    String(r.reviewStatus || '') === 'approved' &&
    String((p.rubika || {}).status || '') === 'published' &&
    String((p.eitaa || {}).status || '') === 'published';
}


// ===== Integrated Qoqnus_Central_V14_Image_Upload_Patch.gs =====
/**
 * QOQNUS CENTRAL OFFICE — V1.4 independent image transfer patch
 * Add to the existing Apps Script project; do not replace Code.gs.
 * Requires the existing v1.2 helpers: withLock_, sheet_, findRecordById_,
 * safeParse_, appendHistory_, appendChange_, cleanText_.
 */
'use strict';
const QOQNUS_V14_IMAGE_FOLDER_ID = '1ibfebczhYw5Kd6WuJYufw1GE3xihD-It';
const QOQNUS_V14_IMAGE_HEADERS = [
  'imageId','recordId','ownerDeviceId','imageIndex','fileId','fileName',
  'mimeType','sizeBytes','sha256','uploadKey','createdAt','status'
];

function qoqnusImageSheetV14_() {
  const sh = sheet_('Images');
  const last = Math.max(1, sh.getLastColumn());
  let headers = sh.getRange(1, 1, 1, last).getValues()[0].map(x => String(x || '').trim());
  if (!headers.some(Boolean)) {
    sh.getRange(1, 1, 1, QOQNUS_V14_IMAGE_HEADERS.length).setValues([QOQNUS_V14_IMAGE_HEADERS]);
    headers = QOQNUS_V14_IMAGE_HEADERS.slice();
  } else {
    QOQNUS_V14_IMAGE_HEADERS.forEach(name => {
      if (!headers.includes(name)) {
        headers.push(name);
        sh.getRange(1, headers.length).setValue(name);
      }
    });
  }
  return { sh, headers, col: name => headers.indexOf(name) + 1 };
}

function qoqnusImageRowsV14_(table) {
  const lastRow = table.sh.getLastRow();
  if (lastRow < 2) return [];
  return table.sh.getRange(2, 1, lastRow - 1, table.headers.length).getValues();
}

function qoqnusRepairRecordImageMetadataV14_(rec, image) {
  const current = safeParse_(rec.values[11], {});
  const images = Array.isArray(current.centralImages) ? current.centralImages.slice() : [];
  const index = images.findIndex(x => String(x.uploadKey || '') === String(image.uploadKey));
  const metadata = { imageId: image.imageId, imageIndex: Number(image.imageIndex), fileName: image.fileName, mimeType: 'image/webp', sizeBytes: Number(image.sizeBytes), sha256: image.sha256, uploadKey: image.uploadKey };
  if (index >= 0) images[index] = metadata; else images.push(metadata);
  images.sort((a, b) => Number(a.imageIndex || 0) - Number(b.imageIndex || 0));
  current.centralImages = images;
  current.centralImageCount = images.length;
  current.updatedAt = new Date().toISOString();
  const records = sheet_('Records');
  records.getRange(rec.row, 8).setValue(current.updatedAt);
  records.getRange(rec.row, 12).setValue(JSON.stringify(current));
  records.getRange(rec.row, 14).setValue(images.length);
  return { current, images };
}

function qoqnusUploadRecordImageV14_(device, body) {
  const recordId = String(body.recordId || '').trim();
  const uploadKey = String(body.uploadKey || '').trim();
  const imageIndex = Math.floor(Number(body.imageIndex));
  const fileName = cleanText_(body.fileName || 'qoqnus-image.webp', 180);
  const dataUrl = String(body.dataUrl || '');
  const expectedHash = String(body.sha256 || '').toLowerCase();
  if (!recordId || !/^[a-zA-Z0-9:_-]{12,180}$/.test(uploadKey) || !Number.isInteger(imageIndex) || imageIndex < 1 || imageIndex > 20) {
    return { ok: false, error: 'invalid_image_request' };
  }
  const match = dataUrl.match(/^data:image\/webp;base64,([A-Za-z0-9+/=]+)$/i);
  if (!match) return { ok: false, error: 'webp_image_required' };
  // Strict shared image contract: WebP, longest edge <= 500px, strictly < 300,000 bytes.
  if (dataUrl.length > 410000) return { ok: false, error: 'image_too_large' };
  const bytes = Utilities.base64Decode(match[1]);
  if (!bytes.length || bytes.length > 299999) return { ok: false, error: 'image_too_large' };
  if (!isWebpBytes_(bytes)) return { ok: false, error: 'invalid_webp_signature' };
  const dimensions = webpDimensions_(bytes);
  if (!dimensions || dimensions.width < 1 || dimensions.height < 1 || dimensions.width > 500 || dimensions.height > 500) {
    return { ok: false, error: 'image_dimensions_limit' };
  }
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes);
  const actualHash = digest.map(b => (b < 0 ? b + 256 : b).toString(16).padStart(2, '0')).join('');
  if (!/^[a-f0-9]{64}$/.test(expectedHash) || actualHash !== expectedHash) return { ok: false, error: 'image_hash_mismatch' };

  return withLock_(() => {
    const rec = findRecordById_(recordId);
    if (!rec || String(rec.values[9]) === 'deleted') return { ok: false, error: 'record_not_found' };
    // Any authenticated active device may add or replace an image on a live record.
    const recordPayload=safeParse_(rec.values[11],{});
    if(String(recordPayload.transferStage||'')!=='complete') return { ok:false, error:'record_data_phase_required' };
    const table = qoqnusImageSheetV14_();
    const rows = qoqnusImageRowsV14_(table);
    const uploadCol = table.col('uploadKey') - 1;
    const recordCol = table.col('recordId') - 1;
    const indexCol = table.col('imageIndex') - 1;
    const hashCol = table.col('sha256') - 1;
    const prior = rows.find((row, i) => String(row[uploadCol]) === uploadKey);
    if (prior) {
      if (String(prior[recordCol]) !== recordId || String(prior[indexCol]) !== String(imageIndex) || String(prior[hashCol]) !== actualHash) {
        return { ok: false, error: 'upload_key_conflict' };
      }
      const priorImage = {
        imageId: String(prior[table.col('imageId') - 1]), recordId, imageIndex,
        fileId: String(prior[table.col('fileId') - 1]), fileName: String(prior[table.col('fileName') - 1]),
        sizeBytes: Number(prior[table.col('sizeBytes') - 1]) || bytes.length, sha256: actualHash, uploadKey
      };
      const repaired = qoqnusRepairRecordImageMetadataV14_(rec, priorImage);
      const effects = qoqnusEnsureImageTransferEffectsV16_(device, rec, priorImage, repaired.current);
      return { ok: true, duplicate: true, version:effects.version, seq:effects.seq, ...priorImage };
    }
    const sameSlotIndex = rows.findIndex(row => String(row[recordCol]) === recordId && String(row[indexCol]) === String(imageIndex) && String(row[table.col('status') - 1]) === 'active');
    const sameSlot = sameSlotIndex >= 0 ? rows[sameSlotIndex] : null;
    if (sameSlot && String(sameSlot[hashCol]) === actualHash) {
      const priorImage = { imageId: String(sameSlot[table.col('imageId') - 1]), recordId, imageIndex, fileId: String(sameSlot[table.col('fileId') - 1]), fileName: String(sameSlot[table.col('fileName') - 1]), sizeBytes: Number(sameSlot[table.col('sizeBytes') - 1]) || bytes.length, sha256: actualHash, uploadKey:String(sameSlot[table.col('uploadKey') - 1] || uploadKey) };
      const repaired = qoqnusRepairRecordImageMetadataV14_(rec, priorImage);
      const effects = qoqnusEnsureImageTransferEffectsV16_(device, rec, priorImage, repaired.current);
      return { ok: true, duplicate: true, version:effects.version, seq:effects.seq, ...priorImage };
    }
    // If an image slot is being replaced, create the new Drive object first; only
    // after the new row is persisted do we mark the previous row superseded.

    const storedName = 'qoqnus-' + uploadKey.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120) + '.webp';
    const blob = Utilities.newBlob(bytes, 'image/webp', storedName);
    const folder = DriveApp.getFolderById(QOQNUS_V14_IMAGE_FOLDER_ID);
    const matches = folder.getFilesByName(storedName);
    let file = matches.hasNext() ? matches.next() : folder.createFile(blob);
    const description = 'Qoqnus central image; record=' + recordId + '; index=' + imageIndex + '; sha256=' + actualHash + '; uploadKey=' + uploadKey;
    if (file.getDescription && file.getDescription() && !String(file.getDescription()).includes('sha256=' + actualHash)) return { ok: false, error: 'drive_file_upload_key_conflict' };
    file.setDescription(description);
    const imageId = Utilities.getUuid().replace(/-/g, '').toLowerCase();
    const now = new Date().toISOString();
    const rowObject = {
      imageId, recordId, ownerDeviceId: String(device.deviceId), imageIndex, fileId: file.getId(),
      fileName, mimeType: 'image/webp', sizeBytes: bytes.length, sha256: actualHash,
      width: dimensions.width, height: dimensions.height,
      uploadKey, createdAt: now, status: 'active'
    };
    const row = table.headers.map(name => Object.prototype.hasOwnProperty.call(rowObject, name) ? rowObject[name] : '');
    table.sh.appendRow(row);
    if (sameSlotIndex >= 0) {
      table.sh.getRange(sameSlotIndex + 2, table.col('status')).setValue('superseded');
    }

    const repaired = qoqnusRepairRecordImageMetadataV14_(rec, { imageId, imageIndex, fileName: storedName, mimeType: 'image/webp', sizeBytes: bytes.length, sha256: actualHash, uploadKey });
    const current = repaired.current;
    const images = repaired.images;
    const effects = qoqnusEnsureImageTransferEffectsV16_(device, rec, {
      imageId, recordId, imageIndex, fileId: file.getId(), fileName: storedName,
      sizeBytes: bytes.length, sha256: actualHash, uploadKey
    }, current);
    return { ok: true, duplicate: false, imageId, recordId, imageIndex, fileId: file.getId(), fileName: storedName, sizeBytes: bytes.length, sha256: actualHash, version:effects.version, seq:effects.seq };
  });
}

function qoqnusGetRecordImageV14_(device, body) {
  const recordId = String(body.recordId || '').trim();
  const imageIndex = Math.floor(Number(body.imageIndex));
  if (!recordId || !Number.isInteger(imageIndex) || imageIndex < 1 || imageIndex > 20) return { ok: false, error: 'invalid_image_request' };
  const rec = findRecordById_(recordId);
  if (!rec || String(rec.values[9]) === 'deleted') return { ok: false, error: 'record_not_found' };
  const table = qoqnusImageSheetV14_();
  const rows = qoqnusImageRowsV14_(table);
  const row = rows.find(x => String(x[table.col('recordId') - 1]) === recordId && String(x[table.col('imageIndex') - 1]) === String(imageIndex) && String(x[table.col('status') - 1]) === 'active');
  if (!row) return { ok: false, error: 'image_not_found' };
  const fileId = String(row[table.col('fileId') - 1] || '');
  const blob = DriveApp.getFileById(fileId).getBlob();
  const dataUrl = 'data:image/webp;base64,' + Utilities.base64Encode(blob.getBytes());
  return { ok: true, recordId, imageIndex, fileName: String(row[table.col('fileName') - 1]), mimeType: 'image/webp', sizeBytes: Number(row[table.col('sizeBytes') - 1]) || blob.getBytes().length, sha256: String(row[table.col('sha256') - 1]), dataUrl };
}


// ===== Integrated Qoqnus_Central_V15_Manual_Id_Manifest_Patch.gs =====
/**
 * QOQNUS CENTRAL OFFICE — V1.5 manual ID manifest patch
 * Add this file to the existing Apps Script project; do not replace Code.gs.
 *
 * Required integration in the authenticated-device branch of doPost(e):
 *   case 'check_ids': return qoqnusCheckIdsV15_(device, body);
 *   case 'fetch_selected_records': return qoqnusFetchSelectedV15_(device, body);
 * `device` must be the already-authenticated device object produced by the
 * existing v1.2 authentication flow. Never call these functions for public requests.
 *
 * Uses the existing Records sheet and v1.2 sheet_() helper. Column layout is
 * the existing 1.2 schema: record_id, kind, local_id, origin_device_id,
 * owner_device_id, owner_device_name, created_at, updated_at, version,
 * status, initial_json, current_json, expected_images, stored_images,
 * last_seq, import_id.
 */
'use strict';

function qoqnusCheckIdsV15_(device, body) {
  if (!device || !device.deviceId) return { ok: false, error: 'unauthorized_device' };
  // Sample the change cursor before scanning Records. Any concurrent later edit
  // remains above this cursor and is delivered by the incremental log next time.
  const baselineSeq = qoqnusSyncMaxSeq_();
  const known = Array.isArray(body.knownRecords) ? body.knownRecords : [];
  if (known.length > 10000) return { ok: false, error: 'known_manifest_too_large' };
  const knownMap = Object.create(null);
  known.forEach(item => {
    const id = String(item && item.recordId || '').trim();
    if (!id || id.length > 180) return;
    // Local sync labels (synced, sending, pending_images, etc.) are not
    // server record statuses. The central Records sheet currently exposes only
    // active/deleted (staging rows are omitted), so normalize all live local
    // copies to active and reserve deleted for an explicit central deletion.
    const localStatus = String(item.status || '').toLowerCase();
    knownMap[id] = {
      version: Math.max(1, Number(item.version) || 1),
      status: localStatus === 'deleted' ? 'deleted' : 'active'
    };
  });

  const sh = sheet_('Records');
  const last = sh.getLastRow();
  if (last < 2) return { ok: true, changes: [], serverCount: 0, manifestOnly: true, baselineSeq };
  const values = sh.getRange(2, 1, last - 1, 16).getValues();
  const changes = [];
  for (let i = 0; i < values.length; i++) {
    const r = values[i];
    const recordId = String(r[0] || '').trim();
    if (!recordId) continue;
    const kind = String(r[1] || '');
    if (!['customer', 'file', 'listing'].includes(kind)) continue;
    const version = Math.max(1, Number(r[8]) || 1);
    const status = String(r[9] || 'active');
    if (status === 'staging') continue; // reserved IDs are invisible until their full data phase completes
    const old = knownMap[recordId];
    if (!old || old.version !== version || old.status !== status) {
      changes.push({
        recordId,
        kind,
        version,
        status,
        updatedAt: String(r[7] || ''),
        ownerDeviceId: String(r[4] || ''),
        changeType: !old ? 'new' : (status === 'deleted' ? 'deleted' : 'updated')
      });
    }
  }
  changes.sort((a, b) => String(a.updatedAt).localeCompare(String(b.updatedAt)) || a.recordId.localeCompare(b.recordId));
  return {
    ok: true,
    manifestOnly: true,
    changes,
    serverCount: values.length,
    knownCount: known.length,
    checkedAt: new Date().toISOString(),
    baselineSeq
  };
}

function qoqnusFetchSelectedV15_(device, body) {
  if (!device || !device.deviceId) return { ok: false, error: 'unauthorized_device' };
  if (body.confirmedByManager !== true) return { ok: false, error: 'manager_confirmation_required' };
  const ids = Array.isArray(body.recordIds)
    ? [...new Set(body.recordIds.map(x => String(x || '').trim()).filter(Boolean))]
    : [];
  if (!ids.length || ids.length > 20) return { ok: false, error: 'invalid_selected_ids' };

  const wanted = Object.create(null);
  ids.forEach(id => { if (id.length <= 180) wanted[id] = true; });
  const sh = sheet_('Records');
  const last = sh.getLastRow();
  if (last < 2) return { ok: true, records: [], fetched: 0 };
  const values = sh.getRange(2, 1, last - 1, 16).getValues();
  const records = [];
  for (let i = 0; i < values.length; i++) {
    const r = values[i];
    const recordId = String(r[0] || '').trim();
    if (!wanted[recordId]) continue;
    const kind = String(r[1] || '');
    if (!['customer', 'file', 'listing'].includes(kind) || ['staging','deleted'].includes(String(r[9] || ''))) continue;
    let record = {};
    if (String(r[9] || '') !== 'deleted') {
      try {
        const parsed = JSON.parse(String(r[11] || '{}'));
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) record = parsed;
      } catch (_) {
        return { ok: false, error: 'record_json_invalid', recordId };
      }
    }
    // Deliberately return no image bytes, image data URLs, or Drive content.
    records.push({
      recordId,
      kind,
      version: Math.max(1, Number(r[8]) || 1),
      status: String(r[9] || 'active'),
      updatedAt: String(r[7] || ''),
      ownerDeviceId: String(r[4] || ''),
      originDeviceId: String(r[3] || ''),
      record
    });
  }
  return { ok: true, records, fetched: records.length, requested: ids.length };
}


/** Return only compact display titles after the ID-manifest phase. No full record JSON or images. */
function qoqnusGetRecordTitlesV15_(device, body) {
  if (!device || !device.deviceId) return { ok: false, error: 'unauthorized_device' };
  const ids = Array.isArray(body.recordIds)
    ? [...new Set(body.recordIds.map(x => String(x || '').trim()).filter(Boolean))]
    : [];
  if (!ids.length || ids.length > 500) return { ok: false, error: 'invalid_title_ids' };
  const wanted = Object.create(null);
  ids.forEach(id => { if (id.length <= 180) wanted[id] = true; });
  const sh = sheet_('Records');
  const last = sh.getLastRow();
  if (last < 2) return { ok: true, titles: [], fetched: 0 };
  const values = sh.getRange(2, 1, last - 1, 16).getValues();
  const titles = [];
  for (const r of values) {
    const recordId = String(r[0] || '').trim();
    if (!wanted[recordId]) continue;
    const kind = String(r[1] || '');
    if (!['customer', 'file', 'listing'].includes(kind) || ['staging','deleted'].includes(String(r[9] || ''))) continue;
    let record = {};
    try { record = JSON.parse(String(r[11] || '{}')) || {}; } catch (_) { record = {}; }
    const title = cleanText_(record.title || record.subject || record.name || record.address || record.fileTitle || record.customerName || (kind === 'customer' ? 'مشتری بدون نام' : kind === 'file' ? 'فایل بدون عنوان' : 'آگهی بدون عنوان'), 180);
    const subtitle = cleanText_(record.city || record.neighborhood || record.phone || record.mobile || record.propertyType || '', 120);
    titles.push({ recordId, kind, title, subtitle, version: Math.max(1, Number(r[8]) || 1), status: String(r[9] || 'active'), ownerDeviceId:String(r[4] || '') });
  }
  return { ok: true, titles, fetched: titles.length, requested: ids.length, titlesOnly: true };
}


// ===== Integrated Qoqnus_Central_V16_Priority_Transfer.gs =====
/** Qoqnus V16 — strict outbound ID -> full record data phases; images are a separate final phase. */
'use strict';
/**
 * Reconcile an uncertain outbound transfer without changing any record.
 * This is a read-only, authenticated lookup by the original device/kind/localId.
 * It deliberately returns metadata only; record JSON and image bytes are never exposed.
 */
function qoqnusHasHistoryOperationV16_(operationId) {
  return !!findExact_('History', 13, String(operationId || ''));
}

function qoqnusHasSyncChangeOperationV16_(operationId, recordId, imageUploadKey) {
  const sh = sheet_('SyncChanges');
  const last = sh.getLastRow();
  if (last < 2) return false;
  const values = sh.getRange(2, 4, last - 1, 5).getValues();
  const wanted = String(operationId || '');
  const wantedRecord = String(recordId || '');
  const wantedImage = String(imageUploadKey || '');
  for (const row of values) {
    const eventType = String(row[0] || '');
    const payload = safeParse_(row[4], {});
    if (wanted && String(payload.operationId || '') === wanted) return true;
    if (wantedImage && eventType === 'record_image_added' && String(payload.recordId || '') === wantedRecord) {
      if (String(payload.image && payload.image.uploadKey || '') === wantedImage) return true;
      if (Array.isArray(payload.current && payload.current.centralImages) && payload.current.centralImages.some(x => String(x.uploadKey || '') === wantedImage)) return true;
    }
  }
  return false;
}

function qoqnusEnsureRecordTransferEffectsV16_(device, recordId, kind, localId, current, version, operationId, expectedImages) {
  const created = current.transferWasNewRecord === true;
  if (!qoqnusHasHistoryOperationV16_(operationId)) {
    appendHistory_({
      recordId, kind,
      eventType: created ? 'record_created' : 'record_updated',
      actor: device,
      eventAt: new Date().toISOString(),
      description: created ? 'ثبت رکورد پس از تأیید شناسه مرکزی' : 'به‌روزرسانی رکورد پس از تأیید شناسه مرکزی',
      operationId,
      status: 'applied'
    });
  }
  if (!qoqnusHasSyncChangeOperationV16_(operationId, recordId, '')) {
    appendChange_(recordId, kind, created ? 'record_created' : 'record_updated', version, device.deviceId, {
      recordId, centralId: recordId, localId, kind, record: current, version, operationId
    });
  }
  const response = {
    ok: true, recordId, centralId: recordId, localId, kind, version,
    ownerDeviceId: device.deviceId, stage: 'data_complete', expectedImages
  };
  if (!findExact_('Operations', 1, operationId)) {
    saveOperation_(operationId, device.deviceId, 'save_record_data', recordId, response);
  }
  return response;
}

function qoqnusEnsureImageTransferEffectsV16_(device, rec, image, current) {
  const uploadKey = String(image.uploadKey || '');
  const recordId = String(image.recordId || rec.values[0] || '');
  const kind = String(rec.values[1] || '');
  const imageSummary = {
    imageId: String(image.imageId || ''), imageIndex: Number(image.imageIndex) || 0,
    sha256: String(image.sha256 || ''), sizeBytes: Number(image.sizeBytes) || 0,
    fileId: String(image.fileId || ''), fileName: String(image.fileName || ''),
    mimeType: 'image/webp', uploadKey
  };
  const historyRow = findExact_('History', 13, uploadKey);
  const hasHistory = !!historyRow;
  let latest = current && typeof current === 'object' ? current : safeParse_(rec.values[11], {});
  let version = Math.max(1, Number(rec.values[8]) || 1);
  let seq = 0;
  const marker = String(latest.qoqnusLastImageOperationId || '');
  if (marker === uploadKey) {
    version = Math.max(version, Number(latest.qoqnusLastImageVersion) || version);
  } else if (!hasHistory) {
    // Persist the operation marker and new version together BEFORE writing history/change rows.
    // A retry after a timeout/crash sees the marker and cannot increment the version twice.
    version += 1;
    const now = new Date().toISOString();
    latest = { ...latest, updatedAt:now, version,
      qoqnusLastImageOperationId:uploadKey, qoqnusLastImageVersion:version };
    const records = sheet_('Records');
    records.getRange(rec.row, 8).setValue(now);
    records.getRange(rec.row, 9).setValue(version);
    records.getRange(rec.row, 12).setValue(JSON.stringify(latest));
  } else {
    // History may exist because the previous attempt stopped after the event journal write.
    // Reuse the version marker if present, otherwise preserve the already stored row version.
    version = Math.max(version, Number(latest.qoqnusLastImageVersion) || version);
  }
  imageSummary.version = version;
  if (!hasHistory) {
    appendHistory_({
      recordId, kind, eventType: 'record_image_added', actor: device,
      eventAt: new Date().toISOString(),
      description: 'تصویر WebP به‌صورت مستقل به رکورد مرکزی افزوده شد.',
      operationId: uploadKey,
      status: 'applied',
      newValue: JSON.stringify(imageSummary)
    });
  }
  if (!qoqnusHasSyncChangeOperationV16_(uploadKey, recordId, uploadKey)) {
    seq = appendChange_(recordId, kind, 'record_image_added', version, device.deviceId, {
      recordId, kind, recordKind: kind, version, status:'active',
      current: latest, image: imageSummary, operationId: uploadKey
    });
  } else {
    const sh = sheet_('SyncChanges');
    const last = sh.getLastRow();
    if (last >= 2) {
      const values = sh.getRange(2, 1, last - 1, 8).getValues();
      for (const row of values) {
        const payload = safeParse_(row[7], {});
        if (String(payload.operationId || '') === uploadKey) {
          seq = Number(row[0]) || 0;
          version = Math.max(version, Number(row[4]) || 0);
          break;
        }
      }
    }
  }
  return { version, seq, current:latest };
}

function qoqnusGetRecordTransferStatusV16_(device, body) {
  if (!device || !device.deviceId) return { ok: false, error: 'unauthorized_device' };
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length || items.length > 20) return { ok: false, error: 'invalid_transfer_status_batch' };

  // Read the image manifest once for this batch. This path is used only after an
  // ambiguous transport result, not during an ordinary successful save.
  const imageTable = qoqnusImageSheetV14_();
  const imageRows = qoqnusImageRowsV14_(imageTable);
  const recordCol = imageTable.col('recordId') - 1;
  const indexCol = imageTable.col('imageIndex') - 1;
  const statusCol = imageTable.col('status') - 1;
  const uploadCol = imageTable.col('uploadKey') - 1;
  const hashCol = imageTable.col('sha256') - 1;
  const results = [];

  for (const item of items) {
    try {
      const operationId = String(item && item.operationId || '').trim();
      const singleOperationId = String(item && item.singleOperationId || '').trim();
      const kind = String(item && item.kind || '').trim();
      const localId = String(item && item.localId || '').trim();
      if (!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId) ||
          (singleOperationId && !/^[a-zA-Z0-9:_-]{12,180}$/.test(singleOperationId)) ||
          !['customer', 'file', 'listing'].includes(kind) || !localId || localId.length > 180) {
        throw new Error('invalid_transfer_status_item');
      }

      const rec = findRecordByOrigin_(device.deviceId, kind, localId);
      if (!rec) {
        results.push({ ok: true, found: false, operationId, kind, localId, stage: 'not_found' });
        continue;
      }
      if (String(rec.values[4] || '') !== String(device.deviceId)) {
        throw new Error('record_owner_device_only');
      }
      if (String(rec.values[9] || '') === 'deleted') {
        throw new Error('local_record_already_deleted');
      }

      const current = safeParse_(rec.values[11], {});
      let stage = String(current.transferStage || '').trim();
      if (!['id_reserved', 'title_saved', 'complete'].includes(stage)) {
        stage = String(rec.values[9] || '') === 'staging' ? 'id_reserved' : 'complete';
      }
      // One-shot saves use a dedicated ':single' operation namespace. Older
      // one-shot builds used the bare outbox ID, while staged V16 uses ':data'.
      // Accept all forms during reconciliation so in-flight records remain recoverable.
      const committedSaveOperationId = String(current.transferDataOperationId || '');
      const directSaveMarker = stage === 'complete' && [operationId, singleOperationId].filter(Boolean).includes(committedSaveOperationId);
      const directSaveOperation = directSaveMarker
        ? findExact_('Operations', 1, committedSaveOperationId)
        : null;
      const directSaveMatches = directSaveOperation &&
        String(directSaveOperation.values[1]) === String(device.deviceId) &&
        String(directSaveOperation.values[2]) === 'save_record';
      if (directSaveMarker) {
        stage = directSaveMatches ? 'complete' : 'save_effects_pending';
      } else {
        const requestedDataOperationId = operationId.endsWith(':data') ? operationId : operationId + ':data';
        const dataOperationId = String(current.transferDataOperationId || '');
        if (stage === 'complete') {
          const dataOperation = dataOperationId === requestedDataOperationId
            ? findExact_('Operations', 1, requestedDataOperationId)
            : null;
          const operationMatches = dataOperation && String(dataOperation.values[1]) === String(device.deviceId) && String(dataOperation.values[2]) === 'save_record_data';
          if (dataOperationId === requestedDataOperationId && !operationMatches) stage = 'data_effects_pending';
          else if (!operationMatches) stage = 'not_reserved';
        }
      }
      const recordId = String(rec.values[0] || '');
      const images = imageRows
        .filter(row => String(row[recordCol] || '') === recordId && String(row[statusCol] || 'active') === 'active')
        .map(row => ({
          imageIndex: Number(row[indexCol]) || 0,
          uploadKey: String(row[uploadCol] || ''),
          sha256: String(row[hashCol] || '')
        }))
        .filter(image => image.imageIndex >= 1 && image.imageIndex <= 20)
        .sort((a, b) => a.imageIndex - b.imageIndex);

      results.push({
        ok: true,
        found: true,
        operationId,
        kind,
        localId,
        recordId,
        centralId: recordId,
        recordStatus: String(rec.values[9] || ''),
        stage,
        version: Math.max(0, Number(rec.values[8]) || 0),
        expectedImages: Math.max(0, Number(rec.values[12]) || 0),
        storedImages: images.length,
        images
      });
    } catch (error) {
      results.push({
        ok: false,
        kind: String(item && item.kind || ''),
        localId: String(item && item.localId || ''),
        error: safeErrorCode_(error),
        message: String(error && error.message || '').slice(0, 180)
      });
    }
  }
  return { ok: true, phase: 'reconcile', results, found: results.filter(x => x.ok && x.found).length };
}

function qoqnusReserveRecordIdsV16_(device, body) {
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length || items.length > 20) return { ok:false, error:'invalid_reserve_batch' };
  return withLock_(() => {
  const results = [];
  for (const item of items) {
    try {
      const operationId=String(item.operationId||'').trim(), kind=String(item.kind||''), localId=String(item.localId||'').trim();
      if (!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId) || !['customer','file','listing'].includes(kind) || !localId || localId.length>180) throw new Error('invalid_reserve_item');
      const prior=findExact_('Operations',1,operationId);
      if(prior){if(String(prior.values[1])!==device.deviceId||String(prior.values[2])!=='reserve_record_id')throw new Error('operation_id_conflict');results.push(replayOperation_(prior));continue;}
      const existing=findRecordByOrigin_(device.deviceId,kind,localId);
      if(existing){
        if(String(existing.values[9])==='deleted')throw new Error('local_record_already_deleted');
        if(String(existing.values[4])!==device.deviceId)throw new Error('record_owner_device_only');
        const id=String(existing.values[0]);
        const existingPayload=safeParse_(existing.values[11],{});
        existingPayload.transferStage='id_reserved';
        sheet_('Records').getRange(existing.row,12).setValue(JSON.stringify(existingPayload));
        const response={ok:true,recordId:id,centralId:id,localId,kind,version:Number(existing.values[8])||0,ownerDeviceId:device.deviceId,stage:'id_reserved'};
        saveOperation_(operationId,device.deviceId,'reserve_record_id',id,response);results.push(response);continue;
      }
      const id=Utilities.getUuid().replace(/-/g,'').toLowerCase(), now=new Date().toISOString();
      const shell={id:localId,localId,recordKind:kind,centralId:id,centralRecordId:id,ownerDeviceId:device.deviceId,ownerDeviceName:device.name,transferStage:'id_reserved',transferNewRecordPending:true};
      sheet_('Records').appendRow([id,kind,localId,device.deviceId,device.deviceId,device.name,now,now,0,'staging','{}',JSON.stringify(shell),Math.max(0,Math.min(20,Number(item.expectedImages)||0)),0,0,'']);
      const response={ok:true,recordId:id,centralId:id,localId,kind,version:0,ownerDeviceId:device.deviceId,stage:'id_reserved'};
      saveOperation_(operationId,device.deviceId,'reserve_record_id',id,response);results.push(response);
    } catch(e) { results.push({ok:false,localId:String(item&&item.localId||''),error:safeErrorCode_(e),message:String(e&&e.message||'').slice(0,180)}); }
  }
  return {ok:true,phase:'ids',results,accepted:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length};
  });
}
function qoqnusSaveRecordTitlesV16_(device, body) {
  const items=Array.isArray(body.items)?body.items:[];
  if(!items.length||items.length>20)return{ok:false,error:'invalid_title_batch'};
  return withLock_(() => {
  const results=[];
  for(const item of items){
    try{
      const operationId=String(item.operationId||'').trim(),recordId=String(item.recordId||'').trim();
      if(!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)||!recordId)throw new Error('invalid_title_item');
      const prior=findExact_('Operations',1,operationId);
      if(prior){if(String(prior.values[1])!==device.deviceId||String(prior.values[2])!=='save_record_title')throw new Error('operation_id_conflict');results.push(replayOperation_(prior));continue;}
      const rec=findRecordById_(recordId);
      if(!rec||String(rec.values[9])==='deleted')throw new Error('record_not_found');
      if(String(rec.values[4])!==device.deviceId)throw new Error('record_owner_device_only');
      const current=safeParse_(rec.values[11],{});
      if(String(current.transferStage||'')!=='id_reserved')throw new Error('record_id_reservation_required');
      current.title=cleanText_(item.title||'',180);
      current.titleSubtitle=cleanText_(item.subtitle||'',120);
      current.transferStage='title_saved';
      sheet_('Records').getRange(rec.row,12).setValue(JSON.stringify(current));
      const response={ok:true,recordId,phase:'title',title:current.title};
      saveOperation_(operationId,device.deviceId,'save_record_title',recordId,response);results.push(response);
    }catch(e){results.push({ok:false,recordId:String(item&&item.recordId||''),error:safeErrorCode_(e),message:String(e&&e.message||'').slice(0,180)});}
  }
  return{ok:true,phase:'titles',results,accepted:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length};
  });
}
function qoqnusSaveRecordDataV16_(device, body) {
  const items=Array.isArray(body.items)?body.items:[];
  if(!items.length||items.length>20)return{ok:false,error:'invalid_data_batch'};
  return withLock_(() => {
  const results=[];
  for(const item of items){
    try{
      const operationId=String(item.operationId||'').trim(),recordId=String(item.recordId||'').trim(),kind=String(item.kind||''),localId=String(item.localId||'').trim();
      const source=item.record&&typeof item.record==='object'&&!Array.isArray(item.record)?item.record:null;
      if(!/^[a-zA-Z0-9:_-]{12,180}$/.test(operationId)||!recordId||!['customer','file','listing'].includes(kind)||!localId||!source)throw new Error('invalid_record_data_item');
      const prior=findExact_('Operations',1,operationId);
      if(prior){if(String(prior.values[1])!==device.deviceId||String(prior.values[2])!=='save_record_data')throw new Error('operation_id_conflict');results.push(replayOperation_(prior));continue;}
      const rec=findRecordById_(recordId);
      if(!rec||String(rec.values[9])==='deleted')throw new Error('record_not_found');
      if(String(rec.values[4])!==device.deviceId||String(rec.values[1])!==kind||String(rec.values[2])!==localId)throw new Error('record_owner_or_identity_mismatch');
      const now=new Date().toISOString(), oldCurrent=safeParse_(rec.values[11],{});
      if(String(oldCurrent.transferStage||'')==='complete' && String(oldCurrent.transferDataOperationId||'')===operationId){
        const recoveredVersion=Math.max(1,Number(rec.values[8])||Number(oldCurrent.version)||1);
        const expected=Math.max(0,Math.min(20,Number(rec.values[12])||Number(item.expectedImages)||0));
        const recovered=qoqnusEnsureRecordTransferEffectsV16_(device,recordId,kind,localId,oldCurrent,recoveredVersion,operationId,expected);
        results.push({...recovered,duplicate:true,recovered:true});
        continue;
      }
      if(String(oldCurrent.transferStage||'')!=='title_saved')throw new Error('record_title_phase_required');
      const isNew=oldCurrent.transferNewRecordPending===true || String(rec.values[9])==='staging';
      const version=isNew?1:(Math.max(1,Number(rec.values[8])||1)+1);
      const createdAt=safeDate_(source.createdAt||source.created_at,String(rec.values[6]||now));
      const fullSource={...source,centralImages:Array.isArray(source.centralImages)?source.centralImages:(Array.isArray(oldCurrent.centralImages)?oldCurrent.centralImages:[])};
      const cleanRecord=qoqnusNormalizeRecordV13_(fullSource,kind,localId,recordId,device,createdAt,now,version,false);
      cleanRecord.transferStage='complete';
      cleanRecord.transferNewRecordPending=false;
      cleanRecord.transferWasNewRecord=isNew;
      cleanRecord.transferDataOperationId=operationId;
      const json=JSON.stringify(cleanRecord);
      if(json.length>QOQNUS.MAX_RECORD_JSON_CHARS)throw new Error('record_too_large_for_sheet_cell');
      const sh=sheet_('Records');
      sh.getRange(rec.row,8).setValue(now);sh.getRange(rec.row,9).setValue(version);sh.getRange(rec.row,10).setValue('active');
      if(isNew)sh.getRange(rec.row,11).setValue(json);
      sh.getRange(rec.row,12).setValue(json);
      sh.getRange(rec.row,13).setValue(Math.max(0,Math.min(20,Number(item.expectedImages)||0)));
      const response=qoqnusEnsureRecordTransferEffectsV16_(device,recordId,kind,localId,cleanRecord,version,operationId,Math.max(0,Math.min(20,Number(item.expectedImages)||0)));
      results.push(response);
    }catch(e){results.push({ok:false,recordId:String(item&&item.recordId||''),localId:String(item&&item.localId||''),error:safeErrorCode_(e),message:String(e&&e.message||'').slice(0,180)});}
  }
  return{ok:true,phase:'data',results,accepted:results.filter(x=>x.ok).length,failed:results.filter(x=>!x.ok).length};
  });
}
