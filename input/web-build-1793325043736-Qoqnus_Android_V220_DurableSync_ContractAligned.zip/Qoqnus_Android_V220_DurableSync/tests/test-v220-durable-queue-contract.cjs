'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { webcrypto } = require('node:crypto');
const { TextEncoder, TextDecoder } = require('node:util');
const androidAssets = path.resolve(__dirname, '../app/src/main/assets');
const app = fs.readFileSync(path.join(androidAssets, 'app.js'), 'utf8');
const androidProto = fs.readFileSync(path.join(androidAssets, 'peer-protocol.js'), 'utf8');
const extRootCandidates = [process.env.QOQNUS_EXTENSION_ROOT, path.resolve(__dirname, '../../../chrome-extension/Qoqnus_Chrome_Extension_4.5.153'), path.resolve(__dirname, '../../chrome-extension'), path.resolve(__dirname, '../../../triage_ext/New folder')].filter(Boolean);
const extRoot = extRootCandidates.find(root => fs.existsSync(path.join(root, 'peer-protocol.js'))) || extRootCandidates[0];
const extProtoPath = path.join(extRoot, 'peer-protocol.js');
const extDurablePath = path.join(extRoot, 'qoqnus-durable-sync.js');
const serverCandidates = [process.env.QOQNUS_SERVER_MOBILE_PEER, path.resolve(__dirname, '../../../server-patch/server/public/mobile-peer.php'), path.resolve(__dirname, '../../server-patch/public/mobile-peer.php'), path.resolve(__dirname, '../../../triage_server/server/public/mobile-peer.php')].filter(Boolean);
const serverPath = serverCandidates.find(candidate => fs.existsSync(candidate)) || serverCandidates[0];
const extProto = fs.existsSync(extProtoPath) ? fs.readFileSync(extProtoPath, 'utf8') : '';
const extDurable = fs.existsSync(extDurablePath) ? fs.readFileSync(extDurablePath, 'utf8') : '';
const server = fs.existsSync(serverPath) ? fs.readFileSync(serverPath, 'utf8') : '';

for (const action of ['queue-register-key','queue-peers','queue-publish','queue-pull','queue-ack','queue-status','queue-meta','queue-request-sync','queue-sync-requests','queue-request-complete','queue-request-status']) {
  assert.ok(app.includes("'" + action + "'") || app.includes('"' + action + '"'), `Android must use server action ${action}`);
}
assert.match(app, /durableQueueApplyIncoming/);
assert.match(app, /applied:true,ack/);
assert.match(app, /async function applyIncomingMobileMediaPack/);
assert.match(app, /Number\(item\.bytes\)!==parsed\.bytes\|\|String\(item\.mime\)!==parsed\.mime/);
assert.match(app, /رکورد .+ پیش از تصویر در مقصد موجود نیست/);
assert.doesNotMatch(app, /backupQuietCycles\)\)>=2/);
console.log('PASS Android uses existing durable queue API and ACKs after validated persistence');

if (extDurable) {
  assert.match(extDurable, /bytes:parsed\.bytes,mime:parsed\.mime/);
  assert.match(extDurable, /Number\(item\.bytes\)!==parsed\.bytes\|\|String\(item\.mime\)!==parsed\.mime/);
  assert.match(extDurable, /classifyQueueRecord\(x\)===kind/);
  assert.match(extDurable, /completePendingRequestsForTarget/);
  assert.match(extDurable, /tickError=lastError=String\(e\?\.message\|\|e\)/);
  console.log('PASS Extension media metadata, kind-safe targeting, deferred completion and error visibility');
} else console.log('SKIP extension source checks (set QOQNUS_EXTENSION_ROOT to run)');

if (server) {
  for (const action of ['queue-publish','queue-pull','queue-ack','queue-request-sync','queue-request-complete']) assert.ok(server.includes("'" + action + "'"), `PHP server should implement ${action}`);
  assert.match(server, /client_epoch/);
  console.log('PASS PHP server keeps existing queue actions and epoch guard; no parallel API required');
} else console.log('SKIP server source checks (set QOQNUS_SERVER_MOBILE_PEER to run)');

async function keyPair() {
  const pair = await webcrypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const publicJwk = await webcrypto.subtle.exportKey('jwk', pair.publicKey);
  const privateJwk = await webcrypto.subtle.exportKey('jwk', pair.privateKey);
  const privateKey = await webcrypto.subtle.importKey('jwk', privateJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  return { privateKey, publicJwk: { kty:'EC', crv:'P-256', x:publicJwk.x, y:publicJwk.y, ext:true, key_ops:[] } };
}
function loadProtocol(source) {
  const context = { crypto:webcrypto, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, DataView, btoa, atob, console, setTimeout, clearTimeout };
  context.self = context;
  context.globalThis = context;
  vm.runInNewContext(source, context, { timeout: 3000 });
  return context.QoqnusPeerProtocol;
}
(async()=>{
  if (!extProto) { console.log('SKIP cross-client crypto test (extension protocol unavailable)'); return; }
  const A = loadProtocol(androidProto), E = loadProtocol(extProto);
  const mobile = await keyPair(), extension = await keyPair();
  const payload = { type:'sync-media-pack', pack:{ schema:'qoqnus.peer-media.v1', items:[{kind:'file',id:'fixture-1',index:0,bytes:5,mime:'image/png'}] } };
  const aad = '0123456789abcdef0123456789abcdef:mobile:0123456789abcdef0123456789abcdef';
  const fromAndroid = await A.sealQueuePayload(extension.publicJwk, payload, aad);
  assert.deepEqual(JSON.parse(JSON.stringify(await E.openQueuePayload(fromAndroid, aad, extension))), payload);
  const fromExtension = await E.sealQueuePayload(mobile.publicJwk, payload, aad);
  assert.deepEqual(JSON.parse(JSON.stringify(await A.openQueuePayload(fromExtension, aad, mobile))), payload);
  await assert.rejects(()=>A.openQueuePayload(fromExtension, aad+':tampered', mobile));
  console.log('PASS Android ↔ extension ECDH/HKDF/AES-GCM envelope round-trip and AAD tamper rejection');
})().catch(e=>{console.error(e);process.exitCode=1;});
