# راهنمای ساخت APK ققنوس V211 در AndroidForge / Android Studio

1. ZIP سورس را استخراج و کل پوشهٔ پروژه را وارد محیط ساخت کنید.
2. از JDK 17 استفاده کنید و Android SDK Platform 34 را نصب کنید.
3. نسخه‌های این سورس: Android Gradle Plugin `8.7.3` و Kotlin plugin `2.0.21` هستند؛ از Gradle `8.9` استفاده کنید.
4. چون Wrapper کامل در بسته وجود ندارد و محیط تحویل SDK ندارد، در محیط ساخت دارای Gradle 8.9 از ریشهٔ پروژه اجرا کنید:
   - `gradle wrapper --gradle-version 8.9`
   - Linux/macOS: `./gradlew assembleDebug`
   - Windows: `gradlew.bat assembleDebug`
5. مسیر APK مورد انتظار: `app/build/outputs/apk/debug/app-debug.apk`.
6. APK را روی دستگاه آزمایشی نصب کنید و همهٔ سناریوهای `TEST_PLAN_FA.md` را بررسی کنید.
7. برای انتشار عمومی از نسخهٔ Release با keystore شخصی امضا کنید. فایل کلید و رمز آن را در سورس یا بسته قرار ندهید.

این فایل راهنما است، نه مدرک ساخت موفق. در محیط حاضر APK ساخته یا نصب نشده است.
