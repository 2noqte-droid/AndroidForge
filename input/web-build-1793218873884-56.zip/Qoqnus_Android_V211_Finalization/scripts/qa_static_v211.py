#!/usr/bin/env python3
"""Reproducible static checks for Qoqnus Android APK source v2.0.8 / V211."""
from pathlib import Path
from collections import Counter
from urllib.parse import urlsplit
from bs4 import BeautifulSoup
import json, re, sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'
HTML = ASSETS / 'index.html'
JS_FILES = [ASSETS / x for x in ('app.js','peer-protocol.js','qoqnus-divar-data-normalizer.js','qoqnus-divar-reader.js')]
checks=[]
def record(name, ok, detail=''):
    checks.append({'name':name,'status':'PASS' if ok else 'FAIL','detail':detail})

def read(p): return p.read_text(encoding='utf-8')

# Android project core
for p in [ROOT/'settings.gradle.kts', ROOT/'build.gradle.kts', ROOT/'gradle.properties', ROOT/'app/build.gradle.kts', ROOT/'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt', ROOT/'app/src/main/AndroidManifest.xml']:
    record('required file '+str(p.relative_to(ROOT)), p.is_file(), '' if p.is_file() else 'file absent')

soup=BeautifulSoup(read(HTML),'html.parser')
id_values=[x.get('id') for x in soup.find_all(attrs={'id':True})]
dupes=[k for k,v in Counter(id_values).items() if v>1]
record('HTML IDs unique', not dupes, f'{len(id_values)} IDs; duplicates={dupes}')
ids=set(id_values)

# Resolve all static $('id') references across scripts.
js_text='\n'.join(read(p) for p in JS_FILES if p.exists())
refs=set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", js_text))
missing=sorted(refs-ids)
record('static JS ID references exist', not missing, f'{len(refs)} static references; missing={missing}')

required_ids=['specialPhone','specialTypeChoices','quickCapturePanel','quickCaptureForm','quickCaptureName','quickFilePhotos','quickFileCamera','lockButton','lockScreen','appShell','specialList','notificationsButton','mobileBottomNav']
missing_required=[x for x in required_ids if x not in ids]
record('quick capture, lock, image and specials controls exist', not missing_required, f'missing={missing_required}')

missing_scripts=[]
for tag in soup.find_all('script',src=True):
    src=tag['src'].split('?',1)[0]
    if not (HTML.parent/src).is_file(): missing_scripts.append(src)
record('HTML local script assets resolve', not missing_scripts, f'scripts={len(soup.find_all("script",src=True))}; missing={missing_scripts}')

# Boot contract: start in quick capture, no explicit lock invocation in boot path.
boot=js_text[js_text.find('async function boot()'):js_text.find("boot().catch", js_text.find('async function boot()'))]
record('boot starts quick capture without opening lock', 'showCaptureOnly()' in boot and 'openPrivateUnlock()' not in boot and 'lockScreen' not in boot, 'boot() calls showCaptureOnly and does not route to the unlock view')
record('private office is reached through lock button flow', "$('lockButton').addEventListener('click'" in js_text and 'openPrivateUnlock()' in js_text and 'await importQuickCaptureQueue()' in js_text, 'manual unlock + queued-record import hooks present')
record('quick capture can queue while office locked', 'enqueueQuickCapture(kind,record)' in js_text and 'quickIntakeQueue' in js_text, 'encrypted local intake queue symbols present')
record('photo compressor enforces 400x400', bool(re.search(r'c\.width\s*=\s*400',js_text)) and bool(re.search(r'c\.height\s*=\s*400',js_text)) and 'ctx.fillRect(0,0,400,400)' in js_text, 'compressor source dimension assignments checked')
record('gallery and camera inputs separate', 'id="quickFilePhotos"' in read(HTML) and 'id="quickFileCamera"' in read(HTML) and 'capture="environment"' in read(HTML), 'two distinct input controls found')
record('special list is generated as single summary row', 'special-item-line' in js_text and 'specialLineText(record,kind)' in js_text and 'special-item-summary' in js_text, 'summary line builder present')
record('private rendered data clears on lock', 'function clearPrivateRenderedData()' in js_text and 'clearPrivateRenderedData();' in js_text[js_text.find('function showCaptureOnly()'):js_text.find('async function showApp()')] and 'showCaptureOnly();' in js_text[js_text.find('function lockApp()'):js_text.find('async function openPrivateUnlock()')], 'manual lock returns through showCaptureOnly, which clears private rendered DOM')

visible_text=soup.get_text(' ',strip=True)
record('no source brand name in static visible HTML', 'دیوار' not in visible_text, 'visible HTML text searched')
record('no legacy app name or standalone install wording in APK UI scripts', all(term not in js_text for term in ('برنامک','نصب برنامه','Install app','PWA')), 'UI script text searched; internal reader normalizers intentionally retain source-stripping patterns')
record('no standalone PWA install UI in HTML', not bool(re.search(r'نصب برنامه|Install app|افزودن به صفحه اصلی|PWA', visible_text, re.I)), 'visible HTML text searched')
record('no manifest or service worker in APK asset bundle', not (ASSETS/'manifest.webmanifest').exists() and not (ASSETS/'sw.js').exists() and not (ASSETS/'icons').exists(), 'standalone PWA assets absent; required web resources remain bundled under app/assets')
record('no service worker registration/install prompt code', not bool(re.search(r'navigator\.serviceWorker|beforeinstallprompt|deferredInstallPrompt',js_text)), 'service worker and install-prompt hooks absent')
record('no independent notifications navigation tab', not any((x.get('data-view')=='notifications' or x.get('data-mobile-view')=='notifications') for x in soup.select('[data-view],[data-mobile-view]')), 'notification panel remains available via the top bell')
record('visible UI avoids legacy app name', 'برنامک' not in visible_text, 'visible HTML text searched')
kt_text=read(ROOT/'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt')
record('native UI strings avoid source brand and standalone app wording', all(term not in kt_text for term in ('دیوار','برنامک','PWA','Install app')), 'source host identifiers remain internal but prohibited display text was searched')

# Script syntax should be checked by the caller through node --check, but presence of files is checked here.
for p in JS_FILES: record('JavaScript file present '+p.name,p.is_file())

# XML well-formedness
for rel in ('app/src/main/AndroidManifest.xml','app/src/main/res/xml/qoqnus_file_paths.xml','app/src/main/res/values/styles.xml'):
    p=ROOT/rel
    try: ET.parse(p); good=True; detail='well-formed XML'
    except Exception as e: good=False; detail=str(e)
    record('XML parses '+rel,good,detail)

# Version and API paths, no secret config is shipped.
gradle=read(ROOT/'app/build.gradle.kts')
record('Android version bumped to 2.0.8 / code 14','versionCode = 14' in gradle and 'versionName = "2.0.8"' in gradle, 'Gradle config markers checked')
kt=read(ROOT/'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt')
record('bundled WebView host mapping present','WebViewAssetLoader' in kt and 'setDomain("aghaj.ir")' in kt and 'addPathHandler(appAssetsPath' in kt,'hybrid UI remains inside APK')
record('Android file chooser/camera handler exists','onShowFileChooser' in kt and 'ACTION_IMAGE_CAPTURE' in kt and 'FileProvider' in kt,'static handler symbols present; device run still required')
record('bridge protocol names aligned','APP_READY' in js_text and 'APP_LOCKED' in js_text and 'APP_READY' in kt and 'APP_LOCKED' in kt,'JS and Kotlin markers match')
secret_patterns=[]
for p in ROOT.rglob('*'):
 if p.is_file() and p.suffix.lower() in ('.json','.properties','.kt','.kts','.xml','.js') and any(s in p.name.lower() for s in ('config','secret','token','key')):
  txt=p.read_text(encoding='utf-8',errors='ignore')
  if re.search(r'(?:api[_-]?key|secret|password)\s*[:=]\s*["\'][A-Za-z0-9_./+=-]{16,}["\']',txt,re.I): secret_patterns.append(str(p.relative_to(ROOT)))
record('no obvious embedded secret literals',not secret_patterns,f'flagged={secret_patterns}')

out={'project':'Qoqnus Android APK source V211 / 2.0.8','checks':len(checks),'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'results':checks}
print(json.dumps(out,ensure_ascii=False,indent=2))
if out['failed']: sys.exit(1)
