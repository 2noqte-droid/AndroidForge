# مانع ساخت APK در محیط فعلی

- `gradle`, `sdkmanager`, `adb` و `android.jar` در محیط یافت نشدند.
- سورس Kotlin به تنهایی قابل کامپایل نهایی نیست؛ Android SDK و وابستگی‌های AndroidX لازم‌اند.
- Gradle wrapper jar در سورس ورودی وجود ندارد.
- دریافت Gradle از اینترنت نیز به‌دلیل عدم دسترسی DNS در این محیط موفق نشد.
- بنابراین خروجی `app/build/outputs/apk/debug/app-debug.apk` ساخته نشده است. فایل APK جعلی یا placeholder تحویل داده نمی‌شود.

راه ادامه: پروژه را در محیط Android Studio/AndroidForge با JDK 17، Android SDK 34 و Gradle 8.9 باز کنید، wrapper بسازید و `assembleDebug` را اجرا کنید. سپس تست‌های دستگاه در `TEST_PLAN_FA.md` را اجرا کنید.
