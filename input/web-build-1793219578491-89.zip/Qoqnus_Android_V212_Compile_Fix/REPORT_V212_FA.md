# گزارش اصلاح خطای کامپایل ققنوس APK — V212

## ورودی
فایل `1.zip` شامل دو لاگ AndroidForge برای `gradle assembleDebug` و `gradle bundleDebug` و گزارش ادغام Manifest بود. هر دو build در `:app:compileDebugKotlin` شکست خورده‌اند.

## علل تشخیص‌داده‌شده
۱. callbackهای `WebViewClient` به `progress.visibility` ارجاع می‌دادند و Kotlin خطای `Unresolved reference 'visibility'` می‌داد.
۲. `normalizeIranMobile` فهرستی از کاراکترها (`List<Char>`) تولید می‌کرد و سپس آن را مانند رشته با `startsWith` و `length` استفاده می‌کرد.

## تغییر اعمال‌شده
- جایگزینی دسترسی به visibility در callbackها با `this@MainActivity.progress.setVisibility(...)`.
- تبدیل کاراکترهای فیلترشده به رشته با `joinToString("")`.
- ارتقای `versionCode` به ۱۵ و `versionName` به ۲.۰.۹؛ package name ثابت مانده است.
- هماهنگ‌سازی نشانگر build داخلی با `V212`.

## نتایج واقعی پس از اصلاح
- اسکریپت کنترل ایستا: **۳۹ موفق، ۰ شکست**.
- `node --check` برای `app.js`، `peer-protocol.js`، `qoqnus-divar-data-normalizer.js` و `qoqnus-divar-reader.js`: موفق.
- کنترل XML و شناسه‌های HTML: موفق.
- ساخت Gradle پس از اصلاح: **تست‌نشده**، چون Gradle و Android SDK در محیط حاضر وجود ندارد.
- نصب و آزمون روی گوشی: **تست‌نشده**.

## اقدام لازم برای تأیید APK
سورس این ZIP را در AndroidForge جایگزین کن و `gradle assembleDebug` را دوباره اجرا کن. اگر build موفق شد، فایل `app/build/outputs/apk/debug/app-debug.apk` را استخراج کن و سناریوهای دستگاه را اجرا کن. هر خطای جدید باید از لاگ تازه بررسی شود.

## محدودیت محدوده
این بسته فقط سورس APK را اصلاح می‌کند. سرور، دیتابیس، feed نسخه، افزونهٔ کروم و ربات تغییر نکرده‌اند. feed موجودی که قبلاً بررسی شده `mobile_app_version=V206` را اعلام می‌کرد؛ هماهنگی نسخهٔ سرور پیش از انتشار عمومی جداگانه لازم است.
