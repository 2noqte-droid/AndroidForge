# وضعیت ساخت APK — V212

مانع محیط محلی: ابزارهای `gradle` و Android SDK در این محیط در دسترس نیستند؛ بنابراین build محلی اجرا نشده است.

وضعیت قبلی AndroidForge: build نسخهٔ V211 با خطاهای Kotlin در `MainActivity.kt` متوقف شده بود. این خطاها در سورس V212 اصلاح شده‌اند و اکنون نیازمند اجرای مجدد `gradle assembleDebug` در AndroidForge هستند.

تا دریافت نتیجهٔ build مجدد، APK نهایی قابل نصب تأیید نشده است.
