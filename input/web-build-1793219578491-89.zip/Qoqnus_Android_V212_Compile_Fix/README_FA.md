# ققنوس APK — نسخهٔ V212 / 2.0.9

این ZIP شامل **سورس اپلیکیشن اندروید** و دارایی‌های درون APK است. HTML/CSS/JavaScript موجود در `app/src/main/assets/` رابط داخلی WebView درون APK است و محصول PWA مستقل نیست.

## چرا این نسخه ساخته شد؟
لاگ AndroidForge برای نسخهٔ V211 دو نوع خطای Kotlin ثبت کرده بود: `visibility` در callbackهای WebViewClient و ناسازگاری `List<Char>` با `String` در نرمال‌سازی شماره موبایل. هر دو علت در سورس اصلاح شده‌اند؛ جزئیات در `BUILD_LOG_ANALYSIS_V212_FA.md` است.

## اصلاحات V212
- در callbackها از `this@MainActivity.progress.setVisibility(...)` به‌جای property access مبهم استفاده می‌شود.
- خروجی نرمال‌سازی شماره با `joinToString("")` به `String` تبدیل می‌شود.
- نسخه به `versionCode=15` و `versionName=2.0.9` ارتقا یافته؛ package name برای حفظ سازگاری نصب تغییر نکرده است.
- شناسهٔ نسخهٔ داخلی رابط و پارامتر cache-busting به `V212` تغییر یافته‌اند.
- قابلیت‌ها و تغییرات رابط موجود در ممیزی پایه حفظ شده‌اند؛ این اصلاح بر خطاهای ساخت متمرکز است.

## کنترل‌های اجراشده
- اسکریپت کنترل ایستا: ۳۹ بررسی موفق، ۰ شکست.
- `node --check` روی چهار فایل JavaScript: موفق.
- اعتبارسنجی XML و شناسه‌های HTML: موفق.
- **ساخت Gradle پس از اصلاح هنوز تأیید نشده**؛ این محیط Gradle و Android SDK ندارد. چون لاگ ارسالی نشان می‌دهد AndroidForge قبلاً build را اجرا کرده، همین ZIP را در workspace آن بارگذاری و `gradle assembleDebug` را دوباره اجرا کن.

## ساخت در AndroidForge / Android Studio
1. محتوای ZIP را در workspace پروژهٔ اندروید جایگزین کن.
2. از JDK 17، Android SDK 34، Gradle 8.9 و Android Gradle Plugin 8.7.3 استفاده کن.
3. اجرا: `gradle assembleDebug`
4. خروجی مورد انتظار: `app/build/outputs/apk/debug/app-debug.apk`.
5. در صورت موفقیت ساخت، APK را روی دستگاه آزمایشی نصب و سناریوهای `TEST_PLAN_V212_FA.md` را اجرا کن.

## وابستگی بیرونی
این بسته API زنده، feed نسخهٔ سرور، افزونهٔ کروم یا ربات را تغییر نمی‌دهد. آرشیو سرور بررسی‌شده `mobile_app_version=V206` را گزارش می‌کرد؛ مدیر سرور باید آن را پیش از انتشار عمومی جداگانه هماهنگ کند.

## اسناد
- `BUILD_LOG_ANALYSIS_V212_FA.md`: خطاهای لاگ ارسالی و اصلاحات دقیق.
- `REPORT_V212_FA.md`: گزارش نسخهٔ جاری.
- `STATIC_QA_V212.txt` و `STATIC_QA_V212.json`: خروجی کنترل ایستا.
- `scripts/qa_static.py`: اسکریپت کنترل ایستای قابل تکرار.
- `TEST_PLAN_V212_FA.md`: فهرست تست‌های دستگاه.
- `ANDROIDFORGE_BUILD_GUIDE_V212_FA.md`: راهنمای ساخت.
- `SERVER_DEPENDENCIES_V212_FA.md`: وابستگی‌ها و feed سرور.
- `BASELINE_AUDIT_V211_FA.md` و `BASELINE_REQUIREMENTS_STATUS_V211_FA.md`: اسناد نسخهٔ پایه؛ برای وضعیت جاری، گزارش V212 مرجع است.
