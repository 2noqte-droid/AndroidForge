# ققنوس APK — بستهٔ اصلاح خطای کامپایل V212

این بسته بر اساس لاگ AndroidForge ارسالی، دو خطای Kotlin را در سورس حل می‌کند:
- ارجاع property `visibility` در callbackهای WebViewClient.
- ناسازگاری نوع `List<Char>` و `String` در نرمال‌سازی شماره موبایل.

نسخهٔ Android: `versionCode=15`, `versionName=2.0.9`; package name ثابت مانده است.

## ساخت
در AndroidForge/Android Studio، پروژهٔ موجود را با محتوای همین ZIP جایگزین و سپس `gradle assembleDebug` اجرا کن. محل معمول خروجی debug: `app/build/outputs/apk/debug/app-debug.apk`.

## وضعیت واقعی
کنترل ایستای سورس و بررسی نحوی JavaScript موفق است. این محیط Gradle و Android SDK ندارد؛ بنابراین APK جدید در اینجا ساخته نشده و build باید در AndroidForge دوباره اجرا شود.

## وابستگی بیرونی
این اصلاح فقط سورس APK را تغییر می‌دهد. feed نسخهٔ سرور، API زنده، افزونهٔ Chrome و ربات در این بسته تغییر نکرده‌اند. پیش از انتشار عمومی، مقدار `mobile_app_version` در feed موجود باید توسط مدیر سرور هماهنگ شود.
