# اصلاح خطای ساخت گزارش‌شده برای V211

لاگ‌های ارسالی نشان دادند هر دو فرمان `assembleDebug` و `bundleDebug` در `compileDebugKotlin` شکست خورده‌اند.

- خطاهای ۳۱۰ و ۳۱۳: `Unresolved reference visibility` در callbackهای WebViewClient. اصلاح: استفاده از `this@MainActivity.progress.setVisibility(View.VISIBLE/GONE)`.
- خطاهای ۶۲۰ تا ۶۲۳: متغیر `value` از عملیات `map/filter` به صورت `List<Char>` باقی مانده بود. اصلاح: `joinToString("")` پس از فیلتر رقم‌ها تا مقدار واقعاً `String` شود.

نسخهٔ اصلاح‌شده V212 است. پس از تغییر سورس، `assembleDebug` باید در AndroidForge دوباره اجرا شود. این گزارش موفقیت build را اعلام نمی‌کند.
