# یادداشت تغییرات APK — V212 / 2.0.9

## اصلاحات این بسته نسبت به V211
- رفع استفادهٔ مبهم از `progress.visibility` در callbackهای `WebViewClient` با فراخوانی صریح `this@MainActivity.progress.setVisibility(...)`.
- تبدیل خروجی فیلتر رقم‌ها به رشته در `normalizeIranMobile` با `joinToString("")`؛ این اصلاح خطاهای `startsWith`، `length`، نوع انتساب و نوع خروجی را هدف می‌گیرد.
- ارتقای نسخه به `versionCode=15`، `versionName=2.0.9` و شناسهٔ داخلی build به `V212`.
- اصلاح cache-busting دارایی‌های محلی APK.

## وضعیت
کنترل ایستای سورس و JavaScript موفق است. نتیجهٔ کامپایل Gradle بعد از این اصلاح هنوز در این محیط در دسترس نیست؛ AndroidForge باید مجدداً `assembleDebug` را اجرا کند. APK ساخته‌شده ادعا یا داخل این ZIP درج نشده است.
