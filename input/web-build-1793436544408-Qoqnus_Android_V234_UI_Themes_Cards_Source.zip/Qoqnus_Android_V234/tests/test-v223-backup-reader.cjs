'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { webcrypto } = require('node:crypto');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');

function loadGlobal(file, globalName, extras = {}) {
  const sandbox = {
    crypto: webcrypto,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    Set,
    Map,
    Date,
    Math,
    JSON,
    Error,
    atob,
    btoa,
    Buffer,
    console,
    ...extras
  };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  vm.runInNewContext(fs.readFileSync(path.join(assets, file), 'utf8'), sandbox, { filename: file });
  assert.ok(sandbox[globalName], `${globalName} exposed`);
  return sandbox[globalName];
}

(async () => {
  const Reader = loadGlobal('qoqnus-backup-file-reader.js', 'QoqnusBackupFileReader');
  const Core = loadGlobal('qoqnus-backup-core.js', 'QoqnusBackupCore');

  const payload = {
    schema: 'qoqnus.mobile.backup.v2',
    formatVersion: 2,
    createdAt: 1770000000000,
    appVersion: 'V223',
    encryptedRecords: true,
    attachmentsIncluded: true,
    manifest: { recordCount: 1, fileCount: 1, listingCount: 0, customerCount: 0, contactCount: 0, attachmentCount: 0, otherCount: 0 },
    records: [{ key: 'file:F-223', kind: 'file', id: 'F-223', updatedAt: 1, iv: 'AQ==', cipher: 'Ag==' }],
    meta: [{ key: 'localSalt', value: 'salt' }, { key: 'lockCheck', value: { iv: 'a', cipher: 'b' } }]
  };
  const document = await Core.createBackupDocument({
    records: payload.records,
    meta: payload.meta,
    appVersion: payload.appVersion,
    createdAt: payload.createdAt
  });
  const json = JSON.stringify(document);
  const serialized = '\uFEFF' + json;
  const bytes = Buffer.from(serialized, 'utf8');
  const receiver = Reader.createChunkReceiver({ name: 'قُقنوس.json', totalBytes: bytes.length });
  let final;
  // Deliberately split multibyte Persian code points across chunk boundaries.
  const cuts = [...new Set([1, 7, 29, Math.floor(bytes.length / 3), Math.floor(bytes.length * 2 / 3), bytes.length - 3, bytes.length].filter(x => x > 0 && x <= bytes.length))].sort((a, b) => a - b);
  let offset = 0;
  for (const end of cuts) {
    if (end <= offset) continue;
    const chunk = bytes.subarray(offset, end);
    final = receiver.push(offset, chunk.toString('base64'), end === bytes.length);
    offset = end;
  }
  assert.equal(final.complete, true);
  assert.equal(final.bytes, bytes.length);
  assert.equal(final.name, 'قُقنوس.json');
  assert.equal(final.text, json, 'BOM stripped and UTF-8 chunks reconstructed without corruption');
  const parsed = JSON.parse(final.text);
  const verified = await Core.verifyBackupDocument(parsed);
  assert.equal(verified.records.length, 1, 'self-generated V2 JSON is readable by importer verifier');

  const wrongOffset = Reader.createChunkReceiver({ totalBytes: 1 });
  assert.throws(() => wrongOffset.push(1, Buffer.from('x').toString('base64'), true), /ترتیب قطعات/);

  const wrongSize = Reader.createChunkReceiver({ totalBytes: 4 });
  assert.throws(() => wrongSize.push(0, Buffer.from('abc').toString('base64'), true), /اندازه اعلام‌شده/);

  const invalidUtf8 = Reader.createChunkReceiver({ totalBytes: 1 });
  assert.throws(() => invalidUtf8.push(0, Buffer.from([0xff]).toString('base64'), false), /encoded data|encoding|encoded/);

  const oversized = Reader.createChunkReceiver({ totalBytes: 2, maxBytes: 1 });
  assert.throws(() => oversized.push(0, Buffer.from('ab').toString('base64'), false), /۱۵۰ مگابایت/);

  const empty = Reader.createChunkReceiver({ totalBytes: 0 });
  assert.throws(() => empty.push(0, '', true), /خالی است/);

  class MockFileReader {
    readAsText(file) {
      this.result = file.content;
      queueMicrotask(() => this.onload && this.onload());
    }
  }
  const readerWithFileReader = loadGlobal('qoqnus-backup-file-reader.js', 'QoqnusBackupFileReader', { FileReader: MockFileReader });
  const fileReaderText = await readerWithFileReader.readFileAsText({ size: json.length, content: '\uFEFF' + json });
  assert.equal(fileReaderText, json, 'browser FileReader path handles BOM');

  const fallback = await Reader.readFileAsText({ size: 7, text: async () => '\uFEFF{"ok":1}' });
  assert.equal(fallback, '{"ok":1}', 'file.text fallback handles BOM');
  await assert.rejects(() => Reader.readFileAsText({ size: 0, text: async () => ' ' }), /خالی است/);
  await assert.rejects(() => Reader.readFileAsText({ size: 100, text: async () => '{}' }, 10), /۱۵۰ مگابایت/);

  const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
  const native = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
  const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
  assert.match(app, /window\.__qoqnusTakeBackupChunk/);
  assert.match(app, /async function exportBackup\s*\(/);
  assert.match(app, /QoqnusBackupCore\.createBackupDocument/);
  assert.match(app, /async function normalizeBackupPayload\s*\(/);
  assert.match(app, /await QoqnusBackupCore\.verifyBackupDocument\(input\)/);
  assert.match(app, /downloadRecoveryBackup\(existingRecords,existingMeta\)/);
  assert.match(app, /window\.__qoqnusTakeBackupChunk/);
  assert.match(app, /async function exportBackup\s*\(/);
  assert.match(app, /QoqnusBackupCore\.createBackupDocument/);
  assert.match(app, /await QoqnusBackupCore\.verifyBackupDocument\(raw\)/);
  assert.match(app, /async function normalizeBackupPayload\s*\(/);
  assert.match(app, /await QoqnusBackupCore\.verifyBackupDocument\(input\)/);
  assert.match(app, /downloadRecoveryBackup\(existingRecords,existingMeta\)/);
  assert.match(app, /QoqnusBackupFileReader\.createChunkReceiver/);
  assert.match(app, /pending\?pending\.text:await readBackupFileAsText\(file\)/);
  assert.match(native, /contentResolver\.openInputStream\(uri\)/);
  assert.match(native, /IMPORT_BACKUP_CHUNK_REQUEST/);
  assert.match(native, /sendNextBackupImportChunk/);
  assert.match(native, /allowContentAccess = false/);
  assert.match(html, /qoqnus-backup-file-reader\.js\?v=234-unified-cards-theme/);
  assert.match(sw, /qoqnus-backup-file-reader\.js\?v=234-unified-cards-theme/);

  console.log('V223 BACKUP FILE IMPORT: PASS (V2 self-generated JSON round-trip, Android-style chunk stream, UTF-8 split boundaries, BOM, FileReader fallback, exact offset/size checks, invalid UTF-8, empty/oversized files, native ContentResolver bridge, export/import handlers preserved, generated backup self-verifies, WebView content access remains disabled)');
})().catch(error => { console.error(error); process.exitCode = 1; });
