'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'app/src/main/assets/sw.js'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const kotlin = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');

for (const name of ['activateView', 'saveLocalNotification', 'renderNotifications', 'localDateLabel', 'syncDashboardCounters']) {
  assert.match(app, new RegExp(`function\\s+${name}\\s*\\(`), `${name} must be implemented`);
}
assert.match(app, /Promise\.allSettled\(\[renderCustomers\(\),renderFiles\(\),renderListings\(\),renderDashboardHighlights\(\),renderConflicts\(\),renderNotifications\(\)\]\)/,
  'one office renderer failing must not abort all UI rendering');
assert.doesNotMatch(app, /checkSoftwareUpdate\s*\(/, 'retired updater must not be called');
assert.doesNotMatch(html, /checkUpdatesButton|openUpdateManager|بررسی نسخهٔ جدید/, 'retired updater controls must be removed');
assert.doesNotMatch(app, /mobile-peer\.php|durableQueueTick\s*\(|startDurableQueueAutomation\s*\(|peer-protocol\.js/, 'legacy PHP/P2P file sync must stay removed');

for (const action of ['customers','files','listings','notifications','read-listing','register-customer','register-file','sync']) {
  assert.match(html, new RegExp(`data-home-action="${action}"`), `dashboard action ${action} must exist`);
  assert.match(app, new RegExp(`case '${action}'`), `dashboard action ${action} must be wired`);
}
assert.match(app, /\.tab'\)\.forEach\(b=>b\.addEventListener\('click',\(\)=>activateView\(b\.dataset\.view\)\)\)/);
assert.match(app, /\.mobile-nav-item\[data-mobile-view\]'\)\.forEach\(b=>b\.addEventListener\('click',\(\)=>activateView\(b\.dataset\.mobileView\)\)\)/);
for (const id of ['notificationsButton','closeNotificationsButton','notificationBackdrop','markAllNotificationsRead','clearReadNotifications','downloadListingSyncAuditReport']) {
  assert.match(app, new RegExp(`\\$\\('${id}'\\).*?addEventListener`), `notification/diagnostic control ${id} must be wired`);
}

const expectedApis = ['pair','reserve_record_ids','save_record_titles','save_record_data','upload_record_image','check_ids','get_record_titles','fetch_selected_records','get_record_image','delete_record'];
for (const action of expectedApis) assert.ok(app.includes(`centralApi('${action}'`), `central API ${action} must be used`);
const sendStart = app.indexOf('async function centralSendChanges()');
const sendEnd = app.indexOf('async function centralReadList', sendStart);
const send = app.slice(sendStart, sendEnd);
const reserve = send.indexOf("centralApi('reserve_record_ids'");
const titles = send.indexOf("centralApi('save_record_titles'");
const data = send.indexOf("centralApi('save_record_data'");
const images = send.indexOf('centralUploadImages(task');
assert.ok(sendStart >= 0 && reserve >= 0 && titles > reserve && data > titles && images > data, 'outgoing order must be IDs -> titles -> full data -> images');
assert.match(app, /const CENTRAL_BATCH=20;/, 'central sync must use the extension-compatible batch size of 20');
assert.match(app, /confirmedByManager:true/);
assert.match(app, /centralRenderReviewWorkspace\(\)/);
assert.match(app, /content-type.*text\/plain/i);
assert.match(app, /qoqnusCentralDeletedAckV1/);
assert.match(app, /function centralBuildKnownRecords\(/);
assert.match(app, /function centralRememberDeletedAcks\(/);
assert.match(app, /'android-v239-id-title-manifest'/);
assert.match(app, /'android-v239-manager-staging'/);

assert.match(app, /const APP_VERSION='V239'/);
assert.match(gradle, /versionCode\s*=\s*49/);
assert.match(gradle, /versionName\s*=\s*"2\.0\.43"/);
assert.match(kotlin, /build=V239-consumer-audit-delete-retry/);
assert.match(kotlin, /onPageCommitVisible/);
assert.match(kotlin, /postDelayed\([\s\S]{0,500}?10000L/);
assert.match(sw, /qoqnus-mobile-pwa-v239-consumer-audit-delete-retry/);
assert.match(sw, /app\.js\?v=239-consumer-audit-delete-retry/);

// Every static ID used by a direct addEventListener must exist in the bundled HTML.
const ids = new Set([...html.matchAll(/\bid="([A-Za-z0-9_-]+)"/g)].map(m => m[1]));
const directListenerIds = new Set([...app.matchAll(/\$\('([A-Za-z0-9_-]+)'\)\??\.addEventListener/g)].map(m => m[1]));
for (const id of directListenerIds) assert.ok(ids.has(id), `direct listener target #${id} must exist in HTML`);
const duplicateIds = [...html.matchAll(/\bid="([A-Za-z0-9_-]+)"/g)].map(m => m[1]).filter((id, i, all) => all.indexOf(id) !== i);
assert.deepEqual([...new Set(duplicateIds)], [], 'HTML ids must be unique');

console.log('PASS V239: required UI functions exist; navigation, dashboard actions and notification controls are wired; retired updater and PHP/P2P sync are absent; Sheetachi API phase ordering and manager review are preserved; release/cache identifiers are aligned; direct listener targets exist and HTML IDs are unique.');
