package ir.qoqnus.divarreader

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.view.Gravity
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SafeBrowsingResponse
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import androidx.webkit.WebViewAssetLoader
import androidx.core.content.FileProvider
import java.io.OutputStream
import java.io.InputStream
import java.io.File
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.util.LinkedHashMap
import java.util.Locale

class MainActivity : Activity() {
    // The current web UI is bundled inside this APK. API requests outside the mobile-app path
    // continue to reach the live HTTPS server using the same origin and relative URL layout.
    private val appUrl = "https://aghaj.ir/RobikaBot/rubika_realestate/public/mobile-app-apk/index.html?build=V228-private-view-lock-eye-reader-default-img"
    private val appOrigin = "https://aghaj.ir"
    private val appAssetsPath = "/RobikaBot/rubika_realestate/public/mobile-app-apk/"
    private lateinit var assetLoader: WebViewAssetLoader
    private lateinit var readerControls: LinearLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var sessionReturnButton: Button
    private var loginPopupWeb: WebView? = null
    private val divarOrigins = setOf("https://divar.ir", "https://www.divar.ir")
    private lateinit var appWeb: WebView
    private lateinit var divarWeb: WebView
    private lateinit var statusText: TextView
    private lateinit var urlInput: EditText
    private lateinit var readButton: Button
    private lateinit var sessionButton: Button
    private lateinit var revealPhoneButton: Button
    private lateinit var manualContactPanel: LinearLayout
    private lateinit var manualOwnerNameInput: EditText
    private lateinit var manualPhoneInput: EditText
    private var pendingManualPayload: JSONObject? = null
    private lateinit var progress: ProgressBar
    private val queuedRecords = LinkedHashMap<String, JSONObject>()
    private var appReady = false
    private var pageIsDivar = false
    private var readerScript = ""
    private var autoReadUrl: String? = null
    private var autoReadAttempts = 0
    private var pendingReaderUrl: String? = null
    private var activeOfficeFileId: String? = null
    private var activeOfficeFileUrl: String? = null
    private var sessionLoginRequested = false
    private var externalLoginRedirectSeen = false
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraUri: Uri? = null
    private var pendingCameraFile: File? = null
    private var startupSplashView: View? = null
    private var startupSplashDismissed = false
    private var backupOutput: OutputStream? = null
    private var backupExpectedChars = 0
    private var backupNextOffset = 0
    private var backupFileName = "qoqnus-mobile-encrypted-backup.json"
    private val backupExportRequestCode = 6201
    private val fileChooserRequestCode = 6202
    private var pendingBackupImportChooser = false
    private var backupImportInput: InputStream? = null
    private var backupImportNextOffset = 0
    private var backupImportFileName = "qoqnus-backup.json"
    private val backupImportChunkBytes = 48 * 1024
    private val backupImportMaxBytes = 150L * 1024L * 1024L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            showUnsupportedWebView()
            return
        }
        readerScript = assets.open("qoqnus-divar-reader.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        assetLoader = WebViewAssetLoader.Builder()
            .setDomain("aghaj.ir")
            .addPathHandler(appAssetsPath, WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        buildUi()
        configureWebViews()
        appWeb.loadUrl(appUrl)
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun showUnsupportedWebView() {
        val text = TextView(this).apply {
            text = "نسخهٔ Android System WebView قدیمی است. آن را از فروشگاه به‌روزرسانی کنید و دوباره برنامه را باز کنید."
            textSize = 18f; setPadding(28, 32, 28, 32); gravity = Gravity.CENTER
        }
        setContentView(text)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17, 17, 15))
        }
        readerControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 10, 16, 10)
            setBackgroundColor(Color.rgb(43, 35, 22))
            val logoSize = (34 * resources.displayMetrics.density).toInt()
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_launcher)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "لوگوی ققنوس"
            }, LinearLayout.LayoutParams(logoSize, logoSize).apply {
                marginEnd = (10 * resources.displayMetrics.density).toInt()
            })
            addView(TextView(this@MainActivity).apply {
                text = "ققنوس — خواندن آگهی"
                textSize = 18f
                setTextColor(Color.rgb(242, 219, 164))
                gravity = Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        readerControls.addView(header, LinearLayout.LayoutParams(-1, -2))
        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 8, 8, 4) }
        urlInput = EditText(this).apply {
            hint = "پیوند مستقیم آگهی /v/…"
            textSize = 13f
            isSingleLine = true
            setTextDirection(View.TEXT_DIRECTION_LTR)
            setPadding(10, 7, 10, 7)
        }
        inputRow.addView(urlInput, LinearLayout.LayoutParams(0, 48, 1f))
        val open = Button(this).apply {
            text = "بازکردن"
            setOnClickListener {
                val u = canonicalDetailUrl(urlInput.text.toString())
                if (u == null) toast("پیوند باید مستقیم به صفحهٔ جزئیات آگهی /v/ باشد.") else openDivar(u)
            }
        }
        inputRow.addView(open, LinearLayout.LayoutParams(-2, 48))
        readerControls.addView(inputRow)
        sessionButton = Button(this).apply {
            text = "ورود و حفظ نشست منبع آگهی"
            setOnClickListener {
                sessionLoginRequested = true
                statusText.text = "صفحهٔ آگهی را در همین برنامه باز می‌کنیم. در صورت نیاز وارد حساب خودت شو؛ نشست تا زمانی که منبع آن را معتبر بداند حفظ می‌شود."
                openDivar("https://divar.ir/")
            }
        }
        readerControls.addView(sessionButton, LinearLayout.LayoutParams(-1, -2).apply { setMargins(8, 2, 8, 2) })
        sessionReturnButton = Button(this).apply {
            text = "بازگشت به آگهی پس از ورود"
            visibility = View.GONE
            setOnClickListener {
                val target = canonicalDetailUrl(urlInput.text.toString()) ?: "https://divar.ir/"
                closeLoginPopup()
                sessionLoginRequested = false
                externalLoginRedirectSeen = false
                openDivar(target)
            }
        }
        readerControls.addView(sessionReturnButton, LinearLayout.LayoutParams(-1, -2).apply { setMargins(8, 0, 8, 2) })
        val sessionHint = TextView(this).apply {
            text = "ورود از داخل همین برنامه انجام می‌شود؛ نشست مرورگر جداست. ققنوس فقط شماره‌ای را ذخیره می‌کند که صفحهٔ منبع پس از ورود و اقدام مجاز نمایش دهد."
            textSize = 12f
            setTextColor(Color.rgb(190, 181, 160))
            setPadding(12, 4, 12, 8)
        }
        readerControls.addView(sessionHint, LinearLayout.LayoutParams(-1, -2))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(6, 0, 6, 4) }
        val app = Button(this).apply { text = "بازگشت به دفتر"; setOnClickListener { showApp() } }
        val sourcePage = Button(this).apply {
            text = "بازکردن صفحهٔ آگهی"
            setOnClickListener {
                if (!pageIsDivar) openDivar(canonicalDetailUrl(urlInput.text.toString()) ?: "https://divar.ir/") else showDivar()
            }
        }
        readButton = Button(this).apply {
            text = "خواندن و ذخیره"
            isEnabled = false
            setOnClickListener {
                if (pageIsDivar) {
                    statusText.text = "در حال پیمایش آرام صفحه برای بارگذاری مشخصات قابل‌مشاهده…"
                    divarWeb.evaluateJavascript("window.__QOQNUS_READER_READ_FULL_VISIBLE__ ? window.__QOQNUS_READER_READ_FULL_VISIBLE__() : (window.__QOQNUS_READER_READ_CURRENT__ && window.__QOQNUS_READER_READ_CURRENT__());", null)
                }
            }
        }
        listOf(app, sourcePage, readButton).forEach { buttons.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        readerControls.addView(buttons)
        revealPhoneButton = Button(this).apply {
            text = "نمایش شماره در صفحهٔ آگهی"
            isEnabled = false
            setOnClickListener {
                if (pageIsDivar) {
                    statusText.text = "ققنوس دکمهٔ نمایش شماره را در صفحه جست‌وجو می‌کند؛ اگر پیدا نشد، آن را مستقیماً در صفحهٔ آگهی بزن."
                    divarWeb.evaluateJavascript("window.__QOQNUS_READER_REVEAL_PHONE__ && window.__QOQNUS_READER_REVEAL_PHONE__();", null)
                }
            }
        }
        readerControls.addView(revealPhoneButton, LinearLayout.LayoutParams(-1, -2).apply { setMargins(8, 0, 8, 4) })
        manualContactPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(10, 8, 10, 8)
            setBackgroundColor(Color.rgb(34, 32, 26))
        }
        manualContactPanel.addView(TextView(this).apply {
            text = "شماره به‌صورت خودکار پیدا نشد؛ می‌توانی نام و شماره را دستی وارد کنی."
            textSize = 13f
            setTextColor(Color.rgb(237, 226, 202))
            setPadding(4, 2, 4, 6)
        }, LinearLayout.LayoutParams(-1, -2))
        manualOwnerNameInput = EditText(this).apply {
            hint = "نام آگهی‌دهنده (اختیاری)"
            textSize = 14f
            isSingleLine = true
        }
        manualPhoneInput = EditText(this).apply {
            hint = "شماره موبایل (مثلاً 09123456789)"
            textSize = 14f
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        manualContactPanel.addView(manualOwnerNameInput, LinearLayout.LayoutParams(-1, 48))
        manualContactPanel.addView(manualPhoneInput, LinearLayout.LayoutParams(-1, 48))
        val manualActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manualActions.addView(Button(this).apply {
            text = "ثبت دستی و ذخیره"
            setOnClickListener {
                val payload = pendingManualPayload
                val phone = normalizeIranMobile(manualPhoneInput.text.toString())
                if (payload == null) { toast("ابتدا یک آگهی را بخوان."); return@setOnClickListener }
                if (phone.isBlank()) { manualPhoneInput.error = "شماره موبایل معتبر وارد کن."; return@setOnClickListener }
                payload.put("phone", phone); payload.put("ownerPhone", phone); payload.put("sellerPhone", phone)
                payload.put("phones", org.json.JSONArray().put(phone)); payload.put("ownerName", manualOwnerNameInput.text.toString().trim())
                payload.put("customerName", manualOwnerNameInput.text.toString().trim()); payload.put("phoneReadState", "manual_entry"); payload.put("phoneSource", "user_manual_entry")
                manualContactPanel.visibility = View.GONE; pendingManualPayload = null
                enqueueReaderPayload(payload)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        manualActions.addView(Button(this).apply {
            text = "ذخیره بدون شماره"
            setOnClickListener {
                val payload = pendingManualPayload ?: return@setOnClickListener
                manualContactPanel.visibility = View.GONE; pendingManualPayload = null
                enqueueReaderPayload(payload)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        manualContactPanel.addView(manualActions, LinearLayout.LayoutParams(-1, -2))
        readerControls.addView(manualContactPanel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(8, 0, 8, 6) })
        progress = ProgressBar(this).apply { visibility = View.GONE; isIndeterminate = true }
        readerControls.addView(progress, LinearLayout.LayoutParams(-1, 4))
        root.addView(readerControls, LinearLayout.LayoutParams(-1, -2))

        webContainer = FrameLayout(this)
        appWeb = WebView(this)
        divarWeb = WebView(this).apply { visibility = View.GONE }
        webContainer.addView(appWeb, FrameLayout.LayoutParams(-1, -1))
        webContainer.addView(divarWeb, FrameLayout.LayoutParams(-1, -1))
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(17, 17, 15))
            val logoSize = (96 * resources.displayMetrics.density).toInt()
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_launcher)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "لوگوی آغازین ققنوس"
            }, LinearLayout.LayoutParams(logoSize, logoSize).apply { bottomMargin = (18 * resources.displayMetrics.density).toInt() })
            addView(TextView(this@MainActivity).apply {
                text = "ققنوس"
                textSize = 30f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(Color.rgb(232, 197, 107))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-2, -2))
            addView(TextView(this@MainActivity).apply {
                text = "دفتر همراه املاک"
                textSize = 14f
                setTextColor(Color.rgb(190, 174, 133))
                gravity = Gravity.CENTER
                setPadding(0, (6 * resources.displayMetrics.density).toInt(), 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
        }
        startupSplashView = splash
        webContainer.addView(splash, FrameLayout.LayoutParams(-1, -1))
        root.addView(webContainer, LinearLayout.LayoutParams(-1, 0, 1f))

        statusText = TextView(this).apply {
            text = ""
            textSize = 12f
            setTextColor(Color.rgb(193, 183, 161))
            setPadding(12, 8, 12, 10)
            visibility = View.GONE
        }
        root.addView(statusText)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createLoginPopup(): WebView {
        return WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            webChromeClient = object : WebChromeClient() {
                override fun onCloseWindow(window: WebView?) { runOnUiThread { closeLoginPopup() } }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.scheme == "https" && !uri.host.isNullOrBlank() && sessionLoginRequested) return false
                    if (uri.scheme == "tel" || uri.scheme == "mailto" || uri.scheme == "intent") { openExternally(uri); return true }
                    if (uri.scheme == "https" || uri.scheme == "http") { openExternally(uri); return true }
                    return true
                }
                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    if (!isDivarUrl(url)) externalLoginRedirectSeen = true
                    this@MainActivity.progress.visibility = View.VISIBLE
                }
                override fun onPageFinished(view: WebView, url: String) {
                    this@MainActivity.progress.visibility = View.GONE
                    if (isDivarUrl(url) && externalLoginRedirectSeen) {
                        statusText.text = "از مرحلهٔ ورود برگشتی. نشست در همین برنامه ذخیره می‌شود؛ برای ادامه «بازگشت به آگهی پس از ورود» را بزن."
                    } else if (sessionLoginRequested) {
                        statusText.text = "صفحهٔ تأیید ورود باز است. ورود را در همین پنجره کامل کن؛ نشست در فضای امن مرورگر داخلی همین برنامه نگهداری می‌شود."
                    }
                    runCatching { CookieManager.getInstance().flush() }
                }
            }
            setDownloadListener { url, _, _, _, _ -> openExternally(Uri.parse(url)) }
        }.also { CookieManager.getInstance().setAcceptThirdPartyCookies(it, true) }
    }

    private fun closeLoginPopup() {
        val popup = loginPopupWeb ?: run { if (::sessionReturnButton.isInitialized) sessionReturnButton.visibility = View.GONE; return }
        loginPopupWeb = null
        runCatching { webContainer.removeView(popup) }
        runCatching { popup.stopLoading(); popup.webChromeClient = null; popup.webViewClient = WebViewClient(); popup.destroy() }
        if (::sessionReturnButton.isInitialized) sessionReturnButton.visibility = View.GONE
        runCatching { CookieManager.getInstance().flush() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebViews() {
        val configure: (WebView, Boolean) -> Unit = { web, isApp ->
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.settings.databaseEnabled = true
            web.settings.allowFileAccess = false
            web.settings.allowContentAccess = false
            // Some first-party sign-in flows open a same-session window after a user tap.
            // Keep the window in this WebView; the native bridge remains origin-restricted.
            web.settings.javaScriptCanOpenWindowsAutomatically = !isApp
            web.settings.setSupportMultipleWindows(!isApp)
            web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= 26) web.settings.safeBrowsingEnabled = true
            web.webChromeClient = object : WebChromeClient() {
                override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                    // Allow a user-clicked OAuth/login popup only during explicit Divar sign-in.
                    // The popup has no native JavaScript bridge and is restricted to HTTPS navigation.
                    if (isApp || !sessionLoginRequested || !isUserGesture || loginPopupWeb != null || resultMsg == null) return false
                    val popup = createLoginPopup()
                    loginPopupWeb = popup
                    webContainer.addView(popup, FrameLayout.LayoutParams(-1, -1))
                    popup.bringToFront()
                    sessionReturnButton.visibility = View.VISIBLE
                    val transport = resultMsg.obj as? WebView.WebViewTransport
                    if (transport == null) { closeLoginPopup(); return false }
                    transport.webView = popup
                    resultMsg.sendToTarget()
                    statusText.text = "پنجرهٔ ورود باز شد. ورود و تأیید را در همین صفحه کامل کن؛ سپس «بازگشت به آگهی پس از ورود» را بزن."
                    return true
                }
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: WebChromeClient.FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    val acceptTypes = fileChooserParams?.acceptTypes.orEmpty()
                        .flatMap { it.split(',') }.map { it.trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }
                    val imageRequest = acceptTypes.any { it.startsWith("image/") || it == "image/*" }
                    val backupRequest = isApp && !imageRequest // The app has one non-image file picker: the JSON backup importer. Ignore unreliable WebView acceptTypes metadata.
                    pendingBackupImportChooser = backupRequest
                    val captureRequest = imageRequest && fileChooserParams?.isCaptureEnabled == true
                    return try {
                        if (captureRequest) {
                            val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            if (camera.resolveActivity(packageManager) == null) throw ActivityNotFoundException("Camera unavailable")
                            val directory = File(cacheDir, "camera").apply { mkdirs() }
                            val output = File(directory, "qoqnus_capture_${System.currentTimeMillis()}.jpg")
                            if (!output.createNewFile()) throw IllegalStateException("Cannot create camera output")
                            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", output)
                            pendingCameraUri = uri
                            pendingCameraFile = output
                            camera.putExtra(MediaStore.EXTRA_OUTPUT, uri)
                            camera.clipData = ClipData.newUri(contentResolver, "qoqnus camera output", uri)
                            camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                            val resolved = packageManager.queryIntentActivities(camera, 0)
                            resolved.forEach { activity -> grantUriPermission(activity.activityInfo.packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                            startActivityForResult(Intent.createChooser(camera, "گرفتن عکس برای ققنوس"), fileChooserRequestCode)
                        } else {
                            pendingCameraUri = null
                            pendingCameraFile = null
                            val choose = (fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT)).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                if (imageRequest) {
                                    action = Intent.ACTION_GET_CONTENT
                                    type = "image/*"
                                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
                                } else {
                                    action = Intent.ACTION_OPEN_DOCUMENT
                                    type = "*/*"
                                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/json", "text/plain", "application/octet-stream"))
                                }
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivityForResult(choose, fileChooserRequestCode)
                        }
                        true
                    } catch (_: ActivityNotFoundException) {
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        pendingBackupImportChooser = false
                        pendingCameraUri = null
                        pendingCameraFile?.delete(); pendingCameraFile = null
                        toast(if (captureRequest) "دوربین در این گوشی در دسترس نیست؛ گزینهٔ گالری را انتخاب کنید." else "انتخاب‌گر فایل در این گوشی در دسترس نیست.")
                        false
                    } catch (_: Exception) {
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        pendingBackupImportChooser = false
                        pendingCameraUri = null
                        pendingCameraFile?.delete(); pendingCameraFile = null
                        toast("بازکردن دوربین یا انتخاب‌گر فایل ناموفق بود.")
                        false
                    }
                }
            }
            web.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): android.webkit.WebResourceResponse? {
                    return if (isApp) assetLoader.shouldInterceptRequest(request.url) else null
                }
                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    progress.visibility = View.VISIBLE
                    if (!isApp) {
                        if (sessionLoginRequested && !isDivarUrl(url)) externalLoginRedirectSeen = true
                        val detail = canonicalDetailUrl(url)
                        if (detail != null && activeOfficeFileUrl != null && detail != activeOfficeFileUrl) {
                            activeOfficeFileId = null
                            activeOfficeFileUrl = null
                        }
                        pageIsDivar = false
                        readButton.isEnabled = false
                        revealPhoneButton.isEnabled = false
                    }
                }
                override fun onPageFinished(view: WebView, url: String) {
                    progress.visibility = View.GONE
                    if (isApp && !startupSplashDismissed) {
                        startupSplashDismissed = true
                        val splash = startupSplashView
                        if (splash != null) {
                            splash.animate().alpha(0f).setDuration(180L).withEndAction {
                                if (splash.parent === webContainer) webContainer.removeView(splash)
                                startupSplashView = null
                            }.start()
                        }
                    }
                    if (isApp) { statusText.text = "برنامک ققنوس باز است. ابتدا قفل دفتر را باز کن؛ ثبت سریع فقط فرم محدود را نشان می‌دهد." }
                    else if (isDivarUrl(url)) {
                        val returnedFromExternalLogin = sessionLoginRequested && externalLoginRedirectSeen
                        if (returnedFromExternalLogin) { sessionLoginRequested = false; externalLoginRedirectSeen = false }
                        val canonical = canonicalDetailUrl(url)
                        pageIsDivar = canonical != null
                        readButton.isEnabled = canonical != null
                        revealPhoneButton.isEnabled = canonical != null
                        val host = Uri.parse(url).host?.lowercase(Locale.ROOT).orEmpty()
                        if (host == "divar.ir" || host == "www.divar.ir") view.evaluateJavascript(readerScript, null)
                        if (canonical != null && autoReadUrl != canonical) {
                            autoReadUrl = canonical
                            autoReadAttempts = 0
                            sessionLoginRequested = false
                            if (activeOfficeFileId != null && activeOfficeFileUrl == canonical) {
                                statusText.text = "صفحهٔ آگهی باز شد. در صورت نیاز وارد حساب شو؛ برای شماره، دکمهٔ نمایش شماره را بزن و بعد «خواندن و ذخیره» را اجرا کن."
                            } else {
                                statusText.text = "صفحهٔ آگهی باز شد؛ نشست معتبر در همین برنامه استفاده می‌شود. در حال خواندن مشخصات قابل‌مشاهده…"
                                view.postDelayed({ triggerAutomaticRead(canonical) }, 2600L)
                            }
                        } else if (canonical == null) {
                            statusText.text = when {
                                sessionLoginRequested -> "صفحهٔ ورود باز است. ورود/تأیید را کامل کن؛ سپس لینک آگهی را در کادر بالا باز کن. نشست در مرورگر داخلی همین برنامه نگه داشته می‌شود."
                                returnedFromExternalLogin -> "از مرحلهٔ ورود برگشتی. اگر ورود تأیید شده، لینک آگهی را باز کن؛ اگر نه، ورود را در همین صفحه کامل کن."
                                else -> "صفحهٔ منبع آگهی باز است. برای خواندن، یک آگهی مستقیم /v/ باز کن؛ برای ورود می‌توانی از «ورود و حفظ نشست منبع آگهی» استفاده کنی."
                            }
                        } else {
                            statusText.text = "صفحهٔ آگهی آماده است. اگر شماره نمایش داده شده، «خواندن و ذخیره» را بزن؛ در غیر این صورت ابتدا دکمهٔ نمایش شماره را بزن."
                        }
                        runCatching { CookieManager.getInstance().flush() }
                    } else {
                        pageIsDivar = false; readButton.isEnabled = false; revealPhoneButton.isEnabled = false
                        statusText.text = if (sessionLoginRequested) {
                            "در حال تکمیل ورود/تأیید در همین برنامه هستی. مراحل صفحه را کامل کن؛ سپس لینک آگهی را باز کن."
                        } else {
                            "برای استفاده از نشست، ورود را از دکمهٔ «ورود و حفظ نشست منبع آگهی» آغاز کن."
                        }
                    }
                }
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri=request.url
                    if (isApp) {
                        if (uri.scheme=="https" && uri.host?.lowercase(Locale.ROOT)=="aghaj.ir") return false
                        openExternally(uri); return true
                    }
                    if (isDivarUrl(uri.toString())) return false
                    // During an explicit, user-initiated sign-in only, keep HTTPS identity-provider
                    // redirects inside the same WebView so the authentication round-trip can return
                    // to Divar. No JS bridge is installed on these external origins.
                    if (sessionLoginRequested && uri.scheme=="https" && !uri.host.isNullOrBlank()) {
                        externalLoginRedirectSeen = true
                        return false
                    }
                    if (uri.scheme=="tel" || uri.scheme=="mailto") { openExternally(uri); return true }
                    if (uri.scheme=="https" || uri.scheme=="http") { openExternally(uri); return true }
                    return true
                }
            }
            web.setDownloadListener { url, _, _, _, _ -> openExternally(Uri.parse(url)) }
        }
        configure(appWeb, true); configure(divarWeb, false)
        CookieManager.getInstance().setAcceptCookie(true)
        // Keep normal first-party Divar session cookies in this app's WebView profile.
        // Third-party cookies stay disabled; do not import or export Chrome cookies.
        // Some login/verification flows require third-party session cookies. This applies only
        // to the Divar reader WebView; the app WebView and Chrome cookies are not imported/exported.
        CookieManager.getInstance().setAcceptThirdPartyCookies(divarWeb, true)
        WebViewCompat.addWebMessageListener(appWeb, "qoqnusAppBridge", setOf(appOrigin), object : WebViewCompat.WebMessageListener {
            override fun onPostMessage(view: WebView, message: WebMessageCompat, sourceOrigin: Uri, isMainFrame: Boolean, replyProxy: JavaScriptReplyProxy) {
                if (!isMainFrame || sourceOrigin.scheme != "https" || sourceOrigin.host != "aghaj.ir") return
                val msg = runCatching { JSONObject(message.data ?: "") }.getOrNull() ?: return
                when (msg.optString("type")) {
                    "EXPORT_BACKUP_BEGIN" -> {
                        val total = msg.optInt("totalChars", -1)
                        val name = msg.optString("name", "qoqnus-mobile-encrypted-backup.json")
                        runOnUiThread { beginBackupExport(name, total) }
                    }
                    "EXPORT_BACKUP_CHUNK" -> runOnUiThread { writeBackupExportChunk(msg) }
                    "IMPORT_BACKUP_CHUNK_REQUEST" -> {
                        val offset = msg.optInt("offset", -1)
                        runOnUiThread { sendNextBackupImportChunk(offset) }
                    }
                    "PWA_READY" -> { appReady=true; runOnUiThread { deliverQueuedRecords(); openPendingReaderIfReady() } }
                    "PWA_LOCKED" -> { appReady=false }
                    "OPEN_READER" -> {
                        val link = canonicalDetailUrl(msg.optString("url"))
                        val targetId = msg.optString("recordId").trim()
                        activeOfficeFileId = targetId.takeIf { it.isNotBlank() }
                        activeOfficeFileUrl = if (link != null && !targetId.isBlank()) link else null
                        if (link == null) runOnUiThread { statusText.text="پیوند مستقیم فایل معتبر نیست." }
                        else runOnUiThread { openDivar(link) }
                    }
                    "RECORD_STORED" -> { val id=msg.optString("id"); if(id.isNotBlank()) queuedRecords.remove(id); runOnUiThread { progress.visibility = View.GONE; statusText.text="✅ آگهی در دفتر رمزگذاری‌شدهٔ ققنوس ذخیره شد."; if(queuedRecords.isEmpty()) showApp() } }
                    "RECORD_ERROR" -> runOnUiThread { progress.visibility = View.GONE; statusText.text="ذخیره در ققنوس انجام نشد: "+msg.optString("message")+" صفحه برای تلاش دوباره باز می‌ماند."; showDivar() }
                }
            }
        })
        WebViewCompat.addWebMessageListener(divarWeb, "qoqnusDivarBridge", divarOrigins, object : WebViewCompat.WebMessageListener {
            override fun onPostMessage(view: WebView, message: WebMessageCompat, sourceOrigin: Uri, isMainFrame: Boolean, replyProxy: JavaScriptReplyProxy) {
                if (!isMainFrame || sourceOrigin.scheme != "https" || sourceOrigin.host !in setOf("divar.ir","www.divar.ir")) return
                val msg=runCatching { JSONObject(message.data ?: "") }.getOrNull() ?: return
                when (msg.optString("type")) {
                    "QOQNUS_DIVAR_READER_ERROR" -> {
                        val error = msg.optString("message", "اطلاعات قابل‌خواندن از این صفحه دریافت نشد.")
                        runOnUiThread {
                            progress.visibility = View.GONE
                            if (pageIsDivar && autoReadAttempts < 2) {
                                autoReadAttempts += 1
                                statusText.text = "صفحه هنوز کامل آماده نیست؛ تلاش خودکار ${autoReadAttempts + 1} از 3…"
                                val current = canonicalDetailUrl(divarWeb.url)
                                if (current != null) divarWeb.postDelayed({ triggerAutomaticRead(current) }, 1700L)
                            } else {
                                statusText.text = error + " برای تلاش دوباره، «خواندن و ذخیره» را بزن."
                                readButton.isEnabled = true
                            }
                        }
                        return
                    }
                    "QOQNUS_DIVAR_REVEAL_PHONE_RESULT" -> {
                        val revealed = msg.optBoolean("clicked", false)
                        val count = msg.optInt("visiblePhoneCount", 0)
                        runOnUiThread {
                            statusText.text = when {
                                count > 0 -> "شمارهٔ قابل‌مشاهده پیدا شد؛ در حال خواندن و ذخیرهٔ آگهی و شماره…"
                                revealed -> "دکمهٔ نمایش شماره زده شد، اما هنوز شماره‌ای روی صفحه دیده نمی‌شود. اگر صفحه نیاز به ورود/تأیید دارد، آن را کامل کن یا دکمهٔ نمایش شماره را دوباره بزن."
                                else -> "دکمهٔ «نمایش شماره» پیدا نشد. آن را مستقیماً در صفحهٔ آگهی بزن؛ سپس «خواندن و ذخیره» را اجرا کن."
                            }
                        }
                        return
                    }
                    "QOQNUS_DIVAR_READER_RESULT" -> Unit
                    else -> return
                }
                val payload=msg.optJSONObject("payload") ?: return
                if(payload.toString().length>180_000) { runOnUiThread { toast("حجم اطلاعات این آگهی از حد مجاز بیشتر است.") }; return }
                val link=canonicalDetailUrl(payload.optString("url")) ?: return
                val id="divar:"+link.substringAfterLast('/')
                payload.put("id",id);payload.put("record_uuid",id);payload.put("url",link);payload.put("detailUrl",link);payload.put("sourceUrl",link);payload.put("canonicalUrl",link)
                if (activeOfficeFileId?.isNotBlank() == true && activeOfficeFileUrl == link) {
                    payload.put("targetOfficeFileId", activeOfficeFileId)
                }
                val extractedPhone = normalizeIranMobile(payload.optString("phone"))
                if (extractedPhone.isBlank()) {
                    synchronized(queuedRecords) { pendingManualPayload = payload }
                    runOnUiThread {
                        progress.visibility = View.GONE
                        manualOwnerNameInput.setText(payload.optString("ownerName"))
                        manualPhoneInput.setText("")
                        manualContactPanel.visibility = View.VISIBLE
                        statusText.text = "مشخصات آگهی خوانده شد، اما شماره تماس روی صفحه قابل‌دسترسی نبود. شماره را دستی وارد کن یا آگهی را بدون شماره ذخیره کن."
                        showDivar()
                    }
                    return
                }
                payload.put("phone", extractedPhone); payload.put("ownerPhone", extractedPhone)
                enqueueReaderPayload(payload)
            }
        })
    }

    private fun normalizeIranMobile(raw: String): String {
        var value = raw.map { ch -> when (ch) { in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar(); in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar(); else -> ch } }.filter { it.isDigit() }.joinToString("")
        if (value.startsWith("0098") && value.length == 14) value = "0" + value.drop(4)
        else if (value.startsWith("98") && value.length == 12) value = "0" + value.drop(2)
        else if (value.length == 10 && value.startsWith("9")) value = "0" + value
        return if (Regex("^09[0-9]{9}$").matches(value)) value else ""
    }

    private fun enqueueReaderPayload(payload: JSONObject) {
        val link = canonicalDetailUrl(payload.optString("url")) ?: return
        val id = "divar:" + link.substringAfterLast('/')
        payload.put("id", id); payload.put("record_uuid", id)
        synchronized(queuedRecords) { queuedRecords[id] = payload }
        runOnUiThread {
            manualContactPanel.visibility = View.GONE
            progress.visibility = View.GONE
            statusText.text = "اطلاعات آگهی آمادهٔ ذخیرهٔ امن در دفتر ققنوس است…"
            deliverQueuedRecords()
        }
    }

    private fun deliverQueuedRecords() {
        if (!appReady || queuedRecords.isEmpty()) return
        val first=queuedRecords.entries.firstOrNull() ?: return
        val id=first.key; val payload=first.value.toString(); val quoted=JSONObject.quote(payload)
        val script="(async()=>{try{if(!window.QoqnusMobileDivarReader||typeof window.QoqnusMobileDivarReader.receive!=='function')return;await window.QoqnusMobileDivarReader.receive(JSON.parse($quoted));}catch(e){try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'RECORD_ERROR',id:${JSONObject.quote(id)},message:String(e&&e.message||'ثبت ناموفق').slice(0,200)}));}catch(_){}}})();"
        runOnUiThread { appWeb.evaluateJavascript(script,null) }
    }

    private fun handleIncomingIntent(incoming: Intent?) {
        if (incoming == null) return
        val candidate = when (incoming.action) {
            Intent.ACTION_SEND -> incoming.getStringExtra(Intent.EXTRA_TEXT)
                ?: incoming.getStringExtra(Intent.EXTRA_SUBJECT)
                ?: incoming.getStringExtra(Intent.EXTRA_HTML_TEXT)
            Intent.ACTION_VIEW -> {
                val data = incoming.data
                if (data?.scheme == "qoqnus" && data.host == "read") data.getQueryParameter("url") else incoming.dataString
            }
            else -> null
        } ?: return
        activeOfficeFileId = null
        activeOfficeFileUrl = null
        val link=canonicalDetailUrl(candidate)
        if(link==null) { statusText.text="پیوند ارسالی، نشانی مستقیم یک آگهی نبود. از همان صفحهٔ آگهی گزینهٔ اشتراک‌گذاری را بزن."; return }
        urlInput.setText(link)
        pendingReaderUrl=link
        showApp()
        statusText.text="پیوند دریافت شد؛ اگر دفتر قفل است ابتدا آن را باز کن. خواندن مشخصات به‌طور خودکار شروع می‌شود."
    }

    private fun openPendingReaderIfReady() {
        if (!appReady || queuedRecords.isNotEmpty()) return
        val link = pendingReaderUrl ?: return
        pendingReaderUrl = null
        openDivar(link)
    }

    private fun canonicalDetailUrl(raw: String?): String? {
        val text = raw?.trim().orEmpty()
        if (text.isEmpty()) return null
        // Divar shares may use either /v/{id} or /v/{slug}/{id}; IDs are case-sensitive.
        val match = Regex(
            "https?://(?:www\\.)?divar\\.ir/v/(?:[^\\s/?#]+/)?[A-Za-z0-9][A-Za-z0-9_-]{2,120}/?(?:\\?[^\\s]*)?",
            RegexOption.IGNORE_CASE
        ).find(text)?.value ?: text
        val uri = runCatching { Uri.parse(match) }.getOrNull() ?: return null
        if (uri.scheme?.lowercase(Locale.ROOT) != "https" || uri.host?.lowercase(Locale.ROOT) !in setOf("divar.ir", "www.divar.ir")) return null
        val segments = uri.path.orEmpty().split('/').filter { it.isNotEmpty() }
        if (segments.size !in 2..3 || !segments[0].equals("v", ignoreCase = true)) return null
        val id = runCatching { Uri.decode(segments.last()) }.getOrNull() ?: return null
        if (!Regex("^[A-Za-z0-9][A-Za-z0-9_-]{2,120}$").matches(id)) return null
        if (segments.size == 3) {
            val slug = segments[1]
            if (slug.isBlank() || slug == "." || slug == ".." || slug.contains('/')) return null
            return "https://divar.ir/v/$slug/$id"
        }
        return "https://divar.ir/v/$id"
    }

    private fun isDivarUrl(raw: String): Boolean {
        val uri=runCatching { Uri.parse(raw) }.getOrNull() ?: return false
        val host=uri.host?.lowercase(Locale.ROOT) ?: return false
        return uri.scheme=="https" && (host=="divar.ir" || host=="www.divar.ir" || host.endsWith(".divar.ir"))
    }

    private fun triggerAutomaticRead(expectedUrl: String) {
        if (!pageIsDivar || divarWeb.visibility != View.VISIBLE) return
        val current = canonicalDetailUrl(divarWeb.url) ?: return
        if (current != expectedUrl) return
        progress.visibility = View.VISIBLE
        statusText.text = "در حال خواندن و ذخیرهٔ اطلاعات قابل‌مشاهدهٔ آگهی…"
        divarWeb.evaluateJavascript("window.__QOQNUS_READER_READ_FULL_VISIBLE__ ? window.__QOQNUS_READER_READ_FULL_VISIBLE__() : (window.__QOQNUS_READER_READ_CURRENT__ && window.__QOQNUS_READER_READ_CURRENT__());", null)
    }

    private fun openDivar(url: String) {
        closeLoginPopup()
        val target=canonicalDetailUrl(url) ?: if(url=="https://divar.ir/") url else null
        if(target==null) { toast("لینک باید مستقیم به آگهی /v/ باشد."); return }
        urlInput.setText(target); pageIsDivar=true; readButton.isEnabled=false; autoReadUrl=null; autoReadAttempts=0
        divarWeb.loadUrl(target); showDivar()
    }

    private fun showApp() { closeLoginPopup(); readerControls.visibility=View.GONE; statusText.visibility=View.GONE; appWeb.visibility=View.VISIBLE; divarWeb.visibility=View.GONE; pageIsDivar=false; readButton.isEnabled=false; revealPhoneButton.isEnabled=false; appReady=false; appWeb.evaluateJavascript("!!(window.QoqnusMobileDivarReader && window.QoqnusMobileDivarReader.isReady && window.QoqnusMobileDivarReader.isReady())") { value -> runOnUiThread { appReady=(value=="true"); if(appReady) { deliverQueuedRecords(); openPendingReaderIfReady() } } } }
    private fun showDivar() { readerControls.visibility=View.VISIBLE; statusText.visibility=View.VISIBLE; appWeb.visibility=View.GONE; divarWeb.visibility=View.VISIBLE; pageIsDivar=canonicalDetailUrl(divarWeb.url) != null; readButton.isEnabled=pageIsDivar; revealPhoneButton.isEnabled=pageIsDivar }

    override fun onPause() {
        runCatching { CookieManager.getInstance().flush() }
        super.onPause()
    }

    override fun onDestroy() {
        closeLoginPopup()
        closeBackupImportStream()
        super.onDestroy()
    }

    override fun onStop() {
        runCatching { CookieManager.getInstance().flush() }
        super.onStop()
    }

    private fun openExternally(uri: Uri) { try { startActivity(Intent(Intent.ACTION_VIEW,uri)) } catch (_:ActivityNotFoundException) { toast("برنامه‌ای برای بازکردن این پیوند پیدا نشد.") } }
    private fun toast(message: String) = Toast.makeText(this,message,Toast.LENGTH_LONG).show()

    private fun startNativeBackupImport(uri: Uri) {
        closeBackupImportStream()
        try {
            var displayName = "qoqnus-backup.json"
            var declaredSize = -1L
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0) displayName = cursor.getString(nameIndex)?.takeIf { it.isNotBlank() } ?: displayName
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) declaredSize = cursor.getLong(sizeIndex).takeIf { it > 0L } ?: -1L // Some document providers report 0 for an unknown length.
                }
            }
            if (declaredSize > backupImportMaxBytes) throw IllegalStateException("فایل پشتیبان بیش از ۱۵۰ مگابایت است.")
            backupImportInput = contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل انتخاب‌شده قابل خواندن نیست.")
            backupImportNextOffset = 0
            backupImportFileName = displayName.take(160)
            val sizeArg = "-1" // Treat provider-reported length as advisory; validate actual streamed bytes and the 150 MB cap.
            appWeb.evaluateJavascript(
                "window.__qoqnusBeginNativeBackupImport&&window.__qoqnusBeginNativeBackupImport(${JSONObject.quote(backupImportFileName)},$sizeArg);",
                null
            )
        } catch (error: Exception) {
            closeBackupImportStream()
            val message = error.message ?: "خواندن فایل پشتیبان از حافظه ناموفق بود."
            appWeb.evaluateJavascript("window.__qoqnusBackupImportFailed&&window.__qoqnusBackupImportFailed(${JSONObject.quote(message)});", null)
        }
    }

    private fun sendNextBackupImportChunk(expectedOffset: Int) {
        val input = backupImportInput ?: run {
            appWeb.evaluateJavascript("window.__qoqnusBackupImportFailed&&window.__qoqnusBackupImportFailed('جریان خواندن فایل پشتیبان بسته شده است؛ دوباره فایل را انتخاب کنید.');", null)
            return
        }
        if (expectedOffset != backupImportNextOffset) {
            failBackupImport("ترتیب قطعات فایل پشتیبان نامعتبر شد؛ فایل را دوباره انتخاب کنید.")
            return
        }
        try {
            val bytes = ByteArray(backupImportChunkBytes)
            var count = input.read(bytes)
            // InputStream implementations should normally return data or EOF for a non-empty
            // buffer. Guard a zero-length read so the JS chunk protocol cannot stall forever.
            if (count == 0) {
                val single = input.read()
                if (single < 0) count = -1 else { bytes[0] = single.toByte(); count = 1 }
            }
            if (count < 0) {
                closeBackupImportStream()
                appWeb.evaluateJavascript(
                    "window.__qoqnusReceiveBackupImportChunk&&window.__qoqnusReceiveBackupImportChunk($expectedOffset,'',true);",
                    null
                )
                return
            }
            backupImportNextOffset += count
            if (backupImportNextOffset.toLong() > backupImportMaxBytes) throw IllegalStateException("فایل پشتیبان بیش از ۱۵۰ مگابایت است.")
            val encoded = Base64.encodeToString(bytes, 0, count, Base64.NO_WRAP)
            appWeb.evaluateJavascript(
                "window.__qoqnusReceiveBackupImportChunk&&window.__qoqnusReceiveBackupImportChunk($expectedOffset,${JSONObject.quote(encoded)},false);",
                null
            )
        } catch (error: Exception) {
            failBackupImport(error.message ?: "خواندن قطعهٔ فایل پشتیبان ناموفق بود.")
        }
    }

    private fun failBackupImport(message: String) {
        closeBackupImportStream()
        appWeb.evaluateJavascript("window.__qoqnusBackupImportFailed&&window.__qoqnusBackupImportFailed(${JSONObject.quote(message)});", null)
    }

    private fun closeBackupImportStream() {
        runCatching { backupImportInput?.close() }
        backupImportInput = null
        backupImportNextOffset = 0
    }

    private fun beginBackupExport(name: String, totalChars: Int) {
        if (totalChars <= 0 || totalChars > 150 * 1024 * 1024) {
            appWeb.evaluateJavascript("window.__qoqnusBackupExportFinished&&window.__qoqnusBackupExportFinished(false,'حجم پشتیبان از حد مجاز ۱۵۰ مگابایت بیشتر است.');", null)
            return
        }
        backupExpectedChars = totalChars
        backupNextOffset = 0
        backupFileName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "qoqnus-mobile-encrypted-backup.json" }
        try {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, backupFileName)
            }
            startActivityForResult(intent, backupExportRequestCode)
        } catch (_: Exception) {
            finishBackupExport(false, "انتخاب محل ذخیرهٔ فایل ممکن نشد.")
        }
    }

    private fun requestNextBackupChunk(offset: Int) {
        appWeb.evaluateJavascript("window.__qoqnusTakeBackupChunk&&window.__qoqnusTakeBackupChunk($offset,65536);", null)
    }

    private fun writeBackupExportChunk(msg: JSONObject) {
        val output = backupOutput ?: return
        val offset = msg.optInt("offset", -1)
        val chunk = msg.optString("data", "")
        val done = msg.optBoolean("done", false)
        if (offset != backupNextOffset || (chunk.isEmpty() && !done)) {
            runCatching { output.close() }
            backupOutput = null
            finishBackupExport(false, "ترتیب قطعات پشتیبان نامعتبر شد؛ دوباره خروجی بگیرید.")
            return
        }
        try {
            output.write(chunk.toByteArray(Charsets.UTF_8))
            backupNextOffset += chunk.length
            if (backupNextOffset > backupExpectedChars) throw IllegalStateException("حجم قطعات از اندازهٔ اعلام‌شده بیشتر شد.")
            if (done) {
                if (backupNextOffset != backupExpectedChars) throw IllegalStateException("فایل پشتیبان کامل دریافت نشد.")
                output.flush()
                output.close()
                backupOutput = null
                finishBackupExport(true, "پشتیبان رمزگذاری‌شده ذخیره شد.")
            } else {
                requestNextBackupChunk(backupNextOffset)
            }
        } catch (_: Exception) {
            runCatching { output.close() }
            backupOutput = null
            finishBackupExport(false, "نوشتن فایل پشتیبان ناموفق بود؛ فضای ذخیره‌سازی را بررسی کنید.")
        }
    }

    private fun finishBackupExport(ok: Boolean, message: String) {
        runCatching { backupOutput?.close() }
        backupOutput = null
        backupExpectedChars = 0
        backupNextOffset = 0
        val script = "window.__qoqnusBackupExportFinished&&window.__qoqnusBackupExportFinished(${ok},${JSONObject.quote(message)});"
        if (::appWeb.isInitialized) appWeb.evaluateJavascript(script, null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            fileChooserRequestCode -> {
                val callback = fileChooserCallback
                fileChooserCallback = null
                val cameraUri = pendingCameraUri
                val cameraFile = pendingCameraFile
                val isBackupImport = pendingBackupImportChooser
                pendingBackupImportChooser = false
                pendingCameraUri = null
                pendingCameraFile = null
                val selectedBackupUri = data?.data ?: data?.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                if (resultCode == RESULT_OK && cameraUri == null && isBackupImport && selectedBackupUri != null) {
                    // Read SAF content:// streams natively. WebView content access stays disabled;
                    // the selected JSON reaches the trusted app script only through the bounded bridge.
                    callback?.onReceiveValue(null)
                    startNativeBackupImport(selectedBackupUri)
                    return
                }
                val result: Array<Uri>? = if (resultCode != RESULT_OK) {
                    cameraFile?.delete()
                    null
                } else if (cameraUri != null) {
                    if (cameraFile?.exists() == true && cameraFile.length() > 0L) arrayOf(cameraUri) else null.also { cameraFile?.delete() }
                } else {
                    val picked = data?.clipData
                    when {
                        picked != null && picked.itemCount > 0 -> Array(picked.itemCount) { index -> picked.getItemAt(index).uri }
                        data?.data != null -> arrayOf(data.data!!)
                        else -> null
                    }
                }
                callback?.onReceiveValue(result)
                if (isBackupImport) {
                    val reason = if (resultCode != RESULT_OK) "انتخاب فایل پشتیبان لغو شد." else "انتخاب‌گر، نشانی فایل پشتیبان را برنگرداند؛ دوباره انتخاب کنید."
                    appWeb.evaluateJavascript("window.__qoqnusBackupImportFailed&&window.__qoqnusBackupImportFailed(${JSONObject.quote(reason)});", null)
                }
                runCatching { cameraUri?.let { revokeUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } }
            }
            backupExportRequestCode -> {
                if (resultCode != RESULT_OK || data?.data == null) {
                    finishBackupExport(false, "ذخیرهٔ پشتیبان لغو شد.")
                    return
                }
                try {
                    backupOutput = contentResolver.openOutputStream(data.data!!, "wt")
                        ?: throw IllegalStateException("فایل برای نوشتن باز نشد.")
                    backupNextOffset = 0
                    requestNextBackupChunk(0)
                } catch (_: Exception) {
                    finishBackupExport(false, "امکان نوشتن در فایل انتخاب‌شده وجود ندارد.")
                }
            }
        }
    }

    override fun onBackPressed() { if(divarWeb.visibility==View.VISIBLE) showApp() else super.onBackPressed() }
}
