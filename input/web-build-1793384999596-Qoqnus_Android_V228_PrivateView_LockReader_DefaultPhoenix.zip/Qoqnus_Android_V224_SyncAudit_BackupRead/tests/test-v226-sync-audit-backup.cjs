'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');

function loadAudit() {
  const sandbox = { Set, Map, Date, Math, JSON, Error, console };
  sandbox.self = sandbox; sandbox.globalThis = sandbox;
  vm.runInNewContext(fs.readFileSync(path.join(assets, 'qoqnus-listing-sync-audit.js'), 'utf8'), sandbox);
  return sandbox.QoqnusListingSyncAudit;
}
function loadExtensionInventory() {
  const sandbox = { TextEncoder, TextDecoder, Uint8Array, Set, Map, Date, Math, JSON, Error, URL, console, setTimeout, clearTimeout };
  sandbox.self = sandbox; sandbox.globalThis = sandbox;
  vm.runInNewContext(fs.readFileSync('/mnt/data/triage27/ext/chrome-extension/qoqnus-durable-sync.js', 'utf8'), sandbox, { filename: 'qoqnus-durable-sync.js' });
  return sandbox.QoqnusDurableSync;
}

(async () => {
  const Audit = loadAudit();
  const Durable = loadExtensionInventory();
  // Reproduce the 27 source rows / 22 stable IDs shape. Five repeated source rows
  // must be distinguished from five genuinely missing remote records.
  const rows = [];
  for (let i = 1; i <= 22; i++) rows.push({ kind: 'listing', record: { id: 'AD-' + i, title: 'آگهی ' + i } });
  for (let i = 1; i <= 5; i++) rows.push({ kind: 'listing', record: { id: 'AD-' + i, title: 'آگهی ' + i } });
  const inventory = Durable.summarizeSourceInventory(rows, { queueRows: 27, customerRows: 0, unclassifiedQueueRows: 0 }, []);
  assert.equal(inventory.inventoryCounts.listing, 27);
  assert.equal(inventory.uniqueCounts.listing, 22);
  assert.equal(inventory.duplicateSourceRowCounts.listing, 5);
  assert.deepEqual(Array.from(inventory.duplicateSourceIdsByKind.listing), ['AD-1','AD-2','AD-3','AD-4','AD-5']);
  assert.equal(inventory.idsByKind.listing.length, 22);

  const invalidInventory = Durable.summarizeSourceInventory(rows.slice(0, 22), { queueRows: 27, customerRows: 0, unclassifiedQueueRows: 5 }, [
    { index: 22, reason: 'missing-stable-id' }, { index: 23, reason: 'missing-stable-id' },
    { index: 24, reason: 'missing-stable-id' }, { index: 25, reason: 'missing-stable-id' }, { index: 26, reason: 'missing-stable-id' }
  ]);
  assert.equal(invalidInventory.inventoryCounts.listing, 22);
  assert.equal(invalidInventory.rawStorageCounts.queueRows, 27);
  assert.equal(invalidInventory.unclassifiedQueueRows.length, 5);

  const sourceIds = { listing: Array.from({length: 27}, (_, i) => 'A-' + (i + 1)), file: [] };
  const receivedIds = { listing: sourceIds.listing.slice(0, 22), file: [] };
  const localIds = { listing: sourceIds.listing.slice(0, 22), file: [] };
  const diff = Audit.compareSnapshotIds(sourceIds, receivedIds, localIds);
  assert.equal(diff.listing.expected, 27);
  assert.equal(diff.listing.received, 22);
  assert.equal(diff.listing.stored, 22);
  assert.deepEqual(Array.from(diff.listing.notReceived), ['A-23','A-24','A-25','A-26','A-27']);
  assert.deepEqual(Array.from(diff.listing.notStored), ['A-23','A-24','A-25','A-26','A-27']);
  // An incremental request may contain only the first 22 IDs and ACK them all;
  // the independent full-source comparison must still reveal five rows missing locally.
  const incrementalSource = { listing: sourceIds.listing.slice(0, 22), file: [] };
  const incrementalDiff = Audit.compareSnapshotIds(incrementalSource, { listing: incrementalSource.listing, file: [] }, { listing: localIds.listing, file: [] });
  assert.equal(incrementalDiff.listing.notReceived.length, 0, 'this delta was fully received');
  const fullSourceDiff = Audit.compareSourceInventory(sourceIds, { listing: localIds.listing, file: [] });
  assert.equal(fullSourceDiff.listing.sourceUniqueCount, 27);
  assert.equal(fullSourceDiff.listing.localUniqueCount, 22);
  assert.equal(fullSourceDiff.listing.matchedCount, 22);
  assert.deepEqual(Array.from(fullSourceDiff.listing.missingLocalIds), ['A-23','A-24','A-25','A-26','A-27']);
  const fullSourceWithIncrementalSnapshot = Audit.compareSourceInventory(sourceIds, { listing: localIds.listing, file: [] }, incrementalSource);
  assert.deepEqual(Array.from(fullSourceWithIncrementalSnapshot.listing.missingLocalNotInSnapshotIds), ['A-23','A-24','A-25','A-26','A-27']);
  assert.equal(fullSourceWithIncrementalSnapshot.listing.missingLocalInSnapshotIds.length, 0);
  const fullRepairSnapshot = Audit.compareSourceInventory(sourceIds, { listing: localIds.listing, file: [] }, sourceIds);
  assert.deepEqual(Array.from(fullRepairSnapshot.listing.missingLocalInSnapshotIds), ['A-23','A-24','A-25','A-26','A-27']);
  assert.equal(fullRepairSnapshot.listing.missingLocalNotInSnapshotIds.length, 0);
  const hidden = Audit.summarizeRows([{id:'AD-A'}, {id:'AD-B', archiveBucket:2}, {id:'AD-C', dealOutcome:'sold'}, {id:'AD-D', dealOutcome:'rented'}]);
  assert.equal(hidden.total, 4); assert.equal(hidden.visible, 1); assert.equal(hidden.hidden, 3);

  const merged = Audit.mergeAudits(
    { kindCounts: {listing: 20,file: 0,customer: 0,contact: 0,other: 0}, receivedIds: ['A-1'], sourceInventory: { idsByKind: sourceIds, snapshotIdsByKind: sourceIds, duplicateSourceIdsByKind: {listing:['A-X'],file:[]}, idsManifestComplete: true }, chunksSeen: 1 },
    { kindCounts: {listing: 7,file: 0,customer: 0,contact: 0,other: 0}, receivedIds: ['A-2'], sourceInventory: { listing: 27, idsManifestComplete: true }, chunksSeen: 1 }
  );
  assert.equal(merged.kindCounts.listing, 27);
  assert.deepEqual(Array.from(merged.receivedIds), ['A-1','A-2']);
  assert.deepEqual(Array.from(merged.sourceInventory.snapshotIdsByKind.listing).slice(-2), ['A-26','A-27']);
  assert.deepEqual(Array.from(merged.sourceInventory.duplicateSourceIdsByKind.listing), ['A-X']);

  // Exercise the same normalizeBackupPayload() used by the live Restore button,
  // not only the lower-level backup core.
  const backupSource = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
  const normalizeStart = backupSource.indexOf('async function normalizeBackupPayload(input){');
  const normalizeEnd = backupSource.indexOf('\nasync function downloadRecoveryBackup', normalizeStart);
  assert.notEqual(normalizeStart, -1, 'active restore normalizer exists');
  assert.notEqual(normalizeEnd, -1, 'active restore normalizer terminator exists');
  const coreSandbox = { crypto: require('node:crypto').webcrypto, TextEncoder, TextDecoder, Uint8Array, Set, Map, Date, Math, JSON, Error, btoa: value => Buffer.from(value, 'binary').toString('base64') };
  coreSandbox.self = coreSandbox; coreSandbox.globalThis = coreSandbox;
  vm.runInNewContext(fs.readFileSync(path.join(assets, 'qoqnus-backup-core.js'), 'utf8'), coreSandbox);
  const BackupCore = coreSandbox.QoqnusBackupCore;
  const normalizeSandbox = { window: { QoqnusBackupCore: BackupCore }, QoqnusBackupCore: BackupCore, Set, Map, Date, Math, JSON, Error };
  normalizeSandbox.globalThis = normalizeSandbox;
  vm.runInNewContext(backupSource.slice(normalizeStart, normalizeEnd), normalizeSandbox, { filename: 'app.js:normalizeBackupPayload' });
  const testRow = { key: 'listing:BK-V227', kind: 'listing', id: 'BK-V227', updatedAt: 10, iv: 'AQ==', cipher: 'Ag==' };
  const ownBackup = await BackupCore.createBackupDocument({ records: [testRow], meta: [{ key: 'localSalt', value: 'c2FsdA==' }, { key: 'lockCheck', value: { iv: 'AQ==', cipher: 'Ag==' } }, { key: 'durableQueueState', value: { old: true } }], appVersion: 'V227' });
  const normalizedOwn = await normalizeSandbox.normalizeBackupPayload(JSON.parse(JSON.stringify(ownBackup)));
  assert.equal(normalizedOwn.formatVersion, 2);
  assert.equal(normalizedOwn.records.length, 1);
  assert.equal(normalizedOwn.records[0].key, 'listing:BK-V227');
  assert.ok(!normalizedOwn.meta.some(x => x.key === 'durableQueueState'), 'device-specific queue state must not return from a portable backup');
  const legacyBackup = { schema: 'qoqnus.mobile.backup.v1', records: [{ key: 'file:LEGACY-1', kind: 'file', id: 'LEGACY-1', record: { id: 'LEGACY-1', title: 'ملک قدیمی' } }], meta: [] };
  const normalizedLegacy = await normalizeSandbox.normalizeBackupPayload(legacyBackup);
  assert.equal(normalizedLegacy.formatVersion, 1);
  assert.equal(normalizedLegacy.records[0].legacyPlainRecord.title, 'ملک قدیمی');
  await assert.rejects(() => normalizeSandbox.normalizeBackupPayload({ ...ownBackup, manifest: { ...ownBackup.manifest, recordCount: 99 } }));

  const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
  const native = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
  const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
  const ext = fs.readFileSync('/mnt/data/triage27/ext/chrome-extension/qoqnus-durable-sync.js', 'utf8');
  assert.match(app, /snapshotIds=sourceInventory\.snapshotIdsByKind/);
  assert.match(app, /compareSourceInventory\(allSourceIds/);
  assert.match(app, /sourceLocalDiff/);
  assert.match(app, /notStoredSnapshotListingIds/);
  assert.match(app, /duplicateSourceIdsByKind/);
  assert.match(app, /conflictingDuplicateIdsByKind/);
  assert.match(app, /unclassifiedQueueRows/);
  assert.match(app, /دانلود گزارش تشخیصی اختلاف آگهی‌ها/);
  assert.match(app, /سوابق تعارض همگام‌سازی وجود دارند/);
  assert.match(ext, /function summarizeSourceInventory\(/);
  assert.match(ext, /idsManifestComplete/);
  assert.match(ext, /function sourceInventoryForChunk\(/);
  assert.match(ext, /QoqnusPeerProtocol\.classifyQueueRecord\(x\)===kind/);
  assert.doesNotMatch(ext, /if\(!cur\)continue;/, 'source snapshot rows may not silently disappear when the queue changes');
  assert.match(native, /contentResolver\.openInputStream\(uri\)/);
  assert.match(native, /val sizeArg = "-1"/);
  assert.match(native, /backupRequest = isApp && !imageRequest/);
  assert.match(native, /allowContentAccess = false/);
  assert.match(html, /qoqnus-listing-sync-audit\.js/);
  assert.match(app, /const APP_VERSION='V228'/);
  assert.match(app, /کد سریع ۴ رقمی ورود برای بازیابی پشتیبان کافی نیست/);
  assert.match(app, /QoqnusBackupCore\.verifyBackupDocument\(parsed\)/);
  assert.match(app, /__qoqnusReceiveBackupImportChunk=async function/);
  assert.match(app, /qoqnusNativeBackupImportActive/);
  assert.match(app, /if\(qoqnusNativeBackupImportActive\)return/);
  assert.match(app, /missingLocalNotInSnapshotIds/);
  assert.match(app, /درخواست کامل/);
  assert.match(fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8'), /versionCode = 38[\s\S]*versionName = \"2\.0\.32\"/);
  assert.match(sw, /qoqnus-listing-sync-audit\.js/);
  assert.match(native, /build=V228-private-view-lock-eye-reader-default-img/);
  assert.match(html, /qoqnus-build" content="V228-private-view-lock-eye-reader-default-img/);

  console.log('V227 SYNC AUDIT + BACKUP REGRESSION: PASS (27 raw rows vs 22 unique IDs, full-source vs snapshot delta diff, missing IDs outside delta vs inside full snapshot, archived/sold/rented classification, duplicate/unclassified source rows, chunk manifest merge, native import preflight and callback guard, explicit master-password guidance)');
})().catch(error => { console.error(error); process.exitCode = 1; });
