package ir.qoqnus.divarreader

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Persistent, single-instance daily reminder scheduler. Uses an inexact idle-compatible alarm. */
object DailyFileReminderScheduler {
    const val ACTION_DAILY_FILE_REMINDER = "ir.qoqnus.divarreader.action.DAILY_FILE_REMINDER"
    const val ACTION_DAILY_FILE_REMINDER_DISMISSED = "ir.qoqnus.divarreader.action.DAILY_FILE_REMINDER_DISMISSED"
    private const val PREFS = "qoqnus_daily_reminder_v1"
    private const val REQUEST_CODE = 23701

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, DailyFileReminderReceiver::class.java).setAction(ACTION_DAILY_FILE_REMINDER)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)
    }

    fun configure(context: Context, enabled: Boolean, hour: Int, minute: Int) {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        prefs(context).edit()
            .putBoolean("enabled", enabled)
            .putInt("hour", safeHour)
            .putInt("minute", safeMinute)
            .apply()
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val operation = pendingIntent(context)
        alarm.cancel(operation)
        if (enabled) scheduleNext(context) else NotificationManagerCompat.from(context).cancel(23701)
    }

    fun scheduleNext(context: Context) {
        val saved = prefs(context)
        if (!saved.getBoolean("enabled", false)) return
        val hour = saved.getInt("hour", 9).coerceIn(0, 23)
        val minute = saved.getInt("minute", 0).coerceIn(0, 59)
        val zone = TimeZone.getTimeZone("Asia/Tehran")
        val now = Calendar.getInstance(zone)
        val next = Calendar.getInstance(zone).apply {
            timeInMillis = now.timeInMillis
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DATE, 1)
        }
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pendingIntent(context))
    }

    fun wasShownToday(context: Context): Boolean {
        val zone = TimeZone.getTimeZone("Asia/Tehran")
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply { timeZone = zone }.format(Date())
        return prefs(context).getString("last_shown_day", "") == day
    }

    fun suppressToday(context: Context) {
        markShownToday(context)
        NotificationManagerCompat.from(context).cancel(23701)
        scheduleNext(context)
    }

    fun markShownToday(context: Context) {
        val zone = TimeZone.getTimeZone("Asia/Tehran")
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply { timeZone = zone }.format(Date())
        prefs(context).edit().putString("last_shown_day", day).apply()
    }
}

class DailyFileReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            DailyFileReminderScheduler.ACTION_DAILY_FILE_REMINDER_DISMISSED -> {
                DailyFileReminderScheduler.suppressToday(context)
                return
            }
            DailyFileReminderScheduler.ACTION_DAILY_FILE_REMINDER -> Unit
            else -> return
        }
        val prefs = context.getSharedPreferences("qoqnus_daily_reminder_v1", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        try {
            val hasPermission = Build.VERSION.SDK_INT < 33 ||
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (hasPermission && !DailyFileReminderScheduler.wasShownToday(context)) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) {
                    manager.createNotificationChannel(
                        NotificationChannel("qoqnus_file_review", "یادآوری بررسی فایل‌ها", NotificationManager.IMPORTANCE_DEFAULT)
                    )
                }
                val openApp = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                val openFlags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
                val contentIntent = PendingIntent.getActivity(context, 23702, openApp, openFlags)
                val dismissIntent = Intent(context, DailyFileReminderReceiver::class.java).setAction(DailyFileReminderScheduler.ACTION_DAILY_FILE_REMINDER_DISMISSED)
                val dismissPendingIntent = PendingIntent.getBroadcast(context, 23704, dismissIntent, openFlags)
                val notification = NotificationCompat.Builder(context, "qoqnus_file_review")
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("یادآوری روزانه ققنوس")
                    .setContentText("فایل‌ها، قیمت‌ها و وضعیت تماس‌ها را بررسی کنید.")
                    .setStyle(NotificationCompat.BigTextStyle().bigText("فایل‌ها، قیمت‌ها، وضعیت فعال بودن فایل‌ها و شماره‌های تماس را بررسی و اطلاعات تغییرکرده را به‌روز کنید."))
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setAutoCancel(true)
                    .setContentIntent(contentIntent)
                    .setDeleteIntent(dismissPendingIntent)
                    .build()
                NotificationManagerCompat.from(context).notify(23701, notification)
                DailyFileReminderScheduler.markShownToday(context)
            }
        } catch (_: SecurityException) {
            // Notification permission may have been revoked in Android settings.
        } finally {
            DailyFileReminderScheduler.scheduleNext(context)
        }
    }
}

class DailyFileReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> DailyFileReminderScheduler.scheduleNext(context)
        }
    }
}
