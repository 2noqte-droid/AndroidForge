'use strict';
const CACHE='qoqnus-mobile-pwa-v237-notification-listing-guard';
const CORE=['./','./index.html','./app.css?v=237-card-reference-layout','./app.js?v=237-card-reference-layout','./qoqnus-divar-data-normalizer.js?v=4.5.88-source-brand-cleanup','./qoqnus-image-normalizer.js?v=2-webp-first-400','./qoqnus-customer-photo.js?v=1-customer-webp-400','./qoqnus-listing-presentation.js?v=237-card-reference-layout','./qoqnus-time-grouping.js?v=1-tehran-calendar-groups','./peer-protocol.js?v=237-card-reference-layout','./qoqnus-backup-file-reader.js?v=237-card-reference-layout','./qoqnus-backup-core.js?v=224-backup-integrity','./qoqnus-media-transfer-core.js?v=224-media-100','./qoqnus-listing-sync-audit.js?v=237-card-reference-layout','./manifest.webmanifest?v=237-card-reference-layout','./icons/qoqnus-default-400.webp','./icons/icon-192.svg','./icons/icon-512.svg','./icons/icon-192.png?v=237-card-reference-layout','./icons/icon-512.png?v=237-card-reference-layout'];
const DB_NAME='qoqnus-mobile-local-v1';
function normalizeDivarDetailUrl(raw){
  const text=String(raw??'').trim();if(!text)return null;
  const candidates=[text];
  const matches=text.match(/https?:\/\/(?:www\.)?divar\.ir\/v\/[^\s<>()\[\]\"']+/ig)||[];
  for(const value of matches)candidates.push(value.replace(/[),.;!?،؛\]}]+$/u,''));
  for(const candidate of candidates){
    try{
      const u=new URL(candidate);
      if(u.protocol!=='https:'||!['divar.ir','www.divar.ir'].includes(u.hostname.toLowerCase()))continue;
      const segments=u.pathname.split('/').filter(Boolean);
      if(segments.length<2||segments.length>3||segments[0].toLowerCase()!=='v')continue;
      const id=decodeURIComponent(segments[segments.length-1]);
      if(!/^[A-Za-z0-9][A-Za-z0-9_-]{2,120}$/.test(id))continue;
      if(segments.length===3){const slug=decodeURIComponent(segments[1]);if(!slug||slug.includes('/')||slug==='.'||slug==='..')continue;}
      const path='/v/'+(segments.length===3?segments[1]+'/'+id:id);
      return {id,url:'https://divar.ir'+path};
    }catch{}
  }
  return null;
}
function tidyShareTitle(v){return String(v??'').replace(/[\x00-\x1f\x7f]/g,' ').replace(/\s+/g,' ').trim().slice(0,180);}
function openShareDb(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains('records')){const s=d.createObjectStore('records',{keyPath:'key'});s.createIndex('kind','kind',{unique:false});}if(!d.objectStoreNames.contains('meta'))d.createObjectStore('meta',{keyPath:'key'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('share database open failed'));});}
async function queueShareTarget(item){
  const db=await openShareDb();
  try{return await new Promise((resolve,reject)=>{
    const tx=db.transaction('meta','readwrite'),store=tx.objectStore('meta'),get=store.get('pendingDivarShares');
    get.onsuccess=()=>{
      const old=Array.isArray(get.result?.value)?get.result.value:[];
      const next=[...old.filter(x=>x&&x.url!==item.url&&x.id!==item.id),item].slice(-25);
      store.put({key:'pendingDivarShares',value:next});
    };
    get.onerror=()=>reject(get.error||new Error('share queue read failed'));
    tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('share queue write failed'));tx.onabort=()=>reject(tx.error||new Error('share queue write aborted'));
  });}finally{db.close();}
}
async function handleShareRequest(request){
  let form;try{form=await request.formData();}catch{form=new FormData();}
  const sharedUrl=String(form.get('url')||'').trim();
  const sharedText=String(form.get('text')||'').trim();
  const sharedTitle=String(form.get('title')||'').trim();
  // Android share sheets often put the URL in text (not url); some place it in title.
  const canonical=normalizeDivarDetailUrl(sharedUrl)||normalizeDivarDetailUrl(sharedText)||normalizeDivarDetailUrl(sharedTitle);
  if(canonical){await queueShareTarget({id:canonical.id,url:canonical.url,title:tidyShareTitle(sharedTitle)||tidyShareTitle(sharedText.replace(/https?:\/\/\S+/g,'')),receivedAt:Date.now(),source:'android-share-target'});}
  else{await queueShareTarget({id:'invalid-'+Date.now(),url:'',title:tidyShareTitle(form.get('title')),receivedAt:Date.now(),source:'android-share-target',error:'پیوند اشتراک‌گذاری‌شده، نشانی مستقیم آگهی از نوع /v/ نبود.'});}
  return Response.redirect(new URL('./index.html?shared_file=1',self.registration.scope).href,303);
}
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('qoqnus-mobile-pwa-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const req=event.request,url=new URL(req.url);
  if(url.origin===self.location.origin&&req.method==='POST'&&url.searchParams.has('qoqnus_share')&&(url.pathname.endsWith('/index.html')||url.pathname.endsWith('/'))){
    event.respondWith(handleShareRequest(req).catch(async()=>Response.redirect(new URL('./index.html?shared_file=error',self.registration.scope).href,303)));return;
  }
  if(req.method!=='GET')return;
  if(url.origin!==self.location.origin)return;
  if(url.pathname.endsWith('/mobile-peer.php'))return;
  event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(res=>{if(res.ok&&url.pathname.includes('/mobile-app/')){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));}return res;}).catch(()=>caches.match('./index.html'))));
});
// Exposed only for lightweight regression tests; it does not access external pages.
self.__qoqnusShareTargetTest={normalizeDivarDetailUrl};
