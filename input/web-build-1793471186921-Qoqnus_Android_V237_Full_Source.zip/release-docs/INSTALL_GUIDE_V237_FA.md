# راهنمای ساخت و نصب ققنوس Android V237

## مشخصات

- applicationId: `ir.qoqnus.divarreader`
- versionCode: `47`
- versionName: `2.0.41`
- نسخه مبنا: V236 (`46`, `2.0.40`)
- DB_NAME: `qoqnus-mobile-local-v1` (بدون تغییر)
- DB_VERSION: `2` (بدون تغییر)

## وضعیت بسته

خروجی ارائه‌شده سورس کامل و Patch است؛ APK آماده نصب در بسته وجود ندارد. در محیط فعلی Gradle، Gradle Wrapper، Android SDK و keystore نسخه انتشار موجود نیست.

## ساخت در Android Studio یا CI

۱. ZIP سورس V237 را استخراج کنید و پوشه‌ای را باز کنید که `settings.gradle.kts` در ریشه آن است.
۲. JDK 17، Android SDK Platform 35 و Build Tools سازگار را نصب کنید.
۳. Android Gradle Plugin پروژه `8.7.3` است؛ نسخه Gradle سازگار (Gradle 8.9 یا بالاتر در محدوده پشتیبانی AGP) را در محیط توسعه تأمین کنید. این بسته Gradle Wrapper ندارد.
۴. در Signing Config، کلید انتشار همان برنامه نصب‌شده را از مخزن امن CI/Android Studio معرفی کنید. فایل keystore و رمز آن را داخل پروژه یا گفتگو قرار ندهید.
۵. task زیر را اجرا کنید:

```bash
gradle :app:assembleRelease
```

۶. APK خروجی را با `apksigner verify --verbose --print-certs app-release.apk` بررسی کنید.
۷. SHA-256 یا fingerprint گواهی APK جدید را با گواهی APK نصب‌شده مقایسه کنید. اگر یکسان نیستند، نصب Update را روی گوشی اصلی امتحان نکنید.
۸. ابتدا روی گوشی آزمایشی، بدون uninstall، نسخه جدید را نصب کنید و حفظ فایل‌ها، مشتریان، شماره‌ها، تصاویر، قفل، دفتر املاک و تنظیمات را بررسی کنید.

## نصب روی گوشی اصلی

- قبل از نصب، از داخل ققنوس پشتیبان معتبر تهیه کنید.
- برنامه فعلی را حذف نکنید و داده‌های WebView/IndexedDB را پاک نکنید.
- فقط APK دارای applicationId و certificate سازگار را به‌صورت Update نصب کنید.
- پس از نصب، مجوز اعلان‌ها را در Android 13+ فعال کنید.
- تنظیم یادآوری روزانه را یک‌بار خاموش/روشن یا زمان آن را ذخیره کنید تا زمان‌بندی Native ثبت شود.
- با یادآوری inexact، اعلان ممکن است تحت Doze یا بهینه‌سازی باتری با تأخیر برسد.

## بازگشت

برای بازگشت، APK نسخه قبلی باید با همان امضای معتبر نصب شده باشد و داده‌ها پیش از آزمون پشتیبان‌گیری شوند. کاهش versionCode ممکن است توسط Android رد شود؛ در این حالت rollback استاندارد، نصب APK قبلی بدون حذف داده‌ها با همان certificate و از مسیر تست‌شده است. هرگز برای rollback برنامه را uninstall نکنید.
