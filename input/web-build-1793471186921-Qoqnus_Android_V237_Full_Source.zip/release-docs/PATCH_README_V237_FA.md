# Patch ققنوس V236 به V237

این patch برای اعمال روی سورس دقیق V236 است؛ برای APK یا نصب مستقیم روی گوشی نیست.

## پیش‌نیاز

- سورس کامل Qoqnus Android V236
- نسخه پایه باید `versionCode=46` و `versionName=2.0.40` باشد.
- از پوشه پروژه یک کپی پشتیبان بگیرید.

## اعمال

در ریشه پروژه V236:

```bash
git apply --check Qoqnus_Android_V236_to_V237_Patch.diff
git apply Qoqnus_Android_V236_to_V237_Patch.diff
```

اگر پروژه Git ندارد، می‌توان Patch ZIP را در پوشه‌ای جدا روی کپی V236 باز کرد و با `git apply` روی سورس اعمال کرد؛ فایل diff مسیرهای نسبی پروژه را دارد.

## کنترل

- `app/build.gradle.kts` باید `versionCode=47` و `versionName=2.0.41` داشته باشد.
- `DB_NAME` و `DB_VERSION` باید بدون تغییر بمانند.
- تست‌ها را با Node اجرا کنید:

```bash
for f in tests/*.cjs; do node "$f" || exit 1; done
```

## انتشار

Patch سورس نصب‌شدنی نیست. برنامه از دارایی‌های داخل APK با WebViewAssetLoader استفاده می‌کند و V237 receiver بومی AlarmManager نیز دارد؛ در نتیجه برای استفاده روی گوشی باید APK جدید ساخته و با همان certificate نسخه نصب‌شده امضا شود. APK و keystore در این تحویل تولید/ارائه نشده‌اند.
