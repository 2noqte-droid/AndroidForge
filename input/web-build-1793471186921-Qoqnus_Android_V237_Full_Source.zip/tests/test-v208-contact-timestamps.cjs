'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const project = path.resolve(__dirname, '..');
const assets = path.join(project, 'app/src/main/assets');
const js = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));
const gradle = fs.readFileSync(path.join(project, 'app/build.gradle.kts'), 'utf8');
const activity = fs.readFileSync(path.join(project, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }
function functionSource(name, prefix='function') {
  const start = js.indexOf(`${prefix} ${name}(`);
  assert.notEqual(start, -1, `missing function ${name}`);
  const end = js.indexOf('\n}', start);
  assert.notEqual(end, -1, `cannot find end of function ${name}`);
  return js.slice(start, end + 2);
}

test('V232 cache keys, HTML assets, native start URL, and Android version align', () => {
  assert.match(js, /const APP_VERSION\s*=\s*'V237'/);
  assert.match(html, /app\.js\?v=237-card-reference-layout/);
  assert.match(html, /app\.css\?v=237-card-reference-layout/);
  assert.match(sw, /qoqnus-mobile-pwa-v237-notification-listing-guard/);
  assert.match(sw, /app\.js\?v=237-card-reference-layout/);
  assert.match(manifest.start_url, /build=V237-notification-listing-guard/);
  assert.match(activity, /build=V237-notification-listing-guard/);
  assert.match(gradle, /versionCode\s*=\s*47/);
  assert.match(gradle, /versionName\s*=\s*"2\.0\.41"/);
});

test('customer, file, and listing use compact two-line timelines and real record details', () => {
  assert.match(js, /function renderCustomerCard\(r,id\)/);
  assert.match(js, /function renderFileCard\(r,id\)/);
  assert.match(js, /async function renderListings\(\)/);
  assert.match(js, /function createPropertyCardSummary\(record,kind,id,options=\{\}\)/, 'shared property-card renderer is present');
  assert.match(js, /const cardSummary=createPropertyCardSummary\(r,'file'/, 'manual file cards use the shared renderer');
  assert.match(js, /const summaryBody=createPropertyCardSummary\(r,'listing'/, 'imported listing cards use the same renderer');
  assert.match(css, /\.qoqnus-property-summary\s*\{/);
  assert.match(css, /\.qoqnus-record-timeline-row\s*\{/);
  assert.match(js, /createCallControl\(r,'تماس با مشتری',\{kind:'customer',id\}\)/);
  assert.match(js, /createCallControl\(r,'تماس با مالک',\{kind:'file',id\}\)/);
  assert.match(js, /createRecordCallControl\(r,'listing',id,'تماس با مالک'\)/);
  assert.match(js, /هنوز تماسی ثبت نشده/);
  assert.match(js, /هنوز پیگیری نشده/);
  assert.match(js, /recordCreatedTimestamp\(r\)/);
});

test('contact actions only become tracked with a valid phone and a supported record kind', () => {
  const create = functionSource('createCallControl');
  assert.match(create, /if\(phone&&tracking&&\['customer','file','listing'\]\.includes\(String\(tracking\.kind\)\)/);
  assert.match(create, /node\.addEventListener\('click'/);
  assert.match(create, /node\.disabled=true/);
  assert.match(create, /event\.preventDefault\(\)/);
  assert.match(create, /await persistCallAction\(kind,id,phone\.tel\)/);
  assert.match(create, /window\.location\.href=href/);
  assert.ok(create.indexOf('await persistCallAction') < create.indexOf('window.location.href=href'), 'save is awaited before dialer navigation');
});

test('actual click handler records before opening the dialer and disables invalid numbers', async () => {
  const createSource = functionSource('createCallControl');
  class FakeNode {
    constructor(tag) { this.tagName = tag.toUpperCase(); this.dataset = {}; this.attrs = {}; this.handlers = {}; this.classList = { add: (...items) => { this.classes = [...(this.classes || []), ...items]; } }; this.disabled = false; this.href = ''; }
    setAttribute(key, value) { this.attrs[key] = value; }
    addEventListener(type, fn) { this.handlers[type] = fn; }
  }
  const order = [];
  const sandbox = {
    document: { createElement: tag => new FakeNode(tag) },
    listingPhoneItems(value) {
      const raw = typeof value === 'string' ? value : (value?.phone || value?.mobile || '');
      return /^09\d{9}$/.test(raw) ? [{ tel: raw, text: raw }] : [];
    },
    telHref: value => `tel:${value}`,
    persistCallAction: async (kind, id, phone) => { order.push(`persist:${kind}:${id}:${phone}`); return 1_798_000_000_000; },
    renderCustomers: async () => { order.push('render:customer'); },
    renderFiles: async () => { order.push('render:file'); },
    renderListings: async () => { order.push('render:listing'); },
    setStatus: () => { order.push('status'); },
    localDateLabel: () => '۱۴۰۵/۰۸/۰۷، ۱۱:۰۰',
    window: { location: { href: '' } },
  };
  vm.runInNewContext(createSource, sandbox, { filename: 'createCallControl.js' });
  const node = sandbox.createCallControl({ id: 'c1', phone: '09123456789' }, 'تماس با مشتری', { kind: 'customer', id: 'c1' });
  assert.equal(node.tagName, 'A');
  let prevented = false;
  node.handlers.click({ preventDefault: () => { prevented = true; } });
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(prevented, true);
  assert.equal(order[0], 'persist:customer:c1:09123456789');
  assert.equal(order[1], 'render:customer');
  assert.equal(order[order.length - 1], 'status');
  assert.equal(sandbox.window.location.href, 'tel:09123456789');
  const invalid = sandbox.createCallControl('', 'تماس با مشتری', { kind: 'customer', id: 'c1' });
  assert.equal(invalid.tagName, 'BUTTON');
  assert.equal(invalid.disabled, true);
  assert.equal(invalid.handlers.click, undefined);
});

test('creation-date helper does not invent a creation date from updatedAt', () => {
  const parseSource = functionSource('parseRecordTimestamp');
  const createdSource = functionSource('recordCreatedTimestamp');
  const sandbox = {};
  vm.runInNewContext(`${parseSource}\n${createdSource}`, sandbox, { filename: 'recordCreatedTimestamp.js' });
  assert.equal(sandbox.recordCreatedTimestamp({ updatedAt: 1_798_000_000_000 }), 0);
  assert.equal(sandbox.recordCreatedTimestamp({ createdAt: 1_700_000_000_000, updatedAt: 1_798_000_000_000 }), 1_700_000_000_000);
  assert.equal(sandbox.recordCreatedTimestamp({}), 0);
});

test('creation time stays separate from last-action time', () => {
  const created = functionSource('recordCreatedTimestamp');
  assert.match(created, /createdAt/);
  assert.match(created, /firstSeenAt/);
  assert.doesNotMatch(created, /for\s*\(const key[^\n]*['"]updatedAt['"]/);
  assert.match(js, /const now=Date\.now\(\),field=kind==='customer'\?'lastContactAt':'lastFollowUpAt'/);
  assert.match(js, /\{\.\.\.current,\[field\]:now,updatedAt:now\}/);
});

test('call action persistence uses existing encrypted record writer and syncable kinds', async () => {
  const persistSource = functionSource('persistCallAction', 'async function');
  const fixedNow = 1_798_000_000_000;
  const originals = new Map([
    ['customer:c1', { id: 'c1', createdAt: 1_700_000_000_000, name: 'مشتری' }],
    ['file:f1', { id: 'f1', createdAt: 1_710_000_000_000, title: 'فایل' }],
    ['listing:l1', { id: 'l1', createdAt: 1_720_000_000_000, title: 'آگهی' }],
  ]);
  const saved = [];
  const sandbox = {
    Date: { now: () => fixedNow },
    recordById: async (kind, id) => originals.get(`${kind}:${id}`) || null,
    storeRecord: async (kind, row) => { saved.push({ kind, row: structuredClone(row) }); return row; },
  };
  vm.runInNewContext(persistSource, sandbox, { filename: 'persistCallAction.js' });
  await sandbox.persistCallAction('customer', 'c1', '09123456789');
  await sandbox.persistCallAction('file', 'f1', '09123456789');
  await sandbox.persistCallAction('listing', 'l1', '09123456789');
  assert.equal(saved.length, 3);
  assert.equal(saved[0].row.lastContactAt, fixedNow);
  assert.equal(saved[0].row.lastFollowUpAt, undefined);
  assert.equal(saved[1].row.lastFollowUpAt, fixedNow);
  assert.equal(saved[2].row.lastFollowUpAt, fixedNow);
  assert.equal(saved[0].row.createdAt, originals.get('customer:c1').createdAt);
  assert.equal(saved[1].row.createdAt, originals.get('file:f1').createdAt);
  assert.equal(saved[2].row.createdAt, originals.get('listing:l1').createdAt);
  assert.ok(saved.every(x => x.row.updatedAt === fixedNow));
  await assert.rejects(() => sandbox.persistCallAction('contact', 'x', '09123456789'));
  await assert.rejects(() => sandbox.persistCallAction('customer', 'missing', '09123456789'));
});

test('timestamp fields are not filtered from the existing sync contract', () => {
  const syncWriterStart = js.indexOf('function safeSyncRecord(');
  const syncWriterEnd = js.indexOf('\nfunction mergeLocalOnlyMedia', syncWriterStart);
  assert.ok(syncWriterStart >= 0 && syncWriterEnd > syncWriterStart);
  const syncWriter = js.slice(syncWriterStart, syncWriterEnd);
  assert.doesNotMatch(syncWriter, /['"]lastContactAt['"]/);
  assert.doesNotMatch(syncWriter, /['"]lastFollowUpAt['"]/);
  assert.match(js, /const SYNCABLE_RECORD_KINDS=new Set\(\['customer','contact','file','listing'\]\)/);
  assert.match(js, /syncJournalFingerprint\(kind,record\)/);
});

test('existing RTL manifest and brand icon assets remain present', () => {
  assert.equal(manifest.dir, 'rtl');
  assert.equal(manifest.lang, 'fa-IR');
  for (const icon of manifest.icons) assert.ok(fs.existsSync(path.join(assets, icon.src.replace(/^\.\//, ''))), `missing icon ${icon.src}`);
  assert.match(css, /--paper:\s*#11110f/);
  assert.match(css, /#d4ad58/i);
});

(async () => {
  for (const item of tests) { await item.fn(); process.stdout.write(`PASS ${item.name}\n`); }
  process.stdout.write('V223 compatibility/contact timeline tests complete. These checks do not replace Android Gradle compilation or physical-device testing.\n');
})().catch(error => { console.error(error); process.exitCode = 1; });
