 'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const app = read('app/src/main/assets/app.js');
const css = read('app/src/main/assets/app.css');
const html = read('app/src/main/assets/index.html');
const manifest = read('app/src/main/AndroidManifest.xml');
const native = read('app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt');
const scheduler = read('app/src/main/java/ir/qoqnus/divarreader/DailyFileReminder.kt');
const tests=[]; const test=(name,fn)=>{tests.push({name,fn});};
const block=(start,end)=>{const a=app.indexOf(start);assert.ok(a>=0,`missing ${start}`);const b=app.indexOf(end,a);assert.ok(b>a,`missing ${end}`);return app.slice(a,b);};

test('listing render computes needsDivarRead before use and keeps one broken record from hiding every other card',()=>{
 const listings=block('async function renderListings(', 'async function renderConflicts(');
 assert.match(listings,/const divarLink=normalizeDivarDetailUrl/);
 assert.match(listings,/const needsDivarRead=!!divarLink/);
 assert.ok(listings.indexOf('const needsDivarRead=')<listings.indexOf('if(needsDivarRead)'));
 assert.match(listings,/catch\(error\)\{console\.error\('qoqnus listing card render failed'/);
 assert.match(listings,/qoqnus-listing-render-error/);
});

test('financial detail is placed after title and before property table, and finance rows are not duplicated',()=>{
 const listings=block('async function renderListings(', 'async function renderConflicts(');
 const title=listings.indexOf('detailTitle.textContent');
 const finance=listings.indexOf('appendListingFinancialSummary(detail,r)');
 const table=listings.indexOf('appendListingDetailTable(detail,r,id)');
 assert.ok(title>=0&&finance>title&&table>finance);
 const detail=block('async function appendListingDetailTable(', 'function appendDivarOwnerNameEditor(');
 assert.doesNotMatch(detail, /'قیمت فروش'|'قیمت هر متر'|'ودیعه \/ رهن'|'اجاره ماهانه'/);
 const financial=block('function appendListingFinancialSummary(', 'async function appendListingDetailTable(');
 assert.match(financial,/tx==='sale'/); assert.match(financial,/tx==='rent'/);
 assert.match(financial,/مبلغ رهن/); assert.match(financial,/اجاره ماهانه/);
 assert.match(financial,/if\(!rows\.length\)return/);
});

test('customer followups have a stable daily cap of five and count existing notifications before adding',()=>{
 const fn=block('async function ensureDailyCustomerFollowupNotifications(', 'function makeCustomerPhotoElement(');
 assert.match(fn,/generatedToday=Math\.max\(todayNotices\.length/);
 assert.match(fn,/if\(generatedToday>=5\)break/);
 assert.match(fn,/customerFollowupCountDate/);
 assert.match(fn,/customerFollowupCount=generatedToday/);
 assert.match(fn,/\.sort\(\(a,b\)=>/);
});

test('dismissed notifications have a persistent meta tombstone and are never recreated',()=>{
 assert.match(app,/notificationDismissalsV1/);
 assert.match(app,/async function dismissNotification\(id\)/);
 assert.match(app,/async function saveLocalNotification[\s\S]*?if\(dismissals\[safeId\]\)return false/);
 assert.match(app,/!notificationDismissed\(n,dismissals\)/);
 assert.match(app,/!notificationDismissed\(r,dismissals\)/);
 assert.match(app,/clearReadNotifications[^;]*dismissNotification/s);
 assert.doesNotMatch(app,/clearReadNotifications[^;]*removeRecord\('notice'/s);
 assert.match(app,/dismiss\.textContent='حذف اعلان'/);
});

test('read, dismissed and completed followup are stored as separate fields',()=>{
 assert.match(app,/dismissedAt/);
 assert.match(app,/markNoticeRead\(id\)[\s\S]*?DISMISS_DAILY_FILE_REMINDER_TODAY/);
 assert.match(app,/completedAt/);
 assert.match(app,/notification-status/);
 assert.match(app,/پیگیری انجام‌شده/);
 assert.match(app,/readAt/);
 assert.match(app,/completedAt:Number\(existing\.completedAt\)\|\|now/);
});

test('native reminder is persistent across app close and boot and uses a Tehran day key',()=>{
 assert.match(app,/SCHEDULE_DAILY_FILE_REMINDER/);
 assert.match(native,/DailyFileReminderScheduler\.configure/);
 assert.match(manifest,/POST_NOTIFICATIONS/);
 assert.match(manifest,/RECEIVE_BOOT_COMPLETED/);
 assert.match(manifest,/DailyFileReminderBootReceiver/);
 assert.match(scheduler,/setAndAllowWhileIdle/);
 assert.match(scheduler,/else NotificationManagerCompat\.from\(context\)\.cancel/);
 assert.match(scheduler,/Asia\/Tehran/);
 assert.match(scheduler,/ACTION_BOOT_COMPLETED/);
 assert.match(scheduler,/last_shown_day/);
 assert.match(scheduler,/ACTION_DAILY_FILE_REMINDER_DISMISSED/);
 assert.match(scheduler,/setDeleteIntent\(dismissPendingIntent\)/);
 assert.match(native,/DISMISS_DAILY_FILE_REMINDER_TODAY/);
});

test('notification and customer status colors follow both theme palettes',()=>{
 assert.match(css,/notification-card\{background:var\(--surface-raised\)!important/);
 assert.match(css,/html\[data-theme="dark"\] body \.qoqnus-customer-closed\{background:#174b35!important;color:#a8f0c5!important/);
 assert.match(css,/html\[data-theme="light"\] body \.qoqnus-customer-closed\{background:#e0f8e9!important;color:#135f3c!important/);
 assert.match(css,/notification-dismiss/);
 assert.match(css,/--nav-shadow/);
 assert.match(css,/mobile-bottom-nav\{background:var\(--surface-raised\)!important/);
});

test('mobile list has bottom safe-area space and financial details have themed containers',()=>{
 assert.match(css,/main-content\{padding-bottom:calc\(96px \+ env\(safe-area-inset-bottom\)\)!important\}/);
 assert.match(css,/listing-financial-summary/);
 assert.match(css,/record-list\{padding-bottom:12px!important/);
});

test('listing statistics and list are computed from the same filtered array',()=>{
 const fn=block('async function renderListings(', 'async function renderConflicts(');
 assert.match(fn,/\$\('listingCount'\)\.textContent=displayCount\(filtered\.length\)/);
 assert.match(fn,/buildTimeGroupedSections\(list,filtered,'listing'/);
});

let failures=0;for(const t of tests){try{t.fn();console.log('PASS '+t.name);}catch(e){failures++;console.error('FAIL '+t.name+'\n'+(e.stack||e));}}
console.log(`QOQNUS V237 NOTIFICATION/LISTING TESTS: ${tests.length-failures}/${tests.length} PASS`);
if(failures)process.exitCode=1;
