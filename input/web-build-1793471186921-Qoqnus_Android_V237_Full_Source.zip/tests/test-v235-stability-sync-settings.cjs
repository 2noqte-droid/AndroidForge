'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const app = read('app/src/main/assets/app.js');
const html = read('app/src/main/assets/index.html');
const css = read('app/src/main/assets/app.css');
const sw = read('app/src/main/assets/sw.js');
const manifest = JSON.parse(read('app/src/main/assets/manifest.webmanifest'));
const gradle = read('app/build.gradle.kts');
const native = read('app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt');
const tests = [];
function test(name, fn) { fn(); tests.push(name); console.log('PASS ' + name); }

test('V237 release identifiers and cache-busting align', () => {
  assert.match(app, /const APP_VERSION='V237'/);
  assert.match(gradle, /versionCode\s*=\s*47/);
  assert.match(gradle, /versionName\s*=\s*"2\.0\.41"/);
  assert.match(html, /qoqnus-build" content="V237-notification-listing-guard/);
  assert.match(sw, /qoqnus-mobile-pwa-v237-notification-listing-guard/);
  assert.match(manifest.start_url, /build=V237-notification-listing-guard/);
  assert.match(native, /build=V237-notification-listing-guard/);
});

test('ordinary upsert never erases a local tombstone; explicit restore is preserved transactionally', () => {
  assert.match(app, /explicitRestore=record\.__qoqnusExplicitRestore===true/);
  assert.match(app, /if\(tombstone&&!explicitRestore\)throw new Error/);
  assert.match(app, /deleteKeys=SYNCABLE_RECORD_KINDS\.has\(String\(kind\)\)&&explicitRestore\?\['tombstone:'/);
  assert.match(app, /const tomb=\{id:tombId,kind:recordKind,recordId:rid,deletedAt\}/);
  assert.match(app, /localTombstone=await recordById\('tombstone',tombstoneId\)/);
  assert.match(app, /reason:'locally-deleted-tombstone'/);
});

test('record identity is stable-ID or explicit alias only, never title/phone fuzzy matching', () => {
  const begin = app.indexOf('async function applyIncomingPack(');
  const end = app.indexOf('async function ', begin + 30);
  const body = app.slice(begin, end);
  assert.match(body, /const aliasMap=await getMetaObj\('aliases',\{\}\)/);
  assert.doesNotMatch(body, /fileSignature\(/);
  const identityLines = body.split('\n').filter(line => /let prior=/.test(line)).join('\n');
  assert.doesNotMatch(identityLines, /phone|title|normalizeText/);
  assert.match(body, /String\(rec\.id\|\|''\)!==id/);
});

test('deleting an aliased record keeps its remote identity mapping and commits tombstone with row deletion atomically', () => {
  const begin = app.indexOf('function removeRecord(');
  const finish = app.indexOf('async function fingerprint(', begin);
  const removal = app.slice(begin, finish);
  assert.match(removal, /const tomb=\{id:tombId,kind:recordKind,recordId:rid,deletedAt\}/);
  assert.match(removal, /putRows\.push\(\{key:'tombstone:'\+tomb\.id/);
  assert.match(removal, /commitLocalRecordMutation\(\{putRows,deleteKeys,journal,journalChanged\}\)/);
  const start = app.indexOf('async function deleteLocalRecord(');
  const end = app.indexOf('function tag(', start);
  const deletion = app.slice(start, end);
  assert.match(deletion, /await removeRecord\(kind,id\)/);
  assert.doesNotMatch(deletion, /delete .*aliases|createTombstone/);
  assert.match(app, /knownAlias=String\(aliasMap/);
});

test('new remote records are staged for explicit approval and not inserted into active books', () => {
  assert.match(app, /storeRecord\('syncCandidate',\{id:candidateId,kind,recordId:id,remoteRecord:incoming/);
  assert.match(app, /async function acceptSyncCandidate\(candidateId\)/);
  assert.match(app, /async function ignoreSyncCandidate\(candidateId/);
  assert.match(app, /await storeRecord\(kind,saved\);await removeRecord\('syncCandidate',candidateId\)/);
  assert.match(html, /id="syncNewCandidates"/);
  assert.match(html, /id="syncIgnoredCandidates"/);
  assert.match(html, /id="syncUpdatedRecords"/);
});

test('sync summary counts pending review per record kind and preserves applied change detail', () => {
  assert.match(app, /pendingReview:\{customer:0,file:0,listing:0\}/);
  assert.match(app, /summary\.pendingReview\[kind\]\+=eventStats\.pendingReview\[kind\]/);
  assert.match(app, /lastSyncReviewChangesV1/);
  assert.match(app, /changedFields/);
});

test('full sync does not force-replace local changes and request failures can be settled', () => {
  assert.doesNotMatch(app, /forceReplace|forcedFull/);
  assert.match(app, /classifySyncChange\(change\)/);
  assert.match(app, /queue-request-status/);
  assert.match(app, /epochMismatch\|\|\['failed','cancelled','canceled','expired','rejected','missing','not_found'/);
  assert.match(html, /id="resolvePendingSyncRequest"/);
});

test('daily file reminder is Tehran-time and persisted once per calendar day', () => {
  assert.match(app, /dailyReminderStateV1/);
  assert.match(app, /state\.fileReviewDate!==today/);
  assert.match(app, /currentTehranMinutes\(\)>=timeToMinutes\(settings\.dailyFileReminderTime\)/);
  assert.match(app, /'file-review-'\+today/);
  assert.match(html, /id="settingDailyFileReminderTime"/);
  assert.match(html, /زمان‌بندی بومی اندروید/);
  assert.match(app, /SCHEDULE_DAILY_FILE_REMINDER/);
  assert.match(native, /DailyFileReminderScheduler.configure/);
});

test('update-check notification UI and producer are removed, legacy notices are hidden without deleting user data', () => {
  assert.doesNotMatch(html, /checkUpdatesButton|بررسی نسخه جدید/);
  assert.doesNotMatch(app, /checkSoftwareUpdate|UPDATE_FEED_URL|checkUpdatesButton/);
  assert.doesNotMatch(css, /notification-type\.software-update/);
  assert.match(app, /all\.filter\(n=>n\.type!=='software-update'&&!notificationDismissed\(n,dismissals\)\)/);
  assert.match(app, /rows=\(await recordsOf\('notice'\)\)\.map\(x=>x\.record\)\.filter\(r=>r\.type!=='software-update'&&!notificationDismissed\(r,dismissals\)\)/);
});

test('single settings store controls notifications and theme modes', () => {
  assert.match(app, /const APP_SETTINGS_KEY='qoqnus-app-settings-v1'/);
  for (const id of ['settingNotificationsEnabled','settingDailyFileReminderEnabled','settingNewFilesEnabled','settingNewCustomersEnabled','settingSyncNotificationsEnabled','settingErrorsEnabled','settingThemeMode']) assert.ok(html.includes(`id="${id}"`), id);
  assert.match(app, /\['dark','light','system'\]\.includes/);
  assert.match(app, /function writeAppSettings\(next\)/);
});

console.log(`QOQNUS V237 STABILITY TESTS: ${tests.length}/${tests.length} PASS`);
