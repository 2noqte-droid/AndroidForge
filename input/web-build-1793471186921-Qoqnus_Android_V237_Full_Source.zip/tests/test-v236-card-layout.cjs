'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app/src/main/assets');
const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(assets, 'app.css'), 'utf8');
const tests = [];
const test = (name, fn) => tests.push({name, fn});
function block(start, end) { const a=app.indexOf(start); assert.ok(a>=0,`missing ${start}`); const b=app.indexOf(end,a); assert.ok(b>a,`missing end ${end}`); return app.slice(a,b); }
function luminance(hex) { const clean=hex.replace('#',''); const rgb=[0,2,4].map(i=>parseInt(clean.slice(i,i+2),16)/255).map(v=>v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4); return .2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2]; }
function contrast(a,b) { const v=[luminance(a),luminance(b)].sort((x,y)=>y-x); return (v[0]+.05)/(v[1]+.05); }

test('property card uses the required left identity, center information and right photo columns',()=>{
 const summary=block('function createPropertyCardSummary(', 'function renderFileCard(');
 assert.match(summary,/heading\.append\(title,price\)/);
 assert.match(summary,/main\.append\(identity,info,thumbnail\)/);
 assert.match(summary,/qoqnus-card-thumbnail--property/);
 assert.match(summary,/qoqnus-card-new-badge/);
 assert.match(css,/grid-template-columns:52px minmax\(0,1fr\) 70px/);
 assert.match(css,/direction:ltr!important/);
 assert.match(css,/\.qoqnus-card-heading\{[\s\S]*direction:rtl!important/);
});

test('file action row has exact left-to-right icon order: more, delete, view, confirm',()=>{
 const file=block('function renderFileCard(', 'function renderCard(');
 const row=file.slice(file.indexOf("const actions=document.createElement('div')"),file.indexOf('art.append(cardSummary'));
 const icons=[...row.matchAll(/createCardIconAction\('(more|trash|eye|check)'/g)].map(m=>m[1]);
 assert.deepEqual(icons,['more','trash','eye','check']);
 assert.match(file,/deleteLocalRecord\('file',id\)/);
 assert.match(file,/completeListingDeal|archiveBucket:2|archiveReason:res/);
});

test('customer card follows the same columns, places budget opposite the name and keeps five icon actions',()=>{
 const customer=block('function renderCustomerCard(', 'async function readDivarFromOfficeFile(');
 assert.match(customer,/heading\.append\(name,budget\)/);
 assert.match(customer,/main\.append\(identity,info,thumbnail\)/);
 assert.match(customer,/createCardIdentityStrip\('customer','',r\.type\)/);
 const row=customer.slice(customer.indexOf("const actions=document.createElement('div')"),customer.indexOf('art.append(main,actions'));
 const icons=[...row.matchAll(/createCardIconAction\('(more|edit|check|trash)'/g)].map(m=>m[1]);
 assert.deepEqual(icons,['more','edit','check','trash']);
 assert.match(row,/setListingActionIcon\(call,'phone'/);
 assert.match(customer,/customerBudgetLabel\(r\)/);
});

test('file, customer and listing follow-up plus creation date are only in the footer',()=>{
 const footer=block('function createCardFooter(', 'function customerBudgetLabel(');
 assert.match(footer,/آخرین پیگیری|lastActionLabel/);
 assert.match(footer,/تاریخ ثبت/);
 assert.match(footer,/footer\.append\(left\);if\(createdLabel\)footer\.append\(right\)/);
 const property=block('function createPropertyCardSummary(', 'function renderFileCard(');
 assert.doesNotMatch(property,/آخرین پیگیری|تاریخ ثبت/);
 assert.match(app,/createCardFooter\('آخرین تماس'/);
 assert.match(app,/createCardFooter\('آخرین پیگیری'/);
});

test('published listing card exposes existing edit and guarded central republish actions',()=>{
 const listings=block('async function renderListings(', 'async function renderConflicts(');
 const row=listings.slice(listings.indexOf("const actions=document.createElement('div')"),listings.indexOf('detail.append(detailActions)'));
 assert.match(row,/createCardIconAction\('more','اطلاعات کامل آگهی'/);
 assert.match(row,/createCardIconAction\('edit','ویرایش اطلاعات آگهی'/);
 assert.match(row,/createCardIconAction\('trash','حذف آگهی'/);
 assert.match(row,/createCardIconAction\('eye','مشاهده و خواندن آگهی'/);
 assert.match(row,/createCardIconAction\('send','انتشار مجدد یا جایگزینی آگهی/);
 assert.match(row,/actions\.append\(more,edit,del,view,republish,deal\)/, 'DOM order is explicit and stable');
 assert.match(row,/publishMobileRecord\('listing',id,republish\)/);
 assert.match(row,/detail\.querySelector\('\.divar-owner-editor input'\)\|\|detail\.querySelector\('\.office-private-panel summary'\)/);
 assert.match(css,/qoqnus-card-actions--listing\{grid-template-columns:repeat\(6,minmax\(0,1fr\)\)/);
});

test('published listing metadata is data-driven and omitted when unavailable',()=>{
 const meta=block('function listingPublicationMeta(', 'function createPropertyCardSummary(');
 for(const key of ['publicationChannel','publishChannel','channels','rubika_status','eitaa_status','publishedAt','published_at','validUntil','expiresAt']) assert.ok(meta.includes(key),`missing optional ${key}`);
 assert.match(meta,/if\(!parts\.length\)return null/);
 assert.match(meta,/qoqnus-card-publication-meta/);
 assert.match(css,/qoqnus-card-publication-meta/);
});

test('transaction ribbon contains a white dot before the label and sale/rent colors pass contrast',()=>{
 const identity=block('function createCardIdentityStrip(', 'function createCardFooter(');
 assert.match(identity,/ribbon\.append\(dot,text\)/);
 assert.match(css,/qoqnus-card-ribbon--sale\{background:#94640d/);
 assert.match(css,/qoqnus-card-ribbon--rent\{background:#087f86/);
 assert.ok(contrast('#fff8e8','#94640d')>=4.5);
 assert.ok(contrast('#efffff','#087f86')>=4.5);
});

test('no archive badge or bookmark is present in the compact primary action row',()=>{
 const badges=block('function buildPropertyCardBadges(', 'function optionalCardDateLabel(');
 assert.doesNotMatch(badges,/بایگانی/);
 const file=block('function renderFileCard(', 'function renderCard(');
 const actions=file.slice(file.indexOf("const actions=document.createElement('div')"),file.indexOf('art.append(cardSummary'));
 assert.doesNotMatch(actions,/bookmark/);
 assert.match(css,/font-size:0!important/);
 assert.match(css,/qoqnus-listing-action-svg/);
 assert.match(css,/height:44px!important;min-height:44px!important/);
});

test('small screens retain horizontal three-column card and fit actions without horizontal scrolling',()=>{
 assert.match(css,/@media\(max-width:420px\)/);
 assert.match(css,/@media\(max-width:340px\)/);
 assert.match(css,/grid-template-columns:45px minmax\(0,1fr\) 60px/);
 assert.match(css,/grid-template-columns:40px minmax\(0,1fr\) 54px/);
 assert.doesNotMatch(css,/qoqnus-compact-card[^}]*overflow-x:auto/);
});

let failures=0;
for(const item of tests){try{item.fn();console.log('PASS '+item.name)}catch(e){failures++;console.error('FAIL '+item.name+'\n'+(e.stack||e));}}
console.log(`QOQNUS V237 CARD LAYOUT TESTS: ${tests.length-failures}/${tests.length} PASS`);
if(failures)process.exitCode=1;
