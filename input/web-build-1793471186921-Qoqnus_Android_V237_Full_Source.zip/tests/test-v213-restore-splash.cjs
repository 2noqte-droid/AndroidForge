const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const db = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const backupCore = fs.readFileSync(path.join(root, 'app/src/main/assets/qoqnus-backup-core.js'), 'utf8');
const splash = fs.readFileSync(path.join(root, 'app/src/main/res/values-v31/styles.xml'), 'utf8');
const transparent = fs.readFileSync(path.join(root, 'app/src/main/res/drawable/splash_transparent.xml'), 'utf8');
const manifest = fs.readFileSync(path.join(root, 'app/src/main/AndroidManifest.xml'), 'utf8');
const build = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const checks = [
 ['restore validates v2 backup and retains legacy container compatibility', /async function normalizeBackupPayload\(input\)/.test(js) && /QoqnusBackupCore\.verifyBackupDocument/.test(js) && /schema\.endsWith\(\'.v2\'\) \? 2 : 1/.test(backupCore)],
 ['encrypted rows are authenticated before replacement', /decryptWithKey\(key,\{iv:row\.iv,cipher:row\.cipher\}\)/.test(js)],
 ['legacy plaintext rows are re-encrypted', /legacyPlainRecord/.test(js) && /encryptWithKey\(key,record\)/.test(js)],
 ['restore stores recovery snapshot and uses atomic transaction', /lastRestoreSafetyCopy/.test(js) && /db\.transaction\(\[STORE,META,RECOVERY\],'readwrite'\)/.test(js)],
 ['current records remain protected if validation fails', /دیتابیس فعلی دست\u200cنخورده ماند/.test(js)],
 ['Android 12+ system splash icon is transparent', /windowSplashScreenAnimatedIcon">@drawable\/splash_transparent/.test(splash) && /#0011110F/.test(transparent)],
 ['launcher activity and current theme remain configured', /android:name="\.MainActivity"/.test(manifest) && /android:theme="@style\/AppTheme"/.test(manifest)],
 ['version and SDK values updated without changing target/min SDK', /versionCode = 47/.test(build) && /versionName = "2\.0\.41"/.test(build) && /minSdk = 26/.test(build) && /targetSdk = 34/.test(build) && /compileSdk = 35/.test(build)],
];
for (const [name, ok] of checks) { if (!ok) { console.error('FAIL', name); process.exitCode = 1; } else console.log('PASS', name); }
if (!process.exitCode) console.log(`V223 restore/splash source checks: ${checks.length} passed. Device/Gradle build not implied.`);
