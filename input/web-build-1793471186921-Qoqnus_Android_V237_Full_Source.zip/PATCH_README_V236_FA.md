# Patch بازطراحی کارت ققنوس V235 به V236

این patch برای سورس پایه `Qoqnus_Android_V235` ساخته شده است.

## اعمال روی سورس

از ریشه پروژه V235 اجرا کنید:

```bash
git apply Qoqnus_Android_V235_to_V236_Card_Redesign.patch
```

یا با patch:

```bash
patch -p1 < Qoqnus_Android_V235_to_V236_Card_Redesign.patch
```

پس از اعمال، پروژه نسخه V236 خواهد بود (`versionCode=46`, `versionName=2.0.40`).

## بررسی

```bash
node --check app/src/main/assets/app.js
node tests/test-v236-card-layout.cjs
```

تمام تست‌ها با اجرای `node tests/*.cjs` قابل اجرا هستند.

## نکته انتشار

این patch فایل نصب APK نیست. منابع WebView داخل بسته Android قرار دارند؛ برای نصب روی گوشی باید APK جدید build شود و برای Update روی برنامه قبلی، گواهی امضای همان نسخه حفظ شود. دیتابیس و Storeها در این patch تغییر نکرده‌اند.
