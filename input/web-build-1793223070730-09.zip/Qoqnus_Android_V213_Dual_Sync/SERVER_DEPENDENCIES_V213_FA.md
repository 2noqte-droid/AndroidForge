# وابستگی‌ها و محدودیت‌های سمت سرور — V213

این گزارش از سورس سرور ارسالی `rubika_realestate.zip` استخراج شده است؛ سرور تغییر نکرده است.

## فعال‌سازی لازم

1. اطمینان از اجرای مهاجرت‌های موجود:
   - `026_mobile_peer_persistent_pairing.sql`
   - `029_mobile_peer_sync_state.sql`
   - `030_mobile_peer_durable_queue.sql`
   - `031_peer_queue_retain_until_ack.sql`
   - `032_weekly_sync_epoch_requests.sql`
2. فعال‌کردن گزینهٔ `mobile_peer_durable_queue_enabled` در بخش تنظیمات اتصال/همگام‌سازی مدیر. در `config/integrations.example.php` مقدار پیش‌فرض `false` است.
3. استفاده از نسخهٔ افزونه‌ای که قرارداد `qoqnus.sealed-queue.v1` و endpointهای `queue-sync-requests-ext` را پشتیبانی می‌کند. سورس افزونه در ZIP ورودی حاضر نبود؛ بنابراین سازگاری متقابل آن را کامپایل یا به‌صورت زنده تست نکردم.

## APIهای استفاده‌شده

`queue-meta`, `queue-register-key`, `queue-peers`, `queue-publish`, `queue-pull`, `queue-ack`, `queue-status`, `queue-request-sync`, `queue-sync-requests`, `queue-request-complete`, `queue-request-status`.

## ناسازگاری مهم با شرط «ACK همهٔ دستگاه‌ها»

تابع `qoqnus_peer_weekly_rotate_queue()` در `public/mobile-peer.php` هنگام رسیدن زمان epoch، این دستورات را اجرا می‌کند:

- `DELETE FROM qoqnus_mobile_peer_delivery_queue`
- `DELETE FROM qoqnus_mobile_peer_sync_requests`

این پاک‌سازی همهٔ ردیف‌ها را حذف می‌کند؛ شرط `status='received'` یا تأیید همهٔ دستگاه‌ها ندارد. پس دستگاهی که بیش از یک چرخهٔ هفتگی آفلاین باشد ممکن است بستهٔ افزایشی خودش را از دست بدهد. موبایل epoch mismatch را تشخیص می‌دهد و full-sync را الزامی می‌کند، ولی جلوگیری مطلق از پاک‌سازی pending نیازمند اصلاح سرور است؛ خارج از محدودهٔ این تحویل.
