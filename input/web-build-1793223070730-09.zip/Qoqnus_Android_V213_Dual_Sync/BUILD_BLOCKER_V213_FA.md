# مانع ساخت APK در این محیط

ساخت `assembleDebug` اجرا نشد، چون Gradle/Gradle Wrapper و Android SDK/`android.jar` در محیط موجود نبودند. سورس Android با نسخهٔ `versionCode=17`, `versionName=2.1.1` آماده است؛ برای دریافت APK باید در AndroidForge یا Android Studio دارای SDK ساخت شود. هیچ APK نصب‌پذیر در این تحویل ساخته نشده است.
