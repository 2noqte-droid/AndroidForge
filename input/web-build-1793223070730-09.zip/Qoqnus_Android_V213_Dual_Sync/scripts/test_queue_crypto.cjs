const fs = require('fs');
const vm = require('vm');
const { webcrypto } = require('crypto');
const source = fs.readFileSync('app/src/main/assets/peer-protocol.js', 'utf8');
const context = { crypto: webcrypto, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, DataView, btoa, atob, console };
context.self = context;
context.globalThis = context;
vm.runInNewContext(source, context, { filename: 'peer-protocol.js' });
const P = context.QoqnusPeerProtocol;
(async () => {
  const target = await webcrypto.subtle.generateKey({name:'ECDH', namedCurve:'P-256'}, true, ['deriveBits']);
  const targetPrivJwk = await webcrypto.subtle.exportKey('jwk', target.privateKey);
  const targetPubJwk = await webcrypto.subtle.exportKey('jwk', target.publicKey);
  const targetPrivate = await webcrypto.subtle.importKey('jwk', targetPrivJwk, {name:'ECDH',namedCurve:'P-256'}, false, ['deriveBits']);
  const identity = { id:'self', privateKey: targetPrivate, publicJwk: targetPubJwk };
  const value = { type:'sync-pack', pack:{schema:'qoqnus.peer-sync.v1',deviceId:'0123456789abcdef0123456789abcdef',items:[{kind:'file',id:'F-1',record:{id:'F-1',title:'تست'} }],tombstones:[]}, finalChunk:true };
  const aad='0123456789abcdef0123456789abcdef:mobile:fedcba9876543210fedcba9876543210';
  const envelope = await P.sealQueuePayload(targetPubJwk, value, aad);
  if (envelope.schema !== 'qoqnus.sealed-queue.v1' || envelope.alg !== 'ECDH-P256-HKDF-SHA256-AES-256-GCM') throw new Error('bad envelope schema');
  const decoded = await P.openQueuePayload(envelope, aad, identity);
  if (JSON.stringify(decoded) !== JSON.stringify(value)) throw new Error('round-trip mismatch');
  let aadRejected=false;
  try { await P.openQueuePayload(envelope, aad+':tampered', identity); } catch { aadRejected=true; }
  if (!aadRejected) throw new Error('modified AAD should fail authentication');
  let ciphertextRejected=false;
  const tampered={...envelope,ciphertext:envelope.ciphertext.slice(0,-4)+'AAAA'};
  try { await P.openQueuePayload(tampered, aad, identity); } catch { ciphertextRejected=true; }
  if (!ciphertextRejected) throw new Error('tampered ciphertext should fail authentication');
  console.log('test_queue_crypto: PASS (round-trip, AAD authentication, ciphertext tamper rejection)');
})().catch(e=>{ console.error(e); process.exit(1); });
