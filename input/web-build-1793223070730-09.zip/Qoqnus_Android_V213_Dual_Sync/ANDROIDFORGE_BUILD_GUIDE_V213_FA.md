# راهنمای ساخت APK ققنوس V213

1. فایل `Qoqnus_Android_Source_V213_Dual_Sync.zip` را در AndroidForge به‌عنوان پروژهٔ Android/Kotlin وارد کنید؛ یا پوشهٔ پروژه را در Android Studio باز کنید.
2. اجازه دهید Gradle Sync وابستگی‌های `androidx.webkit:webkit:1.12.1` و `androidx.core:core:1.13.1` را resolve کند.
3. Build Variant را روی `debug` قرار دهید و `assembleDebug` را اجرا کنید.
4. خروجی مورد انتظار در صورت ساخت موفق: `app/build/outputs/apk/debug/app-debug.apk`.
5. ابتدا روی یک گوشی آزمایشی نصب کنید؛ بعد جفت‌سازی، فهرست مبدأ، همگام‌سازی delta، full sync، دریافت دوبارهٔ همان بسته، قطع/وصل اینترنت و تصاویر را آزمایش کنید.
6. برای انتشار عمومی، APK release را با کلید امضای تحت کنترل مالک پروژه بسازید. کلید امضا را داخل ZIP سورس قرار ندهید.

## نتیجه این محیط

در محیط آماده‌سازی این بسته `gradle`, `gradlew`, `ANDROID_HOME`, `ANDROID_SDK_ROOT` و `android.jar` وجود نداشتند؛ بنابراین ساخت APK در اینجا اجراشدنی نبود و هیچ APK ساخته‌شده‌ای ادعا نمی‌شود.
