(() => {
  'use strict';
  const clean = (v, max = 30000) => String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ').replace(/[ \t\r]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim().slice(0, max);
  const safeText = (v, max = 30000) => clean(v, max).replace(/(?:(?:\+|00)?98\s*)?0?9[\d۰-۹٠-٩\s()\-]{8,15}/gu, '[شمارهٔ تماس؛ برای ثبت شماره، آن را جداگانه و با اقدام کاربر ثبت کنید]');
  const send = (payload) => { try { if (window.qoqnusDivarBridge && typeof window.qoqnusDivarBridge.postMessage === 'function') window.qoqnusDivarBridge.postMessage(JSON.stringify(payload)); } catch (_) {} };
  const canonical = () => {
    try {
      const u = new URL(location.href);
      if (!['divar.ir', 'www.divar.ir'].includes(u.hostname.toLowerCase())) return null;
      const segments = u.pathname.split('/').filter(Boolean);
      if (segments.length < 2 || segments.length > 3 || segments[0].toLowerCase() !== 'v') return null;
      const id = decodeURIComponent(segments[segments.length - 1]);
      if (!/^[A-Za-z0-9][A-Za-z0-9_-]{2,120}$/.test(id)) return null;
      let path = '/v/' + id;
      if (segments.length === 3) {
        const slug = decodeURIComponent(segments[1]);
        if (!slug || slug.includes('/') || slug === '.' || slug === '..') return null;
        path = '/v/' + segments[1] + '/' + id;
      }
      return { id, url: 'https://divar.ir' + path };
    } catch (_) { return null; }
  };
  const jsonLdItems = () => {
    const out = [];
    for (const node of document.querySelectorAll('script[type="application/ld+json"]')) {
      if (!node.textContent || node.textContent.length > 500000) continue;
      try { const x = JSON.parse(node.textContent); const visit = v => { if (!v || typeof v !== 'object') return; if (Array.isArray(v)) return v.forEach(visit); out.push(v); if (v['@graph']) visit(v['@graph']); if (v.mainEntity) visit(v.mainEntity); }; visit(x); } catch (_) {}
    }
    return out;
  };
  const visibleText = el => {
    try { const s = getComputedStyle(el), r = el.getBoundingClientRect(); return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0 && r.width > 0 && r.height > 0; } catch (_) { return false; }
  };
  const extractRows = () => {
    const rows = {};
    for (const tr of document.querySelectorAll('tr')) {
      if (!visibleText(tr)) continue;
      const cells = [...tr.querySelectorAll('th,td')].map(x => clean(x.innerText, 200)).filter(Boolean);
      if (cells.length >= 2) rows[cells[0]] = cells.slice(1).join('، ').slice(0, 500);
    }
    for (const dl of document.querySelectorAll('dl')) {
      const children = [...dl.children];
      for (let i = 0; i < children.length - 1; i++) if (children[i].tagName === 'DT' && children[i + 1].tagName === 'DD') {
        const k = clean(children[i].innerText, 150), v = clean(children[i + 1].innerText, 500); if (k && v) rows[k] = v;
      }
    }
    // Many listing layouts render each public attribute as two adjacent text lines rather than table/dl rows.
    const lines = clean(document.body?.innerText || '', 60000).split('\n').map(x => clean(x, 500)).filter(Boolean);
    const knownLabels = /^(?:قیمت(?: کل| فروش| هر متر)?|ودیعه|رهن|اجاره(?: ماهانه)?|متراژ|مساحت(?: زمین)?|زیربنا|متراژ بنا|تعداد خواب|خواب|اتاق|طبقه|سال ساخت|سن بنا|نوع ملک|نوع معامله|موقعیت|محله|آدرس|نشانی|پارکینگ|آسانسور|انباری|بالکن|سند|وضعیت سند|جهت ساختمان|سیستم گرمایش|سیستم سرمایش|کفپوش|آشپزخانه|تعداد طبقات|واحد در طبقه|قیمت هر متر|قابل تبدیل|امکانات)$/iu;
    for (let i = 0; i < lines.length && i < 500; i++) {
      const line = lines[i];
      const labelled = line.match(/^([^:：]{1,80})\s*[:：]\s*(.{1,450})$/u);
      if (labelled && knownLabels.test(clean(labelled[1], 80))) {
        rows[clean(labelled[1], 80)] = clean(labelled[2], 450);
        continue;
      }
      if (knownLabels.test(line) && !rows[line] && lines[i + 1] && lines[i + 1].length <= 450) {
        const next = lines[i + 1];
        if (!knownLabels.test(next) && !/^(?:ثبت آگهی|تماس|چت|گزارش آگهی|ذخیره|مشاهدهٔ بیشتر|توضیحات)$/iu.test(next)) rows[line] = next;
      }
    }
    return Object.fromEntries(Object.entries(rows).slice(0, 140));
  };
  const asciiDigits = v => String(v ?? '').replace(/[۰-۹٠-٩]/g, d => String.fromCharCode(d.charCodeAt(0) >= 0x6f0 && d.charCodeAt(0) <= 0x6f9 ? d.charCodeAt(0) - 0x6f0 + 48 : d.charCodeAt(0) - 0x660 + 48));
  const normalizeIranMobile = raw => {
    let s = asciiDigits(raw).replace(/\D/g, '');
    if (s.startsWith('0098') && s.length === 14) s = '0' + s.slice(4);
    else if (s.startsWith('98') && s.length === 12) s = '0' + s.slice(2);
    if (s.length === 10 && s.startsWith('9')) s = '0' + s;
    return /^09\d{9}$/.test(s) ? s : '';
  };
  // Only numbers currently rendered to the user, including tel links. No hidden API/state or private page payload is queried.
  const extractVisiblePhones = () => {
    const found = new Set();
    const addFrom = value => {
      const visible = asciiDigits(String(value || ''));
      const re = /(?:(?:\+?98|0098)[\s().-]*)?0?9(?:[\s().-]*\d){9}/g;
      for (const m of visible.matchAll(re)) { const n = normalizeIranMobile(m[0]); if (n) found.add(n); if (found.size >= 10) break; }
    };
    for (const a of document.querySelectorAll('a[href^="tel:"]')) {
      if (!visibleText(a)) continue;
      const n = normalizeIranMobile(a.getAttribute('href').slice(4));
      if (n) found.add(n);
    }
    // Read only numbers currently rendered in the listing main area or a visible contact dialog.
    const roots = new Set([document.querySelector('main,[role="main"]') || document.body]);
    for (const dialog of document.querySelectorAll('[role="dialog"],[aria-modal="true"]')) if (visibleText(dialog)) roots.add(dialog);
    for (const root of roots) if (root) addFrom(root.innerText || '');
    // Some mobile layouts expose the revealed number on a visible tel/label button instead of main text.
    for (const el of document.querySelectorAll('button,[role="button"],a[aria-label],a[title]')) {
      if (!visibleText(el)) continue;
      addFrom([el.innerText,el.getAttribute('aria-label'),el.getAttribute('title')].filter(Boolean).join(' '));
      if (found.size >= 10) break;
    }
    return [...found].slice(0, 10);
  };
  const images = () => {
    const values = [];
    const add = v => { try { const u = new URL(String(v || ''), location.href); if (u.protocol === 'https:' && !values.includes(u.href) && !/\.svg(?:$|\?)/i.test(u.pathname)) values.push(u.href); } catch (_) {} };
    for (const key of ['og:image', 'twitter:image']) { const m = document.querySelector('meta[property="' + key + '"],meta[name="' + key + '"]'); if (m) add(m.content); }
    for (const img of document.querySelectorAll('main img, [role="main"] img, img')) { if (!visibleText(img)) continue; add(img.currentSrc || img.src); if (values.length >= 35) break; }
    return values.slice(0, 35);
  };
  const structured = () => {
    const all = jsonLdItems();
    const choose = pred => all.find(pred) || {};
    const item = choose(x => /Product|Offer|RealEstateListing|Residence|House|Apartment/.test(String(x['@type'] || '')));
    const offer = item.offers && (Array.isArray(item.offers) ? item.offers[0] : item.offers) || choose(x => /Offer/.test(String(x['@type'] || '')));
    const address = item.address && (typeof item.address === 'string' ? item.address : [item.address.addressLocality, item.address.streetAddress, item.address.addressRegion].filter(Boolean).join('، '));
    return { item, offer: offer || {}, address: address || '' };
  };
  window.__QOQNUS_READER_READ_CURRENT__ = () => {
    const link = canonical();
    if (!link) { send({type:'QOQNUS_DIVAR_READER_ERROR', message:'این صفحه، جزئیات یک آگهی نیست. یک آگهی را باز کنید تا نشانی آن /v/شناسه باشد.'}); return; }
    const st = structured(), body = clean(document.body?.innerText || '', 60000);
    const h1 = [...document.querySelectorAll('h1')].find(visibleText);
    const meta = (key) => document.querySelector('meta[property="' + key + '"],meta[name="' + key + '"]')?.content || '';
    const title = clean(h1?.innerText || meta('og:title') || st.item.name || st.item.headline || document.title.replace(/\s*[|—-]\s*دیوار\s*$/u,''), 240) || ('آگهی ' + link.id);
    const description = clean(meta('description') || st.item.description || '', 8000);
    const rows = extractRows();
    const usefulBody = body.replace(/(?:دسته‌ها|من|چت|تماس|پشتیبانی|گزارش آگهی|ثبت آگهی)/g,' ').trim();
    if ((!title || /^آگهی\s+[A-Za-z0-9_-]+$/u.test(title)) && usefulBody.length < 160 && !Object.keys(rows).length) { send({type:'QOQNUS_DIVAR_READER_ERROR', message:'اطلاعات قابل‌خواندن از این صفحه دریافت نشد. صفحه را کامل باز کن و دوباره تلاش کن.'}); return; }
    if (usefulBody.length < 80 && Object.keys(rows).length===0) { send({type:'QOQNUS_DIVAR_READER_ERROR', message:'جزئیات صفحه هنوز بارگذاری نشده است. چند لحظه صبر کن و دوباره «خواندن و ذخیره» را بزن.'}); return; }
    const lineValue = (pattern) => {
      const row = Object.entries(rows).find(([k]) => pattern.test(clean(k, 150)));
      if (row && row[1]) return clean(row[1], 300);
      const lines = body.split('\n').map(x => clean(x,500)).filter(Boolean);
      const exact = lines.find(x => pattern.test(x)); if (!exact) return '';
      const match = exact.match(/[:：]\s*(.+)$/u); return clean(match ? match[1] : exact.replace(pattern,'').trim(), 160);
    };
    const areaText = lineValue(/^(?:متراژ|مساحت|زیربنا|متراژ بنا|متراژ ساختمان|مساحت زمین)\s*[:：]?/u);
    const roomsText = lineValue(/^(?:تعداد خواب|خواب|اتاق)\s*[:：]?/u);
    const locationText = lineValue(/^(?:موقعیت|محل|محله|آدرس|نشانی)\s*[:：]?/u) || clean(st.address,300);
    const priceText = clean(st.offer.price || lineValue(/^(?:قیمت کل|قیمت فروش|قیمت|ودیعه|رهن|اجاره ماهانه|اجاره|قیمت هر متر)\s*[:：]?/u), 180);
    const attrs = {...rows};
    const visiblePhones = extractVisiblePhones();
    const rowText = Object.entries(rows).map(([k,v])=>k+': '+v).join('\n');
    const detailText = safeText([rowText, usefulBody].filter(Boolean).join('\n\n'), 12000);
    const payload = {
      schema:'qoqnus.listing-reader.v1', readerState:'complete', detailReadState:'complete', mobileReaderState:'complete',
      id:'divar:' + link.id, divarId:link.id, postId:link.id, url:link.url, detailUrl:link.url, sourceUrl:link.url, canonicalUrl:link.url,
      title, text:safeText(body,30000), content:safeText(body,30000), description:safeText(description,8000), publicDescription:safeText(description,8000), detailText,
      location:locationText, locationText:locationText, priceText, salePrice:clean(st.offer.price || lineValue(/^(?:قیمت کل|قیمت فروش|قیمت)\s*[:：]?/u),60), area:areaText, area_sqm:areaText, rooms:roomsText,
      attributes:attrs, facts:{location:locationText, priceText, area:areaText, rooms:roomsText}, imageUrls:images(),
      phones:visiblePhones, phone:visiblePhones[0] || '', ownerPhone:visiblePhones[0] || '',
      phoneReadState:visiblePhones.length ? 'visible_on_page' : 'not_displayed_by_divar', phoneSource:visiblePhones.length ? 'visible-divar-contact' : '',
      source:'qoqnus-mobile-reader', sourceLabel:'خوانشگر همراه ققنوس', collectedFrom:'android-webview-reader', extractedAt:Date.now(), createdAt:Date.now(), updatedAt:Date.now(), status:'saved', sendStatus:'not_sent', reviewStatus:'not_required', publicationState:'not_sent'
    };
    send({type:'QOQNUS_DIVAR_READER_RESULT', payload});
  };
  // One user-initiated, bounded scroll helps load lazy public details. It returns to the original position and reads only the rendered page.
  window.__QOQNUS_READER_READ_FULL_VISIBLE__ = async () => {
    if (!canonical()) { window.__QOQNUS_READER_READ_CURRENT__(); return; }
    const original = window.scrollY || 0;
    let lastHeight = 0;
    for (let i = 0; i < 12; i++) {
      const height = Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0);
      const step = Math.max(360, Math.floor(window.innerHeight * 0.75));
      if (window.scrollY + window.innerHeight >= height - 4 && height === lastHeight) break;
      window.scrollTo(0, Math.min(height, i * step));
      lastHeight = height;
      await new Promise(resolve => setTimeout(resolve, 240));
    }
    window.scrollTo(0, original);
    await new Promise(resolve => setTimeout(resolve, 450));
    window.__QOQNUS_READER_READ_CURRENT__();
  };
  // This only clicks an exact, visible official reveal button. It does not call private endpoints or bypass login/anti-bot checks.
  window.__QOQNUS_READER_REVEAL_PHONE__ = () => {
    if (!canonical()) { send({type:'QOQNUS_DIVAR_REVEAL_PHONE_RESULT', clicked:false, visiblePhoneCount:0}); return; }
    const allowed = /^(?:نمایش شماره|نمایش شماره تماس|مشاهده شماره|مشاهده شماره تماس|نمایش تلفن|مشاهده تلفن|دیدن شماره|دیدن شماره تماس|شماره تماس|اطلاعات تماس|نمایش اطلاعات تماس|مشاهده اطلاعات تماس|دریافت شماره تماس|نمایش شماره فروشنده|مشاهده شماره فروشنده|نمایش شماره آگهی.?دهنده|مشاهده شماره آگهی.?دهنده)$/u;
    const target = [...document.querySelectorAll('button,[role="button"]')].find(el => visibleText(el) && allowed.test(clean(el.innerText || el.getAttribute('aria-label') || el.textContent, 100)));
    if (!target) {
      const phones = extractVisiblePhones();
      send({type:'QOQNUS_DIVAR_REVEAL_PHONE_RESULT', clicked:false, visiblePhoneCount:phones.length});
      if (phones.length) window.__QOQNUS_READER_READ_CURRENT__();
      return;
    }
    target.click();
    (async()=>{let phones=[];for(let attempt=0;attempt<10;attempt++){await new Promise(resolve=>setTimeout(resolve,350));phones=extractVisiblePhones();if(phones.length)break;}send({type:'QOQNUS_DIVAR_REVEAL_PHONE_RESULT', clicked:true, visiblePhoneCount:phones.length});if(phones.length)window.__QOQNUS_READER_READ_CURRENT__();})();
  };
})();
