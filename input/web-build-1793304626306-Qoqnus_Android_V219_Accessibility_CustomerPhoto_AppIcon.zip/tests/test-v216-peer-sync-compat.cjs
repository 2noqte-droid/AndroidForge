'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const build = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const activity = fs.readFileSync(path.join(root, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'app/src/main/assets/sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'app/src/main/assets/manifest.webmanifest'), 'utf8'));

function extractDeviceIdNormalizer(source) {
  const match = source.match(/function cleanDeviceId\(v\)\{([\s\S]*?return '';\})/);
  assert.ok(match, 'cleanDeviceId function exists');
  return new Function('v', match[1].replace(/\}$/, ''));
}
const cleanDeviceId = extractDeviceIdNormalizer(js);
assert.equal(cleanDeviceId('0123456789abcdef0123456789abcdef'), '0123456789abcdef0123456789abcdef');
assert.equal(cleanDeviceId('01234567-89ab-cdef-0123-456789abcdef'), '0123456789abcdef0123456789abcdef');
assert.equal(cleanDeviceId(' 01234567-89AB-CDEF-0123-456789ABCDEF '), '0123456789abcdef0123456789abcdef');
assert.equal(cleanDeviceId('not-a-device-id'), '');
assert.equal(cleanDeviceId('01234567-89ab-cdef-0123-456789abcde'), '');

assert.match(html, /id="downloadExtensionBackup"/);
assert.match(js, /async function startPairedMobileSync\(options=\{\}\)/);
assert.match(js, /startPairedMobileSync\(\{exportBackupAfter:true\}\)/);
assert.match(js, /receivedRemoteFullSnapshotV1=true/);
assert.match(js, /backupAfterExtensionSync=false,receivedRemoteFullSnapshotV1=false,remoteFullSnapshotCounts=null/);
assert.match(js, /فرایند خروجی پشتیبان آغاز شد/);
assert.match(js, /wantsExtensionBackup&&!receivedRemoteFullSnapshotV1/);
assert.match(js, /if\(wantsExtensionBackup\)\{try\{await exportBackup\(\)/);
assert.match(build, /versionCode = 29/);
assert.match(build, /versionName = "2\.0\.23"/);
assert.match(activity, /V219-accessibility-customer-photo-icon/);
assert.match(sw, /qoqnus-mobile-pwa-v219-accessibility-customer-photo-icon/);
assert.match(manifest.start_url, /V219-accessibility-customer-photo-icon/);
console.log('PASS device IDs accept legacy 32-hex and canonical UUID without changing identity');
console.log('PASS remote-backup action requires a complete incoming V1 snapshot before exporting');
console.log('PASS version, WebView URL, manifest and cache identifiers are aligned');
console.log('V217 focused sync compatibility tests: 3 groups passed; no live extension/server transfer was simulated.');
