'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'app/src/main/assets/app.css'), 'utf8');
const build = fs.readFileSync(path.join(root, 'app/build.gradle.kts'), 'utf8');
const tests = [];
const test = (name, fn) => tests.push({ name, fn });
test('backup has no device dropdown but local export and restore remain', () => {
  const backup = html.slice(html.indexOf('id="view-backup"'), html.indexOf('</section>', html.indexOf('id="view-backup"')));
  assert.doesNotMatch(backup, /<select|backupSourceDevice|backupSourceHelp/);
  assert.match(backup, /id="exportBackup"/);
  assert.match(backup, /id="restoreBackupFile"/);
  assert.match(backup, /id="restoreBackup"/);
  assert.match(js, /\$\('exportBackup'\)\.addEventListener\('click',\(\)=>exportBackup\(\)/);
});
test('sync device selector is visible, accurately documents one locally paired peer', () => {
  assert.match(html, /id="syncDeviceSelect"/);
  assert.match(html, /انتخاب دستگاه برای همگام‌سازی/);
  assert.match(js, /async function refreshSyncDeviceSelector/);
  assert.match(js, /if\(!p\).*اتصال معتبر و ذخیره‌شده‌ای پیدا نشد/s);
  assert.match(js, /فهرست چند گوشی نیازمند API فهرست دستگاه‌ها در سرویس سمت سرور است/);
  assert.match(css, /#syncDeviceSelect\{/);
});
test('incremental and full sync validate and use the selected actual pairing', () => {
  assert.match(js, /async function selectedSyncPairing\(\)/);
  assert.match(js, /saved=await selectedSyncPairing\(\)/);
  assert.match(js, /activePairingId=saved\.pairId;activePairingToken=saved\.token/);
  assert.match(js, /fullRefreshListingSync.*selectedSyncPairing\(\)/);
});
test('sync timestamp is tied to the pairing that actually completed', () => {
  assert.match(js, /lastSuccessfulSyncPairId/);
  assert.match(js, /if\(completedPairId\)await setMetaObj\('lastSuccessfulSyncPairId',completedPairId\)/);
});
test('release identifiers are aligned', () => {
  assert.match(js, /const APP_VERSION='V219'/);
  assert.match(html, /V219-accessibility-customer-photo-icon/);
  assert.match(build, /versionCode = 29/);
  assert.match(build, /versionName = "2\.0\.23"/);
});
for (const item of tests) { item.fn(); process.stdout.write(`PASS ${item.name}\n`); }
process.stdout.write(`V217 focused sync/backup source tests: ${tests.length} passed. This is not a live server/device test.\n`);
