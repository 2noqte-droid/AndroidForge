const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { webcrypto } = require('crypto');
const assert = require('assert/strict');

const assets = path.resolve(__dirname, '../app/src/main/assets');
function loadGlobal(file, globalName) {
  const sandbox = {
    crypto: webcrypto,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    Set,
    Map,
    Date,
    Math,
    JSON,
    Error,
    btoa: value => Buffer.from(value, 'binary').toString('base64'),
    console
  };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  vm.runInNewContext(fs.readFileSync(path.join(assets, file), 'utf8'), sandbox, { filename: file });
  assert.ok(sandbox[globalName], `${globalName} exposed`);
  return sandbox[globalName];
}

(async () => {
  const Backup = loadGlobal('qoqnus-backup-core.js', 'QoqnusBackupCore');
  const imageA = 'data:image/webp;base64,UklGRg==';
  const imageB = 'data:image/jpeg;base64,/9j/2Q==';
  const records = [
    { key: 'file:F-1', kind: 'file', id: 'F-1', iv: 'AQ==', cipher: 'Ag==', updatedAt: 10 },
    { key: 'customer:C-1', kind: 'customer', id: 'C-1', iv: 'Aw==', cipher: 'BA==', updatedAt: 11 }
  ];
  const meta = [
    { key: 'localSalt', value: 'salt-value' },
    { key: 'lockCheck', value: { iv: 'iv', cipher: 'cipher' } },
    { key: 'quickPinSalt', value: 'pin-salt' },
    { key: 'deviceCryptoKey', value: 'old-device-key' },
    { key: 'deviceId', value: 'old-device-id' },
    { key: 'peerPairing', value: { pairId: 'old-pair' } },
    { key: 'durableQueueState', value: { cursor: 999 } },
    { key: 'peer:old-pair', value: { mediaCursor: 999 } },
    { key: 'changeJournal', value: { changes: { stale: true } } },
    { key: 'deviceName', value: 'گوشی کاربر' }
  ];
  const plaintext = new Map([
    ['file:F-1', { id: 'F-1', imageDataUrls: [imageA, imageB] }],
    ['customer:C-1', { id: 'C-1', profilePhotoWebp: imageA }]
  ]);
  const backup = await Backup.createBackupDocument({
    records,
    meta,
    appVersion: 'V222',
    createdAt: 123456,
    decryptRecord: async row => plaintext.get(row.key)
  });
  assert.equal(backup.schema, 'qoqnus.mobile.backup.v2');
  assert.equal(backup.formatVersion, 2);
  assert.equal(backup.manifest.recordCount, 2);
  assert.equal(backup.manifest.fileCount, 1);
  assert.equal(backup.manifest.customerCount, 1);
  assert.equal(backup.manifest.attachmentCount, 3);
  assert.ok(backup.integrity?.digest);
  assert.ok(backup.meta.some(x => x.key === 'localSalt'));
  assert.ok(backup.meta.some(x => x.key === 'quickPinSalt'));
  assert.ok(backup.meta.some(x => x.key === 'deviceName'));
  for (const key of ['deviceCryptoKey','deviceId','peerPairing','durableQueueState','peer:old-pair','changeJournal']) {
    assert.ok(!backup.meta.some(x => x.key === key), `transient meta ${key} excluded`);
  }
  const verified = await Backup.verifyBackupDocument(JSON.parse(JSON.stringify(backup)));
  assert.equal(verified.records.length, 2);
  assert.equal(verified.manifest.attachmentCount, 3);

  const tampered = JSON.parse(JSON.stringify(backup));
  tampered.records[0].cipher = 'changed';
  await assert.rejects(() => Backup.verifyBackupDocument(tampered), /دست‌کاری|ناقص/);

  const badCount = JSON.parse(JSON.stringify(backup));
  badCount.manifest.recordCount = 99;
  // Manifest is integrity-protected; failure should occur before any restore writes.
  await assert.rejects(() => Backup.verifyBackupDocument(badCount));

  const restoredMeta = Backup.restoreMetaRows(backup.meta, {
    localSalt: 'new-salt', lockCheck: { iv: 'fresh', cipher: 'fresh' },
    deviceId: 'new-device', deviceCryptoKey: 'fresh-key'
  });
  assert.ok(restoredMeta.some(x => x.key === 'deviceId' && x.value === 'new-device'));
  assert.ok(restoredMeta.some(x => x.key === 'deviceCryptoKey' && x.value === 'fresh-key'));
  assert.ok(!restoredMeta.some(x => x.key === 'peerPairing' || x.key === 'durableQueueState'));

  const legacy = await Backup.verifyBackupDocument({ schema: 'qoqnus.mobile.backup.v1', records: [{ key: 'file:old', kind: 'file', id: 'old', iv: 'AQ==', cipher: 'Ag==' }], meta: [] });
  assert.equal(legacy.formatVersion, 1);
  assert.equal(legacy.records.length, 1);
  const emptyV2 = await Backup.createBackupDocument({ records: [], meta: [], appVersion: 'V222' });
  const emptyVerified = await Backup.verifyBackupDocument(JSON.parse(JSON.stringify(emptyV2)));
  assert.equal(emptyVerified.records.length, 0, 'a valid empty v2 backup can restore settings on a fresh install');

  // Simulate uninstall/reinstall: only the JSON file survives; the new installation
  // derives the same master key from the backed-up salt and the user's password.
  const password = 'qoqnus-restore-test-pass';
  const salt = webcrypto.getRandomValues(new Uint8Array(16));
  const material = await webcrypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  const masterKey = await webcrypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 310000, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt','decrypt']);
  const iv = webcrypto.getRandomValues(new Uint8Array(12));
  const originalRecord = { id: 'restore-1', kind: 'file', title: 'ملک آزمایشی', imageDataUrls: [imageA] };
  const encrypted = await webcrypto.subtle.encrypt({ name: 'AES-GCM', iv }, masterKey, new TextEncoder().encode(JSON.stringify(originalRecord)));
  const toB64 = bytes => Buffer.from(bytes).toString('base64');
  const checkIv = webcrypto.getRandomValues(new Uint8Array(12));
  const checkCipher = await webcrypto.subtle.encrypt({ name: 'AES-GCM', iv: checkIv }, masterKey, new TextEncoder().encode(JSON.stringify({ magic: 'qoqnus-mobile-lock-v1' })));
  const portableMeta = [
    { key: 'localSalt', value: toB64(salt) },
    { key: 'lockCheck', value: { iv: toB64(checkIv), cipher: toB64(checkCipher) } },
    { key: 'deviceId', value: 'old-device' },
    { key: 'deviceCryptoKey', value: 'must-not-export' },
    { key: 'durableQueueState', value: { stale: true } },
    { key: 'peer:old', value: { mediaCursor: 777 } }
  ];
  const restorable = await Backup.createBackupDocument({
    records: [{ key: 'file:restore-1', kind: 'file', id: 'restore-1', iv: toB64(iv), cipher: toB64(encrypted) }],
    meta: portableMeta, appVersion: 'V222', decryptRecord: async () => originalRecord
  });
  const afterReinstall = await Backup.verifyBackupDocument(JSON.parse(JSON.stringify(restorable)));
  const importedMeta = Object.fromEntries(restorable.meta.map(x => [x.key, x.value]));
  const reinstallMaterial = await webcrypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  const reinstallKey = await webcrypto.subtle.deriveKey({ name: 'PBKDF2', salt: Buffer.from(importedMeta.localSalt, 'base64'), iterations: 310000, hash: 'SHA-256' }, reinstallMaterial, { name: 'AES-GCM', length: 256 }, false, ['encrypt','decrypt']);
  const lockCheck = JSON.parse(new TextDecoder().decode(await webcrypto.subtle.decrypt({ name: 'AES-GCM', iv: Buffer.from(importedMeta.lockCheck.iv, 'base64') }, reinstallKey, Buffer.from(importedMeta.lockCheck.cipher, 'base64'))));
  assert.equal(lockCheck.magic, 'qoqnus-mobile-lock-v1');
  const restoredPlain = JSON.parse(new TextDecoder().decode(await webcrypto.subtle.decrypt({ name: 'AES-GCM', iv: Buffer.from(restorable.records[0].iv, 'base64') }, reinstallKey, Buffer.from(restorable.records[0].cipher, 'base64'))));
  assert.equal(restoredPlain.title, 'ملک آزمایشی');
  const freshMeta = Backup.restoreMetaRows(restorable.meta, { localSalt: importedMeta.localSalt, lockCheck: importedMeta.lockCheck, deviceId: 'fresh-device', deviceCryptoKey: reinstallKey });
  assert.equal(freshMeta.find(x => x.key === 'deviceId').value, 'fresh-device');
  assert.ok(!freshMeta.some(x => x.key === 'durableQueueState' || x.key === 'peer:old' || x.key === 'deviceCryptoKey' && x.value === 'must-not-export'));

  const Media = loadGlobal('qoqnus-media-transfer-core.js', 'QoqnusMediaTransferCore');
  const imageList = Array.from({ length: 12 }, (_, i) => `data:image/webp;base64,${Buffer.from(String(i)).toString('base64')}`);
  assert.equal(Media.collectMediaDataCandidates({ imageDataUrls: imageList }).length, 12, 'no 10-image truncation');
  assert.equal(Media.collectMediaDataCandidates({ images: [{ src: 'data:image/gif;base64,R0lG' }] }).length, 1, 'malformed/unsupported data:image is kept for explicit validation failure');
  assert.equal(Media.validateMediaIndex(99), 99);
  assert.throws(() => Media.validateMediaIndex(100), /محدوده/);
  const oneHundred = Array.from({ length: 100 }, (_, i) => `data:image/jpeg;base64,${Buffer.from('x' + i).toString('base64')}`);
  assert.equal(Media.collectMediaDataCandidates({ photos: oneHundred }).length, 100);
  assert.throws(() => Media.collectMediaDataCandidates({ photos: [...oneHundred, 'data:image/png;base64,AA=='] }), /۱۰۰ تصویر/);

  const app = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
  assert.match(app, /changeCursor:items\.length\?cursor:lastMediaBuildCursor/, 'cursor remains unchanged while media remains pending');
  assert.match(app, /catch\(error\)\{throw new Error\('انتقال تصویر/, 'invalid media stops instead of being silently skipped');
  assert.doesNotMatch(app, /function mobileMediaDataCandidates\([^\n]+slice\(0,10\)/);
  assert.match(app, /QoqnusBackupCore\.restoreMetaRows\(data\.meta/);
  assert.match(app, /await QoqnusBackupCore\.verifyBackupDocument\(input\)/);
  assert.ok(app.includes("typeof value==='string'&&/^data:image\\//i.test(value)"), 'all data:image formats must be validated; unsupported images cannot be silently preserved');
  const indexHtml = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
  assert.match(indexHtml, /qoqnus-media-transfer-core\.js\?v=222-media-100/);
  assert.match(sw, /qoqnus-media-transfer-core\.js\?v=222-media-100/);

  console.log('V222 BACKUP/MEDIA CORE: PASS (backup v2 integrity, legacy v1, reinstall key recovery, transient metadata reset, empty backup, attachment manifest, tamper detection, no silent media truncation, all data:image validation, 100-image bound, cursor safety, cache version)');
})().catch(error => { console.error(error); process.exitCode = 1; });
