'use strict';
(() => {
const $ = id => document.getElementById(id);
// Report early WebView/runtime failures instead of leaving controls apparently unresponsive.
window.addEventListener('error', event => {
 const message=String(event?.message||event?.error?.message||'خطای ناشناخته جاوااسکریپت');
 console.error('[Qoqnus runtime]',message,event?.filename||'',event?.lineno||'');
 const target=$('lockStatus');if(target&&!target.textContent)target.textContent='خطای اجرای برنامه: '+message.slice(0,220);
 const sync=$('syncStatus');if(sync)sync.textContent='خطای اجرای برنامه: '+message.slice(0,220);
 const storage=$('storageStatus');if(storage)storage.textContent='خطای اجرای برنامه؛ جزئیات در گزارش WebView: '+message.slice(0,180);
});
window.addEventListener('unhandledrejection', event => {
 const reason=event?.reason,message=String(reason?.message||reason||'خطای عملیات ناهمگام');
 console.error('[Qoqnus async runtime]',message);
 const sync=$('syncStatus');if(sync)sync.textContent='عملیات ناموفق: '+message.slice(0,220);
});
const DB_NAME='qoqnus-mobile-local-v1', DB_VERSION=2, STORE='records', META='meta', RECOVERY='restoreRecovery';
const APP_VERSION='V241';
const DEFAULT_RECORD_IMAGE='./icons/qoqnus-default-400.webp';
let appliedCustomerSearchText='', appliedCustomerSearchRole='all', appliedCustomerSearchFields=['name','phone'];
let appliedFileSearchText='', appliedFileCriteria={transaction:[],property:[],rooms:[],hvac:[]};
const shareArrivalState=new URL(location.href).searchParams.get('shared_file')||'';
let readerLaunchState=new URL(location.href).searchParams.get('reader')||'';
let readerLaunchRecordId=new URL(location.href).searchParams.get('readerRecord')||'';
let readerLaunchWatchdog=null,readerLaunchAttempt=0,readerLaunchButton=null,readerLaunchWentBackground=false;
const encoder=new TextEncoder(), decoder=new TextDecoder();
let db=null, cryptoKey=null, deviceId='', deferredInstallPrompt=null, dailyReminderCheckedDate='', pinSetupPending=false, masterFallback=false, lockSubmitBusy=false;
const pendingAppAcks=new Map();
let quickEntryMode=false,backgroundOperationsMode=false,fullOfficeUnlocked=false,quickEntryPhone='',quickEntryStagedFiles=[],quickFormContext=null,quickEntryUnlockPromise=null,imageNormalizationPromise=Promise.resolve(null),backupAfterExtensionSync=false,receivedRemoteFullSnapshotV1=false,remoteFullSnapshotCounts=null,pendingCustomerPhotoWebp='',listingPriceNormalizationPromise=null;
function b64(bytes){let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+32768)));return btoa(s)}
function unb64(s){const x=atob(s);const b=new Uint8Array(x.length);for(let i=0;i<x.length;i++)b[i]=x.charCodeAt(i);return b}
function uuid(){if(crypto.randomUUID)return crypto.randomUUID().replace(/-/g,'');return [...crypto.getRandomValues(new Uint8Array(16))].map(x=>x.toString(16).padStart(2,'0')).join('')}
function digits(v){return String(v??'').replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/\D/g,'')}
function phoneNorm(v){let s=digits(v);if(s.startsWith('0098')&&s.length===14)s='0'+s.slice(4);if(s.startsWith('98')&&s.length===12)s='0'+s.slice(2);if(s.length===10&&s.startsWith('9'))s='0'+s;return /^09\d{9}$/.test(s)?s:''}
function maskPhoneNumbersInText(value){const toFa=s=>String(s).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);return String(value??'').replace(/(?:(?:\+|00|۰۰)?(?:98|۹۸|٩٨)\s*)?[0۰٠]?[9۹٩](?:[\s().-]*[0-9۰-۹٠-٩]){9}/gu,match=>{let n=digits(match);if(n.startsWith('0098')&&n.length===14)n='0'+n.slice(4);else if(n.startsWith('98')&&n.length===12)n='0'+n.slice(2);else if(n.length===10&&n.startsWith('9'))n='0'+n;if(!/^09\d{9}$/.test(n))return 'شمارهٔ تماس مخفی';return toFa(n.slice(0,4))+'•••••••';});}
function money(v){const s=digits(v).replace(/^0+/,'');return s&&s.length<=15?s:''}
function clean(v,max=900){return String(v??'').replace(/[\x00-\x1f\x7f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max)}
function normalizeText(v){return clean(v,240).toLocaleLowerCase('fa-IR').replace(/[\u064a]/g,'ی').replace(/[\u0643]/g,'ک').replace(/\s+/g,' ')}
function displayCount(n){return Number(n||0).toLocaleString('fa-IR')}
function cleanPublicSourceText(value){const n=window.QoqnusDivarNormalizer;if(n&&typeof n.stripSourceBrandForDisplay==='function')return n.stripSourceBrandForDisplay(value);return String(value??'').replace(/https?:\/\/[^\s]+/giu,' ').replace(/با\s+تشکر\s+از\s*(?:وب\s*سایت|سایت|سامانه)?\s*دیوار/giu,'با تشکر از ققنوس').replace(/(?:وب\s*سایت|سایت|سامانه|پلتفرم)\s+دیوار/giu,' ').replace(/آگهی\s+دیوار/giu,'آگهی').replace(/صفحه\s+دیوار/giu,'صفحه').replace(/\bdivar(?:\.ir)?\b/giu,' ').replace(/[ \t]{2,}/gu,' ').trim();}
function displaySourceLabel(value){const raw=String(value??'').trim();if(/divar|دیوار/i.test(raw))return 'دریافت‌شده با ققنوس';return cleanPublicSourceText(raw)||'ثبت‌شده در ققنوس';}
function openDb(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE)){const s=d.createObjectStore(STORE,{keyPath:'key'});s.createIndex('kind','kind',{unique:false});}if(!d.objectStoreNames.contains(META))d.createObjectStore(META,{keyPath:'key'});if(!d.objectStoreNames.contains(RECOVERY))d.createObjectStore(RECOVERY,{keyPath:'key'});};req.onblocked=()=>{try{const el=$('storageStatus');if(el)el.textContent='پایگاه داده در برگهٔ دیگری باز است؛ برگه‌های قدیمی ققنوس را ببندید تا ارتقای ذخیره‌سازی انجام شود.';}catch{}};req.onsuccess=()=>{const opened=req.result;opened.onversionchange=()=>{try{opened.close();}catch{}if(db===opened)db=null;try{const el=$('storageStatus');if(el)el.textContent='نسخهٔ ذخیره‌سازی تغییر کرده است؛ دفتر را دوباره باز کنید.';}catch{}};opened.onclose=()=>{if(db===opened)db=null;};resolve(opened);};req.onerror=()=>reject(req.error||new Error('بازکردن پایگاه دادهٔ محلی ناموفق بود.'));});}
function txStore(name,mode='readonly'){return db.transaction(name,mode).objectStore(name)}
function dbGet(store,key){return new Promise((resolve,reject)=>{let result=null,settled=false;const tx=db.transaction(store,'readonly'),r=tx.objectStore(store).get(key);const fail=e=>{if(settled)return;settled=true;reject(e||new Error('خواندن پایگاه دادهٔ محلی ناموفق بود.'));};r.onsuccess=()=>{result=r.result?.value??r.result??null;};r.onerror=()=>fail(r.error);tx.oncomplete=()=>{if(!settled){settled=true;resolve(result);}};tx.onerror=()=>fail(tx.error);tx.onabort=()=>fail(tx.error||new Error('تراکنش خواندن لغو شد.'));})}
function dbSet(store,key,value){return new Promise((resolve,reject)=>{let settled=false;const tx=db.transaction(store,'readwrite'),r=tx.objectStore(store).put(store===STORE?value:{key,value});const fail=e=>{if(settled)return;settled=true;reject(e||new Error('ذخیرهٔ محلی ناموفق بود.'));};r.onerror=()=>fail(r.error);tx.oncomplete=()=>{if(!settled){settled=true;resolve(true);}};tx.onerror=()=>fail(tx.error);tx.onabort=()=>fail(tx.error||new Error('تراکنش ذخیرهٔ محلی لغو شد.'));})}
function dbSetMany(store,entries){return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite'),os=tx.objectStore(store);for(const item of entries)os.put(store===STORE?item.value:{key:item.key,value:item.value});tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('ذخیرهٔ گروهی ناموفق بود.'));tx.onabort=()=>reject(tx.error||new Error('ذخیرهٔ گروهی لغو شد.'));})}
function dbAll(store){return new Promise((resolve,reject)=>{let result=[] ,settled=false;const tx=db.transaction(store,'readonly'),r=tx.objectStore(store).getAll();const fail=e=>{if(settled)return;settled=true;reject(e||new Error('خواندن فهرست محلی ناموفق بود.'));};r.onsuccess=()=>{result=r.result||[];};r.onerror=()=>fail(r.error);tx.oncomplete=()=>{if(!settled){settled=true;resolve(result);}};tx.onerror=()=>fail(tx.error);tx.onabort=()=>fail(tx.error||new Error('تراکنش خواندن فهرست لغو شد.'));})}
function dbDelete(store,key){return new Promise((resolve,reject)=>{let settled=false;const tx=db.transaction(store,'readwrite'),r=tx.objectStore(store).delete(key);const fail=e=>{if(settled)return;settled=true;reject(e||new Error('حذف محلی ناموفق بود.'));};r.onerror=()=>fail(r.error);tx.oncomplete=()=>{if(!settled){settled=true;resolve(true);}};tx.onerror=()=>fail(tx.error);tx.onabort=()=>fail(tx.error||new Error('تراکنش حذف محلی لغو شد.'));})}
async function deriveKey(password,salt){const material=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:310000,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
async function encryptWithKey(key,value){const iv=crypto.getRandomValues(new Uint8Array(12));const plain=encoder.encode(JSON.stringify(value));const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,plain);return {iv:b64(iv),cipher:b64(new Uint8Array(cipher))}}
async function decryptWithKey(key,envelope){const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(envelope.iv)},key,unb64(envelope.cipher));return JSON.parse(decoder.decode(plain))}
async function encryptValue(value){if(!cryptoKey)throw new Error('ابتدا برنامک را باز کنید.');const iv=crypto.getRandomValues(new Uint8Array(12));const plain=encoder.encode(JSON.stringify(value));const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},cryptoKey,plain);return {iv:b64(iv),cipher:b64(new Uint8Array(cipher))}}
async function decryptValue(envelope){if(!cryptoKey)throw new Error('برنامک قفل است.');const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(envelope.iv)},cryptoKey,unb64(envelope.cipher));return JSON.parse(decoder.decode(plain))}
async function getMetaObj(key,fallback={}){const v=await dbGet(META,key);return v==null?fallback:v}
async function setMetaObj(key,value){return dbSet(META,key,value)}
const SYNCABLE_RECORD_KINDS=new Set(['customer','file','listing']);
let localRecordMutationChain=Promise.resolve();
function serializeLocalRecordMutation(work){const task=localRecordMutationChain.then(work,work);localRecordMutationChain=task.then(()=>undefined,()=>undefined);return task;}
function commitLocalRecordMutation({putRows=[],deleteKeys=[]}){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite'),os=tx.objectStore(STORE);for(const row of putRows)os.put(row);for(const key of deleteKeys)os.delete(key);tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('ذخیره محلی ناموفق بود.'));tx.onabort=()=>reject(tx.error||new Error('تراکنش ذخیره محلی لغو شد.'));});}
function storeRecord(kind,record){return serializeLocalRecordMutation(async()=>{
 if(kind==='listing'&&window.QoqnusListingPresentation)record=window.QoqnusListingPresentation.normalizeRecord(record,{transaction:listingTransaction(record),topic:listingTopic(record),probe:listingPriceProbe(record)});
 if(!record||record.id==null||String(record.id)==='')throw new Error('شناسهٔ رکورد برای ذخیره معتبر نیست.');
 if(SYNCABLE_RECORD_KINDS.has(String(kind))&&!record.centralId)record={...record,centralStatus:'draft',syncStatus:'draft'};
 const id=String(record.id),key=kind+':'+id,envelope=await encryptValue(record),putRows=[{key,kind,id,updatedAt:centralStamp(record.updatedAt)||Date.now(),iv:envelope.iv,cipher:envelope.cipher}],deleteKeys=[];
 if(SYNCABLE_RECORD_KINDS.has(String(kind)))deleteKeys.push('tombstone:'+String(kind)+':'+id);
 await commitLocalRecordMutation({putRows,deleteKeys});return record;
});}
async function readRow(row){return decryptValue({iv:row.iv,cipher:row.cipher})}
async function recordsOf(kind){const rows=await dbAll(STORE),wanted=kind?rows.filter(x=>x.kind===kind):rows.filter(x=>x.kind!=='meta');const out=[];for(const row of wanted){try{out.push({kind:row.kind,key:row.key,record:await readRow(row)});}catch(e){console.error('qoqnus decrypt row failed',row.key,e);}}return out}
// ===== Qoqnus Central Office V1.6 direct Android transport (manual only) =====
const CENTRAL_KINDS=new Set(['customer','file','listing']);
const CENTRAL_BATCH=20;
const centralNow=()=>Date.now();
const centralStamp=value=>{const n=Number(value);if(Number.isFinite(n)&&n>0)return n;const t=Date.parse(String(value||''));return Number.isFinite(t)?t:0;};
const centralLocalKey=(kind,id)=>String(kind)+':'+String(id);
async function centralConfig(){
 const saved=await getMetaObj('qoqnusCentralOfficeV1',null);
 if(!saved||!saved.apiUrl||!saved.tokenEnvelope||!saved.deviceId) return null;
 const token=await decryptValue(saved.tokenEnvelope);
 return {apiUrl:String(saved.apiUrl),deviceId:String(saved.deviceId),token:String(token),deviceName:String(saved.deviceName||'گوشی ققنوس')};
}
async function centralApi(action,payload={},cfg=null){
 const c=cfg||await centralConfig();
 if(action!=='pair'&&!c)throw new Error('ابتدا نشانی شیتاچی و کد جفت‌سازی را ثبت کنید.');
 const body={action,...(c?{deviceId:c.deviceId,deviceToken:c.token,token:c.token}:{}),...payload};
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),90000);
 try{
  const response=await fetch(action==='pair'?String(payload.apiUrl||''):c.apiUrl,{method:'POST',redirect:'follow',cache:'no-store',credentials:'omit',signal:controller.signal,headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(body)});
  const raw=await response.text();let data;try{data=JSON.parse(raw.replace(/^\uFEFF/,'').trim());}catch{throw new Error('پاسخ شیتاچی قابل‌خواندن نیست: '+raw.slice(0,160));}
  if(!response.ok||data?.ok===false||data?.success===false)throw new Error(String(data?.error||data?.message||('HTTP '+response.status)));
  return data;
 }finally{clearTimeout(timer);}
}
async function centralPair(){
 const apiUrl=String($('centralApiUrl')?.value||'').trim(),pairingCode=String($('pairCode')?.value||'').trim(),deviceName=clean($('mobileDeviceName')?.value||'گوشی ققنوس',50)||'گوشی ققنوس';
 let u;try{u=new URL(apiUrl);}catch{throw new Error('نشانی Web App شیتاچی معتبر نیست.');}if(u.protocol!=='https:'||!/^https:\/\/script\.google\.com\/macros\/s\//i.test(apiUrl)||!apiUrl.endsWith('/exec'))throw new Error('نشانی کامل Web App شیتاچی که به /exec ختم می‌شود وارد کنید.');if(!pairingCode)throw new Error('کد جفت‌سازی را وارد کنید.');
 let installId=await getMetaObj('qoqnusCentralInstallIdV1','');if(!/^[A-Za-z0-9_-]{12,100}$/.test(String(installId)))installId=uuid();await setMetaObj('qoqnusCentralInstallIdV1',installId);
 // First recover an already persisted local pairing instead of registering the same
 // installation again. This avoids device_already_paired when the token is still valid.
 try{
  const existing=await centralConfig();
  if(existing&&existing.apiUrl.replace(/\/+$/,'')===apiUrl.replace(/\/+$/,'')){
   await centralApi('check_ids',{knownRecords:[],clientVersion:'android-v241-pairing-recovery'},existing);
   await refreshPairingUi();
   setSyncFeedback('اتصال قبلی این گوشی به شیتاچی معتبر است؛ جفت‌سازی تکراری انجام نشد.','success');
   return;
  }
 }catch(error){console.warn('Saved Sheetachi pairing could not be resumed; trying validated pairing:',error);}
 let data;
 try{data=await centralApi('pair',{apiUrl,pairingCode,clientInstallId:installId,deviceName,deviceType:'android'},null);}
 catch(error){
  const message=String(error?.message||error);
  if(/device_already_paired/i.test(message)){
   throw new Error('شیتاچی این شناسه نصب را قبلاً ثبت کرده، اما توکن معتبر آن روی این گوشی قابل بازیابی نیست. برای رفع قطعی، تابع pairDevice_ در کد مرکزی شیتاچی باید پس از اعتبارسنجی کد، همان دستگاه و همان deviceId را بازیابی و توکن معتبر صادر کند؛ ردیف دستگاه را حذف نکنید و کد جفت‌سازی را بی‌دلیل نچرخانید.');
  }
  throw error;
 }
 const token=String(data.deviceToken||data.token||data.accessToken||data.device?.token||''),deviceIdValue=String(data.deviceId||data.id||data.device?.id||'');
 if(!token||!deviceIdValue)throw new Error('شیتاچی جفت‌سازی را پذیرفت اما شناسه یا توکن دستگاه را برنگرداند.');
 const tokenEnvelope=await encryptValue(token);await setMetaObj('qoqnusCentralOfficeV1',{apiUrl,deviceId:deviceIdValue,tokenEnvelope,deviceName,pairedAt:centralNow(),active:true});
 await setMetaObj('qoqnusCentralLastIncomingV1',null);await centralWriteList('qoqnusCentralPendingIncomingV1',[]);await centralWriteList('qoqnusCentralStagingV1',[]);await centralWriteList('qoqnusCentralImageDownloadPendingV1',[]);
 await refreshPairingUi();setSyncFeedback('اتصال مستقیم این گوشی به شیتاچی برقرار شد. از این پس ارسال و دریافت فقط با دکمه‌های همین صفحه انجام می‌شود.','success');
}
async function centralWriteLocalRecord(kind,record){
 const id=String(record.id||'');if(!id)throw new Error('شناسه محلی رکورد خالی است.');
 const envelope=await encryptValue(record);const row={key:centralLocalKey(kind,id),kind,id,updatedAt:Number(record.updatedAt)||centralNow(),iv:envelope.iv,cipher:envelope.cipher};await dbSet(STORE,row.key,row);
}
function centralImageSources(record){
 const found=[];const add=x=>{if(typeof x==='string'&&/^data:image\/(?:jpeg|jpg|png|webp);base64,/i.test(x)&&!found.includes(x))found.push(x);else if(x&&typeof x==='object'){add(x.dataUrl||x.dataURL||x.base64||'');}};
 for(const k of ['imageDataUrls','images','photoDataUrls','localImageDataUrls','localPhotos','photos']){const a=record?.[k];if(Array.isArray(a))a.forEach(add);else add(a);}
 for(const k of ['imageDataUrl','photoDataUrl','profilePhotoWebp'])add(record?.[k]);return found.slice(0,20);
}
function centralRemoteImageUrls(record){
 const found=[];const add=x=>{const raw=typeof x==='string'?x:(x&&typeof x==='object'?(x.url||x.src||x.imageUrl||''):'');const value=String(raw||'').trim();if(/^https?:\/\//i.test(value)&&!found.includes(value))found.push(value);};
 for(const k of ['imageUrls','photoUrls','photos','images']){const value=record?.[k];if(Array.isArray(value))value.forEach(add);else add(value);}
 for(const k of ['imageUrl','photoUrl','thumbnailUrl','coverImageUrl'])add(record?.[k]);return found.slice(0,20);
}
function centralValidateTransferPayload(record,imageSizes=[]){
 const jsonLength=JSON.stringify(record).length;
 if(jsonLength>43000)throw new Error('اطلاعات این رکورد برای انتقال به شیتاچی بیش از حد بزرگ است؛ توضیحات یا فیلدهای اضافی را کوتاه کنید. (حد امن: ۴۳٬۰۰۰ نویسه)');
 if(imageSizes.length>20)throw new Error('برای هر رکورد حداکثر ۲۰ تصویر قابل ارسال است.');
 if(imageSizes.some(size=>Number(size)>409600))throw new Error('حجم یکی از تصاویر WebP پس از بهینه‌سازی بیش از ۴۰۰ کیلوبایت است؛ تصویر ارسال نشد.');
 return {jsonLength,imageCount:imageSizes.length};
}
async function centralNormalizeImageSource(source){
 if(/^data:image\//i.test(String(source||'')))return QoqnusImageNormalizer.normalizeDataUrl(source);
 const response=await fetch(String(source),{method:'GET',mode:'cors',credentials:'omit',cache:'force-cache',referrerPolicy:'no-referrer'});
 if(!response.ok)throw new Error('دریافت تصویر منبع ناموفق بود (HTTP '+response.status+').');
 const blob=await response.blob();if(!String(blob.type||'').toLowerCase().startsWith('image/'))throw new Error('نشانی تصویر، فایل تصویری برنگرداند.');
 if(blob.size>15*1024*1024)throw new Error('حجم تصویر منبع بیش از ۱۵ مگابایت است.');
 return QoqnusImageNormalizer.normalizeFile(blob);
}
async function centralPrepareRecord(kind,record){
 const images=[],imageHashes=[],imageSizes=[],imageWarnings=[];const sources=[...centralImageSources(record)];
 for(const url of centralRemoteImageUrls(record)){if(sources.length>=20)break;try{const normalized=await centralNormalizeImageSource(url);if(!/^data:image\/webp;base64,/i.test(normalized.dataUrl))throw new Error('مبدل WebP در این دستگاه در دسترس نیست.');sources.push(normalized.dataUrl);}catch(error){imageWarnings.push(String(error?.message||error).slice(0,100));}}
 for(const source of sources.slice(0,20)){const normalized=await centralNormalizeImageSource(source);if(!/^data:image\/webp;base64,/i.test(normalized.dataUrl))throw new Error('تصویر به WebP تبدیل نشد؛ ارسال تصویر این رکورد متوقف شد.');const bytes=Uint8Array.from(atob(normalized.dataUrl.split(',')[1]),c=>c.charCodeAt(0));const digest=await crypto.subtle.digest('SHA-256',bytes);imageHashes.push([...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join(''));imageSizes.push(bytes.length);images.push(normalized.dataUrl);}
 const cleanRecord={...record};for(const k of ['images','imageDataUrls','imageDataUrl','image_data_url','photoDataUrls','photoDataUrl','localImageDataUrls','localPhotos','photos','profilePhotoWebp','centralStatus','centralServerStatus','centralStatus','syncStatus','centralSyncedAt','centralSyncedLocalUpdatedAt','centralSyncedFingerprint','centralError','centralQueuedAt','centralReceivedAt','centralReceiveDecision','centralId','centralRecordId','ownerDeviceId','version'])delete cleanRecord[k];
 cleanRecord.imageUrls=centralRemoteImageUrls(record);cleanRecord.imagesProvided=images.length;cleanRecord.recordKind=kind;cleanRecord.sourceType=kind==='customer'?'manual_customer':kind==='file'?'office_file':'manual_divar_capture';cleanRecord.bookKey=kind==='customer'?'customers':kind==='file'?'office-files':'qoqnus-files';cleanRecord.localId=String(record.id);cleanRecord.id=String(record.id);
 if(imageWarnings.length)cleanRecord.centralImageWarnings=imageWarnings.slice(0,5);
 centralValidateTransferPayload(cleanRecord,imageSizes);
 // Exclude server-managed version/status fields from the fingerprint. Otherwise each successful
 // round-trip increments version and makes an unchanged record look modified forever.
 const recordFingerprint=await fingerprint({record:cleanRecord,imageHashes});
 const operationDigest=await sha256Hex(kind+':'+String(record.id)+':'+recordFingerprint);
 return {kind,localId:String(record.id),record:cleanRecord,images,imageHashes,fingerprint:recordFingerprint,operationId:'android:'+operationDigest,imageWarnings};
}

async function centralQueueOutgoingImages(task,recordId){
 const sources=Array.isArray(task.images)?task.images:[];
 if(!sources.length)return 0;
 const queue=await centralReadList('qoqnusCentralImageOutboxV1',[]);
 const known=new Set(queue.map(x=>String(x.uploadKey||'')));
 const additions=[];
 for(let i=0;i<sources.length;i++){
  const uploadKey=String(task.operationId)+':image:'+String(i+1);
  if(known.has(uploadKey))continue;
  const dataUrl=String(sources[i]||'');
  if(!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/i.test(dataUrl))throw new Error('تصویر صف ارسال، WebP معتبر نیست.');
  const bytes=Uint8Array.from(atob(dataUrl.split(',')[1]),c=>c.charCodeAt(0));
  if(!bytes.length||bytes.length>409600)throw new Error('حجم تصویر صف ارسال از ۴۰۰ کیلوبایت بیشتر است.');
  additions.push({uploadKey,operationId:String(task.operationId),kind:String(task.kind),localId:String(task.localId),recordId:String(recordId),imageIndex:i+1,dataUrl,sha256:String(task.imageHashes?.[i]||''),fileName:'qoqnus-'+String(recordId).slice(0,16)+'-'+(i+1)+'.webp',fingerprint:String(task.fingerprint||''),attempts:0,nextAttemptAt:0,status:'pending',createdAt:centralNow()});
 }
 if(additions.length)await centralWriteList('qoqnusCentralImageOutboxV1',[...queue,...additions]);
 return additions.length;
}
async function centralDrainOutgoingImages(cfg,limit=2){
 let queue=await centralReadList('qoqnusCentralImageOutboxV1',[]);
 let uploaded=0;
 const due=queue.filter(x=>Number(x.nextAttemptAt||0)<=centralNow()).slice(0,Math.max(1,Math.min(2,Number(limit)||2)));
 for(const task of due){
  try{
   const dataUrl=String(task.dataUrl||'');
   await QoqnusImageNormalizer.validateWebpDataUrl(dataUrl);
   const bytes=Uint8Array.from(atob(dataUrl.split(',')[1]),c=>c.charCodeAt(0));
   if(bytes.length>409600)throw new Error('حجم تصویر از ۴۰۰ کیلوبایت بیشتر است.');
   const digest=await sha256Hex(bytes);
   if(task.sha256&&digest!==task.sha256)throw new Error('هش تصویر صف با محتوای تصویر مطابقت ندارد.');
   const response=await centralApi('upload_record_image',{recordId:String(task.recordId),imageIndex:Number(task.imageIndex),fileName:String(task.fileName||'qoqnus-image.webp'),uploadKey:String(task.uploadKey),sha256:digest,dataUrl},cfg);
   const metadata={uploadKey:String(task.uploadKey),imageId:String(response.imageId||response.id||''),fileId:String(response.fileId||''),imageIndex:Number(task.imageIndex),fileName:String(response.fileName||task.fileName),mimeType:'image/webp',sizeBytes:Number(response.sizeBytes||bytes.length),sha256:digest,uploadedAt:centralNow()};
   const local=await recordById(String(task.kind),String(task.localId));
   if(local){
    const images=Array.isArray(local.centralImages)?local.centralImages:[];
    local.centralImages=[...images.filter(x=>String(x.uploadKey||'')!==String(task.uploadKey)),metadata].sort((a,b)=>Number(a.imageIndex||0)-Number(b.imageIndex||0));
    local.centralImageStatus='uploaded';local.centralImageCount=local.centralImages.length;
    await centralWriteLocalRecord(String(task.kind),local);
   }
   queue=queue.filter(x=>String(x.uploadKey)!==String(task.uploadKey));
   await centralWriteList('qoqnusCentralImageOutboxV1',queue);
   uploaded++;
   const remaining=queue.filter(x=>String(x.recordId)===String(task.recordId));
   if(!remaining.length){
    const latest=await recordById(String(task.kind),String(task.localId));
    if(latest&&task.fingerprint){
     latest.centralStatus='synced';latest.centralServerStatus='active';latest.syncStatus='synced';
     latest.centralSyncedLocalUpdatedAt=centralStamp(latest.updatedAt);latest.centralSyncedFingerprint=String(task.fingerprint);
     latest.centralSyncedAt=centralNow();await centralWriteLocalRecord(String(task.kind),latest);
    }
   }
  }catch(error){
   const message=String(error?.message||error||'بارگذاری تصویر ناموفق بود.');
   const attempts=Number(task.attempts||0)+1;
   queue=queue.map(x=>String(x.uploadKey)===String(task.uploadKey)?{...x,attempts,lastError:message,status:'pending',nextAttemptAt:centralNow()+Math.min(6*60*60*1000,30000*Math.pow(2,Math.min(attempts,7)))}:x);
   await centralWriteList('qoqnusCentralImageOutboxV1',queue);
  }
 }
 return {uploaded,pending:queue.length};
}
async function centralDeleteOperationId(tomb){
 // A delete can succeed on the server while its HTTP response is lost. A stable
 // operation ID makes the next manual retry replay the same server operation.
 const identity=String(tomb?.id||tomb?.centralId||'')+':'+Math.max(1,Number(tomb?.version||1));
 return 'android-delete:'+await sha256Hex(identity);
}
async function centralSendTombstones(cfg){
 const rows=await dbAll(STORE);let removed=0;
 for(const row of rows.filter(x=>x.kind==='tombstone')){
  let tomb;try{tomb=await readRow(row);}catch{continue;}
  if(!tomb?.centralId||String(tomb.ownerDeviceId||'')!==cfg.deviceId)continue;
  const operationId=await centralDeleteOperationId(tomb);
  await centralApi('delete_record',{operationId,recordId:String(tomb.centralId),expectedVersion:Math.max(1,Number(tomb.version||1)),description:'حذف توسط دستگاه مالک'},cfg);
  await dbDelete(STORE,row.key);removed++;
 }
 return removed;
}
async function centralSendChanges(){
 if(!navigator.onLine)throw new Error('گوشی آفلاین است؛ رکوردها روی همین گوشی به‌صورت پیش‌نویس باقی می‌مانند و هنوز شناسه مرکزی نمی‌گیرند.');
 const cfg=await centralConfig();if(!cfg)throw new Error('ابتدا گوشی را به شیتاچی متصل کنید.');
 const all=await recordsOf(),prepared=[];
 for(const item of all){if(!CENTRAL_KINDS.has(item.kind))continue;const r=item.record;if(r.centralDeleted||r.centralStatus==='deleted')continue;if(r.centralId&&!r.ownerDeviceId)continue;if(r.ownerDeviceId&&String(r.ownerDeviceId)!==cfg.deviceId)continue;const task=await centralPrepareRecord(item.kind,r);if(r.centralId&&r.centralSyncedFingerprint&&r.centralSyncedFingerprint===task.fingerprint)continue;prepared.push(task);
 }
 if(!prepared.length){const imageResult=await centralDrainOutgoingImages(cfg,2);const deleted=await centralSendTombstones(cfg),at=centralNow();await setMetaObj('qoqnusCentralLastOutgoingV1',{at,sent:0,images:imageResult.uploaded,pendingImages:imageResult.pending,deleted,status:imageResult.pending?'pending':'success',noChanges:true});await setMetaObj('lastSuccessfulSyncAt',at);await centralRenderRunSummary();setSyncFeedback(imageResult.pending?displayCount(imageResult.uploaded)+' تصویر ارسال شد؛ '+displayCount(imageResult.pending)+' تصویر در صف باقی ماند.':(deleted?displayCount(deleted)+' حذف مجاز در شیتاچی ثبت شد.':'تغییر جدیدی برای ارسال وجود ندارد.'),'success');return {sent:0,images:imageResult.uploaded,pendingImages:imageResult.pending,deleted};}
 const chunks=[];for(let i=0;i<prepared.length;i+=CENTRAL_BATCH)chunks.push(prepared.slice(i,i+CENTRAL_BATCH));
 const idMap=new Map();
 // Global phase 1: reserve every central ID before any title/data/image request.
 for(const chunk of chunks){const result=await centralApi('reserve_record_ids',{items:chunk.map(x=>({operationId:x.operationId,kind:x.kind,localId:x.localId,expectedImages:x.images.length}))},cfg);const rows=Array.isArray(result.results)?result.results:[];if(rows.length!==chunk.length||rows.some(x=>!x.ok||!(x.recordId||x.centralId)))throw new Error('مرحله تخصیص شناسه مرکزی کامل نشد؛ عنوان، اطلاعات و تصاویر ارسال نشدند.');rows.forEach(x=>idMap.set(centralLocalKey(x.kind,x.localId),String(x.recordId||x.centralId)));}
 // Phase 2: match Chrome extension exactly — publish compact titles/subtitles only after
 // every central ID has been confirmed. Full JSON remains deferred until this phase succeeds.
 for(const chunk of chunks){
  const result=await centralApi('save_record_titles',{items:chunk.map(x=>({operationId:x.operationId+':title',recordId:idMap.get(centralLocalKey(x.kind,x.localId)),title:String(x.record.title||x.record.subject||x.record.name||x.record.address||x.record.fileTitle||x.record.customerName||''),subtitle:String(x.record.city||x.record.neighborhood||x.record.phone||x.record.mobile||x.record.propertyType||'')}))},cfg);
  const rows=Array.isArray(result.results)?result.results:[];
  if(rows.length!==chunk.length||rows.some(x=>!x.ok))throw new Error('مرحله انتقال عنوان‌های خلاصه ناموفق بود؛ اطلاعات کامل و تصاویر متوقف ماندند.');
 }
 // Phase 3: full record JSON is sent only after IDs and compact titles are accepted.
 const completed=[],serverVersions=new Map();
 for(const chunk of chunks){
  const result=await centralApi('save_record_data',{items:chunk.map(x=>({operationId:x.operationId+':data',recordId:idMap.get(centralLocalKey(x.kind,x.localId)),kind:x.kind,localId:x.localId,expectedImages:x.images.length,record:x.record}))},cfg);
  const rows=Array.isArray(result.results)?result.results:[];
  if(rows.length!==chunk.length||rows.some(x=>!x.ok))throw new Error('مرحله ذخیره اطلاعات کامل رکوردها ناموفق بود؛ مرحله تصاویر آغاز نشد.');
  for(const x of rows)serverVersions.set(centralLocalKey(x.kind||chunk.find(y=>y.localId===x.localId)?.kind,x.localId),Math.max(1,Number(x.version||1)));
  completed.push(...chunk);
 }
 // Persist the central identity and enqueue images durably only after all text batches succeed.
 let queuedImages=0;
 for(const task of completed){
  const recordId=idMap.get(centralLocalKey(task.kind,task.localId));
  const local=await recordById(task.kind,task.localId);
  if(local){local.centralId=recordId;local.centralRecordId=recordId;local.ownerDeviceId=cfg.deviceId;local.centralStatus='data_complete';local.centralServerStatus='active';local.syncStatus=task.images.length?'pending_images':'synced';local.version=serverVersions.get(centralLocalKey(task.kind,task.localId))||Math.max(1,Number(local.version||1));await centralWriteLocalRecord(task.kind,local);}
  queuedImages+=await centralQueueOutgoingImages(task,recordId);
  if(!task.images.length&&local){local.centralStatus='synced';local.syncStatus='synced';local.centralSyncedLocalUpdatedAt=centralStamp(local.updatedAt);local.centralSyncedFingerprint=task.fingerprint;local.centralSyncedAt=centralNow();await centralWriteLocalRecord(task.kind,local);}
 }
 // Phase 4: independent durable image outbox. Like Chrome, at most two images per run;
 // failed items stay queued with exponential backoff and stable upload keys.
 const imageResult=await centralDrainOutgoingImages(cfg,2);
 const imageCount=imageResult.uploaded;
 const deleted=await centralSendTombstones(cfg),at=centralNow();await setMetaObj('qoqnusCentralLastOutgoingV1',{at,sent:completed.length,images:imageCount,pendingImages:imageResult.pending,queuedImages,deleted,status:imageResult.pending?'pending':'success'});await setMetaObj('lastSuccessfulSyncAt',at);await centralRenderRunSummary();if(fullOfficeUnlocked)await renderAll();setSyncFeedback(displayCount(completed.length)+' رکورد با شناسه، عنوان و اطلاعات کامل تأیید شد؛ '+displayCount(imageCount)+' تصویر ارسال شد و '+displayCount(imageResult.pending)+' تصویر در صف مستقل باقی ماند. '+displayCount(deleted)+' حذف مجاز ثبت شد.',imageResult.pending?'warn':'success');return {sent:completed.length,images:imageCount,pendingImages:imageResult.pending,deleted};
}
async function centralReadList(key,fallback=[]){
 const raw=await getMetaObj(key,null);if(raw==null)return fallback;if(Array.isArray(raw))return raw;
 if(raw&&typeof raw==='object'&&raw.iv&&raw.cipher){try{const value=await decryptValue(raw);return Array.isArray(value)?value:fallback;}catch(error){console.warn('Central encrypted metadata could not be read:',key,error);return fallback;}}
 return fallback;
}
async function centralWriteList(key,value){return setMetaObj(key,await encryptValue(Array.isArray(value)?value:[]));}
async function centralDownloadPendingImages(cfg){
 let pending=await centralReadList('qoqnusCentralImageDownloadPendingV1',[]),downloaded=0;
 const due=pending.filter(x=>Number(x.nextAttemptAt||0)<=centralNow()).slice(0,2);
 for(const task of due){
  try{
   const remote=await centralApi('get_record_image',{recordId:String(task.recordId),imageIndex:Number(task.imageIndex)},cfg);
   const dataUrl=String(remote.dataUrl||'');
   if(!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/i.test(dataUrl)||Number(remote.imageIndex)!==Number(task.imageIndex)||String(remote.recordId)!==String(task.recordId))throw new Error('تصویر برگشتی از شیتاچی معتبر نیست.');
   await QoqnusImageNormalizer.validateWebpDataUrl(dataUrl);
   const bytes=Uint8Array.from(atob(dataUrl.split(',')[1]),c=>c.charCodeAt(0));
   const actualHash=await sha256Hex(bytes);
   if(task.sha256&&actualHash!==task.sha256)throw new Error('اثر انگشت تصویر با اطلاعات شیتاچی مطابقت ندارد.');
   const latest=await recordById(String(task.kind),String(task.localId));
   if(latest){
    const images=Array.isArray(latest.imageDataUrls)?latest.imageDataUrls.slice():[];
    images[Number(task.imageIndex)-1]=dataUrl;latest.imageDataUrls=images;
    if(task.kind==='customer'&&Number(task.imageIndex)===1)latest.profilePhotoWebp=dataUrl;
    await centralWriteLocalRecord(String(task.kind),latest);
   }
   pending=pending.filter(x=>!(String(x.recordId)===String(task.recordId)&&Number(x.imageIndex)===Number(task.imageIndex)));
   await centralWriteList('qoqnusCentralImageDownloadPendingV1',pending);downloaded++;
  }catch(error){
   const message=String(error?.message||error||'دریافت تصویر مرکزی ناموفق بود.');
   const attempts=Number(task.attempts||0)+1;
   pending=pending.map(x=>String(x.recordId)===String(task.recordId)&&Number(x.imageIndex)===Number(task.imageIndex)?{...x,attempts,lastError:message,nextAttemptAt:centralNow()+Math.min(6*60*60*1000,30000*Math.pow(2,Math.min(attempts,7)))}:x);
   await centralWriteList('qoqnusCentralImageDownloadPendingV1',pending);
  }
 }
 return downloaded;
}
function centralCreateText(tag,text,className=''){const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=String(text);return node;}
async function centralRenderIncomingManifest(){
 const root=$('centralIncomingManifest');if(!root)return;const items=await centralReadList('qoqnusCentralPendingIncomingV1',[]);root.replaceChildren();root.classList.toggle('hidden',!items.length);if(!items.length)return;
 root.append(centralCreateText('h3','موارد شناسایی‌شده در شیتاچی'));
 root.append(centralCreateText('p',displayCount(items.length)+' رکورد جدید یا تغییرکرده پیدا شد. ابتدا عناوین را بررسی کنید؛ اطلاعات کامل فقط برای موارد انتخاب‌شده دریافت می‌شود.','hint'));
 const tools=centralCreateText('div',undefined,'central-review-tools');const allLabel=centralCreateText('label',undefined,'central-select-all');const all=document.createElement('input');all.type='checkbox';all.id='centralSelectAllIncoming';all.checked=true;allLabel.append(all,centralCreateText('span','انتخاب همه'));tools.append(allLabel);
 const fetchBtn=centralCreateText('button','دریافت اطلاعات موارد انتخاب‌شده','primary full');fetchBtn.type='button';fetchBtn.id='centralFetchSelected';tools.append(fetchBtn);root.append(tools);
 const list=centralCreateText('div',undefined,'central-sync-list');list.id='centralIncomingManifestList';
 for(const item of items){const label=centralCreateText('label',undefined,'central-sync-record');const check=document.createElement('input');check.type='checkbox';check.checked=true;check.dataset.centralSelect=String(item.recordId);const info=centralCreateText('span',undefined,'central-sync-record-info');const title=centralCreateText('strong',item.title||'بدون عنوان');const meta=centralCreateText('small',(item.kind==='customer'?'مشتری':item.kind==='file'?'فایل دفتری':'آگهی')+' · '+(item.changeType||'تغییر')+' · نسخه '+String(item.version||1)+(item.subtitle?' · '+item.subtitle:''));info.append(title,meta);label.append(check,info);list.append(label);}
 root.append(list);
 all.addEventListener('change',()=>list.querySelectorAll('input[data-central-select]').forEach(x=>x.checked=all.checked));
 fetchBtn.addEventListener('click',async()=>{const ids=[...list.querySelectorAll('input[data-central-select]:checked')].map(x=>x.dataset.centralSelect);if(!ids.length){setSyncFeedback('حداقل یک رکورد را برای دریافت انتخاب کنید.','warn');return;}fetchBtn.disabled=true;try{await centralFetchSelected(ids);}catch(error){setSyncFeedback(String(error?.message||error),'error');}finally{fetchBtn.disabled=false;}});
}
async function centralRenderStaging(){
 const root=$('centralIncomingStaging');if(!root)return;const staging=await centralReadList('qoqnusCentralStagingV1',[]);root.replaceChildren();root.classList.toggle('hidden',!staging.length);if(!staging.length)return;
 root.append(centralCreateText('h3','صندوق بررسی دریافت‌شده‌ها'));
 root.append(centralCreateText('p','این موارد هنوز وارد دفتر اصلی نشده‌اند. برای هر مورد جداگانه تصمیم بگیرید. تصاویر فقط پس از ثبت یا بایگانی نهایی دریافت می‌شوند.','hint'));
 const list=centralCreateText('div',undefined,'central-sync-list');
 for(const item of staging){const card=centralCreateText('article',undefined,'central-sync-review-card');const heading=centralCreateText('strong',item.record?.title||item.record?.name||item.record?.customerName||'رکورد بدون عنوان');const meta=centralCreateText('p',(item.kind==='customer'?'مشتری':item.kind==='file'?'فایل دفتری':'آگهی')+' · شناسه مرکزی '+String(item.centralId).slice(0,16)+' · نسخه '+String(item.version||1));const actions=centralCreateText('div',undefined,'central-sync-actions');
  for(const [decision,label,klass] of [['save','ثبت در دفتر اصلی','primary'],['finalArchive','بایگانی نهایی','outline'],['discard','نادیده گرفتن','danger']]){const b=centralCreateText('button',label,klass);b.type='button';b.dataset.centralDecision=decision;b.dataset.centralStagingId=String(item.stagingId);b.addEventListener('click',async()=>{b.disabled=true;try{await centralDecideIncoming(item.stagingId,decision);}catch(error){setSyncFeedback(String(error?.message||error),'error');}finally{b.disabled=false;}});actions.append(b);}
  card.append(heading,meta,actions);list.append(card);
 }
 root.append(list);
}
async function centralRenderFinalArchive(){
 const root=$('centralFinalArchive');if(!root)return;root.replaceChildren();const all=await recordsOf();const archived=all.filter(x=>CENTRAL_KINDS.has(x.kind)&&x.record?.finalArchived===true);root.classList.toggle('hidden',!archived.length);if(!archived.length)return;
 root.append(centralCreateText('h3','بایگانی نهایی دریافت‌شده‌ها'));root.append(centralCreateText('p',displayCount(archived.length)+' رکورد بایگانی نهایی شده است. برای بازگرداندن هر مورد به دفتر، دکمه روبه‌رو را بزنید.','hint'));
 for(const item of archived){const row=centralCreateText('div',undefined,'central-sync-archive-row');const name=centralCreateText('strong',item.record.title||item.record.name||item.record.customerName||item.record.id);const b=centralCreateText('button','بازگردانی به دفتر','outline');b.type='button';b.addEventListener('click',async()=>{b.disabled=true;try{item.record.finalArchived=false;item.record.updatedAt=centralNow();await centralWriteLocalRecord(item.kind,item.record);await centralRenderFinalArchive();await renderAll();setSyncFeedback('رکورد از بایگانی نهایی به دفتر بازگردانده شد.','success');}catch(error){setSyncFeedback(String(error?.message||error),'error');}finally{b.disabled=false;}});row.append(name,b);root.append(row);}
}
async function centralRenderReviewWorkspace(){await centralRenderIncomingManifest();await centralRenderStaging();await centralRenderFinalArchive();}
async function centralFetchSelected(recordIds){
 if(!navigator.onLine)throw new Error('برای دریافت اطلاعات کامل اتصال اینترنت لازم است.');const ids=[...new Set((Array.isArray(recordIds)?recordIds:[]).map(x=>String(x||'').trim()).filter(Boolean))];if(!ids.length)return {fetched:0,staged:0};if(ids.length>500)throw new Error('در هر نوبت حداکثر ۵۰۰ رکورد قابل دریافت است.');
 const allowed=await centralReadList('qoqnusCentralPendingIncomingV1',[]),permitted=new Set(allowed.map(x=>String(x.recordId)));const unauthorized=ids.filter(id=>!permitted.has(id));if(unauthorized.length)throw new Error('این شناسه در آخرین بررسی دستی وجود ندارد؛ ابتدا شناسه‌ها را دوباره بررسی کنید.');
 const cfg=await centralConfig();if(!cfg)throw new Error('ابتدا گوشی را به شیتاچی متصل کنید.');let records=[];
 for(let i=0;i<ids.length;i+=CENTRAL_BATCH){const chunk=ids.slice(i,i+CENTRAL_BATCH);const result=await centralApi('fetch_selected_records',{recordIds:chunk,confirmedByManager:true,clientVersion:'android-v241-manager-staging'},cfg);if(!Array.isArray(result.records))throw new Error('پاسخ اطلاعات کامل رکوردها معتبر نیست؛ تصاویر دریافت نشدند.');records.push(...result.records);setSyncFeedback('اطلاعات کامل '+displayCount(records.length)+' از '+displayCount(ids.length)+' رکورد دریافت شد؛ هنوز وارد دفتر اصلی نشده‌اند.');}
 let staging=await centralReadList('qoqnusCentralStagingV1',[]);const map=new Map(staging.map(x=>[String(x.centralId),x]));let staged=0;
 for(const item of records){const centralId=String(item.recordId||item.id||''),kind=String(item.kind||'');if(!centralId||!CENTRAL_KINDS.has(kind))continue;const existing=map.get(centralId);map.set(centralId,{...(existing||{}),stagingId:existing?.stagingId||uuid(),centralId,kind,version:Number(item.version||item.record?.version||1),status:String(item.status||'active'),ownerDeviceId:String(item.ownerDeviceId||item.record?.ownerDeviceId||''),updatedAt:item.updatedAt||centralNow(),record:item.record&&typeof item.record==='object'?item.record:{},stagedAt:existing?.stagedAt||centralNow(),decision:'pending'});staged++;}
 const next=[...map.values()];await centralWriteList('qoqnusCentralStagingV1',next);await centralWriteList('qoqnusCentralPendingIncomingV1',allowed.filter(x=>!ids.includes(String(x.recordId))));
 await centralRenderReviewWorkspace();setSyncFeedback(displayCount(staged)+' رکورد در صندوق بررسی قرار گرفت؛ هیچ‌کدام هنوز به دفتر اصلی اضافه نشده‌اند و تصاویر نیز فعلاً دانلود نشده‌اند.','success');return {fetched:records.length,staged};
}
async function centralDecideIncoming(stagingId,decision){
 if(!['save','discard','finalArchive'].includes(decision))throw new Error('تصمیم مدیر معتبر نیست.');const staging=await centralReadList('qoqnusCentralStagingV1',[]),item=staging.find(x=>String(x.stagingId)===String(stagingId));if(!item)throw new Error('رکورد در صندوق بررسی پیدا نشد.');
 if(decision==='discard'){const ignored=await centralReadList('qoqnusCentralIgnoredIncomingV1',[]);await centralWriteList('qoqnusCentralIgnoredIncomingV1',[...ignored.filter(x=>String(x.centralId)!==String(item.centralId)),{centralId:item.centralId,kind:item.kind,version:item.version,ignoredAt:centralNow()}].slice(-1000));}
 else {
  const localItems=await recordsOf(item.kind),existing=localItems.find(x=>String(x.record?.centralId||x.record?.centralRecordId||'')===String(item.centralId));const old=existing?.record||null;const record={...(old||{}),...(item.record||{})};
  let localId=String(old?.id||record.localId||record.id||record.recordId||'');if(!localId||localItems.some(x=>String(x.record?.id||'')===localId&&!old))localId=uuid();
  record.id=localId;record.centralId=String(item.centralId);record.centralRecordId=String(item.centralId);record.ownerDeviceId=String(item.ownerDeviceId||'');record.version=Math.max(1,Number(item.version||1));record.centralStatus='synced';record.centralServerStatus=String(item.status||'active');record.syncStatus='synced';record.centralReceivedAt=centralNow();record.centralReceiveDecision=decision;record.finalArchived=decision==='finalArchive';record.updatedAt=Number(record.updatedAt||item.updatedAt)||centralNow();
  if(old){if(!Array.isArray(record.imageDataUrls)&&Array.isArray(old.imageDataUrls))record.imageDataUrls=old.imageDataUrls;if(!record.profilePhotoWebp&&old.profilePhotoWebp)record.profilePhotoWebp=old.profilePhotoWebp;}
  await centralWriteLocalRecord(item.kind,record);
  const imageMeta=Array.isArray(item.record?.centralImages)?item.record.centralImages:[];const imageQueue=await centralReadList('qoqnusCentralImageDownloadPendingV1',[]);for(const image of imageMeta){const index=Number(image.imageIndex||0);if(index>0&&!imageQueue.some(x=>String(x.recordId)===String(item.centralId)&&Number(x.imageIndex)===index))imageQueue.push({kind:item.kind,localId,recordId:String(item.centralId),imageIndex:index,sha256:String(image.sha256||'').toLowerCase()});}await centralWriteList('qoqnusCentralImageDownloadPendingV1',imageQueue);
 }
 await centralWriteList('qoqnusCentralStagingV1',staging.filter(x=>String(x.stagingId)!==String(stagingId)));
 let imageCount=0;if(decision!=='discard'){const cfg=await centralConfig();if(cfg)imageCount=await centralDownloadPendingImages(cfg);if(fullOfficeUnlocked)await renderAll();}
 await centralRenderReviewWorkspace();const label=decision==='save'?'در دفتر اصلی ثبت شد':decision==='finalArchive'?'در بایگانی نهایی ذخیره شد':'نادیده گرفته شد';setSyncFeedback('تصمیم مدیر اعمال شد: '+label+(imageCount?'؛ '+displayCount(imageCount)+' تصویر دریافت شد.':'.'),'success');return {decision,images:imageCount};
}
function centralBuildKnownRecords(localEntries,deletedAcknowledgements){
 const known=new Map();
 for(const entry of (Array.isArray(localEntries)?localEntries:[])){
  if(!CENTRAL_KINDS.has(entry?.kind))continue;
  const record=entry.record||{};if(!record.centralId)continue;
  known.set(String(record.centralId),{recordId:String(record.centralId),version:Math.max(1,Number(record.version||1)),status:String(record.centralServerStatus||(record.centralDeleted?'deleted':'active'))});
 }
 for(const item of (Array.isArray(deletedAcknowledgements)?deletedAcknowledgements:[])){
  const id=String(item?.recordId||'');if(!id||known.has(id))continue;
  known.set(id,{recordId:id,version:Math.max(1,Number(item.version)||1),status:'deleted'});
 }
 return [...known.values()];
}
function centralRememberDeletedAcks(previous,changes,stamp=Date.now()){
 const map=new Map((Array.isArray(previous)?previous:[]).filter(x=>x&&x.recordId).map(x=>[String(x.recordId),x]));
 for(const change of (Array.isArray(changes)?changes:[])){
  if(!change?.recordId||change.status!=='deleted')continue;
  map.set(String(change.recordId),{recordId:String(change.recordId),version:Math.max(1,Number(change.version)||1),status:'deleted',acknowledgedAt:Number(stamp)||Date.now()});
 }
 return [...map.values()].slice(-10000);
}
async function centralCheckIncoming(){
 if(!navigator.onLine)throw new Error('برای بررسی تغییرات شیتاچی اتصال اینترنت لازم است.');const cfg=await centralConfig();if(!cfg)throw new Error('ابتدا گوشی را به شیتاچی متصل کنید.');
 const priorImages=await centralDownloadPendingImages(cfg),local=await recordsOf();
 // Remember remote deletions even after the user removes the local row. Without this
 // acknowledgement the next manifest would report the same deleted ID as unknown again.
 const deletedAck=await centralReadList('qoqnusCentralDeletedAckV1',[]),knownRecords=centralBuildKnownRecords(local,deletedAck);
 const manifest=await centralApi('check_ids',{knownRecords,clientVersion:'android-v241-extension-parity-manifest'},cfg);if(!Array.isArray(manifest.changes))throw new Error('فهرست شناسه‌های برگشتی از شیتاچی معتبر نیست.');
 const deleted=manifest.changes.filter(x=>x.recordId&&x.status==='deleted');let localDeleted=0;
 for(const change of deleted){const match=local.find(x=>CENTRAL_KINDS.has(x.kind)&&String(x.record?.centralId||'')===String(change.recordId));if(match){const title=String(match.record?.title||match.record?.name||match.record?.customerName||'رکورد بدون عنوان');if(confirm('رکورد زیر توسط دستگاه مالک در شیتاچی حذف شده است. نسخه محلی نیز حذف شود؟\n\n'+title)){await dbDelete(STORE,match.key);localDeleted++;}else{match.record.centralServerStatus='deleted';await centralWriteLocalRecord(match.kind,match.record);}}}
 if(deleted.length)await centralWriteList('qoqnusCentralDeletedAckV1',centralRememberDeletedAcks(deletedAck,deleted,centralNow()));
 const changes=manifest.changes.filter(x=>x.recordId&&x.status!=='deleted'),titleMap=new Map();for(let i=0;i<changes.length;i+=100){const ids=changes.slice(i,i+100).map(x=>String(x.recordId));const titles=await centralApi('get_record_titles',{recordIds:ids,clientVersion:'android-v241-title-manifest'},cfg);for(const title of (titles.titles||[]))titleMap.set(String(title.recordId),title);}
 const ignored=await centralReadList('qoqnusCentralIgnoredIncomingV1',[]),ignoredMap=new Map(ignored.map(x=>[String(x.centralId),Number(x.version||0)]));const candidates=changes.map(x=>({...x,...(titleMap.get(String(x.recordId))||{}),kind:String(x.kind||''),recordId:String(x.recordId)})).filter(x=>!ignoredMap.has(x.recordId)||Number(x.version||0)>ignoredMap.get(x.recordId));
 const checkedAt=centralNow();await centralWriteList('qoqnusCentralPendingIncomingV1',candidates);await setMetaObj('qoqnusCentralLastIncomingV1',{at:checkedAt,count:candidates.length,serverCount:manifest.serverCount||0,knownCount:knownRecords.length});await setMetaObj('lastSuccessfulSyncAt',checkedAt);await centralRenderRunSummary();if(fullOfficeUnlocked)await centralRenderReviewWorkspace();
 if(!candidates.length){if(fullOfficeUnlocked)await renderAll();setSyncFeedback('بررسی شیتاچی کامل شد؛ '+displayCount(localDeleted)+' حذف تأییدشده، '+displayCount(priorImages)+' تصویر معوق و هیچ مورد جدیدی برای بررسی وجود نداشت.','success');return {found:0,images:priorImages,deleted:localDeleted};}
 setSyncFeedback(displayCount(candidates.length)+' مورد شناسایی شد؛ فقط عنوان‌ها دریافت شدند. برای دریافت اطلاعات کامل، موارد را انتخاب و تأیید کنید. تصاویر تا تصمیم جداگانه مدیر دریافت نمی‌شوند.','success');return {found:candidates.length,images:priorImages,deleted:localDeleted};
}
async function centralRenderRunSummary(){
 const root=$('syncRunSummary');if(!root)return;root.replaceChildren();const title=centralCreateText('h3','گزارش آخرین ارتباط با شیتاچی');root.append(title);
 const [outgoing,incoming]=await Promise.all([getMetaObj('qoqnusCentralLastOutgoingV1',null),getMetaObj('qoqnusCentralLastIncomingV1',null)]);
 const add=(heading,detail,stamp)=>{const section=centralCreateText('div',undefined,'sync-run-summary-item');section.append(centralCreateText('strong',heading));section.append(centralCreateText('p',detail));if(stamp)section.append(centralCreateText('small',localDateLabel(stamp)));root.append(section);};
 if(outgoing)add('آخرین ارسال',displayCount(outgoing.sent||0)+' رکورد · '+displayCount(outgoing.images||0)+' تصویر ارسال‌شده · '+displayCount(outgoing.pendingImages||0)+' تصویر معوق · '+displayCount(outgoing.deleted||0)+' حذف مجاز'+(outgoing.noChanges?' · بدون تغییر جدید':''),outgoing.at);
 if(incoming)add('آخرین بررسی دریافت',displayCount(incoming.count||0)+' مورد برای بررسی · '+displayCount(incoming.knownCount||0)+' شناسه محلی · '+displayCount(incoming.serverCount||0)+' رکورد در دفتر مرکزی',incoming.at);
 if(!outgoing&&!incoming)root.append(centralCreateText('p','هنوز ارتباطی با شیتاچی ثبت نشده است؛ پس از جفت‌سازی، ارسال یا بررسی شناسه‌ها گزارش اینجا نمایش داده می‌شود.','hint'));
}
async function centralRefreshStatus(){await centralRenderRunSummary();const cfg=await centralConfig();if(!cfg){setSyncFeedback('هنوز این گوشی به شیتاچی جفت نشده است. نشانی Web App و کد جفت‌سازی را وارد کنید.','warn');return;}setSyncFeedback('گوشی به شیتاچی متصل است · شناسه دستگاه: '+cfg.deviceId.slice(0,8)+'…','success');await centralRenderReviewWorkspace();}

// ===== End central transport =====
async function recordById(kind,id){const row=await new Promise((resolve,reject)=>{let result=null,settled=false;const tx=db.transaction(STORE,'readonly'),r=tx.objectStore(STORE).get(kind+':'+id);const fail=e=>{if(settled)return;settled=true;reject(e||new Error('خواندن رکورد محلی ناموفق بود.'));};r.onsuccess=()=>{result=r.result||null;};r.onerror=()=>fail(r.error);tx.oncomplete=()=>{if(!settled){settled=true;resolve(result);}};tx.onerror=()=>fail(tx.error);tx.onabort=()=>fail(tx.error||new Error('تراکنش خواندن رکورد لغو شد.'));});return row?readRow(row):null}
function removeRecord(kind,id){return serializeLocalRecordMutation(async()=>{
 const rid=String(id),key=String(kind)+':'+rid;let prior=null;try{prior=await recordById(String(kind),rid);}catch{}
 const centralId=String(prior?.centralId||prior?.centralRecordId||'');
 if(centralId){const cfg=await centralConfig().catch(()=>null);if(!cfg||String(prior.ownerDeviceId||'')!==cfg.deviceId)throw new Error('این رکورد متعلق به دستگاه دیگری است؛ فقط دستگاه سازنده یا مدیر مجاز به حذف آن است.');}
 const putRows=[],deleteKeys=[key];
 if(SYNCABLE_RECORD_KINDS.has(String(kind))&&prior&&centralId){const tomb={id:String(kind)+':'+rid,kind:String(kind),recordId:rid,centralId,ownerDeviceId:String(prior.ownerDeviceId||''),version:Number(prior.version||1),deletedAt:Date.now()};const envelope=await encryptValue(tomb);putRows.push({key:'tombstone:'+tomb.id,kind:'tombstone',id:tomb.id,updatedAt:tomb.deletedAt,iv:envelope.iv,cipher:envelope.cipher});}
 await commitLocalRecordMutation({putRows,deleteKeys});return true;
});}

async function sha256Hex(bytes){const digest=await crypto.subtle.digest('SHA-256',bytes instanceof Uint8Array?bytes:encoder.encode(String(bytes)));return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function fingerprint(value){const normalized=canonical(value);return sha256Hex(encoder.encode(JSON.stringify(normalized)))}
function safeHttpUrl(v){const s=String(v??'').trim();return /^https?:\/\//i.test(s)?s:''}
// Command 31: keep only location in the location field and remove source-ad age/time from every public template.
function cleanPublicAdLocation(value){let s=String(value??'').replace(/[\u200e\u200f\u202a-\u202e]/g,'').replace(/\s+/g,' ').trim();s=s.replace(/^(?:📍\s*)?(?:موقعیت|محل|Location)\s*[:：]?\s*/iu,'');s=s.replace(/(?:^|[\s،,؛|·•])(?:امروز|دیروز|پریروز)(?:\s+در\s*دیوار)?/giu,' ');s=s.replace(/(?:^|[\s،,؛|·•])(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*(?:پیش|قبل)(?:\s*(?:در\s*)?دیوار)?/giu,' ');s=s.replace(/(?:^|[\s,;|·•])(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?|[smhdwy])\s+ago(?:\s+(?:on|at|in)\s+divar)?/giu,' ');s=s.replace(/\s*(?:[|·•—–،,])\s*(?:(?:زمان|تاریخ|مدت|انتشار|وقت)(?:\s+[\p{L}\p{M}‌]+){0,3}|(?:posted|updated|created)(?:\s+at|\s+on)?|published(?:\s+on\s+divar)?)\s*[:：]?[\s\S]*$/iu,'');return s.replace(/[،,؛|·•\s-]+$/u,'').trim();}
function cleanPublicAdTimeMetadata(value){const out=[];for(let line of String(value??'').replace(/\r\n?/g,'\n').split('\n')){const raw=line.trim();if(!raw){out.push('');continue;}if(/^█\s*ثبت آگهی رایگان\s+░░\s*مشاوره خرید و اجاره$/u.test(raw)){out.push(raw);continue;}if(/^(?:[🕒⏰📅🗓️]\s*)?(?:(?:زمان|تاریخ|مدت|وقت)(?:\s+[\p{L}\p{M}‌]+){0,3}|(?:ad\s*age|listing\s*age|posted(?:\s+at|\s+on)?|published(?:\s+on\s+divar)?|created(?:\s+on\s+divar|\s+at)?|last\s+updated))\s*[:：]/iu.test(raw)||/^(?:امروز|دیروز|پریروز)$/u.test(raw)||/^(?:posted|published|created|last\s+updated)(?:\s+(?:on|at|in)\s+divar)?\s*[:：-]?\s*(?:(?:today|yesterday|just now|a moment ago)|(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?|[smhdwy])\s+ago)$/iu.test(raw)||/^(?:(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|چند|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*(?:پیش|قبل)(?:\s+در\s*دیوار)?)$/u.test(raw)||/^(?:(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?|[smhdwy])\s+ago(?:\s+(?:on|at|in)\s+divar)?)$/iu.test(raw))continue;if(/موقعیت\s*[:：]/iu.test(line))line=line.replace(/^(\s*📍?\s*موقعیت\s*[:：]\s*)(.*)$/iu,(_,prefix,place)=>prefix+cleanPublicAdLocation(place));line=line.replace(/\s*(?:[|·•—–])\s*(?:(?:نیم|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|[۰-۹0-9٠-٩]+)\s*(?:ثانیه|دقیقه|ساعت|روز|هفته|ماه|سال)\s*(?:پیش|قبل)(?:\s*(?:در\s*)?دیوار)?|(?:[0-9]+\s*)?(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?|[smhdwy])\s+ago(?:\s+(?:on|at|in)\s+divar)?)$/iu,'');line=line.replace(/\s*(?:[|·•]|—|–)\s*(?:زمان|تاریخ|مدت|انتشار آگهی|posted at|updated at|created at)\s*[:：].*$/iu,'').replace(/[ \t]{2,}/g,' ').trim();if(line)out.push(line);}return out.join('\n').replace(/\n{3,}/g,'\n\n').trim();}
function mobilePublicationText(record){
 // The extension prepares publicPost once for Rubika; never rebuild public copy from raw source-ad fields on the phone.
 const prepared=String(record?.publicPost||record?.public_post||'').trim();
 return prepared?cleanPublicAdTimeMetadata(prepared):'';
}
function parsePreparedRubikaListing(record){
 const prepared=String(record?.publicPost||record?.public_post||'').trim();if(!prepared)return [];
 const lines=cleanPublicAdTimeMetadata(prepared).replace(/\r\n?/g,'\n').split('\n');const rows=[];let titleSkipped=false,descriptionIndex=-1;
 const cleanPreparedLabel=value=>String(value||'').replace(/^(?:(?:\:[a-z0-9_+-]+\:)\s*)+/ig,'').replace(/^[^\p{L}\p{N}]+/u,'').trim().replace(/\s+/g,' ');
 const cleanPreparedValue=value=>String(value||'').trim().replace(/\:white_check_mark\:/ig,'✅').replace(/\:heavy_check_mark\:/ig,'✅').replace(/\:x\:/ig,'❌').replace(/\:package\:/ig,'📦').replace(/[ \t]{2,}/g,' ').trim();
 const addLine=part=>{let text=String(part||'').trim();if(!text)return;text=text.replace(/^(?:(?:\:[a-z0-9_+-]+\:)\s*)+/ig,'').replace(/^[^\p{L}\p{N}]+/u,'').trim();const colon=text.search(/[:：]/u);if(colon<1)return;const label=cleanPreparedLabel(text.slice(0,colon));const value=cleanPreparedValue(text.slice(colon+1));if(!label||!value)return;if(/^توضیحات(?: بیشتر| آگهی| تکمیلی)?$/u.test(label)){const idx=rows.findIndex(r=>r.label==='توضیحات بیشتر');if(idx>=0){rows[idx].value+=' '+value;descriptionIndex=idx;}else{rows.push({label:'توضیحات بیشتر',value});descriptionIndex=rows.length-1;}return;}if(/^(?:دسته.?بندی|تماس|شماره تماس|ثبت آگهی رایگان|مشاوره خرید و اجاره)$/u.test(label))return;rows.push({label,value});};
 for(const rawLine of lines){const line=rawLine.trim();if(!line||/^━{2,}$/u.test(line)||/^[-—–_]{3,}$/u.test(line))continue;if(!titleSkipped){titleSkipped=true;continue;}if(/^🏷?️?\s*دسته.?بندی\s*[:：]?$/u.test(line)||/^█\s*ثبت آگهی رایگان/u.test(line)||/^☎️?\s*تماس\s*[:：]/u.test(line)||/^مشاوره خرید و اجاره$/u.test(line))break;if(/^#[\p{L}\p{M}0-9_]+(?:\s+#[\p{L}\p{M}0-9_]+)*$/u.test(line))continue;
   // A prepared amenity line may contain several labeled values separated by vertical bars.
   const parts=line.includes('|')?line.split('|').map(x=>x.trim()).filter(Boolean):[line];for(const part of parts)addLine(part);
 }
 return rows;
}
function appendPreparedRubikaDetailsTable(container,r){
 const rows=parsePreparedRubikaListing(r);if(!rows.length){const note=document.createElement('p');note.className='qoqnus-prepared-text-missing';note.textContent='متن آمادهٔ روبیکا برای این آگهی همراه همگام‌سازی دریافت نشده است؛ افزونهٔ Chrome را دوباره همگام‌سازی کنید. متن خام آگهی جایگزین نمی‌شود.';container.append(note);return;}
 const table=document.createElement('table');table.className='listing-details-table qoqnus-prepared-rubika-table';const tbody=document.createElement('tbody');for(const row of rows){const tr=document.createElement('tr'),th=document.createElement('th'),td=document.createElement('td');th.scope='row';th.textContent=row.label;td.textContent=maskPhoneNumbersInText(row.value);if(row.label==='توضیحات بیشتر'){tr.className='qoqnus-prepared-description-row';td.classList.add('qoqnus-prepared-description-cell');}tr.append(th,td);tbody.append(tr);}table.append(tbody);container.append(table);
}
async function mobileBlobToBase64(blob){if(!(blob instanceof Blob)||!blob.size)return null;const imgUrl=URL.createObjectURL(blob);try{const image=new Image();image.src=imgUrl;await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('خواندن تصویر ناموفق بود.'));});let maxSide=1800;for(let round=0;round<5;round++){const scale=Math.min(1,maxSide/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));const ctx=canvas.getContext('2d',{alpha:false});ctx.drawImage(image,0,0,canvas.width,canvas.height);for(const quality of [0.84,0.76,0.68,0.58]){const out=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));if(out&&out.size<=3*1024*1024){return {image_base64:b64(new Uint8Array(await out.arrayBuffer())),image_mime:out.type||'image/webp'};}}maxSide=Math.round(maxSide*0.78);if(maxSide<720)break;}throw new Error('فشرده‌سازی تصویر تا سقف ۳ مگابایت موفق نشد.');}finally{URL.revokeObjectURL(imgUrl);}}
async function mobilePublicationImage(record){const candidates=[...(Array.isArray(record.imageDataUrls)?record.imageDataUrls:[]),...(Array.isArray(record.localImageDataUrls)?record.localImageDataUrls:[]),record.imageDataUrl,record.image_data_url,...(Array.isArray(record.images)?record.images:[])].filter(x=>typeof x==='string'&&x.trim());let blob=null;for(const candidate of candidates){const c=String(candidate).trim();if(/^data:image\/(?:jpeg|jpg|png|webp);base64,/i.test(c)){try{const b=c.slice(c.indexOf(',')+1);const mime=c.slice(5,c.indexOf(';')).toLowerCase().replace('jpg','jpeg');blob=new Blob([unb64(b)],{type:mime});break;}catch{}}}if(!blob){for(const u of collectPhotoLinks([record.imageUrls,record.imageUrl,record.image_url,record.photos,record.images,record.pictures])){try{const res=await fetch(u,{mode:'cors',credentials:'omit',cache:'no-store'});if(res.ok&&/^image\//i.test(res.headers.get('content-type')||'')){blob=await res.blob();break;}}catch{}}}if(!blob)return {image_base64:'',image_mime:'',warning:'تصویر در دادهٔ محلی نبود یا سایت مبدأ اجازهٔ دریافت مستقیم نداد.'};return await mobileBlobToBase64(blob);}
function mobilePublishStateLabel(state){return ({published:'بررسی/ارسال نسخهٔ فعلی','replacement_published':'نسخهٔ جدید منتشر شد','needs_approval':'منتظر تأیید مدیر','unknown':'نتیجه نامشخص؛ بررسی لازم','replacement_unknown':'جایگزینی نامشخص؛ بررسی لازم','publishing':'در حال بررسی انتشار…','replacement_sending':'در حال جایگزینی…','replacement_partial':'جایگزینی ناقص؛ پنل مدیر','cleanup_pending':'پاک‌سازی پیام قبلی مانده','partial':'تکمیل مقصدهای ناموفق'})[String(state||'')]||'انتشار از ربات مرکزی';}
function mobilePublishDiagnostic(data){const base=String(data?.message||'انتشار کامل نشد؛ وضعیت مقصدها را در پنل مدیر بررسی کنید.').trim();const results=data?.results&&typeof data.results==='object'?data.results:{};const labels={rubika:'روبیکا',eitaa:'ایتا'};const failures=[];for(const key of ['rubika','eitaa']){const row=results[key];if(!row||typeof row!=='object')continue;const st=String(row.status||'');if(st==='sent'||st==='published')continue;const reason=String(row.error||({failed:'ارسال توسط سرویس مقصد رد شد.',unknown:'نتیجهٔ ارسال نامشخص است؛ کانال باید بررسی شود.',sending:'ارسال هنوز در حال پردازش است.'}[st]||st||'وضعیت نامشخص'));failures.push((labels[key]||key)+': '+clean(reason,180));}return failures.length?base+'\nجزئیات مقصد: '+failures.join(' | '):base;}
function mobilePublishBlockedMessage(state){return ({unknown:'نتیجهٔ انتشار قبلی نامشخص است. برای جلوگیری از آگهی تکراری، از این گوشی دوباره ارسال نکنید؛ مدیر باید وضعیت هر دو کانال را بررسی کند.','replacement_unknown':'نتیجهٔ جایگزینی نامشخص است؛ مدیر باید ابتدا کانال‌ها را بررسی کند.','publishing':'درخواست انتشار قبلی هنوز تعیین‌تکلیف نشده است؛ از ارسال مجدد خودداری کنید.','replacement_sending':'درخواست جایگزینی هنوز در حال پردازش است؛ دوباره ارسال نکنید.','needs_approval':'این نسخه منتظر تأیید مدیر است؛ درخواست تازه نسازید.','approved':'نسخهٔ جدید تأیید شده و پردازش آن در حال انجام است؛ دوباره ارسال نکنید.','replacement_partial':'جایگزینی ناقص است؛ مدیر باید از پنل انتشار مرکزی مقصد ناموفق را تعیین‌تکلیف کند.','cleanup_pending':'نسخهٔ جدید منتشر شده اما پاک‌سازی پیام قبلی باقی است؛ مدیر باید آن را از پنل مرکزی پیگیری کند.'})[String(state||'')]||'';}
async function publishMobileRecord(kind,id,button){
 if(button?.disabled)return;
 const oldLabel=button?.textContent;
 if(button){button.disabled=true;button.textContent='در حال آماده‌سازی انتشار مرکزی…';}
 let record=null,requestId='',requestStarted=false,responseParsed=false,responseStatus=0;
 const refresh=async()=>{if(kind==='listing')await renderListings();else await renderFiles();};
 const persist=async(state,extra={})=>{if(!record)return;record={...record,centralPublishState:state,centralPublishRequestId:requestId||record.centralPublishRequestId||'',centralPublishUpdatedAt:Date.now(),centralPublishResult:state,...extra};await storeRecord(kind,record);await refresh();};
 try{
  const pairing=await readSavedPairing();
  if(!pairing)throw new Error('برای انتشار از موبایل ابتدا دستگاه را با کد اختصاصی به افزونهٔ دفتر جفت کنید.');
  record=await recordById(kind,id);
  if(!record)throw new Error('رکورد آگهی پیدا نشد.');
  const blocked=mobilePublishBlockedMessage(record.centralPublishState);
  if(blocked){alert(blocked);return {ok:false,blocked:true,state:record.centralPublishState};}
  const phones=listingPhoneItems(record);
  if(!phones.length)throw new Error('این آگهی شمارهٔ تماس معتبر ندارد؛ طبق سیاست ققنوس ارسال مسدود شد. شماره فقط برای کنترل محلی بررسی می‌شود و به کانال فرستاده نمی‌شود.');
  const text=mobilePublicationText(record);
  if(!text)throw new Error('نسخهٔ آمادهٔ روبیکا برای این آگهی موجود نیست؛ افزونهٔ Chrome را دوباره همگام‌سازی کنید. متن خام آگهی بازسازی نمی‌شود.');
  let image={image_base64:'',image_mime:'',warning:''};
  try{image=await mobilePublicationImage(record);}catch(e){image={image_base64:'',image_mime:'',warning:String(e?.message||e)};}
   // Resolve a canonical Divar detail URL from the known source/link fields. A search/category URL must never be mistaken for a listing ID.
   const urlFields=['url','listingUrl','listing_url','detailUrl','detail_url','sourceUrl','source_url','canonicalUrl','canonical_url','permalink','href','originalUrl','original_url'];
   const urlCandidates=[...new Set(urlFields.map(k=>String(record[k]||'').trim()).filter(Boolean))];let url='',sawDivarUrl=false;
   for(const raw of urlCandidates){
    const parsed=normalizeDivarDetailUrl(raw);
    if(parsed){url=parsed.url;sawDivarUrl=true;break;}
    try{const u=new URL(raw);if(['divar.ir','www.divar.ir'].includes(u.hostname.toLowerCase()))sawDivarUrl=true;}catch{}
   }
   let adId=String(record.qoqnusSyncId||record.qoqnus_sync_id||record.divarId||record.divar_id||record.listingId||record.listing_id||record.trackingId||record.tracking_id||record.trackingCode||record.tracking_code||record.code||record.id||'').trim();
   const divarSource=/divar|دیوار/i.test([record.source,record.sourceLabel,record.source_label,record.origin,record.originLabel].map(v=>String(v||'')).join(' '))||/^divar:/i.test(adId)||sawDivarUrl;
   if(url){const parsed=normalizeDivarDetailUrl(url);adId='divar:'+parsed.id;}
   else if(divarSource)throw new Error('پیوند مستقیم جزئیات این آگهی پیدا نشد. نشانی صفحهٔ همان آگهی (/v/شناسه) را در افزونه ذخیره و سپس دفتر موبایل را دوباره همگام کنید؛ پیوند جست‌وجو قابل انتشار نیست.');
   else if(!/^[a-z0-9][a-z0-9:_-]{2,127}$/i.test(adId))throw new Error('شناسهٔ ثابت آگهی معتبر نیست؛ آگهی را از افزونه دوباره همگام کنید.');
  requestId=uuid();
  // Persist the outbound attempt before the request leaves the device. This survives PWA close/restart.
  await persist('publishing',{centralPublishRequestId:requestId,centralPublishResult:'pending',centralPublishError:''});
  const endpoint=new URL('../central-publish.php',location.href);
  requestStarted=true;
  const response=await fetch(endpoint.href,{method:'POST',redirect:'error',cache:'no-store',credentials:'omit',headers:{'Content-Type':'application/json','Accept':'application/json','X-Qoqnus-Pair-ID':pairing.pairId,'X-Qoqnus-Pair-Token':pairing.token},body:JSON.stringify({action:'submit',request_id:requestId,ad_id:adId,url,title:clean(record.title||record.headline||'آگهی ملک',180),rubika_text:text,eitaa_text:text,use_configured_destinations:true,...image})});
  responseStatus=Number(response.status||0);
  let data;try{data=await response.json();responseParsed=true;}catch(e){const badBody='پاسخ ربات مرکزی JSON معتبر نیست (HTTP '+responseStatus+').';if(response.ok||responseStatus>=500)throw Object.assign(new Error(badBody+' نتیجهٔ انتشار قطعی نیست.'),{qoqnusAmbiguous:true});throw Object.assign(new Error(badBody+' درخواست پیش از انتشار رد شد.'),{qoqnusDefinite:true});}
  const state=String(data?.state||'');
  const handledStates=new Set(['published','replacement_published','needs_approval','publishing','replacement_sending','partial','unknown','replacement_partial','replacement_unknown','cleanup_pending']);
  if(!response.ok||(data?.ok!==true&&!handledStates.has(state))){
   const message=data?.message||({unauthorized:'اتصال این گوشی به ربات مرکزی معتبر نیست؛ دستگاه را دوباره با کد اختصاصی جفت کنید.',pairing_not_ready:'جدول جفت‌سازی روی هاست آماده نیست؛ مدیر باید مهاجرت جفت‌سازی موبایل را اجرا کند.',publication_migration_required:'مدیر باید صفحهٔ «انتشار مرکزی آگهی» را در پنل باز کند تا جدول‌های لازم ساخته شوند.',https_required:'نشانی انتشار مرکزی باید با HTTPS باز شود؛ تنظیم SSL و پروکسی هاست بررسی شود.',invalid_json:'سرور درخواست انتشار را JSON معتبر تشخیص نداد؛ نسخهٔ برنامک و endpoint باید همسان باشند.',invalid_request:'اطلاعات درخواست انتشار ناقص یا نامعتبر است؛ شناسه، عنوان و متن آگهی را بررسی کنید.',conflict:'این آگهی درخواست هم‌زمان یا تعیین‌تکلیف‌نشده دارد؛ از پنل مرکزی وضعیت قبلی را بررسی کنید.',rate_limited:'سقف انتشار این دستگاه در یک ساعت تمام شده است.',payload_too_large:'حجم عکس و متن زیاد است؛ عکس باید کمتر از ۳ مگابایت باشد.',internal_error:'خطای داخلی سرور؛ مدیر باید گزارش PHP هاست را با شناسهٔ خطا بررسی کند.',unknown_action:'نسخهٔ endpoint انتشار با برنامک سازگار نیست؛ فایل central-publish.php را همسان کنید.'})[data?.error]||('انتشار ناموفق شد: HTTP '+response.status);
   if(response.status>=500||data?.error==='internal_error')throw Object.assign(new Error(message),{qoqnusAmbiguous:true});
   await persist('failed',{centralPublishError:clean(message,320)});throw Object.assign(new Error(message),{qoqnusDefinite:true});
  }
  await persist(state,{centralPublishRequestId:String(data.request_id||requestId),centralPublishResult:state==='published'||state==='replacement_published'?'success':state,centralPublishError:''});
  const summary=state==='published'||state==='replacement_published'?'✅ انتشار مرکزی کامل شد. شناسهٔ پیام مقصدها در دفتر مرکزی ثبت شد.':state==='needs_approval'?'این آگهی قبلاً با همین شناسه منتشر شده ولی متن/عکس تغییر کرده است؛ درخواست برای تأیید مدیر ثبت شد.':(state==='publishing'||state==='replacement_sending')?'درخواست هم‌زمان دیگری برای این آگهی در حال اجراست؛ از ارسال مجدد خودداری کنید.':state==='unknown'||state==='replacement_unknown'?'نتیجهٔ انتشار نامشخص است. پیش از هر تلاش مجدد، هر دو کانال را بررسی کنید.'+(data?.results?'\n'+mobilePublishDiagnostic(data):''):state==='partial'||state==='replacement_partial'||state==='cleanup_pending'?mobilePublishDiagnostic(data):data.message||'انتشار کامل نشد؛ وضعیت مقصدها را در پنل مدیر بررسی کنید.';
  alert(summary+(image.warning?'\n\nهشدار عکس: '+image.warning:''));return data;
 }catch(e){
  const ambiguous=!!e?.qoqnusAmbiguous||(requestStarted&&(!responseStatus||responseStatus>=500||(!responseParsed&&responseStatus>=200&&responseStatus<300)));
  if(record&&requestId&&requestStarted&&ambiguous){
   try{const diagnostic=clean(e?.message||'پاسخ قطعی از سرور دریافت نشد.',320);await persist('unknown',{centralPublishRequestId:requestId,centralPublishResult:'unknown',centralPublishError:diagnostic});}catch(saveError){console.error('ثبت وضعیت انتشار نامشخص در دفتر محلی ناموفق بود.',saveError);}
   const diagnostic=clean(e?.message||'',240);alert('نتیجهٔ انتشار نامشخص است. برای جلوگیری از آگهی تکراری، از موبایل دوباره ارسال نکنید؛ مدیر باید روبیکا و ایتا را بررسی کند. شناسهٔ درخواست در دفتر این گوشی ذخیره شد.'+(diagnostic?'\nجزئیات: '+diagnostic:''));
   return {ok:false,state:'unknown',request_id:requestId,ambiguous:true};
  }
  if(record&&requestId&&requestStarted&&e?.qoqnusDefinite){try{await persist('failed',{centralPublishRequestId:requestId,centralPublishResult:'failed',centralPublishError:clean(e?.message||'درخواست رد شد.',320)});}catch(saveError){console.error('ثبت خطای قطعی انتشار در دفتر محلی ناموفق بود.',saveError);}}
  alert(String(e?.message||e));return null;
 }finally{if(button){button.disabled=false;button.textContent=oldLabel||'انتشار از ربات مرکزی';}}
}
function collectPhotoLinks(v){const out=[];const add=x=>{if(typeof x==='string'){const u=safeHttpUrl(x);if(u)out.push(u);return}if(Array.isArray(x)){x.forEach(add);return}if(x&&typeof x==='object'){for(const k of ['url','src','href','originalUrl','imageUrl','photoUrl'])if(x[k])add(x[k]);}};add(v);return [...new Set(out)].slice(0,50)}
function mergeLocalOnlyMedia(kind,incoming,prior){if(!['listing','file'].includes(kind)||!prior)return incoming;const merged={...incoming};let expected=Number.isFinite(Number(incoming.imagesProvided))&&incoming.imagesProvided!==''?Math.max(0,Math.floor(Number(incoming.imagesProvided))):null;for(const key of ['imageUrls','image_urls','imageUrl','image_url','photos','pictures','images']){if(!(key in incoming))continue;const v=incoming[key],items=Array.isArray(v)?v:[v],urls=items.filter(x=>typeof x==='string'?/^https?:\/\//i.test(x):x&&typeof x==='object'&&/^https?:\/\//i.test(String(x.url||x.src||x.href||'')));expected=Math.max(expected||0,urls.length);}for(const k of ['imageDataUrls','imageDataUrl','localImageDataUrls','localPhotos','photoDataUrls','photoDataUrl']){const pv=prior[k],mv=merged[k],hasPrior=Array.isArray(pv)?pv.length>0:pv!==undefined&&pv!==null&&pv!==''&&pv!==false,hasIncoming=Array.isArray(mv)?mv.length>0:mv!==undefined&&mv!==null&&mv!==''&&mv!==false;if(hasPrior&&!hasIncoming){if(expected===0)merged[k]=Array.isArray(pv)?[]:'';else if(expected!==null&&Array.isArray(pv))merged[k]=pv.slice(0,expected);else merged[k]=pv;}}return merged;}
function canonical(v){if(Array.isArray(v))return v.map(canonical);if(v&&typeof v==='object'){const o={};for(const k of Object.keys(v).sort())o[k]=canonical(v[k]);return o;}return v}
function fileSignature(r){return [phoneNorm(r.phone||r.customerPhone||''),r.officeTransactionType||r.transactionType||'',r.officePropertyType||r.propertyType||'',normalizeText(r.neighborhood||''),digits(r.area_sqm||r.landArea||''),normalizeText(r.street||''),normalizeText(r.title||'')].join('|')}
function canonicalDivarListingKey(record){if(!record||typeof record!=='object')return '';const fields=['url','detailUrl','detail_url','listingUrl','listing_url','sourceUrl','source_url','divarUrl','divar_url','canonicalUrl','canonical_url'];for(const field of fields){const parsed=normalizeDivarDetailUrl(String(record[field]||''));if(parsed)return 'divar:'+parsed.id;}const source=normalizeText([record.source,record.sourceLabel,record.origin,record.originLabel].join(' '));const rawId=String(record.divarId||record.divar_id||record.qoqnusSyncId||record.qoqnus_sync_id||'').trim();if(/divar|دیوار/.test(source)&&/^[a-z0-9][a-z0-9_-]{2,120}$/i.test(rawId))return 'divar:'+rawId;const id=String(record.id||'').trim();if(/^divar:[a-z0-9][a-z0-9_-]{2,120}$/i.test(id))return id;return '';}
function mergeAliasedDivarListing(prior,incoming,targetId){const next={...(prior||{})},listKeys=new Set(['imageUrls','image_urls','images','imageLinks','image_links','photos','photoUrls','photo_urls','categories','categoryLinks','attributes','phones','tags']);for(const [key,value] of Object.entries(incoming||{})){if(key==='id'||key==='record_uuid'||value===undefined||value===null||value==='')continue;if(Array.isArray(value)){if(!value.length)continue;if(listKeys.has(key)){const old=Array.isArray(next[key])?next[key]:[];const sig=v=>typeof v==='object'&&v!==null?JSON.stringify(v):String(v);next[key]=[...new Map([...old,...value].map(v=>[sig(v),v])).values()].slice(0,key.toLowerCase().includes('image')||key.toLowerCase().includes('photo')?50:100);}else next[key]=value;continue;}next[key]=value;}for(const key of ['text','publicDescription','public_description','description','detailText','detail_text','priceText']){const old=String(prior?.[key]||''),fresh=String(incoming?.[key]||'');if(old.length>fresh.length)next[key]=prior[key];}for(const key of ['code','trackingCode','tracking_code','trackingId','tracking_id','archiveCode','archive_code','createdAt','created_at','collectedAt','manuallySavedAt','notes','userNotes','followUp','purchasePreference','syncViewedAt','syncNew','syncReceivedAt','syncSourceDeviceId'])if(prior&&prior[key]!==undefined&&prior[key]!==null&&prior[key]!==''&&(key!=='syncNew'||!Object.prototype.hasOwnProperty.call(incoming||{},key)))next[key]=prior[key];if(['published','archived','approved'].includes(String(prior?.status||''))&&['pending','saved','not_sent','ready_to_publish'].includes(String(incoming?.status||'')))next.status=prior.status;if(Number(prior?.archiveBucket)>0||Number(prior?.archivedAt)>0){next.status=String(prior.status||'archived');next.archiveBucket=prior.archiveBucket;next.archivedAt=prior.archivedAt;} next.id=String(targetId);next.record_uuid=String(prior?.record_uuid||targetId);return next;}
function sourceListingLines(record){const values=[record?.priceText,record?.price_text,record?.detailText,record?.detail_text,record?.publicDescription,record?.public_description,record?.description,record?.text,record?.content,...(Array.isArray(record?.attributes)?record.attributes:[])];const out=[],seen=new Set();for(const value of values){if(value===undefined||value===null)continue;for(const line of String(value).split(/\r?\n/)){const cleanLine=String(line).replace(/[\u200e\u200f\u202a-\u202e]/g,'').trim();if(cleanLine&&!seen.has(normalizeText(cleanLine))){seen.add(normalizeText(cleanLine));out.push(cleanLine);}}}return out;}
function sourceListingValue(record,labels){const lines=sourceListingLines(record),pattern=new RegExp('^(?:'+labels.join('|')+')\\s*(?:[:：]\\s*)?(.*)$','iu');for(let i=0;i<lines.length;i++){const m=lines[i].match(pattern);if(!m)continue;const inline=String(m[1]||'').trim().replace(/^[—–-]\s*/,'');if(inline&&inline.length<180)return inline;const next=String(lines[i+1]||'').trim();if(next&&next.length<100&&!/^(?:توضیحات|مشخصات|جزئیات|موقعیت|آدرس|ویژگی)/u.test(next))return next;}return '';}

async function setLocalPassword(password){const salt=crypto.getRandomValues(new Uint8Array(16));cryptoKey=await deriveKey(password,salt);const check=await encryptValue({magic:'qoqnus-mobile-lock-v1',createdAt:Date.now()});await setMetaObj('localSalt',b64(salt));await setMetaObj('lockCheck',check);let did=await getMetaObj('deviceId','');if(!did){did=uuid();await setMetaObj('deviceId',did)}deviceId=did;}
async function unlockPassword(password){const saltText=await getMetaObj('localSalt','');if(!saltText)return false;const candidate=await deriveKey(password,unb64(saltText));const check=await getMetaObj('lockCheck',null);try{const val=await decryptWithKey(candidate,check);if(val.magic!=='qoqnus-mobile-lock-v1')return false;cryptoKey=candidate;deviceId=await getMetaObj('deviceId','');if(!deviceId){deviceId=uuid();await setMetaObj('deviceId',deviceId)}return true;}catch{return false}}
async function setQuickPin(pin){const p=digits(pin);if(!/^\d{4}$/.test(p))throw new Error('کد ورود باید دقیقاً ۴ رقم باشد.');if(!cryptoKey)throw new Error('ابتدا با رمز اصلی وارد شوید.');const previous={quickPinSalt:await getMetaObj('quickPinSalt',null),quickPinCheck:await getMetaObj('quickPinCheck',null),deviceCryptoKey:await getMetaObj('deviceCryptoKey',null),pinAttemptState:await getMetaObj('pinAttemptState',null)};const salt=crypto.getRandomValues(new Uint8Array(16));const saltText=b64(salt);const pinKey=await deriveKey('qoqnus-app-pin-v1:'+p,salt);const check=await encryptWithKey(pinKey,{magic:'qoqnus-app-pin-v1',createdAt:Date.now()});const selfTest=await decryptWithKey(pinKey,check);if(selfTest.magic!=='qoqnus-app-pin-v1')throw new Error('اعتبارسنجی داخلی کد جدید ناموفق بود. کد قبلی حفظ شد.');try{await dbSetMany(META,[{key:'quickPinSalt',value:saltText},{key:'quickPinCheck',value:check},{key:'deviceCryptoKey',value:cryptoKey},{key:'pinAttemptState',value:{failures:0,blockedUntil:0}}]);const savedSalt=await getMetaObj('quickPinSalt',''),savedCheck=await getMetaObj('quickPinCheck',null);if(savedSalt!==saltText||!savedCheck)throw new Error('کد جدید به‌طور پایدار ذخیره نشد؛ دوباره تلاش کنید.');const savedKey=await deriveKey('qoqnus-app-pin-v1:'+p,unb64(savedSalt));const savedVerifier=await decryptWithKey(savedKey,savedCheck);if(savedVerifier.magic!=='qoqnus-app-pin-v1')throw new Error('بررسی کد ذخیره‌شده ناموفق بود.');window.qoqnusQuickPinExists=true;}catch(err){for(const [key,value] of Object.entries(previous)){if(value===null||value===undefined)await dbDelete(META,key).catch(()=>{});else await setMetaObj(key,value).catch(()=>{});}throw new Error((err.message||'تغییر کد ورود ناموفق بود.')+' کد قبلی حفظ شد.');}}
async function unlockQuickPin(pin){const p=digits(pin);if(!/^\d{4}$/.test(p))return false;const attempt=await getMetaObj('pinAttemptState',{failures:0,blockedUntil:0});if(Number(attempt.blockedUntil||0)>Date.now())throw new Error('برای امنیت، ورود موقتاً متوقف شده است. چند لحظه دیگر دوباره تلاش کنید.');const saltText=await getMetaObj('quickPinSalt',''),check=await getMetaObj('quickPinCheck',null);if(!saltText||!check)return false;let valid=false;try{const pinKey=await deriveKey('qoqnus-app-pin-v1:'+p,unb64(saltText));const val=await decryptWithKey(pinKey,check);valid=val.magic==='qoqnus-app-pin-v1';}catch{valid=false}if(!valid){const failures=Number(attempt.failures||0)+1;let blockedUntil=0;if(failures>=5){const tier=Math.floor((failures-5)/3);blockedUntil=Date.now()+Math.min(15*60*1000,30*1000*Math.pow(2,tier));}await setMetaObj('pinAttemptState',{failures,blockedUntil});if(blockedUntil)throw new Error('کد اشتباه است؛ برای امنیت ورود تا '+new Date(blockedUntil).toLocaleTimeString('fa-IR')+' متوقف شد.');return false;}const savedKey=await getMetaObj('deviceCryptoKey',null);if(!savedKey||savedKey.type!=='secret'||savedKey.algorithm?.name!=='AES-GCM'||!savedKey.usages?.includes('decrypt')||!savedKey.usages?.includes('encrypt'))throw new Error('کلید محلی در دسترس نیست؛ با رمز اصلی وارد شوید و کد ورود را دوباره تنظیم کنید.');cryptoKey=savedKey;await dbDelete(META,'pinAttemptState');deviceId=await getMetaObj('deviceId','');if(!deviceId){deviceId=uuid();await setMetaObj('deviceId',deviceId)}return true;}
function configureLockMode(){const input=$('localPassword'),confirm=$('confirmPassword'),passLabel=$('passwordLabel'),confirmLabel=$('confirmPasswordLabel'),hasMaster=!!window.qoqnusPasswordExists,hasPin=!!window.qoqnusQuickPinExists;const pinMode=pinSetupPending||(hasPin&&!masterFallback);const visualPinMode=hasMaster&&hasPin&&!masterFallback&&!pinSetupPending;input.value='';confirm.value='';input.setCustomValidity('');confirm.setCustomValidity('');$('masterLoginButton').classList.toggle('hidden',!(hasPin&&!masterFallback&&!pinSetupPending));$('pinLoginButton').classList.toggle('hidden',!(hasPin&&masterFallback&&!pinSetupPending));$('pinKeypadPanel')?.classList.toggle('hidden',!visualPinMode||quickEntryMode);passLabel.classList.toggle('hidden',visualPinMode||quickEntryMode);$('unlockButton').classList.toggle('hidden',visualPinMode||quickEntryMode);$('unlockForm').classList.toggle('hidden',quickEntryMode);$('startupQuickEntry')?.classList.toggle('hidden',!!quickFormContext);$('lockPrivacyNote')?.classList.toggle('hidden',!!quickFormContext);$('installHelpLock')?.classList.toggle('hidden',!!quickFormContext);confirmLabel.classList.toggle('hidden',!pinSetupPending&&!(!hasMaster));updatePinIndicators();if(pinSetupPending){input.classList.add('quick-pin-field');confirm.classList.add('quick-pin-field');input.type='tel';input.inputMode='numeric';input.setAttribute('pattern','[0-9]{4}');input.minLength=4;input.maxLength=4;input.autocomplete='new-password';input.placeholder='۴ رقم';passLabel.firstChild.textContent='کد ورود ۴ رقمی را بسازید';confirm.type='tel';confirm.inputMode='numeric';confirm.setAttribute('pattern','[0-9]{4}');confirm.minLength=4;confirm.maxLength=4;confirm.autocomplete='new-password';confirm.placeholder='۴ رقم را تکرار کنید';confirmLabel.firstChild.textContent='تکرار کد ورود';$('unlockButton').textContent='ثبت کد و بازکردن دفتر';$('lockIntro').textContent='رمز اصلی دفتر حفظ می‌شود؛ برای ورودهای روزانه یک کد ۴ رقمی انتخاب کنید.';return;}if(!hasMaster){input.classList.remove('quick-pin-field');confirm.classList.remove('quick-pin-field');input.type='password';input.inputMode='text';input.removeAttribute('pattern');input.minLength=8;input.removeAttribute('maxlength');input.autocomplete='new-password';input.placeholder='حداقل ۸ نویسه';passLabel.firstChild.textContent='ساخت رمز اصلی دفتر (برای بازیابی)';confirm.type='password';confirm.minLength=8;confirm.autocomplete='new-password';confirm.placeholder='رمز را دوباره وارد کنید';confirmLabel.firstChild.textContent='تکرار رمز اصلی';$('unlockButton').textContent='ساخت دفتر امن';$('lockIntro').textContent='ابتدا رمز اصلی را یک‌بار بسازید؛ سپس ورود روزانه با کد ۴ رقمی انجام می‌شود.';return;}confirmLabel.classList.add('hidden');if(pinMode){input.classList.add('quick-pin-field');confirm.classList.remove('quick-pin-field');input.type='tel';input.inputMode='numeric';input.setAttribute('pattern','[0-9]{4}');input.minLength=4;input.maxLength=4;input.autocomplete='current-password';input.placeholder='••••';passLabel.firstChild.textContent='کد ورود ۴ رقمی';$('unlockButton').textContent='بازکردن دفتر ققنوس';$('lockIntro').textContent='کد ورود چهاررقمی را وارد کنید؛ با رسیدن به ۴ رقم، دفتر باز می‌شود.';}else{input.classList.remove('quick-pin-field');confirm.classList.remove('quick-pin-field');input.type='password';input.inputMode='text';input.removeAttribute('pattern');input.minLength=8;input.removeAttribute('maxlength');input.autocomplete='current-password';input.placeholder='رمز اصلی دفتر';passLabel.firstChild.textContent='رمز اصلی دفتر';$('unlockButton').textContent=hasPin?'ورود با رمز اصلی':'ورود و تنظیم کد ۴ رقمی';$('lockIntro').textContent=hasPin?'ورود با رمز اصلی برای بازیابی کد سریع یا تنظیم مجدد آن است.':'برای استفاده از دفتر قبلی، رمز اصلی را وارد کنید؛ سپس کد ۴ رقمی تنظیم کنید.';}}
async function beginQuickPinSetup(message){pinSetupPending=true;masterFallback=false;await setMetaObj('deviceCryptoKey',cryptoKey);configureLockMode();setStatus('lockStatus',message||'اکنون کد ۴ رقمی ورود روزانه را بسازید.');}
function setStatus(id,message,kind=''){const el=$(id);if(!el)return;el.textContent=message;el.className='status'+(kind?' '+kind:'')}

function normalizeDivarDetailUrl(raw){
 const text=String(raw??'').trim();if(!text)return null;
 const candidates=[text];
 const found=text.match(/https?:\/\/(?:www\.)?divar\.ir\/v\/[^\s<>()\[\]\"']+/ig)||[];
 for(const value of found)candidates.push(value.replace(/[),.;!?،؛\]}]+$/u,''));
 for(const candidate of candidates){
  try{
   const u=new URL(candidate);
   if(u.protocol!=='https:'||!['divar.ir','www.divar.ir'].includes(u.hostname.toLowerCase()))continue;
   const segments=u.pathname.split('/').filter(Boolean);
   if(segments.length<2||segments.length>3||segments[0].toLowerCase()!=='v')continue;
   let id=decodeURIComponent(segments[segments.length-1]);
   if(!/^[A-Za-z0-9][A-Za-z0-9_-]{2,120}$/.test(id))continue;
   if(segments.length===3){const slug=decodeURIComponent(segments[1]);if(!slug||slug.includes('/')||slug==='.'||slug==='..')continue;}
   const path='/v/'+(segments.length===3?segments[1]+'/'+id:id);
   return {id,url:'https://divar.ir'+path};
  }catch{}
 }
 return null;
}
function stopReaderLaunchWatchdog(){if(readerLaunchWatchdog!==null){clearTimeout(readerLaunchWatchdog);readerLaunchWatchdog=null;}}
function setReaderActionBusy(button,busy){if(!button)return;button.disabled=!!busy;button.classList.toggle('is-busy',!!busy);setListingActionIcon(button,'eye',busy?'در حال بازکردن خوانشگر آگهی':'خواندن آگهی');}
function failReaderLaunch(attempt){
 if(attempt!==readerLaunchAttempt)return;
 stopReaderLaunchWatchdog();
 if(readerLaunchButton)setReaderActionBusy(readerLaunchButton,false);
 setStatus('divarShareStatus','خوانشگر همراه ققنوس روی گوشی باز نشد. این فایل همچنان در دفتر محفوظ است؛ برای خواندن خودکار باید برنامهٔ همراه اندرویدی ققنوس روی همین گوشی نصب باشد. پس از نصب، دوباره «خواندن آگهی» را بزنید.','error');
}
async function readDivarIntoExistingRecord(id,url,button){
 const link=normalizeDivarDetailUrl(url);if(!link){setStatus('divarShareStatus','پیوند مستقیم این فایل معتبر نیست.','error');return;}
 stopReaderLaunchWatchdog();const attempt=++readerLaunchAttempt;readerLaunchButton=button||null;readerLaunchWentBackground=false;
 const fallback=new URL(location.href);fallback.searchParams.set('reader','missing');fallback.searchParams.set('readerRecord',String(id||''));
 const target='intent://read?url='+encodeURIComponent(link.url)+'&recordId='+encodeURIComponent(String(id||''))+'#Intent;scheme=qoqnus;package=ir.qoqnus.divarreader;S.browser_fallback_url='+encodeURIComponent(fallback.href)+';end';
 setStatus('divarShareStatus','در حال بازکردن خوانشگر همراه ققنوس…','');
 if(button)setReaderActionBusy(button,true);
 // Inside the native Qoqnus app, use its trusted bridge directly. In Chrome/PWA, launch the installed Android companion through an intent URL.
 try{if(window.qoqnusAppBridge&&typeof window.qoqnusAppBridge.postMessage==='function'){window.qoqnusAppBridge.postMessage(JSON.stringify({type:'OPEN_READER',url:link.url,recordId:String(id||'')}));return;}}catch{}
 readerLaunchWatchdog=setTimeout(()=>{if(document.visibilityState==='visible')failReaderLaunch(attempt);},6500);
 location.href=target;
}
document.addEventListener('visibilitychange',()=>{
 if(document.visibilityState==='hidden'){
  if(readerLaunchWatchdog!==null){readerLaunchWentBackground=true;stopReaderLaunchWatchdog();}
  return;
 }
 if(readerLaunchWentBackground&&readerLaunchButton&&readerLaunchButton.disabled){
  readerLaunchWentBackground=false;setReaderActionBusy(readerLaunchButton,false);
  setStatus('divarShareStatus','از خوانشگر به برنامک برگشتید. اگر ذخیرهٔ موفق تأیید نشده، دوباره «خواندن آگهی» را بزنید.','warn');
 }else if(readerLaunchWentBackground&&!readerLaunchButton){
  // The reader can also be launched from the lock-screen operations panel.
  // Clear its pending state when the user returns, without opening private views.
  readerLaunchWentBackground=false;syncLockedOperationsPanel();
 }
});
function usefulIncomingValue(value){if(value==null)return false;if(typeof value==='string')return !!value.trim();if(Array.isArray(value))return value.length>0;if(typeof value==='object')return Object.keys(value).length>0;return true;}
async function receiveDivarReaderRecord(payload){
 if(!cryptoKey)throw new Error('ابتدا قفل برنامک ققنوس را باز کنید؛ اطلاعات خوانده‌شده تا آن زمان در حافظهٔ موقت خوانشگر می‌ماند.');
 if(!payload||typeof payload!=='object')throw new Error('ساختار اطلاعات دریافتی معتبر نیست.');
 const link=normalizeDivarDetailUrl(payload.url||payload.sourceUrl||payload.detailUrl||payload.canonicalUrl);if(!link)throw new Error('پیوند مستقیم و معتبر آگهی پیدا نشد.');
 const claimed=String(payload.divarId||payload.divar_id||payload.postId||'').trim();if(claimed&&claimed!==link.id)throw new Error('شناسهٔ فایل با پیوند سازگار نیست.');
 const now=Date.now(),stableId='divar:'+link.id,all=(await recordsOf('listing')).map(x=>x.record);let prior=await recordById('listing',stableId);if(!prior)prior=all.find(x=>canonicalDivarListingKey(x)===stableId)||null;
 const fullRead=String(payload.readerState||payload.mobileReaderState||payload.detailReadState||'')==='complete'||String(payload.schema||'')==='qoqnus.divar-reader.v1';
 // Keep the PWA and Chrome Extension on the same V4.5.88 shared normalizer for complete listing reads.
 // Link-only shares are not falsely marked complete or enriched with guessed fields.
 const normalizedPayload=fullRead&&window.QoqnusDivarNormalizer&&typeof window.QoqnusDivarNormalizer.normalizeRecord==='function'?window.QoqnusDivarNormalizer.normalizeRecord({...payload,url:link.url,detailUrl:link.url,divarId:link.id}):payload;
 const incoming={...payload,...normalizedPayload,id:stableId,record_uuid:stableId,divarId:link.id,url:link.url,detailUrl:link.url,sourceUrl:link.url,canonicalUrl:link.url,source:payload.source||'divar-mobile-reader',sourceLabel:payload.sourceLabel||'خوانشگر همراه ققنوس',collectedFrom:payload.collectedFrom||'android-webview-reader',mobileReaderState:fullRead?'complete':'link_only',mobileReaderLastReadAt:now,createdAt:Number(payload.createdAt)||now,updatedAt:now};
 const disclosedPhones=String(payload.phoneReadState||'')==='visible_on_page'&&String(payload.phoneSource||'')==='visible-divar-contact' ? [...new Set([...(Array.isArray(payload.phones)?payload.phones:[]),payload.phone,payload.ownerPhone,payload.sellerPhone,payload.contactPhone].map(phoneNorm).filter(Boolean))].slice(0,10) : [];
 if(disclosedPhones.length){incoming.divarPhone=disclosedPhones[0];incoming.divarPhones=disclosedPhones;incoming.phone=disclosedPhones[0];incoming.phones=disclosedPhones;incoming.ownerPhone=disclosedPhones[0];incoming.phoneReadState='visible_on_page';incoming.phoneSource='visible-divar-contact';}
 const mergeFields=['title','headline','text','content','description','publicDescription','public_description','detailText','detail_text','priceText','price_text','price','salePrice','sale_price','deposit','monthlyRent','monthly_rent','rent_price','pricePerMeter','price_per_meter','area','area_sqm','buildingArea','building_area','builtArea','landArea','rooms','bedrooms','year','propertyType','property_type','listingType','listingTypeLabel','transactionType','transaction_type','transactionLabel','location','locationText','location_text','fullLocation','city','neighborhood','street','address','amenities','featureFlags','convertible','attributes','facts','categories','categoryLinks','tags','imageUrls','image_urls','imageUrl','images','photos','phone','phones','ownerPhone','ownerName','customerName','sellerPhone','contactPhone','divarPhone','divarPhones','phoneReadState','phoneSource','agency','agencyCheck','normalizedSchema','normalizerVersion','normalizerSource'];
 let merged;if(prior){merged={...prior};for(const key of mergeFields){const v=incoming[key];if(!usefulIncomingValue(v))continue;if(['imageUrls','image_urls','images','photos'].includes(key)){const old=Array.isArray(prior[key])?prior[key]:(prior[key]?[prior[key]]:[]),fresh=Array.isArray(v)?v:[v];merged[key]=[...new Set([...old,...fresh].filter(Boolean))].slice(0,50);}else if(['attributes','facts'].includes(key)&&v&&typeof v==='object')merged[key]={...(prior[key]&&typeof prior[key]==='object'?prior[key]:{}),...v};else merged[key]=v;}
  merged.id=String(prior.id||stableId);merged.record_uuid=String(prior.record_uuid||prior.id||stableId);merged.createdAt=Number(prior.createdAt)||Number(incoming.createdAt)||now;merged.updatedAt=now;merged.url=link.url;merged.detailUrl=link.url;merged.sourceUrl=link.url;merged.canonicalUrl=link.url;merged.divarId=link.id;merged.mobileReaderState=(fullRead||prior.mobileReaderState==='complete')?'complete':'link_only';merged.mobileReaderLastReadAt=now;
 }else{merged={...incoming,title:clean(firstText(payload.title,payload.headline,'آگهی '+link.id),180),status:'saved',sendStatus:'not_sent',reviewStatus:'not_required',publicationState:'not_sent',createdAt:now,updatedAt:now};}
 // Legacy moderation labels are normalized locally: a saved Divar record is not a manager-review request. Keep published/archived lifecycle state untouched.
 if(!['published','archived','approved'].includes(String(merged.status||''))&&['pending','rejected'].includes(String(merged.status||''))){merged.status='saved';merged.sendStatus=String(merged.sendStatus||'not_sent');merged.reviewStatus='not_required';merged.publicationState=String(merged.publicationState||'not_sent');}
 // Preserve all office-only/private state on update; the reader never clears it just because Divar doesn't expose it.
 if(prior){for(const key of ['notes','privateNotes','followUp','followUpAt','reviewStatus','reviewedAt','syncViewedAt','syncReceivedAt','syncNew','mobileSyncNew','mobileSyncReceivedAt','mobileSyncViewedAt','centralPublishState','centralPublishRequestId','centralPublishResult','centralPublishError','ownerName','customerName','customerPhone'])if(prior[key]!==undefined&&(!usefulIncomingValue(incoming[key])||key==='notes'||key==='privateNotes'||key==='followUp'||key==='followUpAt'||key==='reviewStatus'||key==='reviewedAt'))merged[key]=prior[key];if(prior.phone!==undefined&&!usefulIncomingValue(incoming.phone)&&!disclosedPhones.length)merged.phone=prior.phone;if(prior.phones!==undefined&&!usefulIncomingValue(incoming.phones)&&!disclosedPhones.length)merged.phones=prior.phones;}
 if(disclosedPhones.length){merged.divarPhone=disclosedPhones[0];merged.divarPhones=disclosedPhones;merged.phone=disclosedPhones[0];merged.phones=disclosedPhones;merged.ownerPhone=disclosedPhones[0];merged.phoneReadState='visible_on_page';merged.phoneSource='visible-divar-contact';}
 // A newly read Divar record belongs in the main saved-listings view, not the archive bucket.
 if(!['published','archived','approved'].includes(String(merged.status||''))){merged.archiveBucket=0;merged.archiveReason='';merged.archivedAt=0;merged.status='saved';merged.sendStatus=String(merged.sendStatus||'not_sent');merged.reviewStatus='not_required';merged.publicationState=String(merged.publicationState||'not_sent');}
 await storeRecord('listing',merged);
 // If the read was launched from an office-file card, copy newly read public details
 // back to that same local record and mark it complete; do not leave its action on Publish.
 if(fullRead&&merged.targetOfficeFileId){
  try{
   const officeFileId=String(merged.targetOfficeFileId),officeFile=await recordById('file',officeFileId);
   if(officeFile){
    const next={...officeFile,readerState:'complete',mobileReaderState:'complete',readListingId:stableId,lastReaderAt:now,updatedAt:now};
    const fill=(key,value)=>{if(!usefulIncomingValue(next[key])&&usefulIncomingValue(value))next[key]=value;};
    fill('title',firstText(merged.title,merged.headline));
    fill('neighborhood',firstText(merged.neighborhood,merged.facts?.neighborhood,merged.locationText));
    fill('street',firstText(merged.street,merged.address,merged.facts?.street));
    fill('landArea',firstText(merged.landArea,merged.land_area,merged.area_sqm,merged.area));
    fill('buildingArea',firstText(merged.buildingArea,merged.building_area,merged.builtArea,merged.built_area));
    fill('rooms',firstText(merged.rooms,merged.bedrooms,merged.facts?.rooms));
    fill('year',firstText(merged.year,merged.buildingYear,merged.building_year));
    fill('salePrice',firstText(merged.salePrice,merged.sale_price,listingTransaction(merged)==='sale'?merged.price:''));
    fill('deposit',firstText(merged.deposit,merged.deposit_toman,merged.facts?.deposit));
    fill('monthlyRent',firstText(merged.monthlyRent,merged.monthly_rent,merged.rent_price,merged.facts?.monthlyRent));
    fill('landUse',firstText(merged.landUse,merged.land_use,merged.facts?.landUse));
    fill('access',firstText(merged.access,merged.amenities,merged.features));
    const visiblePhone = firstText(merged.divarPhone, merged.phone, merged.ownerPhone, merged.sellerPhone, Array.isArray(merged.divarPhones) ? merged.divarPhones[0] : Array.isArray(merged.phones) ? merged.phones[0] : '');
    if(visiblePhone&&disclosedPhones.length){next.divarPhone=disclosedPhones[0];next.divarPhones=disclosedPhones;}
    fill('phone', visiblePhone);
    fill('ownerPhone', visiblePhone);
    fill('phones', Array.isArray(merged.phones) ? merged.phones : []);
    fill('notes',firstText(merged.description,merged.publicDescription,merged.detailText,merged.text));
    const officeTx=listingTransaction(merged);if(!next.officeTransactionType&&['sale','rent'].includes(officeTx))next.officeTransactionType=officeTx;
    const officeTopic=listingTopic(merged);if(!next.officePropertyType){next.officePropertyType=officeTopic==='land'?'land':officeTopic==='commercial'?'commercial':officeTopic==='residential'?'villa':'';}
    const newPhotos=Array.isArray(merged.imageUrls)?merged.imageUrls:Array.isArray(merged.images)?merged.images:[];if(newPhotos.length){const oldPhotos=Array.isArray(next.imageUrls)?next.imageUrls:[];next.imageUrls=[...new Set([...oldPhotos,...newPhotos])].slice(0,12);}
    await storeRecord('file',next);
   }
  }catch(e){console.warn('Could not enrich source office file from read listing:',e);}
 }
 const aliases=await getMetaObj('aliases',{});if(prior&&String(prior.id)!==stableId)aliases['listing:'+stableId]=String(prior.id);await setMetaObj('aliases',aliases);
 await saveLocalNotification('divar-mobile-reader-'+link.id,prior?'updated-listing':'new-listing',prior?'آگهی به‌روزرسانی شد':'آگهی دریافت شد',fullRead?'اطلاعات قابل‌مشاهدهٔ آگهی در گوشی خوانده و در دفتر رمزگذاری‌شده ذخیره شد.':'پیوند آگهی دریافت شد؛ برای تکمیل مشخصات، آن را در برنامهٔ همراه ققنوس باز کنید.',{recordKind:'listing',recordId:String(merged.id)});
 if(fullOfficeUnlocked){activateView('listings');$('listingSearch').value='';await renderListings();setStatus('divarShareStatus',prior?'اطلاعات همان آگهی به‌روزرسانی شد و اطلاعات داخلی ققنوس حفظ شد.':(fullRead?'آگهی خوانده و روی گوشی ذخیره شد.':'پیوند آگهی ذخیره شد؛ جزئیات کامل هنوز خوانده نشده است.'),'success');}else{setStatus('lockedOperationsStatus',fullRead?'آگهی خوانده و به‌صورت رمزگذاری‌شده ذخیره شد؛ برای مشاهدهٔ آن قفل چهاررقمی را باز کنید.':'پیوند آگهی ذخیره شد؛ دفتر خصوصی همچنان قفل است.','success');}return {ok:true,id:stableId,recordId:String(merged.id),newRecord:!prior,fullRead};
}
async function processPendingDivarShares(){
 if(!cryptoKey)return {imported:0,fullyRead:0,linkOnly:0,errors:['دفتر قفل است.']};
 const pending=await getMetaObj('pendingDivarShares',[]);if(!Array.isArray(pending)||!pending.length)return {imported:0,fullyRead:0,linkOnly:0,errors:[]};
 let imported=0,linkOnly=0,errors=[];
 for(const item of pending){
  try{
   if(item?.error)throw new Error(String(item.error));
   const url=normalizeDivarDetailUrl(item?.url);if(!url)throw new Error('پیوند اشتراک‌گذاری‌شده معتبر نیست؛ نشانی مستقیم صفحهٔ همان آگهی را بفرستید.');
   await receiveDivarReaderRecord({url:url.url,title:clean(item.title||'',180),source:'mobile-share-target',sourceLabel:'دریافت پیوند آگهی از گوشی',collectedFrom:'pwa-share-target',readerState:'link_only',status:'saved',sendStatus:'not_sent',reviewStatus:'not_required',publicationState:'not_sent'});
   imported++;linkOnly++;
  }catch(e){errors.push(e?.message||'ثبت پیوند ناموفق بود.');}
 }
 await setMetaObj('pendingDivarShares',[]);
 if(imported){activateView('listings');setStatus('divarShareStatus',imported+' پیوند ذخیره شد؛ برای تکمیل مشخصات روی «خواندن آگهی» در کارت همان فایل بزنید؛ برنامهٔ همراه اندرویدی باید نصب باشد.','error');}
 if(errors.length)setStatus('divarShareStatus',errors.join(' '),'error');
 return {imported,fullyRead:0,linkOnly,errors};
}
window.QoqnusMobileDivarReader={isReady:()=>!!cryptoKey&&(fullOfficeUnlocked||backgroundOperationsMode||quickEntryMode),receive:async payload=>{try{const result=await receiveDivarReaderRecord(payload);readerLaunchWentBackground=false;if(readerLaunchButton){setReaderActionBusy(readerLaunchButton,false);readerLaunchButton=null;}syncLockedOperationsPanel();try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'RECORD_STORED',id:String(result.id||payload?.id||'')}));}catch{}return result;}catch(error){try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'RECORD_ERROR',id:String(payload?.id||''),message:String(error?.message||'ذخیرهٔ آگهی ناموفق بود.').slice(0,240)}));}catch{}throw error;}}};

async function normalizeLegacyDivarReviewStates(){
 const rows=await recordsOf('listing');let changed=0;
 for(const row of rows){
  const r=row?.record;if(!r||!canonicalDivarListingKey(r))continue;
  const status=String(r.status||'').toLowerCase();
  if(['published','archived','approved'].includes(status)||Number(r.archiveBucket)>0||Number(r.archivedAt)>0||['sold','rented'].includes(String(r.dealOutcome||r.archiveReason||'')))continue;
  const review=String(r.reviewStatus||'').toLowerCase();
  const legacy=['pending','rejected','under_review','review_pending','needs_review'].includes(status)||/pending|review|بررسی|در انتظار|reject|ردشده|رد شده/u.test(review);
  if(!legacy)continue;
  await storeRecord('listing',{...r,status:'saved',sendStatus:String(r.sendStatus||'not_sent'),reviewStatus:'not_required',publicationState:String(r.publicationState||'not_sent'),updatedAt:Date.now()});changed++;
 }
 return changed;
}
function updatePinIndicators(){
 const panel=$('pinDigitsDisplay'),input=$('localPassword');if(!panel||!input)return;const value=digits(input.value).slice(0,4),items=[...panel.querySelectorAll('.pin-digit')];items.forEach((item,index)=>{item.classList.toggle('filled',index<value.length);item.textContent=index<value.length?'●':'';});panel.setAttribute('aria-label',String(value.length).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)])+' رقم از ۴ رقم وارد شده');
}
function syncLockedOperationsPanel(){
 const panel=$('lockedOperationsPanel');if(!panel)return;
 panel.classList.toggle('hidden',!!quickEntryMode||!!quickFormContext);
 panel.classList.toggle('is-running',!!backgroundOperationsMode);
 const stop=$('stopLockedOperations');if(stop)stop.classList.toggle('hidden',!backgroundOperationsMode);
 const start=$('startLockedSync');if(start)start.disabled=!!backgroundOperationsMode;
 const full=$('startLockedFullSync');if(full)full.disabled=!!backgroundOperationsMode;
 const read=$('startLockedReader');if(read)read.disabled=!!backgroundOperationsMode&&!!readerLaunchWentBackground;
}
function setSyncFeedback(message,kind=''){
 setStatus('syncStatus',message,kind);
 if(backgroundOperationsMode)setStatus('lockedOperationsStatus',message,kind);
}
async function enterBackgroundOperationsMode(){
 if(backgroundOperationsMode&&cryptoKey)return true;
 if(quickEntryMode&&cryptoKey){backgroundOperationsMode=true;syncLockedOperationsPanel();try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'PWA_READY'}));}catch{}return true;}
 const configured=!!window.qoqnusPasswordExists&&!!window.qoqnusQuickPinExists;
 if(!configured)throw new Error('ابتدا دفتر امن و کد چهاررقمی را یک‌بار راه‌اندازی کنید. پس از راه‌اندازی، همگام‌سازی و خواندن آگهی بدون بازکردن دفتر خصوصی در دسترس است.');
 const key=await getMetaObj('deviceCryptoKey',null);
 if(!key||key.type!=='secret'||key.algorithm?.name!=='AES-GCM'||!key.usages?.includes('decrypt')||!key.usages?.includes('encrypt'))throw new Error('کلید امن این دستگاه موجود نیست؛ یک‌بار با رمز اصلی وارد شوید و کد چهاررقمی را دوباره تنظیم کنید.');
 cryptoKey=key;deviceId=await getMetaObj('deviceId','');backgroundOperationsMode=true;quickEntryMode=false;fullOfficeUnlocked=false;
 syncLockedOperationsPanel();
 try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'PWA_READY'}));}catch{}
 return true;
}
async function runLockedSync(mode='delta'){try{await enterBackgroundOperationsMode();if(mode==='full')await centralCheckIncoming();else await centralSendChanges();syncLockedOperationsPanel();}catch(error){setStatus('lockedOperationsStatus',String(error?.message||'همگام‌سازی مستقیم شیتاچی ناموفق بود.'),'error');}}
function stopLockedOperationsMode(){
 if(!backgroundOperationsMode)return;
 backgroundOperationsMode=false;cryptoKey=null;quickEntryMode=false;fullOfficeUnlocked=false;
 try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'PWA_LOCKED'}));}catch{}
 syncLockedOperationsPanel();setStatus('lockedOperationsStatus','عملیات پس‌زمینه متوقف شد؛ دفتر خصوصی همچنان قفل است.','');
}
async function readListingFromLockScreen(){
 try{await enterBackgroundOperationsMode();const input=$('lockedReaderUrl'),link=normalizeDivarDetailUrl(input?.value||'');if(!link)throw new Error('پیوند مستقیم آگهی معتبر نیست.');if(!window.qoqnusAppBridge||typeof window.qoqnusAppBridge.postMessage!=='function')throw new Error('خواندن خودکار آگهی در این محیط فقط از داخل برنامهٔ اندرویدی ققنوس پشتیبانی می‌شود.');readerLaunchButton=null;readerLaunchWentBackground=true;syncLockedOperationsPanel();window.qoqnusAppBridge.postMessage(JSON.stringify({type:'OPEN_READER',url:link.url,recordId:''}));setStatus('lockedOperationsStatus','خوانشگر باز شد؛ اطلاعات پس از دریافت در دفتر رمزگذاری می‌شود و فهرست خصوصی نمایش داده نخواهد شد.','success');}
 catch(error){readerLaunchWentBackground=false;syncLockedOperationsPanel();setStatus('lockedOperationsStatus',String(error?.message||'خواندن آگهی آغاز نشد.'),'error');}
}
function showQuickEntryControls(){
 syncLockedOperationsPanel();$('pinKeypadPanel')?.classList.add('hidden');$('quickEntryActions')?.classList.remove('hidden');$('unlockForm')?.classList.add('hidden');$('lockIntro').textContent='ثبت سریع فایل یا مشتری؛ این مسیر دفتر خصوصی را باز نمی‌کند.';
}
function restoreQuickEntryLanding(message=''){
 const input=$('quickEntryPhone');if(input)input.value=quickEntryPhone;
 $('quickEntryFormHost')?.classList.add('hidden');$('startupQuickEntry')?.classList.remove('hidden');$('lockPrivacyNote')?.classList.remove('hidden');$('installHelpLock')?.classList.remove('hidden');
 if(quickFormContext){const {form,parent,nextSibling}=quickFormContext;if(parent){if(nextSibling&&nextSibling.parentNode===parent)parent.insertBefore(form,nextSibling);else parent.appendChild(form);}form.classList.add('hidden');form.classList.remove('quick-entry-form');quickFormContext=null;}
 $('quickEntryActions')?.classList.remove('hidden');$('quickEntryActions')?.classList.toggle('hidden',!quickEntryMode);
 if(quickEntryMode){$('pinKeypadPanel')?.classList.add('hidden');$('unlockForm')?.classList.add('hidden');$('lockIntro').textContent='ثبت سریع فعال است؛ دفتر و پرونده‌های خصوصی هنوز قفل هستند.';}
 else {cryptoKey=null;$('unlockForm')?.classList.remove('hidden');configureLockMode();}
 if(message)setStatus('quickEntryStatus',message,'success');
}
async function enterQuickEntryMode(){
 if(quickEntryMode)return true;
 if(quickEntryUnlockPromise)return quickEntryUnlockPromise;
 quickEntryPhone=$('quickEntryPhone')?.value||quickEntryPhone;
 const configured=!!window.qoqnusPasswordExists&&!!window.qoqnusQuickPinExists;
 // The phone field always changes the visual state immediately. On a first run there is no
 // initialized encrypted vault/key to write into, so show the reason and keep save actions disabled.
 showQuickEntryControls();
 $('quickEntryFile').disabled=true;$('quickEntryCustomer').disabled=true;
 if(!configured){
  $('lockIntro').textContent='برای ثبت سریع، ابتدا دفتر امن را فقط یک‌بار راه‌اندازی و کد چهاررقمی را تعریف کنید.';
  setStatus('quickEntryStatus','راه‌اندازی اولیه لازم است: از «بازگشت به ورود رمز» استفاده کنید و دفتر امن و کد چهاررقمی را یک‌بار بسازید. پس از آن ثبت سریع به ورود روزانه با PIN نیاز ندارد.');
  return false;
 }
 // Key retrieval is asynchronous and never shows private lists; this mode is limited to the existing record forms.
 quickEntryUnlockPromise=(async()=>{
  try{
   const key=await getMetaObj('deviceCryptoKey',null);
   if(!key||key.type!=='secret'||key.algorithm?.name!=='AES-GCM'||!key.usages?.includes('decrypt')||!key.usages?.includes('encrypt'))throw new Error('کلید محلی ثبت سریع در دسترس نیست؛ یک‌بار با رمز اصلی وارد شوید و کد را دوباره تنظیم کنید.');
   cryptoKey=key;deviceId=await getMetaObj('deviceId','');quickEntryMode=true;fullOfficeUnlocked=false;syncLockedOperationsPanel();
   $('quickEntryFile').disabled=false;$('quickEntryCustomer').disabled=false;setStatus('quickEntryStatus','حالت ثبت سریع فعال است. اطلاعات خصوصی دفتر نمایش داده نمی‌شود.');return true;
  }catch(err){cryptoKey=null;quickEntryMode=false;$('quickEntryFile').disabled=true;$('quickEntryCustomer').disabled=true;setStatus('quickEntryStatus',err?.message||'ثبت سریع در دسترس نیست.','error');return false;}
 })();
 try{return await quickEntryUnlockPromise;}finally{quickEntryUnlockPromise=null;}
}
function exitQuickEntryMode(message=''){
 if(quickFormContext){restoreQuickEntryLanding(message);return;}
 quickEntryMode=false;cryptoKey=null;fullOfficeUnlocked=false;syncLockedOperationsPanel();
 $('quickEntryActions')?.classList.add('hidden');$('startupQuickEntry')?.classList.remove('hidden');$('unlockForm')?.classList.remove('hidden');$('lockIntro').textContent='دفتر خصوصی مشتریان و فایل‌های شما روی همین گوشی نگهداری می‌شود.';
 configureLockMode();if($('quickEntryPhone'))$('quickEntryPhone').value=quickEntryPhone;
 if(message)setStatus('quickEntryStatus',message);
}
function restoreQuickEntryForm(){if(!quickFormContext)return;const {form,parent,nextSibling}=quickFormContext;if(parent){if(nextSibling&&nextSibling.parentNode===parent)parent.insertBefore(form,nextSibling);else parent.appendChild(form);}form.classList.add('hidden');form.classList.remove('quick-entry-form');quickFormContext=null;}
function cancelQuickEntryForm(){if(!quickFormContext)return;restoreQuickEntryForm();$('quickEntryFormHost').classList.add('hidden');if(quickEntryMode){$('startupQuickEntry').classList.remove('hidden');$('lockIntro').textContent='ثبت سریع فعال است؛ دفتر و پرونده‌های خصوصی هنوز قفل هستند.';}else exitQuickEntryMode();}
async function startQuickEntryForm(kind){
 const available=await enterQuickEntryMode();if(!available)return;
 if(!phoneNorm($('quickEntryPhone').value)){setStatus('quickEntryStatus','شمارهٔ موبایل معتبر را وارد کنید؛ اعداد فارسی و انگلیسی پذیرفته می‌شوند.','error');$('quickEntryPhone').focus();return;}
 quickEntryPhone=$('quickEntryPhone').value;
 const isCustomer=kind==='customer',form=$(isCustomer?'customerForm':'fileForm');if(!form)return;
 if(quickFormContext)restoreQuickEntryForm();
 const parent=form.parentNode,nextSibling=form.nextSibling;quickFormContext={kind,form,parent,nextSibling};syncLockedOperationsPanel();$('quickEntryFormHost').appendChild(form);form.classList.remove('hidden');form.classList.add('quick-entry-form');
 $('startupQuickEntry').classList.add('hidden');$('pinKeypadPanel').classList.add('hidden');$('unlockForm').classList.add('hidden');$('lockPrivacyNote').classList.add('hidden');$('installHelpLock').classList.add('hidden');$('quickEntryFormHost').classList.remove('hidden');
 if(isCustomer){clearCustomerForm();$('customerPhone').value=phoneNorm(quickEntryPhone);syncConditionalFields();}else{clearFileForm();$('filePhone').value=phoneNorm(quickEntryPhone);syncConditionalFields();$('photoStatus').textContent=quickEntryStagedFiles.length?'عکس انتخاب‌شده از صفحه آغازین به این فایل متصل می‌شود.':'عکس اختیاری است؛ از بخش عکس‌ها هم می‌توانید انتخاب کنید.';}
 const title=$(isCustomer?'customerEntryTitle':'fileEntryTitle');if(title)title.textContent=isCustomer?'ثبت سریع مشتری':'ثبت سریع فایل';
 form.scrollIntoView({behavior:'smooth',block:'start'});setTimeout(()=>$(isCustomer?'customerName':'fileName')?.focus({preventScroll:true}),60);
}
async function acceptQuickEntryImages(fileList){
 const incoming=[...(fileList||[])].filter(file=>file&&String(file.type||'').startsWith('image/'));if(!incoming.length)return;
 const combined=[...quickEntryStagedFiles,...incoming];if(combined.length>3){setStatus('quickMediaStatus','حداکثر سه عکس می‌توان انتخاب کرد. عکس‌های قبلی حفظ شدند.','error');return;}
 if(incoming.some(file=>file.size>15*1024*1024)){setStatus('quickMediaStatus','حداقل یکی از عکس‌ها بیش از ۱۵ مگابایت است؛ عکس کوچک‌تری انتخاب کنید.','error');return;}
 quickEntryStagedFiles=combined;quickEntryPhone=$('quickEntryPhone').value||quickEntryPhone;$('quickMediaChooser').classList.add('hidden');
 setStatus('quickMediaStatus',quickEntryStagedFiles.length+' عکس آمادهٔ اتصال به فایل است. اگر ثبت مشتری را انتخاب کنید، عکس‌ها محفوظ می‌مانند تا فایل بعدی.','success');
 const ok=await enterQuickEntryMode();if(ok)showQuickEntryControls();
}
function setupStartupQuickEntry(){
 const phone=$('quickEntryPhone');phone.value=quickEntryPhone;
 phone.addEventListener('focus',()=>{quickEntryPhone=phone.value;enterQuickEntryMode().catch(()=>{});});
 phone.addEventListener('input',()=>{quickEntryPhone=phone.value;enterQuickEntryMode().catch(()=>{});});
 $('quickMediaChoose').addEventListener('click',()=>{$('quickMediaChooser').classList.remove('hidden');$('quickMediaCamera').focus();});
 $('quickMediaCancel').addEventListener('click',()=>{$('quickMediaChooser').classList.add('hidden');});
 $('quickMediaCamera').addEventListener('click',()=>{$('quickMediaChooser').classList.add('hidden');$('quickCameraInput').click();});
 $('quickMediaGallery').addEventListener('click',()=>{$('quickMediaChooser').classList.add('hidden');$('quickGalleryInput').click();});
 $('quickCameraInput').addEventListener('change',e=>{acceptQuickEntryImages(e.target.files).catch(err=>setStatus('quickMediaStatus',err?.message||'دریافت عکس از دوربین ناموفق بود.','error'));e.target.value='';});
 $('quickGalleryInput').addEventListener('change',e=>{acceptQuickEntryImages(e.target.files).catch(err=>setStatus('quickMediaStatus',err?.message||'انتخاب عکس ناموفق بود.','error'));e.target.value='';});
 document.querySelectorAll('[data-pin-key]').forEach(button=>button.addEventListener('click',()=>{
  if($('pinKeypadPanel').classList.contains('hidden'))return;const input=$('localPassword');let value=digits(input.value).slice(0,4),key=button.dataset.pinKey;
  if(key==='clear')value='';else if(key==='backspace')value=value.slice(0,-1);else if(/^\d$/.test(key)&&value.length<4)value+=key;
  input.value=value;updatePinIndicators();input.dispatchEvent(new Event('input',{bubbles:true}));
 }));
 $('quickEntryFile').addEventListener('click',()=>startQuickEntryForm('file').catch(err=>setStatus('quickEntryStatus',err?.message||'فرم فایل باز نشد.','error')));
 $('quickEntryCustomer').addEventListener('click',()=>startQuickEntryForm('customer').catch(err=>setStatus('quickEntryStatus',err?.message||'فرم مشتری باز نشد.','error')));
 $('quickEntryBack').addEventListener('click',()=>exitQuickEntryMode());
 $('startLockedSync')?.addEventListener('click',()=>runLockedSync('delta'));
 $('startLockedFullSync')?.addEventListener('click',()=>runLockedSync('full'));
 $('stopLockedOperations')?.addEventListener('click',()=>stopLockedOperationsMode());
 $('startLockedReader')?.addEventListener('click',()=>readListingFromLockScreen());
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&quickEntryMode&&!fullOfficeUnlocked){restoreQuickEntryForm();quickEntryMode=false;cryptoKey=null;$('quickEntryFormHost').classList.add('hidden');$('startupQuickEntry').classList.remove('hidden');$('quickEntryActions').classList.add('hidden');$('unlockForm').classList.remove('hidden');configureLockMode();}});
}
function finishQuickEntrySave(kind,message){
 const form=$(kind==='customer'?'customerForm':'fileForm');if(form){form.classList.add('hidden');form.classList.remove('quick-entry-form');}
 restoreQuickEntryForm();quickEntryMode=false;cryptoKey=null;fullOfficeUnlocked=false;syncLockedOperationsPanel();$('quickEntryFormHost').classList.add('hidden');$('startupQuickEntry').classList.remove('hidden');$('lockPrivacyNote').classList.remove('hidden');$('installHelpLock').classList.remove('hidden');$('unlockForm').classList.remove('hidden');$('quickEntryPhone').value=quickEntryPhone;$('quickEntryActions').classList.add('hidden');configureLockMode();setStatus('quickEntryStatus',message,'success');
}
function showApp(){
 backgroundOperationsMode=false;fullOfficeUnlocked=true;quickEntryMode=false;syncLockedOperationsPanel();quickEntryPhone=$('quickEntryPhone')?.value||quickEntryPhone;$('quickEntryActions')?.classList.add('hidden');$('quickEntryFormHost')?.classList.add('hidden');$('lockScreen').classList.add('hidden');$('appShell').classList.remove('hidden');refreshOnline();
 (async()=>{
  imageNormalizationPromise=normalizeLegacyStoredImages().then(result=>{if(result&&result.failedImages)setStatus('storageStatus','بهینه‌سازی برخی عکس‌های قدیمی کامل نشد؛ دوباره تلاش می‌شود ('+displayCount(result.failedImages)+' مورد).','warn');return result;}).catch(error=>{setStatus('storageStatus','بهینه‌سازی عکس‌های قدیمی متوقف شد؛ دادهٔ اصلی نگه داشته شد: '+String(error&&error.message||error).slice(0,140),'warn');return {failedImages:1};});
  const migrated=await normalizeLegacyDivarReviewStates();
  await renderAll(true);
  const imageResult=await imageNormalizationPromise;if(imageResult&&imageResult.normalizedRecords){await Promise.all([renderFiles(),renderListings(),renderDashboardHighlights()]);}
  refreshPairingUi().catch(error=>{console.error('Qoqnus pairing UI refresh failed',error);setSyncFeedback(String(error?.message||error),'error');});refreshListingSyncAuditExportButton().catch(()=>{});
  if(db)getMetaObj('deviceName','').then(v=>{$('mobileDeviceName').value=String(v||'')}).catch(()=>{});
  try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'PWA_READY'}));}catch{}
  const shareResult=await processPendingDivarShares();
  if(migrated)setStatus('divarShareStatus',migrated+' آگهی قدیمی از وضعیت بررسی به «ذخیره‌شده · آماده انتشار» تبدیل شد.','success');
  if(readerLaunchState==='missing'&&!window.qoqnusAppBridge){activateView('listings');setStatus('divarShareStatus','برنامهٔ همراه ققنوس روی گوشی نصب نیست یا باز نشد. برای خواندن خودکار باید برنامهٔ اندرویدی ققنوس نصب باشد؛ پیوند ذخیره‌شده باقی مانده است.','error');readerLaunchState='';readerLaunchRecordId='';history.replaceState({},'',location.pathname+location.hash);}
  if(shareArrivalState==='error')setStatus('divarShareStatus','درخواست اشتراک‌گذاری به برنامک رسید، اما صف دریافت لینک کامل نشد. صفحه را تازه‌سازی کنید؛ اگر تکرار شد، PWA را از Chrome حذف و دوباره با «نصب برنامه / Install app» نصب کنید.','error');
  else if(shareArrivalState==='1'&&shareResult.imported===0&&shareResult.errors.length===0)setStatus('divarShareStatus','ققنوس از منوی اشتراک‌گذاری باز شد ولی لینک معتبری در صف پیدا نشد. لینک مستقیم آگهی با قالب /v/شناسه را دوباره بفرستید.','error');
  if(shareArrivalState)history.replaceState({},'',location.pathname+location.hash);
 })().catch(e=>setStatus('divarShareStatus',e?.message||'بازکردن دفتر ققنوس ناموفق بود.','error'));
}
function lockApp(){backgroundOperationsMode=false;fullOfficeUnlocked=false;quickEntryMode=false;restoreQuickEntryForm();$('quickEntryFormHost')?.classList.add('hidden');$('startupQuickEntry')?.classList.remove('hidden');$('quickEntryActions')?.classList.add('hidden');cryptoKey=null;syncLockedOperationsPanel();try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'PWA_LOCKED'}));}catch{}$('appShell').classList.add('hidden');$('lockScreen').classList.remove('hidden');pinSetupPending=false;masterFallback=false;configureLockMode();setStatus('lockStatus','');}
$('unlockForm').addEventListener('submit',async e=>{e.preventDefault();if(lockSubmitBusy)return;lockSubmitBusy=true;const btn=$('unlockButton');btn.disabled=true;try{setStatus('lockStatus','در حال بررسی…');const raw=$('localPassword').value;const input=digits(raw);if(pinSetupPending){if(!/^\d{4}$/.test(input)){setStatus('lockStatus','کد ورود باید دقیقاً ۴ رقم باشد.','error');return;}if(input!==digits($('confirmPassword').value)){setStatus('lockStatus','دو کد ورود یکسان نیستند.','error');return;}await setQuickPin(input);pinSetupPending=false;window.qoqnusQuickPinExists=true;showApp();setStatus('storageStatus','کد ۴ رقمی فعال شد؛ برای ورودهای بعدی به رمز اصلی نیاز نیست.');return;}if(!window.qoqnusPasswordExists){const pass=raw;if(pass.length<8){setStatus('lockStatus','رمز اصلی باید دست‌کم ۸ نویسه باشد.','error');return;}if(pass!==$('confirmPassword').value){setStatus('lockStatus','تکرار رمز اصلی یکسان نیست.','error');return;}await setLocalPassword(pass);window.qoqnusPasswordExists=true;await beginQuickPinSetup('رمز اصلی ساخته شد. اکنون یک کد ۴ رقمی برای ورود سریع بسازید.');return;}if(window.qoqnusQuickPinExists&&!masterFallback){const ok=await unlockQuickPin(input);if(!ok){setStatus('lockStatus','کد ورود اشتباه است.','error');return;}showApp();return;}const ok=await unlockPassword(raw);if(!ok){setStatus('lockStatus','رمز اصلی اشتباه است.','error');return;}await setMetaObj('deviceCryptoKey',cryptoKey);if(!window.qoqnusQuickPinExists){await beginQuickPinSetup('دفتر باز شد. برای ورودهای بعدی، یک کد ۴ رقمی تنظیم کنید.');return;}masterFallback=false;showApp();}catch(err){setStatus('lockStatus',err.message||'ورود به برنامک ناموفق بود.','error')}finally{lockSubmitBusy=false;btn.disabled=false;}});
$('localPassword').addEventListener('input',()=>{if(window.qoqnusQuickPinExists&&!masterFallback&&!pinSetupPending){const v=digits($('localPassword').value).slice(0,4);if($('localPassword').value!==v)$('localPassword').value=v;updatePinIndicators();if(v.length===4&&!lockSubmitBusy){setTimeout(()=>{if($('localPassword').value===v&&v.length===4)$('unlockForm').requestSubmit()},80)}}else updatePinIndicators();});
$('masterLoginButton').addEventListener('click',()=>{masterFallback=true;configureLockMode();const field=$('localPassword');field.setCustomValidity('');field.removeAttribute('pattern');field.removeAttribute('maxlength');field.minLength=8;field.type='password';field.inputMode='text';setStatus('lockStatus','حالت ورود با رمز اصلی فعال شد؛ رمز اصلی را وارد کنید.');field.focus()});
$('pinLoginButton').addEventListener('click',()=>{masterFallback=false;configureLockMode();$('localPassword').focus()});
$('lockButton').addEventListener('click',()=>{if(confirm('برنامک قفل شود؟ داده‌ها روی گوشی باقی می‌مانند.'))lockApp()});async function changeLocalPassword(){if(!cryptoKey){setStatus('backupStatus','ابتدا برنامک را باز کنید.','error');return}const next=prompt('رمز محلی جدید را وارد کنید (حداقل ۸ نویسه):');if(next===null)return;if(next.length<8){setStatus('backupStatus','رمز جدید باید دست‌کم ۸ نویسه باشد.','error');return}const confirmNext=prompt('رمز محلی جدید را دوباره وارد کنید:');if(next!==confirmNext){setStatus('backupStatus','دو رمز واردشده یکسان نیستند.','error');return}if(!confirm('رمز محلی عوض می‌شود؛ رکوردهای رمزگذاری‌شده دوباره رمزگذاری خواهند شد. پیش از ادامه، پشتیبان بگیرید. ادامه می‌دهید؟'))return;const oldKey=cryptoKey;try{const oldRows=await dbAll(STORE),salt=crypto.getRandomValues(new Uint8Array(16)),newKey=await deriveKey(next,salt),encoded=[];cryptoKey=newKey;for(const row of oldRows){const record=await decryptValue({iv:row.iv,cipher:row.cipher});const envelope=await encryptValue(record);encoded.push({...row,iv:envelope.iv,cipher:envelope.cipher});}const check=await encryptValue({magic:'qoqnus-mobile-lock-v1',createdAt:Date.now()});const tx=db.transaction([STORE,META],'readwrite');for(const row of encoded)tx.objectStore(STORE).put(row);tx.objectStore(META).put({key:'localSalt',value:b64(salt)});tx.objectStore(META).put({key:'lockCheck',value:check});if(window.qoqnusQuickPinExists)tx.objectStore(META).put({key:'deviceCryptoKey',value:newKey});await new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('ذخیرهٔ رمز جدید ناموفق بود.'));tx.onabort=()=>reject(tx.error||new Error('تغییر رمز لغو شد.'))});setStatus('backupStatus','رمز محلی تغییر کرد و اطلاعات با کلید جدید رمزگذاری شد.','');}catch(err){cryptoKey=oldKey;setStatus('backupStatus',err.message||'تغییر رمز محلی ناموفق بود. رمز قبلی حفظ شد.','error')}}$('changePassword').addEventListener('click',changeLocalPassword);
function openPinChange(){if(!cryptoKey){setStatus('backupStatus','ابتدا برنامک را باز کنید.','error');return}const panel=$('pinChangePanel');panel.classList.remove('hidden');$('pinCurrentValue').value='';$('pinNewValue').value='';$('pinConfirmValue').value='';$('pinMasterValue').value='';$('pinMasterBlock').classList.add('hidden');$('pinCurrentBlock').classList.remove('hidden');$('pinUseMasterMode').textContent='کد فعلی را فراموش کرده‌ام؛ ورود با رمز اصلی';$('applyQuickPin').disabled=false;$('applyQuickPin').textContent='ذخیرهٔ کد جدید';setStatus('pinChangeStatus','ابتدا کد فعلی را تأیید کنید؛ سپس کد جدید را دو بار وارد کنید. کد قبلی تا تأیید کامل ذخیره حفظ می‌شود.');panel.scrollIntoView?.({behavior:'smooth',block:'center'});$('pinCurrentValue').focus();}
function closeQuickPinChange(){$('pinChangePanel').classList.add('hidden');for(const id of ['pinCurrentValue','pinNewValue','pinConfirmValue','pinMasterValue'])$(id).value='';$('pinChangeStatus').textContent='';}
function togglePinMasterMode(){const useMaster=$('pinMasterBlock').classList.contains('hidden');$('pinMasterBlock').classList.toggle('hidden',!useMaster);$('pinCurrentBlock').classList.toggle('hidden',useMaster);$('pinUseMasterMode').textContent=useMaster?'بازگشت به تأیید با کد فعلی':'کد فعلی را فراموش کرده‌ام؛ ورود با رمز اصلی';setStatus('pinChangeStatus',useMaster?'برای بازیابی، رمز اصلی دفتر را وارد کنید. سپس کد جدید را دو بار وارد کنید.':'کد فعلی را وارد کنید؛ کد قبلی تا تأیید کامل ذخیره حفظ می‌شود.');if(useMaster)$('pinMasterValue').focus();else $('pinCurrentValue').focus();}
function normalizePinInput(el){const v=digits(el.value).slice(0,4);if(el.value!==v)el.value=v;}
['pinCurrentValue','pinNewValue','pinConfirmValue'].forEach(id=>$(id).addEventListener('input',()=>normalizePinInput($(id))));
$('pinUseMasterMode').addEventListener('click',togglePinMasterMode);
async function saveQuickPinFromForm(){if(!cryptoKey){setStatus('pinChangeStatus','ابتدا برنامک را باز کنید.','error');return}const next=digits($('pinNewValue').value),confirmNext=digits($('pinConfirmValue').value);if(!/^\d{4}$/.test(next)){setStatus('pinChangeStatus','کد جدید باید دقیقاً ۴ رقم باشد.','error');$('pinNewValue').focus();return}if(next!==confirmNext){setStatus('pinChangeStatus','دو کد واردشده یکسان نیستند.','error');$('pinConfirmValue').focus();return}const oldKey=cryptoKey,useMaster=!$('pinMasterBlock').classList.contains('hidden');if(useMaster){const master=String($('pinMasterValue').value||'');if(master.length<8){setStatus('pinChangeStatus','رمز اصلی را کامل وارد کنید. کد قبلی حفظ شد.','error');$('pinMasterValue').focus();return}const valid=await unlockPassword(master);if(!valid){cryptoKey=oldKey;setStatus('pinChangeStatus','رمز اصلی اشتباه است؛ کد قبلی حفظ شد.','error');$('pinMasterValue').focus();return}}else{const current=digits($('pinCurrentValue').value);if(!/^\d{4}$/.test(current)){setStatus('pinChangeStatus','کد فعلی باید دقیقاً ۴ رقم باشد. کد قبلی حفظ شد.','error');$('pinCurrentValue').focus();return}const valid=await unlockQuickPin(current);if(!valid){cryptoKey=oldKey;setStatus('pinChangeStatus','کد فعلی اشتباه است؛ کد قبلی حفظ شد.','error');$('pinCurrentValue').focus();return}}
const btn=$('applyQuickPin');btn.disabled=true;btn.textContent='در حال ذخیره…';setStatus('pinChangeStatus','در حال رمزگذاری و ذخیرهٔ کد جدید؛ صفحه را نبندید.');try{await setQuickPin(next);window.qoqnusQuickPinExists=true;setStatus('pinChangeStatus','✅ کد ورود ۴ رقمی تغییر کرد و دوباره اعتبارسنجی شد.','success');setStatus('backupStatus','کد ورود ۴ رقمی با موفقیت تغییر کرد.','success');$('pinCurrentValue').value='';$('pinNewValue').value='';$('pinConfirmValue').value='';$('pinMasterValue').value='';btn.textContent='ذخیره شد';}catch(err){cryptoKey=oldKey;setStatus('pinChangeStatus',(err.message||'تغییر کد ناموفق بود.')+' کد قبلی حفظ شد.','error');btn.textContent='ذخیرهٔ کد جدید';}finally{btn.disabled=false}}
$('applyQuickPin').addEventListener('click',saveQuickPinFromForm);$('cancelQuickPinChange').addEventListener('click',closeQuickPinChange);$('changeQuickPin').addEventListener('click',openPinChange);
function canonicalCustomerProperty(value){const v=normalizeText(value||'');if(!v)return '';if(/زمین|باغ|کلنگی|کشاورز/u.test(v))return 'زمین';if(/تجار|مغازه|سوله|کارگاه|انبار/u.test(v))return 'تجاری';if(/خانه|ویلا|آپارتمان|مسکونی|residential/u.test(v))return 'ویلایی';return '';}
function selectedValues(name){return [...document.querySelectorAll('input[name="'+name+'"]:checked')].map(x=>String(x.value));}
function updateHvacChoiceValue(name,hiddenId,otherId){const picked=selectedValues(name),other=clean($(otherId)?.value||'',80);$(hiddenId).value=[...picked,other].filter(Boolean).join('، ');}
function hydrateHvacChoices(name,hiddenId,otherId,rawValue){let remaining=String(rawValue||'');const compare=value=>normalizeText(value).replace(/\s*\/\s*/g,'/');for(const input of document.querySelectorAll('input[name="'+name+'"]')){const label=compare(input.value);const matched=!!label&&compare(remaining).includes(label);input.checked=matched;if(matched){const escaped=input.value.split('/').map(part=>part.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('\\s*\\/\\s*');try{remaining=remaining.replace(new RegExp(escaped,'iu'),' ');}catch{}}}$(otherId).value=remaining.replace(/[،,;؛|]+/g,' ').replace(/(?:^|\s)و(?:\s|$)/gu,' ').replace(/\s+/g,' ').trim();updateHvacChoiceValue(name,hiddenId,otherId);}
function selectedBedroomCount(){return selectedValues('fileRoomsChoice')[0]||'0';}
function roomCountForSearch(raw){const value=String(raw??'').trim();if(!value)return '';const normalized=normalizeText(value);if(/بدون خواب|بدون اتاق|استودیو|studio|no bedrooms?/u.test(normalized))return '0';const ascii=value.replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c));if(/^[0-3]$/.test(ascii))return ascii;const nearby=ascii.match(/(?:^|\s)([0-3])\s*(?:خواب|اتاق|bedrooms?|rooms?)(?:\s|$)/iu)||ascii.match(/(?:خواب|اتاق|bedrooms?|rooms?)\s*([0-3])(?:\s|$)/iu);if(nearby)return nearby[1]||nearby[2]||'';if(/(?:^|\s)(?:یک|تک|one)(?:\s|$)|یک خواب/u.test(normalized))return '1';if(/(?:^|\s)(?:دو|two)(?:\s|$)|دو خواب/u.test(normalized))return '2';if(/(?:^|\s)(?:سه|three)(?:\s|$)|سه خواب/u.test(normalized))return '3';return ''; }
function matchesAppliedFileCriteria(r){const c=appliedFileCriteria||{};const tx=String(r.transactionType||r.officeTransactionType||'');if(c.transaction?.length&&!c.transaction.includes(tx))return false;const rawProp=normalizeText(r.officePropertyType||r.propertyType||'');const prop=/land|زمین|باغ|کلنگی/u.test(rawProp)?'land':/commercial|تجار|مغازه|سوله/u.test(rawProp)?'commercial':/villa|ویلا|خانه|مسکونی|آپارتمان/u.test(rawProp)?'villa':'';if(c.property?.length&&!c.property.includes(prop))return false;const rooms=roomCountForSearch(r.rooms);if(c.rooms?.length&&(!rooms||!c.rooms.includes(rooms)))return false;if(c.hvac?.includes('heating')&&!String(r.heating||'').trim())return false;if(c.hvac?.includes('cooling')&&!String(r.cooling||'').trim())return false;return true;}
function collectFileSearchCriteria(){return{transaction:selectedValues('fileTransactionCriteria'),property:selectedValues('filePropertyCriteria'),rooms:selectedValues('fileRoomsCriteria'),hvac:selectedValues('fileHvacCriteria')};}
function collectCustomerSearchFields(){const fields=selectedValues('customerSearchField');return fields.length?fields:['name','phone','neighborhood','street','desiredArea','budget','notes'];}
function syncConditionalFields(){
 const cn=$('customerName').value.trim()||$('customerPhone').value.trim();$('customerTypeChoices').classList.toggle('hidden',!cn);const ct=document.querySelector('input[name="customerType"]:checked')?.value||'';$('customerDetails').classList.toggle('hidden',!ct);document.querySelectorAll('.buyer-field').forEach(x=>x.classList.toggle('hidden',ct!=='buyer'));document.querySelectorAll('.tenant-field').forEach(x=>x.classList.toggle('hidden',ct!=='tenant'));
 let customerProperty=canonicalCustomerProperty($('customerProperty').value);if(ct==='tenant'&&customerProperty==='زمین'){customerProperty='';$('customerProperty').value='';document.querySelectorAll('input[name="customerPropertyChoice"][value="زمین"]').forEach(r=>r.checked=false);}document.querySelectorAll('input[name="customerPropertyChoice"]').forEach(r=>{const isLand=r.value==='زمین';r.closest('.choice')?.classList.toggle('hidden',ct==='tenant'&&isLand);});if(customerProperty!==$('customerProperty').value&&customerProperty)$('customerProperty').value=customerProperty;
 const fn=$('fileName').value.trim()||$('filePhone').value.trim();$('fileTransactionChoices').classList.toggle('hidden',!fn);const tx=document.querySelector('input[name="fileTransaction"]:checked')?.value||'';$('fileDetails').classList.toggle('hidden',!tx);let prop=$('fileProperty').value||'villa';if(tx==='rent'&&prop==='land'){prop='villa';$('fileProperty').value='villa';const v=document.querySelector('input[name="filePropertyChoice"][value="villa"]');if(v)v.checked=true;}document.querySelectorAll('input[name="filePropertyChoice"]').forEach(r=>{const isLand=r.value==='land';r.closest('.choice')?.classList.toggle('hidden',tx==='rent'&&isLand);});document.querySelectorAll('.sale-field').forEach(x=>x.classList.toggle('hidden',tx!=='sale'));document.querySelectorAll('.rent-field').forEach(x=>x.classList.toggle('hidden',tx!=='rent'));document.querySelectorAll('.villa-field').forEach(x=>x.classList.toggle('hidden',prop!=='villa'));document.querySelectorAll('.land-field').forEach(x=>x.classList.toggle('hidden',prop!=='land'));document.querySelectorAll('.commercial-field').forEach(x=>x.classList.toggle('hidden',prop!=='commercial'));
}
['customerName','customerPhone','fileName','filePhone'].forEach(id=>$(id).addEventListener('input',syncConditionalFields));document.querySelectorAll('input[name="customerType"],input[name="fileTransaction"]').forEach(x=>x.addEventListener('change',syncConditionalFields));document.querySelectorAll('input[name="customerPropertyChoice"]').forEach(x=>x.addEventListener('change',()=>{$('customerProperty').value=x.checked?canonicalCustomerProperty(x.value):$('customerProperty').value;syncConditionalFields();}));document.querySelectorAll('input[name="filePropertyChoice"]').forEach(x=>x.addEventListener('change',()=>{$('fileProperty').value=x.value;syncConditionalFields();}));
function customerPhotoValue(record){const value=String(record?.profilePhotoWebp||'');return value.length<=300000&&/^data:image\/webp;base64,[A-Za-z0-9+/]+={0,2}$/.test(value)?value:'';}
function updateCustomerPhotoPreview(value=pendingCustomerPhotoWebp,message=''){const preview=$('customerPhotoPreview'),label=$('customerPhotoPreviewLabel'),remove=$('removeCustomerPhoto');if(preview){preview.src=customerPhotoValue({profilePhotoWebp:value})||DEFAULT_RECORD_IMAGE;setImageFallback(preview);}if(label)label.textContent=value?'تصویر مشتری آمادهٔ ذخیره است.':'تصویر پیش‌فرض مشتری';if(remove)remove.disabled=!value;if(message)setStatus('customerPhotoStatus',message,message.includes('ناموفق')||message.includes('بیش از')?'error':'');}
function clearCustomerPhoto(){pendingCustomerPhotoWebp='';if($('customerPhotoFile'))$('customerPhotoFile').value='';updateCustomerPhotoPreview('','تصویر اختصاصی حذف شد؛ پس از ذخیره، مشتری بدون تصویر خواهد بود.');}
$('chooseCustomerPhoto').addEventListener('click',()=>{if($('customerPhotoFile'))$('customerPhotoFile').click();});
$('removeCustomerPhoto').addEventListener('click',clearCustomerPhoto);
$('customerPhotoFile').addEventListener('change',async event=>{const file=event.target.files?.[0];event.target.value='';if(!file)return;const button=$('chooseCustomerPhoto');button.disabled=true;setStatus('customerPhotoStatus','در حال پردازش تصویر و تبدیل به WebP با ضلع بزرگ حداکثر ۵۰۰ پیکسل…');try{if(!window.QoqnusCustomerPhoto)throw new Error('پردازشگر تصویر مشتری بارگذاری نشده است.');const result=await QoqnusCustomerPhoto.normalizeFile(file);if(Math.max(result.width,result.height)>500||result.bytes>409600||!/^data:image\/webp;base64,/.test(result.dataUrl))throw new Error('تصویر باید WebP، با ضلع بزرگ حداکثر ۵۰۰ پیکسل و حجم حداکثر ۴۰۰ کیلوبایت باشد.');pendingCustomerPhotoWebp=result.dataUrl;updateCustomerPhotoPreview(pendingCustomerPhotoWebp,'تصویر آماده است؛ با ذخیرهٔ فرم به همین مشتری متصل می‌شود. حجم: '+displayCount(Math.round(result.bytes/1024))+' کیلوبایت.');}catch(error){setStatus('customerPhotoStatus',String(error?.message||'پردازش تصویر ناموفق بود.'),'error');}finally{button.disabled=false;}});
function clearCustomerForm(){ $('customerForm').reset();$('customerEditId').value='';pendingCustomerPhotoWebp='';updateCustomerPhotoPreview('');syncConditionalFields();setStatus('customerStatus','');setStatus('customerPhotoStatus','');$('saveCustomer').textContent='ذخیره روی گوشی';const title=$('customerEntryTitle');if(title)title.textContent='افزودن مشتری';}
function clearFileForm(){ $('fileForm').reset();$('fileEditId').value='';$('fileRooms').value='0';$('fileHeating').value='';$('fileCooling').value='';$('fileHeatingOther').value='';$('fileCoolingOther').value='';syncConditionalFields();setStatus('fileStatus','');$('saveFile').textContent='ذخیره روی گوشی';$('photoStatus').textContent='عکس‌ها پیش از ذخیره فشرده می‌شوند و فقط روی همین دستگاه ذخیره می‌شوند.';const title=$('fileEntryTitle');if(title)title.textContent='افزودن فایل';}

function showEntryForm(kind,mode='new'){
 const isCustomer=kind==='customer',form=$(isCustomer?'customerForm':'fileForm');if(!form)return;
 if(mode==='new'){if(isCustomer)clearCustomerForm();else clearFileForm();}
 form.classList.remove('hidden');
 const title=$(isCustomer?'customerEntryTitle':'fileEntryTitle');if(title)title.textContent=mode==='edit'?(isCustomer?'ویرایش مشتری':'ویرایش فایل'):(isCustomer?'افزودن مشتری':'افزودن فایل');
 form.scrollIntoView({behavior:'smooth',block:'start'});
 const field=$(isCustomer?'customerName':'fileName');setTimeout(()=>field?.focus({preventScroll:true}),80);
}

$('clearCustomer').addEventListener('click',()=>{clearCustomerForm();if(quickEntryMode)$('customerPhone').value=phoneNorm(quickEntryPhone)});$('clearFile').addEventListener('click',()=>{clearFileForm();if(quickEntryMode){$('filePhone').value=phoneNorm(quickEntryPhone);$('photoStatus').textContent=quickEntryStagedFiles.length?'عکس‌های انتخاب‌شده از صفحه آغازین به این فایل متصل می‌شوند.':'عکس‌ها اختیاری هستند.'}});
async function saveCustomer(e){e.preventDefault();if(!cryptoKey)return;const name=clean($('customerName').value,120),phone=phoneNorm($('customerPhone').value),type=document.querySelector('input[name="customerType"]:checked')?.value||'';if(name.length<3||/\d/u.test(name)){setStatus('customerStatus','نام را کامل و بدون عدد وارد کنید.','error');return}if(!phone){setStatus('customerStatus','شمارهٔ موبایل معتبر وارد کنید.','error');return}if(!type){setStatus('customerStatus','خریدار یا مستأجر را انتخاب کنید.','error');return}if(!$('customerConfirm').checked){setStatus('customerStatus','تأیید ذخیرهٔ محلی را علامت بزنید.','error');return}const all=(await recordsOf('customer')).map(x=>x.record),editId=$('customerEditId').value;let old=all.find(x=>String(x.id)===editId)||all.find(x=>phoneNorm(x.phone)===phone);const now=Date.now();const min=type==='buyer'?money($('customerMin').value):'',max=type==='buyer'?money($('customerMax').value):'',deposit=type==='tenant'?money($('customerDeposit').value):'',rent=type==='tenant'?money($('customerRent').value):'';if(min&&max&&Number(max)<Number(min)){setStatus('customerStatus','حداکثر بودجه از حداقل بودجه کمتر است.','error');return}const id=old?.id||('CUST-'+(await sha256Hex(encoder.encode(phone))).slice(0,20).toUpperCase());const priorType=old?.type,changed=!!old&&['type','min','max','deposit','rent','neighborhood','street','desiredArea','propertyType','notes','profilePhotoWebp'].some(k=>String(old[k]||'')!==String(({type,min,max,deposit,rent,neighborhood:$('customerNeighborhood').value.trim(),street:$('customerStreet').value.trim(),desiredArea:money($('customerArea').value),propertyType:canonicalCustomerProperty($('customerProperty').value),notes:clean($('customerNotes').value,1000),profilePhotoWebp:pendingCustomerPhotoWebp})[k]||''));const rec={...(old||{}),id,record_uuid:id,name,phone,type,min,max,deposit,rent,neighborhood:clean($('customerNeighborhood').value,120),street:clean($('customerStreet').value,160),desiredArea:money($('customerArea').value),propertyType:clean(canonicalCustomerProperty($('customerProperty').value),80),notes:clean($('customerNotes').value,1000),profilePhotoWebp:pendingCustomerPhotoWebp||'',status:'active',requestCount:old?Math.max(1,Number(old.requestCount||1)+(changed?1:0)):1,createdAt:Number(old?.createdAt)||now,updatedAt:now,source:'mobile-pwa'};await storeRecord('customer',rec);clearCustomerForm();$('customerForm').classList.add('hidden');if(quickEntryMode){finishQuickEntrySave('customer',old?'اطلاعات مشتری موجود به‌روزرسانی شد.':'مشتری جدید در دفتر محلی ذخیره شد.');return;}setStatus('storageStatus',old?'اطلاعات مشتری به‌روزرسانی و روی گوشی ذخیره شد.':'مشتری در دفتر محلی گوشی ثبت شد.','success');await renderCustomers();await renderDashboardHighlights();await ensureDailyCustomerFollowupNotifications(true);await renderNotifications();}
$('customerForm').addEventListener('submit',saveCustomer);
async function compressImage(file){if(!window.QoqnusImageNormalizer)throw new Error('پردازش استاندارد تصویر بارگذاری نشده است.');const result=await QoqnusImageNormalizer.normalizeFile(file);if(Math.max(result.width,result.height)>500||result.bytes>409600||!/^data:image\/webp;base64,/i.test(result.dataUrl))throw new Error('تصویر باید WebP، با ضلع بزرگ حداکثر ۵۰۰ پیکسل و حجم حداکثر ۴۰۰ کیلوبایت باشد.');return result.dataUrl;}
const INLINE_IMAGE_FIELDS=['imageDataUrls','imageDataUrl','image_data_url','localImageDataUrls','localPhotos','photoDataUrls','photoDataUrl','imageUrls','imageUrl','image_url','images','photos','photo','photoUrl','photo_url','pictures','avatar','avatarUrl','avatar_url','profileImage','profileImageDataUrl','customerPhoto','customerPhotoUrl','ownerPhoto','thumbnailData'];
async function normalizeNestedImageValue(value,memo,state){if(typeof value==='string'&&/^data:image\//i.test(value)){if(memo.has(value))return memo.get(value);try{const result=await QoqnusImageNormalizer.normalizeDataUrl(value);if(result.width!==400||result.height!==400||!/^data:image\/(?:webp|jpeg);base64,/i.test(result.dataUrl))throw new Error('خروجی تصویر با استاندارد هم‌خوانی ندارد.');memo.set(value,result.dataUrl);if(result.dataUrl!==value)state.normalizedImages++;return result.dataUrl;}catch(error){memo.set(value,value);state.failedImages++;state.lastError=String(error&&error.message||error).slice(0,160);return value;}}if(Array.isArray(value)){const out=[];let changed=false;for(const item of value){const normalized=await normalizeNestedImageValue(item,memo,state);out.push(normalized);if(normalized!==item)changed=true;}return changed?out:value;}if(value&&typeof value==='object'){let changed=false;const out={...value};for(const key of ['dataUrl','dataURL','src','url','data'])if(key in out){const normalized=await normalizeNestedImageValue(out[key],memo,state);if(normalized!==out[key]){out[key]=normalized;changed=true;}}return changed?out:value;}return value;}
async function normalizeLegacyStoredImages(force=false){if(!cryptoKey)return {skipped:true,normalizedImages:0,normalizedRecords:0,failedImages:0};const prior=await getMetaObj('imageNormalization400V1',null);if(!force&&prior&&prior.complete===true)return {skipped:true,normalizedImages:0,normalizedRecords:0,failedImages:0};const state={normalizedImages:0,normalizedRecords:0,failedImages:0,lastError:''};for(const kind of ['customer','contact','file','listing']){for(const row of await recordsOf(kind)){const original=row.record,next={...original},memo=new Map();let changed=false;for(const key of INLINE_IMAGE_FIELDS){if(!(key in next))continue;const normalized=await normalizeNestedImageValue(next[key],memo,state);if(normalized!==next[key]){next[key]=normalized;changed=true;}}if(changed){try{const latest=await recordById(kind,original.id);if(!latest)continue;const safeNext={...latest};let applicable=false;for(const key of INLINE_IMAGE_FIELDS){if(next[key]!==original[key]&&JSON.stringify(latest[key])===JSON.stringify(original[key])){safeNext[key]=next[key];applicable=true;}}if(applicable){await storeRecord(kind,safeNext);state.normalizedRecords++;}}catch(error){state.failedImages++;state.lastError=String(error&&error.message||error).slice(0,160);}}}}await setMetaObj('imageNormalization400V1',{version:1,complete:state.failedImages===0,checkedAt:Date.now(),normalizedImages:state.normalizedImages,normalizedRecords:state.normalizedRecords,failedImages:state.failedImages,lastError:state.lastError});return state;}
async function saveFile(e){e.preventDefault();if(!cryptoKey)return;updateHvacChoiceValue('fileHeatingChoice','fileHeating','fileHeatingOther');updateHvacChoiceValue('fileCoolingChoice','fileCooling','fileCoolingOther');$('fileRooms').value=selectedBedroomCount();const name=clean($('fileName').value,120),phone=phoneNorm($('filePhone').value),tx=document.querySelector('input[name="fileTransaction"]:checked')?.value||'',property=$('fileProperty').value; if(name.length<3||/\d/u.test(name)){setStatus('fileStatus','نام مالک یا رابط را درست وارد کنید.','error');return}if(!phone){setStatus('fileStatus','شمارهٔ تماس معتبر وارد کنید.','error');return}if(!tx||!property){setStatus('fileStatus','نوع معامله و نوع ملک را انتخاب کنید.','error');return}if(!$('fileConfirm').checked){setStatus('fileStatus','تأیید صحت و مجازبودن ثبت فایل را علامت بزنید.','error');return}const title=clean($('fileTitle').value,200),neighborhood=clean($('fileNeighborhood').value,120),street=clean($('fileStreet').value,160),area=money($('fileArea').value),editId=$('fileEditId').value,all=(await recordsOf('file')).map(x=>x.record);let old=all.find(x=>String(x.id)===editId);const now=Date.now();const typedTitle=title||((property==='land'?'زمین':property==='villa'?'ملک ویلایی':property==='commercial'?'ملک تجاری':'ملک')+' '+(tx==='sale'?'برای فروش':'برای اجاره')+(neighborhood?' در '+neighborhood:''));const dedupe=[phone,tx,property,normalizeText(neighborhood),area,normalizeText(street),normalizeText(typedTitle)].join('|');if(!old)old=all.find(x=>String(x.dedupeKey||fileSignature(x))===dedupe)||null;let photos=Array.isArray(old?.imageDataUrls)?old.imageDataUrls.slice(0,3):[];const chosen=[...(quickEntryMode?quickEntryStagedFiles:[]),...($('filePhotos').files||[])].filter((file,index,list)=>list.indexOf(file)===index);if(chosen.length>3){setStatus('fileStatus','حداکثر سه عکس انتخاب کنید.','error');return}if(chosen.length){setStatus('fileStatus','در حال فشرده‌سازی عکس‌ها روی گوشی…');$('saveFile').disabled=true;try{photos=[];let total=0;for(const f of chosen){const data=await compressImage(f);total+=Math.ceil(data.length*.75);if(total>1900000)throw new Error('حجم مجموع عکس‌ها باید کمتر از ۱٫۹ مگابایت باشد؛ عکس‌های کمتری انتخاب کنید.');photos.push(data)}}catch(err){$('saveFile').disabled=false;setStatus('fileStatus',err.message||'فشرده‌سازی عکس ناموفق بود.','error');return}$('saveFile').disabled=false;}
const id=old?.id||('MOBFILE-'+uuid().slice(0,16).toUpperCase()),city='نیشابور',location=[city,neighborhood].filter(Boolean).join('، '),builtArea=property==='villa'?money($('fileBuiltArea').value):'',salePrice=tx==='sale'?money($('fileSalePrice').value):'',deposit=tx==='rent'?money($('fileDeposit').value):'',monthlyRent=tx==='rent'?money($('fileMonthlyRent').value):'',pricePerMeter=tx==='sale'?money($('filePricePerMeter').value):'',rooms=property==='villa'?selectedBedroomCount():'',year=property==='villa'?digits($('fileYear').value):'',landUse=property==='land'?clean($('fileLandUse').value,80):'',frontage=property!=='villa'?money($('fileFrontage').value):'',commercialKind=property==='commercial'?clean($('fileCommercialKind').value,100):'',commercialUse=property==='commercial'?clean($('fileCommercialUse').value,100):'',kitchen=property==='villa'?clean($('fileKitchen').value,60):'',flooring=property==='villa'?clean($('fileFlooring').value,60):'',heating=property==='villa'?clean($('fileHeating').value,80):'',cooling=property==='villa'?clean($('fileCooling').value,80):'',convertible=tx==='rent'?$('fileConvertible').value:'unknown',amenities=clean($('fileAmenities').value,250),notes=clean($('fileNotes').value,900);
const defaultTitle=typedTitle;const finalTitle=title||defaultTitle;if(/(?:\+?98|0098)?0?9[\d\s().-]{8,}/u.test(finalTitle)){setStatus('fileStatus','عنوان فایل نباید شمارهٔ تماس داشته باشد.','error');return}const details=[finalTitle,tx==='sale'&&salePrice?'قیمت کل: '+salePrice+' تومان':'',tx==='sale'&&pricePerMeter?'قیمت هر متر: '+pricePerMeter+' تومان':'',tx==='rent'&&deposit?'ودیعه: '+deposit+' تومان':'',tx==='rent'&&monthlyRent?'اجاره ماهانه: '+monthlyRent+' تومان':'',location?'موقعیت: '+location:'',street?'خیابان: '+street:'',area?'متراژ: '+area+' مترمربع':'',builtArea?'زیربنا: '+builtArea+' مترمربع':'',(property==='villa'&&String(rooms)==='0')?'خواب: بدون خواب':(rooms&&Number(rooms)>0?'خواب: '+rooms:''),year?'سال ساخت: '+year:'',landUse?'کاربری زمین: '+landUse:'',frontage?'عرض بر: '+frontage+' متر':'',commercialUse?'کاربری تجاری: '+commercialUse:'',kitchen?'کابینت: '+kitchen:'',flooring?'کف: '+flooring:'',heating?'گرمایش: '+heating:'',cooling?'سرمایش: '+cooling:'',amenities?'امکانات: '+amenities:'',notes?'توضیحات: '+notes:''].filter(Boolean);const detailText=details.join('\n');const propLabel=property==='land'?'زمین/باغ':property==='villa'?'ویلا':'تجاری';const rec={...(old||{}),id,record_uuid:id,code:old?.code||('FILE-'+uuid().slice(0,8).toUpperCase()),title:finalTitle,detailText,text:detailText,publicDescription:detailText,description:detailText,transactionType:tx,officeTransactionType:tx,propertyType:propLabel,officePropertyType:property,city,neighborhood,street,location,area_sqm:area,landArea:property==='land'?area:'',buildingArea:property==='villa'?builtArea:area,salePrice,deposit,monthlyRent,pricePerMeter,rooms,year,landUse,deed:clean($('fileDeed').value,100),access:clean($('fileAccess').value,120),frontage,commercialKind,commercialUse,kitchen,flooring,heating,cooling,convertible:convertible==='yes'?true:convertible==='no'?false:null,amenities:amenities?amenities.split(/[،,]/).map(x=>clean(x,30)).filter(Boolean).slice(0,20):[],amenitiesJson:JSON.stringify(amenities?amenities.split(/[،,]/).map(x=>clean(x,30)).filter(Boolean).slice(0,20):[]),phone,customerPhone:phone,ownerName:name,customerName:name,source:'office-file',sourceLabel:'ثبت از برنامک موبایل',status:'archived',sendStatus:'not_sent',createdAt:Number(old?.createdAt)||now,updatedAt:now,archivedAt:now,imagesProvided:photos.length,imageDataUrls:photos,imageUrls:photos,dedupeKey:dedupe};await storeRecord('file',rec);clearFileForm();$('fileForm').classList.add('hidden');if(quickEntryMode){quickEntryStagedFiles=[];setStatus('quickMediaStatus','عکس به پروندهٔ فایل ذخیره شد.');finishQuickEntrySave('file',old?'پروندهٔ فایل به‌روزرسانی شد و عکس‌ها ذخیره شدند.':'فایل و عکس‌های انتخاب‌شده در دفتر محلی ذخیره شدند.');return;}setStatus('storageStatus',old?'پروندهٔ فایل روی گوشی به‌روزرسانی شد.':'فایل ملک روی گوشی ثبت شد؛ انتشار خودکار انجام نمی‌شود.','success');await renderFiles();await renderDashboardHighlights();}
$('fileForm').addEventListener('submit',saveFile);
async function createTombstone(kind,id){const tomb={id:kind+':'+id,kind,recordId:String(id),deletedAt:Date.now()};await storeRecord('tombstone',tomb);const all=await getMetaObj('aliases',{});delete all[kind+':'+id];await setMetaObj('aliases',all);}
async function deleteLocalRecord(kind,id){const rec=await recordById(kind,id);if(!rec)return;if(!confirm('این رکورد از حافظهٔ همین گوشی حذف و حذف آن در همگام‌سازی بعدی به افزونه منتقل شود؟'))return;await createTombstone(kind,id);await removeRecord(kind,id);if(['customer','file','listing'].includes(kind))await removeRecord('office',officeRecordId(kind,id));if(kind==='customer')for(const row of await recordsOf('followup'))if(String(row.record.customerId)===String(id))await removeRecord('followup',row.record.id);await renderAll();}
function tag(text,extraClass=''){const x=document.createElement('span');x.className='tag'+(extraClass?' '+extraClass:'');x.textContent=text;return x}
function phoneLinksElement(value,label='تماس با شماره'){const phones=listingPhoneItems({phone:value});if(!phones.length)return null;const wrap=document.createElement('span');wrap.className='listing-phone-links';for(const p of phones){const a=document.createElement('a');a.href=telHref(p.tel);a.dir='ltr';a.textContent=p.text;a.setAttribute('aria-label',label+' '+p.text);a.setAttribute('data-phone-link','true');wrap.append(a)}return wrap}
function parseRecordTimestamp(value){
 if(value===undefined||value===null||value==='')return 0;
 if(typeof value==='number'||/^\d{10,13}$/.test(String(value).trim())){let n=Number(value);if(n>0&&n<1e12)n*=1000;return Number.isFinite(n)&&n>0?n:0;}
 const parsed=Date.parse(String(value));return Number.isFinite(parsed)&&parsed>0?parsed:0;
}
function recordCreatedTimestamp(record){
 // Only fields that represent record creation/first registration. Never fall back to updatedAt.
 for(const key of ['createdAt','created_at_ms','created_at','createdDate','created_date','dateCreated','firstSeenAt','first_seen_at','collectedAt','collected_at','submittedAt','submitted_at']){const value=parseRecordTimestamp(record?.[key]);if(value)return value;}
 return 0;
}
function recordLastActionTimestamp(record,kind){
 const keys=kind==='customer'
  ? ['lastContactAt','lastContactedAt','last_contact_at','last_contacted_at','lastCallAt','last_call_at','lastPhoneCallAt']
  : ['lastFollowUpAt','lastFollowupAt','last_follow_up_at','last_followup_at','lastContactAt','last_contact_at','lastCallAt','last_call_at'];
 for(const key of keys){const value=parseRecordTimestamp(record?.[key]);if(value)return value;}return 0;
}
function recordTimeLabel(value,missingLabel){const timestamp=parseRecordTimestamp(value);return timestamp?localDateLabel(timestamp):missingLabel;}
function customerRequestSummary(record){
 const parts=[record?.type==='tenant'?'مستأجر':'خریدار'];
 const property=canonicalCustomerProperty(record?.propertyType||'');if(property)parts.push(property);
 if(record?.type==='tenant'){
  const moneyParts=[];if(record.deposit)moneyParts.push('رهن '+shortDisplayMoney(record.deposit));if(record.rent)moneyParts.push('اجاره '+shortDisplayMoney(record.rent));if(moneyParts.length)parts.push(moneyParts.join(' / '));
 }else if(record?.min||record?.max){const budget=(record.min?'از '+shortDisplayMoney(record.min):'')+(record.min&&record.max?' تا ':'')+(record.max?shortDisplayMoney(record.max):'');if(budget)parts.push('بودجه '+budget);}
 return parts.join(' · ');
}
async function persistCallAction(kind,id,phone){
 if(!['customer','file','listing'].includes(String(kind)))throw new Error('نوع پرونده برای ثبت زمان تماس معتبر نیست.');
 const current=await recordById(String(kind),String(id));if(!current)throw new Error('پروندهٔ مرتبط با این شماره پیدا نشد؛ زمان تماس ثبت نشد.');
 const now=Date.now(),field=kind==='customer'?'lastContactAt':'lastFollowUpAt';
 // Keep createdAt unchanged: call time and record creation time are separate fields.
 await storeRecord(String(kind),{...current,[field]:now,updatedAt:now});
 if(current.qoqnusSpecial&&['customer','file'].includes(String(kind))&&typeof renderDashboardHighlights==='function')await renderDashboardHighlights();
 return now;
}
function createCallControl(value, label='تماس', tracking=null){
  // Accept either a phone value or the full listing record. Passing a record
  // directly preserves ownerPhone/sellerPhone/contactPhone variants.
  const phones=listingPhoneItems(value && typeof value==='object' ? value : {phone:value}), phone=phones[0];
 const node=document.createElement(phone?'a':'button');
 node.className='qoqnus-call-icon';node.setAttribute('aria-label',phone?label:'شماره تماس ثبت نشده');node.title=phone?label:'شماره تماس ثبت نشده';
 if(phone){node.href=telHref(phone.tel);node.dir='ltr';node.setAttribute('data-phone-link','true');}
 else {node.type='button';node.disabled=true;}
 node.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.32.56 3.58.56a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.26.19 2.46.56 3.58a1 1 0 0 1-.24 1.02z"/></svg>';
 if(phone&&tracking&&['customer','file','listing'].includes(String(tracking.kind))&&String(tracking.id||'')){
  node.addEventListener('click',event=>{
   event.preventDefault();if(node.dataset.qoqnusCallBusy==='1')return;node.dataset.qoqnusCallBusy='1';
   const href=node.href,kind=String(tracking.kind),id=String(tracking.id);
   void (async()=>{
    try{
     const at=await persistCallAction(kind,id,phone.tel);
     if(kind==='customer')await renderCustomers();else if(kind==='file')await renderFiles();else await renderListings();
     setStatus('storageStatus',(kind==='customer'?'زمان آخرین تماس مشتری': 'زمان آخرین پیگیری '+(kind==='file'?'فایل':'آگهی'))+' در '+localDateLabel(at)+' ذخیره شد. این زمان، زمان لمس دکمه و آغاز مسیر تماس است؛ نه تأیید برقراری مکالمه.','success');
    }catch(error){setStatus('storageStatus',error?.message||'ثبت زمان تماس ناموفق بود؛ تماس همچنان باز می‌شود.','error');}
    finally{delete node.dataset.qoqnusCallBusy;window.location.href=href;}
   })();
  });
 }
 return node;
}
function appendPhoneFact(container,label,value){const links=createCallControl(value,label);const item=document.createElement('span');item.className='office-file-fact office-file-phone-fact';const b=document.createElement('b');b.textContent=label;item.append(b,links);container.append(item)}
async function createRecordCallControl(record,kind,id,label='تماس'){const tracking={kind:String(kind),id:String(id)};const direct=listingPhoneItems(record);if(direct.length)return createCallControl(record,label,tracking);let office=null;try{office=await recordById('office',officeRecordId(kind,id));}catch{}const privatePhones=(Array.isArray(office?.contacts)?office.contacts:[]).map(c=>normalizeDialPhone(c?.phone)).filter(Boolean);if(privatePhones.length)return createCallControl({phones:privatePhones},label,tracking);return createCallControl(record,label,tracking)}
async function refreshListingCallControlsAfterOfficeSave(kind,id){if(kind!=='listing')return;const record=await recordById('listing',id);if(!record)return;const card=[...document.querySelectorAll('[data-listing-card-id]')].find(node=>String(node.dataset.listingCardId)===String(id));if(!card)return;for(const old of card.querySelectorAll('.qoqnus-action-call,.qoqnus-detail-call-control')){const label=old.getAttribute('aria-label')||'تماس با مالک';const replacement=await createRecordCallControl(record,'listing',id,label);if(old.classList.contains('qoqnus-action-call'))replacement.classList.add('qoqnus-action-call');if(old.classList.contains('qoqnus-detail-call-control'))replacement.classList.add('qoqnus-detail-call-control');old.replaceWith(replacement);}const tbody=card.querySelector('.listing-details-table tbody');if(tbody){let phoneRow=[...tbody.querySelectorAll('tr')].find(tr=>tr.querySelector('th')?.textContent?.trim()==='شماره تماس');const control=await createRecordCallControl(record,'listing',id,'تماس با مالک');if(control.tagName==='A'){control.classList.add('qoqnus-detail-call-control');if(!phoneRow){phoneRow=document.createElement('tr');const th=document.createElement('th');th.scope='row';th.textContent='شماره تماس';const td=document.createElement('td');phoneRow.append(th,td);tbody.insertBefore(phoneRow,tbody.firstChild);}phoneRow.querySelector('td')?.replaceChildren(control);}else if(phoneRow){phoneRow.remove();}}}
function shortDisplayMoney(value){return compactSummaryMoney(value).replace(/\s*(?:تومان|ریال)\s*/g,' ').trim();}
function positiveFeature(value){if(value===true)return true;if(value===false||value===null||value===undefined)return false;const v=normalizeText(value);if(!v||/^(?:خیر|ندارد|ندارم|نه|false|no|0|نامشخص|ثبت نشده|—|-)$/.test(v))return false;return /^(?:بله|دارد|yes|true|1|پارکینگ|انباری|آسانسور)$/i.test(v)||/^(?:بله|دارد|yes|true|1)\b/i.test(v);}
function compactFeatureList(r){const f=r?.facts&&typeof r.facts==='object'?r.facts:{};const out=[],add=(v)=>{if(Array.isArray(v)){v.forEach(add);return;}if(typeof v!=='string')return;for(const x of v.split(/[،,;|\n]+/)){const text=clean(x,80);if(!text)continue;const n=normalizeText(text);if(!out.some(y=>normalizeText(y)===n))out.push(text);}};
 const flags=[['parking','پارکینگ'],['storage','انباری'],['storeRoom','انباری'],['elevator','آسانسور']];for(const [key,label] of flags){if(positiveFeature(r?.[key]??f[key]))add(label)}
 const kitchen=firstText(r?.kitchen,f.kitchen);if(kitchen&&!/^(?:خیر|ندارد|نامشخص)$/i.test(kitchen))add(/کابینت/.test(kitchen)?kitchen:'کابینت '+kitchen);
 const flooring=firstText(r?.flooring,f.flooring);if(flooring&&!/^(?:خیر|ندارد|نامشخص)$/i.test(flooring))add(/کف/.test(flooring)?flooring:'کف '+flooring);
 const heating=firstText(r?.heating,f.heating);if(heating&&!/^(?:خیر|ندارد|نامشخص)$/i.test(heating))add(/بخاری|پکیج|شوفاژ|گرمایش/.test(heating)?heating:'گرمایش '+heating);
 const cooling=firstText(r?.cooling,f.cooling);if(cooling&&!/^(?:خیر|ندارد|نامشخص)$/i.test(cooling))add(/کولر|سرمایش/.test(cooling)?cooling:'سرمایش '+cooling);
 add(r?.amenities);add(f.amenities);return out.slice(0,7);
}
function inlineFactsLine(values,className){const cleanValues=[];for(const raw of (values||[])){const value=String(raw||'').trim();if(!value||value==='—'||value==='-')continue;const n=normalizeText(value);if(cleanValues.some(prev=>{const p=normalizeText(prev);return p===n||(n.length>3&&p.includes(n))}))continue;cleanValues.push(value)}const line=document.createElement('div');line.className=className;cleanValues.forEach((value,i)=>{if(i){const sep=document.createElement('span');sep.className='qoqnus-fact-separator';sep.textContent='|';line.append(sep)}const item=document.createElement('span');item.textContent=maskPhoneNumbersInText(value);line.append(item)});line.hidden=!cleanValues.length;return line;}
function formattedDate(value){const n=Number(value)||Date.parse(String(value||''))||Date.now();return new Date(n).toLocaleDateString('fa-IR');}
function recordPhotoSources(r,max=3){const out=[],seen=new Set();const add=v=>{if(typeof v==='string'){const raw=v.trim();if(!raw)return;const ok=/^data:image\/(?:jpeg|jpg|png|webp|gif);base64,/i.test(raw)?raw:safeHttpUrl(raw);if(ok&&!seen.has(ok)){seen.add(ok);out.push(ok)}return}if(Array.isArray(v)){v.forEach(add);return}if(v&&typeof v==='object'){for(const k of ['dataUrl','data_url','src','url','href','thumbnailUrl','imageUrl','photoUrl','originalUrl'])if(v[k])add(v[k])}};
 for(const k of ['imageDataUrls','localImageDataUrls','photoDataUrls','localPhotos','imageDataUrl','image_data_url','photoDataUrl','thumbnailDataUrl','thumbnail_data_url','imageUrls','imageUrl','image_url','photos','pictures','images','image','photoUrls','photoUrl','thumbnailUrl'])add(r?.[k]);return out.slice(0,max);}
function setImageFallback(img){if(!img)return;img.onerror=()=>{if(img.dataset.qoqnusFallback==='1')return;img.dataset.qoqnusFallback='1';img.onerror=null;img.src=DEFAULT_RECORD_IMAGE;};}
function renderPhotoGallery(r,title,alwaysPlaceholder=false){
 const sources=recordPhotoSources(r,3),gallery=document.createElement('div');gallery.className='qoqnus-photo-gallery';
 if(!sources.length){gallery.classList.add('qoqnus-photo-gallery--single','qoqnus-photo-gallery--placeholder');const empty=document.createElement('div');empty.className='qoqnus-photo-empty';const image=document.createElement('img');image.src=DEFAULT_RECORD_IMAGE;image.alt='تصویر پیش‌فرض ققنوس';image.loading='lazy';image.decoding='async';setImageFallback(image);empty.append(image);gallery.append(empty);return gallery;}
 gallery.classList.add(sources.length>1?'qoqnus-photo-gallery--multiple':'qoqnus-photo-gallery--single');
 const main=document.createElement('a');main.className='qoqnus-photo-main';main.href=sources[0];main.target='_blank';main.rel='noopener noreferrer';main.setAttribute('aria-label','نمایش عکس '+title);
 const img=document.createElement('img');img.src=sources[0];img.alt='عکس '+title;img.loading='lazy';img.decoding='async';img.referrerPolicy='no-referrer';setImageFallback(img);main.append(img);
 const count=document.createElement('span');count.className='qoqnus-photo-count';count.textContent='عکس '+String(sources.length).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)])+' از '+String(Math.max(Number(r.imagesProvided)||sources.length,sources.length)).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);main.append(count);gallery.append(main);
 if(sources.length>1){const strip=document.createElement('div');strip.className='qoqnus-photo-strip';for(const source of sources.slice(1)){const link=document.createElement('a');link.href=source;link.target='_blank';link.rel='noopener noreferrer';link.setAttribute('aria-label','نمایش عکس '+title);const small=document.createElement('img');small.src=source;small.alt='';small.loading='lazy';small.decoding='async';small.referrerPolicy='no-referrer';setImageFallback(small);link.append(small);strip.append(link)}gallery.append(strip)}return gallery;
}
function addButton(label,kind,handler,aria){const b=document.createElement('button');b.type='button';b.className='qoqnus-action-button '+(kind||'');b.textContent=label;if(aria)b.setAttribute('aria-label',aria);b.addEventListener('click',handler);return b;}
function officeRecordId(kind,id){return String(kind)+'::'+String(id)}
function canonicalOfficePhone(value){return normalizeDialPhone(value)}
function appendOfficePrivateEditor(container,kind,id){const panel=document.createElement('details');panel.className='office-private-panel';panel.dataset.officeEditor=officeRecordId(kind,id);const summary=document.createElement('summary');summary.innerHTML='<span class="office-private-title">دفتر املاک <span class="office-private-badge">خصوصی</span></span><span class="office-private-chevron">⌄</span>';panel.append(summary);const body=document.createElement('div');body.className='office-private-body';const hint=document.createElement('p');hint.className='hint';hint.textContent='شماره‌های هماهنگی و یادداشت‌های این پرونده فقط در حافظهٔ رمزگذاری‌شدهٔ همین گوشی نگهداری می‌شوند.';body.append(hint);const status=document.createElement('p');status.className='status office-private-status';status.setAttribute('aria-live','polite');body.append(status);const editor=document.createElement('div');editor.className='office-editor-content';body.append(editor);panel.append(body);panel.addEventListener('toggle',()=>{if(panel.open&&!panel.dataset.loaded){panel.dataset.loaded='1';renderOfficeEditor(editor,kind,id,status).catch(e=>{status.textContent=e?.message||'بازکردن دفتر املاک ناموفق بود.';panel.dataset.loaded='';});}});container.append(panel);}
async function renderOfficeEditor(root,kind,id,status){root.replaceChildren();const saved=await recordById('office',officeRecordId(kind,id))||{id:officeRecordId(kind,id),targetKind:kind,targetId:String(id),contacts:[],notes:[]};const contacts=Array.isArray(saved.contacts)?saved.contacts:[],notes=Array.isArray(saved.notes)?saved.notes:[];const section=(title,desc)=>{const box=document.createElement('section');box.className='office-editor-section';const h=document.createElement('h4');h.textContent=title;box.append(h);if(desc){const p=document.createElement('p');p.className='hint';p.textContent=desc;box.append(p);}root.append(box);return box;};const contactsBox=section('شماره‌های تماس هماهنگی','برای مثال: مستأجر فعلی، مالک، سرایدار یا رابط بازدید.');const contactsList=document.createElement('div');contactsList.className='office-contact-rows';contactsBox.append(contactsList);const addContactRow=item=>{const row=document.createElement('div');row.className='office-contact-row';const role=document.createElement('select');role.setAttribute('aria-label','نقش مخاطب');for(const [v,t] of [['مالک','مالک'],['مستأجر','مستأجر'],['سرایدار','سرایدار'],['رابط بازدید','رابط بازدید'],['سایر','سایر']]){const o=document.createElement('option');o.value=v;o.textContent=t;role.append(o);}role.value=item?.role||'مستأجر';const name=document.createElement('input');name.placeholder='نام مخاطب';name.maxLength=100;name.value=item?.name||'';name.setAttribute('aria-label','نام مخاطب');const phone=document.createElement('input');phone.type='tel';phone.inputMode='tel';phone.placeholder='شماره تماس';phone.maxLength=24;phone.value=item?.phone||'';phone.setAttribute('aria-label','شماره تماس');const phoneWrap=document.createElement('div');phoneWrap.className='office-contact-phone-wrap';const callSlot=document.createElement('span');callSlot.className='office-contact-call-slot';const updateContactCall=()=>{callSlot.replaceChildren();const normalized=canonicalOfficePhone(phone.value);if(!normalized)return;const call=createCallControl({phone:normalized},'تماس با '+(name.value.trim()||role.value),{kind,id});call.classList.add('office-contact-call');callSlot.append(call);};phone.addEventListener('input',updateContactCall);name.addEventListener('input',updateContactCall);role.addEventListener('change',updateContactCall);phoneWrap.append(phone,callSlot);const del=document.createElement('button');del.type='button';del.className='outline office-remove-button';del.textContent='حذف';del.addEventListener('click',()=>row.remove());row.append(role,name,phoneWrap,del);contactsList.append(row);updateContactCall();};contacts.forEach(addContactRow);const addContact=document.createElement('button');addContact.type='button';addContact.className='outline office-add-button';addContact.textContent='+ افزودن شماره تماس';addContact.addEventListener('click',()=>addContactRow({role:'مستأجر'}));contactsBox.append(addContact);const notesBox=section('یادداشت‌های اختصاصی','مثل حداقل قیمت مورد قبول مالک، زمان مجاز بازدید یا نکتهٔ مهم معامله.');const noteList=document.createElement('div');noteList.className='office-note-rows';notesBox.append(noteList);const addNoteRow=item=>{const row=document.createElement('div');row.className='office-note-row';row.dataset.createdAt=String(Number(item?.createdAt)||Date.now());row.dataset.id=String(item?.id||uuid());const head=document.createElement('div');head.className='office-note-row-head';const date=document.createElement('small');date.textContent=item?.createdAt?localDateLabel(item.createdAt):'یادداشت جدید';const del=document.createElement('button');del.type='button';del.className='link-button';del.textContent='حذف یادداشت';del.addEventListener('click',()=>row.remove());head.append(date,del);const textarea=document.createElement('textarea');textarea.rows=2;textarea.maxLength=1000;textarea.placeholder='یادداشت خصوصی…';textarea.value=item?.text||'';row.append(head,textarea);noteList.append(row);};notes.forEach(addNoteRow);const addNote=document.createElement('button');addNote.type='button';addNote.className='outline office-add-button';addNote.textContent='+ افزودن یادداشت';addNote.addEventListener('click',()=>addNoteRow({createdAt:Date.now(),text:''}));notesBox.append(addNote);const save=document.createElement('button');save.type='button';save.className='primary full office-save-button';save.textContent='ذخیرهٔ اطلاعات خصوصی';save.addEventListener('click',async()=>{save.disabled=true;try{const nextContacts=[];for(const row of contactsList.querySelectorAll('.office-contact-row')){const role=row.querySelector('select').value,name=clean(row.querySelector('input[aria-label="نام مخاطب"]').value,100),raw=row.querySelector('input[aria-label="شماره تماس"]').value.trim(),phone=canonicalOfficePhone(raw);if(!name&&!raw)continue;if(raw&&!phone)throw new Error('یکی از شماره‌های تماس معتبر نیست.');if(!name)throw new Error('برای شمارهٔ تماس، نام مخاطب را هم بنویس.');nextContacts.push({role,name,phone,updatedAt:Date.now()});}const nextNotes=[...noteList.querySelectorAll('.office-note-row')].map(row=>({id:row.dataset.id||uuid(),createdAt:Number(row.dataset.createdAt)||Date.now(),text:clean(row.querySelector('textarea').value,1000)})).filter(x=>x.text);const record={...saved,id:officeRecordId(kind,id),targetKind:kind,targetId:String(id),contacts:nextContacts,notes:nextNotes,updatedAt:Date.now(),createdAt:Number(saved.createdAt)||Date.now()};await storeRecord('office',record);await refreshListingCallControlsAfterOfficeSave(kind,id);status.textContent='اطلاعات دفتر املاک روی همین گوشی ذخیره شد.';status.className='status office-private-status success';}catch(e){status.textContent=e?.message||'ذخیره ناموفق بود.';status.className='status office-private-status error';}finally{save.disabled=false;}});root.append(save);}
function appendCustomerFollowupPanel(container,id,customer){const panel=document.createElement('details');panel.className='customer-followup-panel';panel.dataset.customerFollowups=String(id);const summary=document.createElement('summary');summary.innerHTML='<span>سوابق پیگیری مشتری</span><span class="office-private-chevron">⌄</span>';panel.append(summary);const body=document.createElement('div');body.className='customer-followup-body';const hint=document.createElement('p');hint.className='hint';hint.textContent='یادداشت پیگیری اختیاری است؛ همهٔ گزارش‌ها با تاریخ در پروندهٔ همین مشتری ذخیره می‌شوند.';body.append(hint);const history=document.createElement('div');history.className='customer-followup-history';body.append(history);const input=document.createElement('textarea');input.rows=3;input.maxLength=1000;input.placeholder='امروز برای این مشتری چه کاری انجام شد؟';body.append(input);const status=document.createElement('p');status.className='status';status.setAttribute('aria-live','polite');body.append(status);const save=document.createElement('button');save.type='button';save.className='primary full';save.textContent='ثبت گزارش پیگیری';save.addEventListener('click',async()=>{const note=clean(input.value,1000);if(!note){status.textContent='برای ثبت گزارش، یک شرح کوتاه بنویس؛ ثبت اجباری نیست.';return;}const today=localDateKey();await storeRecord('followup',{id:'FUP-'+String(id)+'-'+uuid(),customerId:String(id),customerName:clean(customer.name,120),dateKey:today,note,createdAt:Date.now(),updatedAt:Date.now()});input.value='';status.textContent='گزارش پیگیری ثبت شد.';await renderCustomerFollowupHistory(history,id);await ensureDailyCustomerFollowupNotifications(true);await renderNotifications();});body.append(save);panel.append(body);panel.addEventListener('toggle',()=>{if(panel.open)renderCustomerFollowupHistory(history,id).catch(e=>{status.textContent=e?.message||'خواندن سوابق ناموفق بود.';});});container.append(panel);}
function localDateLabel(value){
 const timestamp=typeof value==='number'?value:parseRecordTimestamp(value);
 if(!Number.isFinite(timestamp)||timestamp<=0)return 'تاریخ نامشخص';
 const date=new Date(timestamp);
 try{return new Intl.DateTimeFormat('fa-IR-u-ca-persian',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(date);}catch{return new Intl.DateTimeFormat('fa-IR',{timeZone:'Asia/Tehran',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(date);}
}
function localDateKey(value=Date.now()){return window.QoqnusTimeGrouping?.dateKey(Number(value)||Date.now())||''}
async function renderCustomerFollowupHistory(container,customerId){const rows=(await recordsOf('followup')).map(x=>x.record).filter(r=>String(r.customerId)===String(customerId)).sort((a,b)=>(Number(b.createdAt)||0)-(Number(a.createdAt)||0));container.replaceChildren();if(!rows.length){container.append(emptyBox('هنوز گزارشی برای این مشتری ثبت نشده است.'));return;}for(const r of rows){const card=document.createElement('article');card.className='customer-followup-entry';const time=document.createElement('time');time.textContent=localDateLabel(r.createdAt);const text=document.createElement('p');text.textContent=String(r.note||'');const del=document.createElement('button');del.type='button';del.className='link-button';del.textContent='حذف گزارش';del.addEventListener('click',async()=>{if(!confirm('این گزارش پیگیری حذف شود؟'))return;await removeRecord('followup',r.id);await renderCustomerFollowupHistory(container,customerId);});card.append(time,text,del);container.append(card);}}
async function ensureDailyCustomerFollowupNotifications(force=false){if(!cryptoKey)return;const today=localDateKey();if(!force&&dailyReminderCheckedDate===today)return;dailyReminderCheckedDate=today;const customers=(await recordsOf('customer')).map(x=>x.record),followups=(await recordsOf('followup')).map(x=>x.record),notices=(await recordsOf('notice')).map(x=>x.record);for(const customer of customers){const id=String(customer.id||'');if(!id)continue;if(['purchased','rented'].includes(String(customer.status||''))){for(const old of notices)if(old.type==='customer-followup'&&String(old.recordId)===id&&!Number(old.readAt))await storeRecord('notice',{...old,readAt:Date.now()});continue;}const todayReport=followups.some(r=>String(r.customerId)===id&&String(r.dateKey||localDateKey(r.createdAt))===today);const todayNoticeId='customer-followup-'+id+'-'+today;const existing=notices.find(n=>String(n.id)===todayNoticeId);if(todayReport){if(existing&&!Number(existing.readAt))await storeRecord('notice',{...existing,readAt:Date.now()});continue;}for(const old of notices){if(old.type==='customer-followup'&&String(old.recordId)===id&&!Number(old.readAt)&&String(old.id)!==todayNoticeId)await storeRecord('notice',{...old,readAt:Date.now()});}if(!existing)await saveLocalNotification(todayNoticeId,'customer-followup','پیگیری امروز: '+clean(customer.name,100),'امروز برای این مشتری چه کاری انجام دادی؟ با لمس اعلان، پرونده و سوابق پیگیری باز می‌شود.',{recordKind:'customer',recordId:id,customerId:id,dateKey:today});}const [fileRows,listingRows]=await Promise.all([recordsOf('file'),recordsOf('listing')]);if(fileRows.length||listingRows.length){const reviewId='file-review-'+today;if(!notices.some(n=>String(n.id)===reviewId))await saveLocalNotification(reviewId,'file-review','یادآوری روزانه: بررسی فایل‌ها','قیمت، وضعیت فعال بودن فایل و شماره‌های تماس را بررسی و اطلاعات تغییرکرده را به‌روز کن.',{recordKind:'file',recordId:'',dateKey:today});}const syncReminderId='sync-review-'+today,lastSuccess=Number(await getMetaObj('lastSuccessfulSyncAt',0))||0,syncReminder=await recordById('notice',syncReminderId),pairedForSync=!!(await centralConfig().catch(()=>null));if(lastSuccess>0&&lastSuccess<=Date.now()&&Date.now()-lastSuccess<24*60*60*1000){if(syncReminder&&!Number(syncReminder.readAt))await storeRecord('notice',{...syncReminder,readAt:Date.now()});}else if(pairedForSync&&!syncReminder)await saveLocalNotification(syncReminderId,'daily-sync-reminder','یادآوری روزانهٔ همگام‌سازی','همگام‌سازی فایل‌های جدید را بررسی کنید.',{recordKind:'sync',recordId:'',dateKey:today});}
function makeCustomerPhotoElement(record,size='thumb'){const wrap=document.createElement('div');wrap.className='qoqnus-customer-photo qoqnus-customer-photo--'+size;const img=document.createElement('img');img.src=customerPhotoValue(record)||DEFAULT_RECORD_IMAGE;img.alt=customerPhotoValue(record)?'تصویر '+String(record.name||'مشتری'):'تصویر پیش‌فرض مشتری';img.loading='lazy';img.decoding='async';setImageFallback(img);wrap.append(img);return wrap;}
function openCustomerPhoto(record){const url=customerPhotoValue(record);if(!url)return;const dialog=document.createElement('dialog');dialog.className='customer-photo-dialog';dialog.setAttribute('aria-label','تصویر مشتری '+String(record.name||''));const img=document.createElement('img');img.src=url;img.alt='تصویر '+String(record.name||'مشتری');setImageFallback(img);const close=document.createElement('button');close.type='button';close.className='primary full';close.textContent='بستن تصویر';close.addEventListener('click',()=>dialog.close());dialog.append(img,close);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove(),{once:true});dialog.showModal();}
function renderCustomerCard(r,id){
 const art=document.createElement('article');art.className='record-card qoqnus-customer-card';art.dataset.customerCardId=String(id);
 const top=document.createElement('div');top.className='qoqnus-customer-head qoqnus-record-summary-head';
 const avatar=makeCustomerPhotoElement(r,'thumb');const who=document.createElement('div');who.className='qoqnus-customer-identity';
 const h=document.createElement('h3');h.className='qoqnus-customer-name';h.textContent=maskPhoneNumbersInText(r.name||'بدون نام');who.append(h);
 const request=document.createElement('span');request.className='qoqnus-customer-request';request.textContent=customerRequestSummary(r);who.append(request);
 const type=tag(r.type==='tenant'?'مستأجر':'خریدار',r.type==='tenant'?'qoqnus-customer-tenant':'qoqnus-customer-buyer');
 const status=String(r.status||'active');if(status==='purchased'||status==='rented')type.textContent+=(status==='purchased'?' · خرید انجام شد':' · اجاره انجام شد');
 const call=createCallControl(r,'تماس با مشتری',{kind:'customer',id});call.classList.add('qoqnus-row-call','qoqnus-action-call');
 if(r.qoqnusSpecial)type.textContent+=' · ویژه';top.append(avatar,who,type,call);art.append(top);
 const createdAt=recordCreatedTimestamp(r),lastContact=recordLastActionTimestamp(r,'customer');
 const metaValues=[];const area=firstText(r.neighborhood,r.street);if(area)metaValues.push('محدوده: '+area);
 metaValues.push('آخرین تماس: '+recordTimeLabel(lastContact,'هنوز تماسی ثبت نشده'));
 if(createdAt)metaValues.push('تاریخ ثبت: '+localDateLabel(createdAt));
 art.append(inlineFactsLine(metaValues,'qoqnus-card-line qoqnus-card-line-secondary qoqnus-record-meta-line'));
 const primary=canonicalCustomerProperty(r.propertyType||''),notes=String(r.notes||'').trim(),fallback=/زمین/.test(notes)&&primary==='ویلایی'?'زمین (در صورت پیدا نشدن خانه)':'';
 const morePanel=document.createElement('section');morePanel.className='qoqnus-customer-details';morePanel.hidden=true;
 const detailPhoto=makeCustomerPhotoElement(r,'detail');if(customerPhotoValue(r)){detailPhoto.tabIndex=0;detailPhoto.setAttribute('role','button');detailPhoto.setAttribute('aria-label','نمایش بزرگ‌تر تصویر مشتری');detailPhoto.addEventListener('click',()=>openCustomerPhoto(r));detailPhoto.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openCustomerPhoto(r);}});}morePanel.append(detailPhoto);const noteText=notes||'توضیحی ثبت نشده است.';const note=document.createElement('p');note.className='qoqnus-customer-notes';note.textContent=maskPhoneNumbersInText(noteText);morePanel.append(note);
 const details=[];if(r.neighborhood)details.push(['محلهٔ مدنظر',r.neighborhood]);if(r.street)details.push(['خیابان/محدوده',r.street]);if(r.desiredArea)details.push(['متراژ مدنظر',String(r.desiredArea)+' متر']);if(r.type==='buyer'&&(r.min||r.max))details.push(['بودجه',((r.min?'از '+shortDisplayMoney(r.min):'')+(r.min&&r.max?' تا ':'')+(r.max?shortDisplayMoney(r.max):''))]);if(r.type==='tenant'&&(r.deposit||r.rent))details.push(['رهن و اجاره',((r.deposit?'رهن '+shortDisplayMoney(r.deposit):'')+(r.deposit&&r.rent?' · ':'')+(r.rent?'اجاره '+shortDisplayMoney(r.rent):''))]);if(primary)details.push(['نوع ملک موردنظر',primary+(fallback?' · '+fallback:'')]);
 if(details.length){const list=document.createElement('dl');list.className='qoqnus-customer-extra-list';for(const [k,v] of details){const dt=document.createElement('dt');dt.textContent=k;const dd=document.createElement('dd');dd.textContent=maskPhoneNumbersInText(v);list.append(dt,dd)}morePanel.append(list)}
 appendOfficePrivateEditor(morePanel,'customer',id);appendCustomerFollowupPanel(morePanel,id,r);
 const internal=document.createElement('div');internal.className='qoqnus-card-secondary-actions';internal.append(addButton(r.qoqnusSpecial?'★ برداشتن از ویژه':'☆ علامت‌گذاری ویژه','outline',()=>toggleSpecialRecord('customer',id)),addButton('ویرایش','',()=>editCustomer(id)),addButton('حذف','danger',()=>deleteLocalRecord('customer',id)));morePanel.append(internal);art.append(morePanel);
 const actions=document.createElement('div');actions.className='qoqnus-record-actions qoqnus-customer-actions';
 const more=addButton('بیشتر','muted',()=>{morePanel.hidden=!morePanel.hidden;more.textContent=morePanel.hidden?'بیشتر':'بستن';more.setAttribute('aria-expanded',String(!morePanel.hidden))});more.dataset.customerMoreToggle=String(id);more.setAttribute('aria-expanded','false');
 const edit=addButton('ویرایش','',()=>editCustomer(id));const closed=status==='purchased'||status==='rented';const dealLabel=r.type==='tenant'?'اجاره کرد':'خرید کرد';
 const deal=addButton(dealLabel,'success',async()=>{if(closed)return;const outcome=r.type==='tenant'?'rented':'purchased';if(!confirm('وضعیت مشتری به «'+dealLabel+'» تغییر کند؟'))return;const current=await recordById('customer',id);if(!current)return;const now=Date.now();await storeRecord('customer',{...current,status:outcome,dealOutcome:outcome,dealOutcomeLabel:dealLabel,dealClosedAt:now,updatedAt:now});await renderCustomers()},closed?'این مشتری قبلاً '+(r.type==='tenant'?'اجاره کرده است':'خرید کرده است'):dealLabel);deal.disabled=closed;
 actions.append(more,edit,deal);art.append(actions);return art;
}
async function readDivarFromOfficeFile(fileId,url,button){
 const link=normalizeDivarDetailUrl(url);if(!link)throw new Error('برای این فایل پیوند مستقیم قابل خواندن وجود ندارد.');
 const officeFile=await recordById('file',String(fileId));if(!officeFile)throw new Error('فایل محلی پیدا نشد.');
 const oldText=button?.textContent;if(button){button.disabled=true;button.textContent='در حال آماده‌سازی…';}
 try{
  const result=await receiveDivarReaderRecord({
   url:link.url,title:clean(firstText(officeFile.title,'فایل ملک'),180),
   description:firstText(officeFile.description,officeFile.notes),neighborhood:officeFile.neighborhood,street:officeFile.street,
   area:officeFile.landArea||officeFile.area,buildingArea:officeFile.buildingArea,rooms:officeFile.rooms,
   transactionType:officeFile.officeTransactionType||officeFile.transactionType,propertyType:officeFile.officePropertyType||officeFile.propertyType,
   targetOfficeFileId:String(fileId),source:'mobile-file-reader',sourceLabel:'دریافت‌شده با ققنوس',collectedFrom:'office-file-reader',readerState:'link_only',status:'saved',sendStatus:'not_sent',reviewStatus:'not_required',publicationState:'not_sent'
  });
  const id=String(result.recordId||('divar:'+link.id));
  await storeRecord('listing',{...(await recordById('listing',id)||{}),id,record_uuid:id,targetOfficeFileId:String(fileId),url:link.url,detailUrl:link.url,sourceUrl:link.url,canonicalUrl:link.url,divarId:link.id,updatedAt:Date.now()});
  const cards=[...$('listingList').querySelectorAll('[data-listing-card-id]')];const card=cards.find(el=>el.dataset.listingCardId===id);const readerButton=card?.querySelector('.qoqnus-divar-read-button')||button;
  await readDivarIntoExistingRecord(id,link.url,readerButton);
 }catch(error){if(button){button.disabled=false;button.textContent=oldText||'خواندن آگهی';}throw error;}
}
function buildPropertyCardBadges(record,kind,transactionType,topicKey,title){
 const meta=document.createElement('div');meta.className='qoqnus-card-badges';
 const txText=transactionType==='rent'?'اجاره':transactionType==='sale'?'فروش':'';
 const titleNorm=normalizeText(title||'');
 const txAlready=/^(?:فروش|اجاره|رهن|خرید)/u.test(titleNorm);
 if(txText&&!txAlready)meta.append(tag(txText,transactionType==='rent'?'office-rent-tag':'office-sale-tag'));
 const topicAlready=topicKey==='land'?/زمین|باغ|کلنگی|کشاورز/u.test(titleNorm):topicKey==='commercial'?/مغازه|تجار|سوله|کارگاه|انبار/u.test(titleNorm):topicKey==='residential'?/خانه|ویلا|آپارتمان|مسکونی/u.test(titleNorm):false;
 if(topicKey&&topicKey!=='other'&&!topicAlready)meta.append(tag(topicLabel(topicKey)));
 if(kind==='listing'){
  const visibleStatus=listingStatus(record),statusLabel=({published:'منتشرشده',archived:'بایگانی‌شده',saved:'ذخیره‌شده · آماده انتشار'})[visibleStatus];
  if(statusLabel)meta.append(tag(statusLabel,'qoqnus-listing-status-'+visibleStatus));
  if(isListingNew(record))meta.append(tag('جدید','qoqnus-fresh-listing-badge'));
 }else{
  if(record.centralPublishState)meta.append(tag(mobilePublishStateLabel(record.centralPublishState),'qoqnus-publish-state-badge'));
  if(Number(record.archiveBucket)===2)meta.append(tag('بایگانی ۲','archive-two-badge'));
  if(record.qoqnusSpecial)meta.append(tag('ویژه','qoqnus-special-tag'));
 }
 meta.hidden=!meta.childElementCount;
 return meta;
}
function createPropertyCardSummary(record,kind,id,options={}){
 const summary=document.createElement('div');summary.className='qoqnus-property-summary qoqnus-listing-body';
 const photoSource=firstText(options.photoSource,kind==='listing'?listingThumbnailSource(record):recordPhotoSources(record,1)[0],listingThumbnailSource(record));
 let photo;
 if(photoSource){
  photo=document.createElement('a');photo.className='qoqnus-listing-photo';photo.href=photoSource;photo.target='_blank';photo.rel='noopener noreferrer';photo.setAttribute('aria-label','نمایش عکس '+String(options.title||''));
 }else{
  photo=document.createElement('div');photo.className='qoqnus-listing-photo qoqnus-listing-no-photo';
 }
 const image=document.createElement('img');image.src=photoSource||DEFAULT_RECORD_IMAGE;image.alt=photoSource?'عکس '+String(options.title||'ملک'):'تصویر پیش‌فرض ققنوس';image.loading='lazy';image.decoding='async';image.referrerPolicy='no-referrer';setImageFallback(image);photo.append(image);
 const content=document.createElement('div');content.className='qoqnus-listing-content';
 if(options.badges)content.append(options.badges);
 const primary=document.createElement('div');primary.className='qoqnus-card-line qoqnus-card-line-primary';
 const primaryItems=[[options.title,'qoqnus-card-title'],[options.areaLabel,'qoqnus-card-area'],[options.priceLabel,'qoqnus-card-price']].filter(([value])=>String(value||'').trim()&&String(value)!=='—'&&String(value)!=='-');
 primaryItems.forEach(([value,className],index)=>{if(index){const separator=document.createElement('span');separator.className='qoqnus-fact-separator';separator.textContent='|';primary.append(separator);}const item=document.createElement('span');item.className=className;item.textContent=maskPhoneNumbersInText(String(value));primary.append(item);});primary.hidden=!primaryItems.length;content.append(primary);
 const owner=firstText(options.ownerName,record.ownerName,record.owner_name,record.ownerFullName,record.owner_full_name,record.sellerName,record.seller_name,record.seller?.name,record.owner?.name,record.contact?.name,record.customerName,record.customer_name,record.contactName,record.contact_name);
 if(owner){const ownerLine=document.createElement('div');ownerLine.className='qoqnus-owner-name';ownerLine.textContent='مالک: '+maskPhoneNumbersInText(owner);content.append(ownerLine);}
 const secondaryValues=[];
 if(options.locationText)secondaryValues.push('موقعیت: '+options.locationText);
 if(options.lastFollowUp)secondaryValues.push('آخرین پیگیری: '+options.lastFollowUp);
 if(options.createdLabel)secondaryValues.push('تاریخ ثبت: '+options.createdLabel);
 const secondary=inlineFactsLine(secondaryValues,'qoqnus-card-line qoqnus-card-line-secondary qoqnus-record-meta-line');
 const timeline=document.createElement('div');timeline.className='qoqnus-record-timeline-row';timeline.append(secondary);
 if(options.callControl){options.callControl.classList.add('qoqnus-action-call','qoqnus-row-call');timeline.append(options.callControl);}
 content.append(timeline);
 const features=inlineFactsLine(options.features||[],'qoqnus-card-line qoqnus-card-line-features');content.append(features);
 summary.append(photo,content);
 return summary;
}
function renderFileCard(r,id){
 const art=document.createElement('article');art.className='record-card qoqnus-property-card compact-office-file-card qoqnus-office-file-card';art.dataset.officeFileId=String(id);
 const tx=String(r.officeTransactionType||r.transactionType||''),property=String(r.officePropertyType||r.propertyType||'');
 const topicKey=listingTopic(r),txLabel=tx==='rent'?'اجاره':tx==='sale'?'فروش':'';
 const propertyLabels={land:'زمین',villa:'ویلایی',commercial:'تجاری'};
 const title=compactListingTitle({...r,title:firstText(r.title,txLabel+' '+(propertyLabels[property]||property),'فایل ملک')});
 const summary=listingSummary(r),areaRaw=firstText(r.landArea,r.area_sqm,r.area,r.buildingArea,summary.land,summary.built),areaLabel=areaRaw&&areaRaw!=='—'?String(areaRaw)+' متر':'';
 const priceLabel=summary.price&&summary.price!=='—'?summary.price:(tx==='rent'?([r.deposit?('رهن '+shortDisplayMoney(r.deposit)):'',r.monthlyRent?('اجاره '+shortDisplayMoney(r.monthlyRent)):''].filter(Boolean).join(' / ')):shortDisplayMoney(r.salePrice||r.price));
 const features=compactFeatureList(r);if(Number(r.rooms)>0)features.push(String(r.rooms)+' خواب');else if(String(r.rooms)==='0')features.push('بدون خواب');if(r.landUse)features.push('کاربری '+r.landUse);if(r.frontage)features.push('عرض بر '+r.frontage+' متر');
 const uniqueFeatures=[...new Map(features.map(x=>[normalizeText(x),x])).values()];
 const call=createCallControl(r,'تماس با مالک',{kind:'file',id});
 art.append(createPropertyCardSummary(r,'file',id,{title,areaLabel,priceLabel,locationText:firstText(r.neighborhood,r.location,r.street),lastFollowUp:recordTimeLabel(recordLastActionTimestamp(r,'file'),'هنوز پیگیری نشده'),createdLabel:recordCreatedTimestamp(r)?localDateLabel(recordCreatedTimestamp(r)):'',ownerName:firstText(r.ownerName,r.owner_name,r.customerName,r.sellerName),features:uniqueFeatures,callControl:call,badges:buildPropertyCardBadges(r,'file',tx,topicKey,title)}));
 const morePanel=document.createElement('section');morePanel.className='qoqnus-file-details';morePanel.hidden=true;const rows=[];const addRow=(label,value)=>{if(value===undefined||value===null||String(value).trim()===''||String(value)==='unknown')return;rows.push([label,maskPhoneNumbersInText(String(value))])};addRow('کد پیگیری',r.code);addRow('مالک / رابط',r.ownerName||r.customerName);addRow('خیابان / نشانی خصوصی',r.street);addRow('تعداد خواب',String(r.rooms)==='0'?'بدون خواب':r.rooms);addRow('گرمایش',r.heating);addRow('سرمایش',r.cooling);addRow('سال ساخت',r.year);addRow('وضعیت سند',r.deed);addRow('دسترسی / انشعابات',r.access);addRow('قابل تبدیل',r.convertible===true?'بله':r.convertible===false?'خیر':'');addRow('توضیحات',maskPhoneNumbersInText(r.notes));addRow('تاریخ ثبت',recordCreatedTimestamp(r)?localDateLabel(recordCreatedTimestamp(r)):'');addRow('آخرین پیگیری',recordLastActionTimestamp(r,'file')?localDateLabel(recordLastActionTimestamp(r,'file')):'هنوز پیگیری نشده');if(rows.length){const table=document.createElement('table');table.className='qoqnus-detail-table';for(const [label,value] of rows){const tr=document.createElement('tr'),th=document.createElement('th'),td=document.createElement('td');th.textContent=label;td.textContent=value;tr.append(th,td);table.append(tr)}morePanel.append(table)}if(r.divarPhone){const divarPhoneRow=document.createElement('div');divarPhoneRow.className='qoqnus-divar-phone-row';const label=document.createElement('strong');label.textContent='شمارهٔ تماس آگهی‌دهنده: '+String(r.divarPhone);divarPhoneRow.append(label,createCallControl({phone:r.divarPhone},'تماس با آگهی‌دهنده',{kind:'file',id}));morePanel.append(divarPhoneRow)}appendOfficePrivateEditor(morePanel,'file',id);const secondary=document.createElement('div');secondary.className='qoqnus-card-secondary-actions';secondary.append(addButton(r.qoqnusSpecial?'★ برداشتن از ویژه':'☆ علامت‌گذاری ویژه','outline',()=>toggleSpecialRecord('file',id)),addButton('ویرایش','',()=>editFile(id)),addButton('حذف','danger',()=>deleteLocalRecord('file',id)));morePanel.append(secondary);art.append(morePanel);
 const actions=document.createElement('div');actions.className='qoqnus-record-actions qoqnus-file-actions';const more=addButton('بیشتر','muted',()=>{morePanel.hidden=!morePanel.hidden;more.textContent=morePanel.hidden?'بیشتر':'بستن';more.setAttribute('aria-expanded',String(!morePanel.hidden))});more.setAttribute('aria-expanded','false');const sourceLink=normalizeDivarDetailUrl(r.url||r.detailUrl||r.detail_url||r.sourceUrl||r.source_url||r.canonicalUrl||r.canonical_url||r.originalUrl||r.original_url||r.listingUrl||r.listing_url);const isImportedSource=!!sourceLink||/^divar:/i.test(String(r.id||r.record_uuid||''))||/divar|دیوار/i.test([r.source,r.sourceLabel,r.source_label,r.origin,r.originLabel,r.collectedFrom].map(v=>String(v||'')).join(' '));let primaryAction;if(isImportedSource){primaryAction=addButton(r.readerState==='complete'||r.mobileReaderState==='complete'?'بازخوانی آگهی':'خواندن آگهی','outline',()=>{if(!sourceLink){alert('پیوند مستقیم این فایل پیدا نشد؛ نسخهٔ آگهی‌شدهٔ فایل را دوباره به ققنوس ارسال کن.');return;}void readDivarFromOfficeFile(id,sourceLink.url,primaryAction).catch(error=>alert('خواندن آگهی انجام نشد: '+(error?.message||'خطای نامشخص')))});primaryAction.classList.add('qoqnus-action-button','qoqnus-divar-read-button');primaryAction.setAttribute('aria-label','خواندن آگهی');}else{primaryAction=document.createElement('button');primaryAction.type='button';primaryAction.className='qoqnus-action-button qoqnus-action-publish qoqnus-central-publish-button';primaryAction.textContent=r.centralPublishState?mobilePublishStateLabel(r.centralPublishState):'انتشار';primaryAction.setAttribute('aria-label','انتشار از ربات مرکزی');primaryAction.addEventListener('click',event=>{event.preventDefault();void publishMobileRecord('file',id,primaryAction).catch(error=>alert('اجرای انتشار مرکزی با خطا متوقف شد: '+(error?.message||'خطای نامشخص')))});}const outcome=String(r.dealOutcome||r.archiveReason||'');const alreadyClosed=outcome==='sold'||outcome==='rented';const dealLabel=alreadyClosed?(outcome==='sold'?'فروخته شد':'اجاره شد'):(tx==='rent'?'اجاره شد':'فروخته شد');const deal=addButton(dealLabel,alreadyClosed?'success':'danger',async()=>{if(alreadyClosed)return;const current=await recordById('file',id);if(!current)return;if(!confirm('این فایل '+(tx==='rent'?'اجاره‌شده':'فروخته‌شده')+' ثبت و به بایگانی ۲ منتقل شود؟'))return;const now=Date.now(),res=tx==='rent'?'rented':'sold',label=res==='rented'?'اجاره شد':'فروخته شد';await storeRecord('file',{...current,status:'archived',sendStatus:'archived',archiveBucket:2,archiveLabel:'بایگانی ۲',archiveReason:res,dealOutcome:res,dealOutcomeLabel:label,dealClosedAt:now,archivedAt:now,updatedAt:now});await renderFiles()});if(alreadyClosed)deal.disabled=true;actions.append(more,primaryAction,deal);art.append(actions);return art;
}
function renderCard(title,lines,kind,id){if(kind==='customer')return renderCustomerCard(lines,id);if(kind==='file')return renderFileCard(lines,id);const art=document.createElement('article');art.className='record-card';const h=document.createElement('h3');h.textContent=title||'بدون عنوان';art.append(h);return art;}
function emptyBox(text){const e=document.createElement('div');e.className='empty';e.textContent=text;return e}
function buildTimeGroupedSections(list,rows,kind,now=Date.now()){
 const grouping=window.QoqnusTimeGrouping;
 if(!grouping||typeof grouping.groupRecords!=='function')throw new Error('ماژول بخش‌بندی زمانی بارگذاری نشده است.');
 const groups=grouping.groupRecords(rows,recordCreatedTimestamp,now),sections=[];
 for(const group of groups){
  const section=document.createElement('section');section.className='qoqnus-time-group qoqnus-time-group--'+kind;section.dataset.timeGroup=group.key;
  const heading=document.createElement('div');heading.className='qoqnus-time-group-heading';
  const title=document.createElement('h3');title.textContent=group.label;
  const count=document.createElement('span');count.className='qoqnus-time-group-count';count.textContent=displayCount(group.count);count.setAttribute('aria-label',displayCount(group.count)+' رکورد');
  heading.append(title,count);
  const line=document.createElement('hr');line.className='qoqnus-time-group-divider';
  const body=document.createElement('div');body.className='qoqnus-time-group-cards';
  section.append(heading,line,body);list.append(section);sections.push({group,body});
 }
 return sections;
}
function appendTimeGroupedRecords(list,rows,renderRecord,kind,now=Date.now()){
 const sections=buildTimeGroupedSections(list,rows,kind,now);
 for(const section of sections)for(const record of section.group.records)section.body.append(renderRecord(record));
 return sections;
}
function captureTimeGroupScrollAnchor(list,kind){
 if(!list||!window.scrollY)return null;
 const selectors={customer:'[data-customer-card-id]',file:'[data-office-file-id]',listing:'[data-listing-card-id]'},selector=selectors[kind];
 if(!selector)return null;
 const anchor=[...list.querySelectorAll(selector)].find(node=>{const rect=node.getBoundingClientRect();return rect.bottom>0&&rect.top<window.innerHeight;});
 if(!anchor)return {scrollY:window.scrollY,kind,id:'',top:0};
 const id=kind==='customer'?anchor.dataset.customerCardId:kind==='file'?anchor.dataset.officeFileId:anchor.dataset.listingCardId;
 return {scrollY:window.scrollY,kind,id:String(id||''),top:anchor.getBoundingClientRect().top};
}
function restoreTimeGroupScrollAnchor(list,state){
 if(!state)return;
 window.requestAnimationFrame(()=>{
  const selectors={customer:'[data-customer-card-id]',file:'[data-office-file-id]',listing:'[data-listing-card-id]'},selector=selectors[state.kind];
  const anchor=selector&&state.id?[...list.querySelectorAll(selector)].find(node=>String(state.kind==='customer'?node.dataset.customerCardId:state.kind==='file'?node.dataset.officeFileId:node.dataset.listingCardId)===state.id):null;
  if(anchor){const delta=anchor.getBoundingClientRect().top-state.top;if(Math.abs(delta)>1)window.scrollBy(0,delta);}
  else window.scrollTo(0,state.scrollY);
 });
}
function recordTimestamp(r){for(const key of ['createdAt','created_at_ms','created_at','createdDate','created_date','dateCreated','firstSeenAt','first_seen_at','collectedAt','collected_at','submittedAt','submitted_at','reviewedAt','reviewed_at','approvedAt','approved_at','publishedAt','published_at','archivedAt','archived_at','updatedAt','updated_at','lastModified','last_modified','timestamp','date']){const v=r?.[key];if(v===undefined||v===null||v==='')continue;if(typeof v==='number'||/^\d{10,13}$/.test(String(v))){let n=Number(v);if(n>0&&n<1e12)n*=1000;if(Number.isFinite(n)&&n>0)return n;}const parsed=Date.parse(String(v));if(Number.isFinite(parsed))return parsed;}return 0;}
const NEW_LISTING_BADGE_WINDOW_MS=24*60*60*1000;
function isListingNew(r,now=Date.now()){const receivedAt=Number(r?.syncReceivedAt)||0,viewedAt=Number(r?.syncViewedAt)||0,anchor=receivedAt||recordTimestamp(r);return anchor>0&&anchor>viewedAt&&anchor<=now&&now-anchor<=NEW_LISTING_BADGE_WINDOW_MS;}
function matchesPeriod(r,period){if(!period||period==='all')return true;const ts=recordCreatedTimestamp(r),grouping=window.QoqnusTimeGrouping;if(!ts||!grouping)return false;const createdOrdinal=grouping.ordinalFor(ts),todayOrdinal=grouping.ordinalFor(Date.now());if(!Number.isFinite(createdOrdinal)||!Number.isFinite(todayOrdinal)||createdOrdinal>todayOrdinal)return false;const age=todayOrdinal-createdOrdinal;if(period==='day')return age===0;if(period==='week'){const weekDay=new Date(todayOrdinal*86400000).getUTCDay(),mondayOrdinal=todayOrdinal-((weekDay+6)%7);return createdOrdinal>=mondayOrdinal;}const createdKey=grouping.dateKey(ts),todayKey=grouping.dateKey(Date.now());if(period==='month')return createdKey.slice(0,7)===todayKey.slice(0,7);if(period==='year')return createdKey.slice(0,4)===todayKey.slice(0,4);return true;}
function listingTopic(r){const s=normalizeText([r.title,r.description,r.publicDescription,r.detailText,r.text,r.listingType,r.listingTypeLabel,r.propertyType,r.property_type,r.officePropertyType,r.category,r.categoryLabel,r.subType,r.subtype,r.type,r.facts?.propertyType,r.facts?.transactionLabel,r.tags].flat().join(' '));if(/زمین|کلنگی|باغ|کشاورز|land|garden/u.test(s))return 'land';if(/مغازه|تجار|سرقفلی|سوله|کارگاه|انبار|commercial|shop|industrial/u.test(s))return 'commercial';if(/خانه|ویلا|آپارتمان|مسکونی|residential|villa|apartment/u.test(s))return 'residential';return 'other';}
function listingTransaction(r){const f=r.facts&&typeof r.facts==='object'?r.facts:{},sourceTransaction=sourceListingValue(r,['نوع معامله','معامله']);const s=normalizeText([f.transactionLabel,f.transactionType,f.dealType,r.transactionType,r.transaction_type,r.dealType,r.deal_type,r.listingType,r.title,r.headline,r.description,r.publicDescription,sourceTransaction,r.text,r.publicPost,r.tags].flat().join(' '));if(/اجاره|رهن|مستاجر|مستأجر|rent|tenant|lease/u.test(s))return 'rent';if(/فروش|خرید|فروشنده|sale|sell/u.test(s))return 'sale';return 'unknown';}
function listingPriceProbe(r){
 const specificTotal=sourceListingValue(r,['قیمت کل','قیمت فروش','قیمت زمین','قیمت ملک']);
 const genericPrice=sourceListingValue(r,['قیمت']);
 const sourceTotal=firstText(specificTotal,/^(?:هر\s*متر|متری|قیمت\s*هر\s*متر)/u.test(normalizeText(genericPrice))?'':genericPrice);
 const sourcePerMeter=sourceListingValue(r,['قیمت هر متر مربع','قیمت هر متر','هر متر مربع','قیمت متری']);
 const sourceLandArea=sourceListingValue(r,['متراژ زمین','مساحت زمین','متراژ کل','مساحت کل']);
 const sourceBuiltArea=sourceListingValue(r,['زیربنا','متراژ بنا','متراژ ساختمان','متراژ ساخت']);
 const sourceGenericArea=sourceListingValue(r,['متراژ','مساحت']);
 return {...r,
  salePrice:firstText(r?.salePrice,r?.sale_price_toman,r?.sale_price,r?.totalSalePriceToman,r?.total_sale_price_toman,r?.totalPrice,r?.total_price,r?.price,sourceTotal),
  pricePerMeter:firstText(r?.pricePerMeter,r?.price_per_meter,r?.price_per_sqm,r?.pricePerSqm,r?.facts?.pricePerMeter,r?.facts?.price_per_meter,r?.facts?.price_per_sqm,sourcePerMeter,(typeof genericPrice==='string'&&/^(?:هر\s*متر|متری)/u.test(normalizeText(genericPrice))?genericPrice:''),(typeof r?.price==='string'&&/(?:هر\s*متر|متری|per\s*(?:sqm|m2))/iu.test(r.price)?r.price:'')),
  landArea:firstText(r?.landArea,r?.land_area,r?.land_area_sqm,r?.facts?.landArea,r?.facts?.land_area,sourceLandArea),
  buildingArea:firstText(r?.buildingArea,r?.building_area,r?.builtArea,r?.built_area,r?.area_building,r?.facts?.builtArea,r?.facts?.buildingArea,r?.facts?.built_area,sourceBuiltArea),
  area_sqm:firstText(r?.area_sqm,r?.area,r?.facts?.area,r?.facts?.area_sqm,sourceGenericArea)
 };
}
function listingSalePriceInfo(r){const helper=window.QoqnusListingPresentation;if(!helper)return {amountToman:null,source:'unavailable',rawText:''};return helper.resolveSalePrice(listingPriceProbe(r),{topic:listingTopic(r)});}
function listingFilterPrices(r){const f=r.facts&&typeof r.facts==='object'?r.facts:{};const tx=listingTransaction(r);if(tx!=='rent'){const resolved=listingSalePriceInfo(r);return resolved.amountToman?[resolved.amountToman]:[];}const keys=['deposit','deposit_toman','rentDeposit','rent_deposit','monthlyRent','monthly_rent_toman','monthly_rent','rent_price','rentPrice','price','price_toman'];const values=[];for(const obj of [r,f])for(const k of keys){const amount=window.QoqnusListingPresentation?.parseMoneyToman(obj?.[k],{forceRial:/rial|riyal/i.test(k)})||null;if(amount&&!values.includes(amount))values.push(amount);}return values;}
function listingTransactionMatches(r,filter){return !filter||filter==='all'||listingTransaction(r)===filter;}
function topicMatches(r,topic,kind){if(!topic||topic==='all')return true;if(kind==='customer')return canonicalCustomerProperty(r.propertyType||'')===canonicalCustomerProperty(topic);if(kind==='file'){const v=String(r.officePropertyType||r.propertyType||'');if(topic==='land')return /land|زمین|کلنگی/i.test(v);if(topic==='villa')return /villa|ویلا|خانه|مسکونی/i.test(v);if(topic==='commercial')return /commercial|تجار|مغازه|سوله/i.test(v);return true;}return listingTopic(r)===topic;}
function topicLabel(key){return ({residential:'خانه/آپارتمان/ویلا',land:'زمین/کلنگی',commercial:'تجاری',other:'سایر'})[key]||key;}
function compactListingTitle(r){let title=cleanPublicSourceText(cleanPublicAdTimeMetadata(firstText(r?.title,r?.headline,r?.code,r?.id,'بدون عنوان')));const cityRaw=firstText(r?.city,r?.facts?.city),city=cleanPublicAdLocation(cityRaw);const candidates=[];if(city)candidates.push(city);const match=String(cityRaw||'').match(/(?:در|in)\s+([\p{L}\p{M}‌][\p{L}\p{M}‌\s-]{1,50})$/iu);if(match)candidates.push(match[1].trim());const esc=v=>String(v).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');for(const raw of [...new Set(candidates)].sort((a,b)=>b.length-a.length)){const name=String(raw).replace(/^(?:در|in)\s+/iu,'').trim();if(name.length<3)continue;try{title=title.replace(new RegExp('\\s+(?:در|in)\\s+'+esc(name)+'(?=\\s*(?:[-–—|·]|$))','iu'),' ')}catch{}}title=title.replace(/\s*(?:[-–—|·]\s*)?(?:[۰-۹0-9]{1,2}\s+)?(?:فروردین|اردیبهشت|خرداد|تیر|مرداد|شهریور|مهر|آبان|آذر|دی|بهمن|اسفند)\s+[۰-۹0-9]{4}\s*$/u,'').replace(/\s*(?:[-–—|·]\s*)?[۰-۹0-9]{4}[/-][۰-۹0-9]{1,2}[/-][۰-۹0-9]{1,2}\s*$/u,'').replace(/\s*(?:[-–—|·])\s*$/u,'').trim();return maskPhoneNumbersInText(title||'بدون عنوان');}
function activateView(view){
 const allowed=new Set(['dashboard','customers','files','listings','sync','backup']);
 const selected=allowed.has(String(view||''))?String(view):'dashboard';
 const target=$('view-'+selected);
 if(!target){console.warn('Qoqnus view not found:',selected);return false;}
 document.querySelectorAll('.view').forEach(node=>node.classList.toggle('active',node===target));
 document.querySelectorAll('.tab[data-view]').forEach(node=>{
  const active=node.dataset.view===selected;node.classList.toggle('active',active);
  if(active)node.setAttribute('aria-current','page');else node.removeAttribute('aria-current');
 });
 document.querySelectorAll('.mobile-nav-item[data-mobile-view]').forEach(node=>{
  const active=node.dataset.mobileView===selected;node.classList.toggle('active',active);
  if(active)node.setAttribute('aria-current','page');else node.removeAttribute('aria-current');
 });
 // Refresh the selected office from encrypted local storage; no network request is made here.
 const refresh={customers:renderCustomers,files:renderFiles,listings:renderListings};
 if(refresh[selected])refresh[selected]().catch(error=>setStatus('storageStatus','نمایش دفتر ناموفق بود: '+String(error?.message||error).slice(0,180),'error'));
 if(selected==='sync')refreshPairingUi().catch(error=>setSyncFeedback(String(error?.message||error),'error'));
 if(selected==='dashboard')renderDashboardHighlights().catch(error=>console.warn('Qoqnus dashboard refresh failed',error));
 return true;
}
function notificationDateLabel(record){
 const stamp=Number(record?.createdAt||record?.updatedAt)||recordTimestamp(record);
 return stamp>0?localDateLabel(stamp):String(record?.dateKey||'');
}
async function saveLocalNotification(id,type,title,message,extra={}){
 if(!cryptoKey)return false;
 const key=String(id||'').trim();if(!key)return false;
 const prior=await recordById('notice',key).catch(()=>null),now=Date.now();
 const record={...(prior||{}),...extra,id:key,type:String(type||'notice'),title:clean(title,180),message:clean(message,1200),createdAt:Number(prior?.createdAt)||now,updatedAt:now,readAt:Number(prior?.readAt)||0};
 await storeRecord('notice',record);return record;
}
async function markNotificationRead(id){
 const record=await recordById('notice',String(id));if(!record)return false;
 if(!Number(record.readAt)){record.readAt=Date.now();record.updatedAt=Date.now();await storeRecord('notice',record);}
 await renderNotifications();return true;
}
async function openNotificationDestination(record){
 const kind=String(record?.recordKind||''),id=String(record?.recordId||'');
 closeNotificationPanel();
 if(kind==='sync'||record?.type==='daily-sync-reminder'){activateView('sync');return;}
 if(!['customer','file','listing'].includes(kind)){activateView('dashboard');return;}
 activateView(kind==='customer'?'customers':kind==='file'?'files':'listings');
 const selector=kind==='customer'?'[data-customer-card-id]':kind==='file'?'[data-office-file-id]':'[data-listing-card-id]';
 const getId=node=>kind==='customer'?node.dataset.customerCardId:kind==='file'?node.dataset.officeFileId:node.dataset.listingCardId;
 let card=id?[...document.querySelectorAll('#view-'+(kind==='customer'?'customers':kind==='file'?'files':'listings')+' '+selector)].find(node=>String(getId(node))===id):null;
 if(!card&&id){
  const searchId=kind==='customer'?'customerSearch':kind==='file'?'fileSearch':'listingSearch';
  const search=$(searchId);if(search){search.value='';if(kind==='customer')appliedCustomerSearchText='';if(kind==='file')appliedFileSearchText='';await (kind==='customer'?renderCustomers():kind==='file'?renderFiles():renderListings());}
  card=[...document.querySelectorAll('#view-'+(kind==='customer'?'customers':kind==='file'?'files':'listings')+' '+selector)].find(node=>String(getId(node))===id);
 }
 if(card){card.scrollIntoView({behavior:'smooth',block:'center'});if(kind==='customer'){const panel=card.querySelector('[data-customer-followups]');if(panel){panel.open=true;panel.scrollIntoView({behavior:'smooth',block:'center'});}}}
}
async function renderNotifications(){
 const list=$('notificationsList');if(!list)return;
 const records=(await recordsOf('notice')).map(item=>item.record).filter(Boolean).sort((a,b)=>(Number(b.createdAt)||Number(b.updatedAt)||0)-(Number(a.createdAt)||Number(a.updatedAt)||0));
 const unread=records.filter(item=>!Number(item.readAt)).length;
 const count=$('notificationTopCount'),dashboardCount=$('dashboardUnreadCount');
 if(count){count.textContent=displayCount(unread);count.classList.toggle('hidden',unread===0);}
 if(dashboardCount)dashboardCount.textContent=displayCount(unread);
 list.replaceChildren();
 if(!records.length){list.append(emptyBox('اعلان تازه‌ای وجود ندارد.'));return;}
 for(const record of records){
  const card=document.createElement('article');card.className='notification-card'+(!Number(record.readAt)?' unread':'');
  const head=document.createElement('div');head.className='notification-head';
  const title=document.createElement('h3');title.textContent=String(record.title||'اعلان ققنوس');
  const time=document.createElement('time');time.className='notification-time';time.textContent=notificationDateLabel(record);head.append(title,time);card.append(head);
  const message=document.createElement('p');message.textContent=String(record.message||'');card.append(message);
  const actions=document.createElement('div');actions.className='notification-actions';
  if(record.recordKind||record.type==='daily-sync-reminder'){
   const open=document.createElement('button');open.type='button';open.className='outline';open.textContent=record.recordKind==='sync'||record.type==='daily-sync-reminder'?'بازکردن همگام‌سازی':'بازکردن پرونده';
   open.addEventListener('click',async()=>{open.disabled=true;try{await markNotificationRead(record.id);await openNotificationDestination(record);}catch(error){setStatus('storageStatus',String(error?.message||error),'error');}finally{open.disabled=false;}});actions.append(open);
  }
  if(!Number(record.readAt)){
   const read=document.createElement('button');read.type='button';read.className='outline';read.textContent='خواندم';read.addEventListener('click',async()=>{read.disabled=true;try{await markNotificationRead(record.id);}catch(error){setStatus('storageStatus',String(error?.message||error),'error');}finally{read.disabled=false;}});actions.append(read);
  }
  if(actions.childElementCount)card.append(actions);
  list.append(card);
 }
}
function openNotificationPanel(){const panel=$('notificationPanel');if(!panel)return;panel.classList.remove('hidden');$('notificationBackdrop')?.classList.remove('hidden');$('notificationsButton')?.setAttribute('aria-expanded','true');renderNotifications().catch(error=>console.error('Qoqnus notification render failed',error));panel.focus();}
function closeNotificationPanel(){ $('notificationPanel')?.classList.add('hidden');$('notificationBackdrop')?.classList.add('hidden');$('notificationsButton')?.setAttribute('aria-expanded','false');}
function toggleNotificationPanel(){const panel=$('notificationPanel');if(!panel)return;if(panel.classList.contains('hidden'))openNotificationPanel();else closeNotificationPanel();}
async function markAllNotificationsRead(){
 const records=(await recordsOf('notice')).map(x=>x.record),now=Date.now();
 for(const record of records){if(!Number(record.readAt))await storeRecord('notice',{...record,readAt:now,updatedAt:now});}
 await renderNotifications();
}
async function clearReadNotifications(){
 const records=(await recordsOf('notice')).map(x=>x.record).filter(record=>Number(record.readAt));
 if(!records.length){setStatus('syncStatus','اعلان خوانده‌شده‌ای برای پاک‌کردن وجود ندارد.');return;}
 if(!confirm('تمام '+displayCount(records.length)+' اعلان خوانده‌شده از حافظهٔ همین گوشی پاک شوند؟'))return;
 for(const record of records)await removeRecord('notice',record.id);
 await renderNotifications();
}
function syncDashboardCounters(){
 // The compact dashboard mirrors the counters already computed by each office view.
 // This function is deliberately synchronous so a missing async counter helper can never
 // abort the unlock/render sequence and leave navigation or action controls half-initialized.
 const pairs=[['dashboardCustomerCount','customerCount'],['dashboardFileCount','fileCount'],['dashboardListingCount','listingCount']];
 for(const [targetId,sourceId] of pairs){const target=$(targetId),source=$(sourceId);if(target)target.textContent=source?.textContent||'۰';}
}
async function renderCustomers(){const rows=(await recordsOf('customer')).map(x=>x.record).filter(r=>r?.finalArchived!==true);$('customerCount').textContent=displayCount(rows.length);syncDashboardCounters();const search=normalizeText(appliedCustomerSearchText),filter=appliedCustomerSearchRole||'all',period=$('customerPeriodFilter').value,topic=$('customerTopicFilter').value,area=normalizeText($('customerAreaFilter').value),fields=appliedCustomerSearchFields.length?appliedCustomerSearchFields:['name','phone','neighborhood','street','desiredArea','budget','notes'];const searchable=r=>{const m={name:[r.name],phone:[r.phone],neighborhood:[r.neighborhood],street:[r.street],desiredArea:[r.desiredArea],budget:[r.min,r.max,r.deposit,r.rent],notes:[r.notes]};return fields.flatMap(k=>m[k]||[]).filter(Boolean).join(' ')};const filtered=rows.filter(r=>(filter==='all'||r.type===filter||(filter==='purchased'&&r.status==='purchased')||(filter==='rented'&&r.status==='rented'))&&(!search||normalizeText(searchable(r)).includes(search))&&matchesPeriod(r,period)&&topicMatches(r,topic,'customer')&&(!area||normalizeText([r.neighborhood,r.street,r.notes].join(' ')).includes(area)));const list=$('customerList'),scrollAnchor=captureTimeGroupScrollAnchor(list,'customer');list.replaceChildren();if(!filtered.length)list.append(emptyBox('مشتری‌ای با این مشخصات پیدا نشد.'));else appendTimeGroupedRecords(list,filtered,r=>renderCard(r.name,r,'customer',r.id),'customer');restoreTimeGroupScrollAnchor(list,scrollAnchor);}
async function renderFiles(){const rows=(await recordsOf('file')).map(x=>x.record).filter(r=>r?.finalArchived!==true);$('fileCount').textContent=displayCount(rows.length);syncDashboardCounters();const search=normalizeText(appliedFileSearchText),filter=$('fileFilter').value,period=$('filePeriodFilter').value,topic=$('fileTopicFilter').value,status=$('fileStatusFilter').value;const filtered=rows.filter(r=>(filter==='all'||(r.transactionType||r.officeTransactionType)===filter)&&matchesAppliedFileCriteria(r)&&(!search||normalizeText([r.title,r.phone,r.customerName,r.ownerName,r.neighborhood,r.street,r.detailText,r.notes,r.salePrice,r.pricePerMeter,r.deposit,r.monthlyRent,r.rooms,r.heating,r.cooling,Array.isArray(r.amenities)?r.amenities.join(' '):r.amenities].join(' ')).includes(search))&&matchesPeriod(r,period)&&topicMatches(r,topic,'file')&&(status==='all'||(status==='not_sent'&&String(r.sendStatus||'')==='not_sent')||(status==='published'&&String(r.status||'')==='published')||(status==='archived'&&String(r.status||'')==='archived'&&Number(r.archiveBucket)!==2)||(status==='archive2'&&Number(r.archiveBucket)===2)));const list=$('fileList'),scrollAnchor=captureTimeGroupScrollAnchor(list,'file');list.replaceChildren();if(!filtered.length)list.append(emptyBox('فایلی با این فیلترها پیدا نشد.'));else appendTimeGroupedRecords(list,filtered,r=>renderCard(r.title,r,'file',r.id),'file');restoreTimeGroupScrollAnchor(list,scrollAnchor);}
function firstText(...values){for(const v of values){if(Array.isArray(v)){const x=v.map(y=>{if(y&&typeof y==='object')return firstText(y.name,y.fullName,y.full_name,y.value,y.text,y.label,y.address,y.phone,y.number,y.url);return String(y??'').trim()}).filter(Boolean);if(x.length)return [...new Set(x)].join('، ');}else if(v&&typeof v==='object'){const nested=firstText(v.name,v.fullName,v.full_name,v.value,v.text,v.label,v.address,v.phone,v.number,v.description);if(nested)return nested;}else if(v!==undefined&&v!==null&&String(v).trim())return String(v).trim();}return '';}
function listingPhotoUrls(r){const out=[];for(const k of ['image','images','imageUrls','image_urls','imageLinks','image_links','photoUrl','photo_url','photoUrls','photo_urls','photoLinks','photo_links','photos','pictures','publishedImageUrl','thumbnailUrl','thumbnail_url']){const v=r?.[k];if(Array.isArray(v)){for(const x of v){if(typeof x==='string'&&safeHttpUrl(x))out.push(safeHttpUrl(x));else if(x&&typeof x==='object')out.push(...collectPhotoLinks(x));}}else if(v)out.push(...collectPhotoLinks(v));}return [...new Set(out)].slice(0,50);}
function listingStatus(r){const s=String(r.status||r.sendStatus||r.rubika_status||'').toLowerCase();if(s==='published'||s.includes('published')||s.includes('منتشر'))return 'published';if(s==='archived'||s.includes('archiv')||s.includes('بایگان')||Number(r.archivedAt)>0||Number(r.archiveBucket)>0)return 'archived';if(['saved','not_sent','ready','ready_to_publish','pending','rejected'].includes(s)||s.includes('pending')||s.includes('review')||s.includes('بررسی')||s.includes('در انتظار')||s.includes('reject')||s.includes('ردشده')||s.includes('رد شده'))return 'saved';return s||'unknown';}
const LISTING_FIELD_LABELS={
 title:'عنوان آگهی',headline:'عنوان آگهی',code:'کد آگهی',trackingCode:'کد پیگیری',tracking_code:'کد پیگیری',trackingId:'شناسه پیگیری',tracking_id:'شناسه پیگیری',archiveCode:'کد بایگانی',archive_code:'کد بایگانی',referenceId:'شناسه مرجع',reference_id:'شناسه مرجع',id:'شناسه رکورد',
 status:'وضعیت آگهی',sendStatus:'وضعیت ارسال',rubika_status:'وضعیت روبیکا',source:'منبع ثبت',sourceLabel:'منبع ثبت',listingType:'دسته‌بندی آگهی',listingTypeLabel:'نوع آگهی',transactionType:'نوع معامله',transaction_type:'نوع معامله',dealType:'نوع معامله',deal_type:'نوع معامله',propertyType:'نوع ملک',property_type:'نوع ملک',category:'دسته‌بندی',categoryLabel:'دسته‌بندی',subType:'زیرنوع ملک',subtype:'زیرنوع ملک',
 ownerName:'نام مالک',owner_name:'نام مالک',ownerSurname:'نام خانوادگی مالک',owner_surname:'نام خانوادگی مالک',ownerFullName:'نام و نام خانوادگی مالک',owner_full_name:'نام و نام خانوادگی مالک',customerName:'نام مشتری',customer_name:'نام مشتری',clientName:'نام رابط',client_name:'نام رابط',contactName:'نام رابط',contact_name:'نام رابط',sellerName:'نام فروشنده/مالک',seller_name:'نام فروشنده/مالک',
 phone:'شماره تماس',phones:'شماره‌های تماس',ownerPhone:'شماره تماس مالک',owner_phone:'شماره تماس مالک',sellerPhone:'شماره تماس فروشنده',seller_phone:'شماره تماس فروشنده',customerPhone:'شماره تماس مشتری',customer_phone:'شماره تماس مشتری',contactPhone:'شماره تماس رابط',contact_phone:'شماره تماس رابط',phoneNumber:'شماره تماس',phone_number:'شماره تماس',mobile:'شماره موبایل',
 city:'شهر',province:'استان',region:'منطقه',neighborhood:'محله',location:'موقعیت',locationText:'موقعیت',location_text:'موقعیت',fullLocation:'موقعیت کامل',full_location:'موقعیت کامل',street:'خیابان',address:'نشانی',propertyAddress:'نشانی ملک',property_address:'نشانی ملک',exactAddress:'نشانی دقیق',exact_address:'نشانی دقیق',fullAddress:'نشانی کامل',full_address:'نشانی کامل',addressText:'نشانی',address_text:'نشانی',addressLine:'نشانی',address_line:'نشانی',formattedAddress:'نشانی قالب‌بندی‌شده',formatted_address:'نشانی قالب‌بندی‌شده',
 bedrooms:'تعداد خواب',rooms:'تعداد خواب',roomCount:'تعداد اتاق',room_count:'تعداد اتاق',buildingArea:'متراژ بنا',building_area:'متراژ بنا',builtArea:'متراژ بنا',built_area:'متراژ بنا',area_building:'متراژ بنا',landArea:'متراژ زمین',land_area:'متراژ زمین',land_area_sqm:'متراژ زمین',area_sqm:'متراژ',area:'متراژ',year:'سال ساخت',buildYear:'سال ساخت',build_year:'سال ساخت',age:'سن بنا',floor:'طبقه',floorNumber:'شماره طبقه',floor_number:'شماره طبقه',totalFloors:'تعداد طبقات',total_floors:'تعداد طبقات',parking:'پارکینگ',storage:'انباری',elevator:'آسانسور',deed:'وضعیت سند',landUse:'کاربری زمین',land_use:'کاربری زمین',frontage:'عرض بر',commercialKind:'نوع واحد تجاری',commercial_kind:'نوع واحد تجاری',commercialUse:'کاربری تجاری',commercial_use:'کاربری تجاری',kitchen:'کابینت',flooring:'کف‌پوش',heating:'گرمایش',cooling:'سرمایش',convertible:'قابلیت تبدیل',amenities:'امکانات',features:'ویژگی‌ها',tags:'برچسب‌ها',
 salePrice:'قیمت فروش',sale_price:'قیمت فروش',sale_price_toman:'قیمت فروش (تومان)',price:'قیمت',price_toman:'قیمت (تومان)',pricePerMeter:'قیمت هر متر',price_per_meter:'قیمت هر متر',price_per_sqm:'قیمت هر مترمربع',deposit:'ودیعه/رهن',deposit_toman:'ودیعه/رهن (تومان)',rentDeposit:'ودیعه/رهن',rent_deposit:'ودیعه/رهن',monthlyRent:'اجاره ماهانه',monthly_rent:'اجاره ماهانه',monthly_rent_toman:'اجاره ماهانه (تومان)',rent_price:'اجاره ماهانه',
 description:'توضیحات',publicDescription:'توضیحات آگهی',public_description:'توضیحات آگهی',detailText:'متن جزئیات',detail_text:'متن جزئیات',details:'جزئیات',detail:'جزئیات',extraDetails:'توضیحات تکمیلی',extra_details:'توضیحات تکمیلی',notes:'یادداشت',url:'لینک آگهی اصلی',listingUrl:'لینک آگهی اصلی',listing_url:'لینک آگهی اصلی',createdAt:'تاریخ ثبت',created_at:'تاریخ ثبت',publishedAt:'تاریخ انتشار',published_at:'تاریخ انتشار',archivedAt:'تاریخ بایگانی',archived_at:'تاریخ بایگانی',updatedAt:'آخرین به‌روزرسانی',updated_at:'آخرین به‌روزرسانی'
};
const LISTING_INTERNAL_KEY=/(?:token|secret|password|passwd|cipher|^iv$|hash|fingerprint|pairing|session|deviceid|device_id|ackhash|remotehash|crypto|privatekey|private_key|blob|base64|dataurl|data_url|syncpack|peertransport|rawresponse|raw_response)/i;
const LISTING_PREPARED_TEXT_KEY=/^(?:publicPost|public_post|publicText|public_text|generatedPost|generated_post|postText|post_text|text|content|caption)$/i;
function listingScalar(v){if(v===undefined||v===null||v==='')return '';if(typeof v==='boolean')return v?'بله':'خیر';if(typeof v==='number')return String(v);if(typeof v==='string')return v.trim();if(Array.isArray(v)){const vals=v.map(x=>typeof x==='object'&&x?firstText(x.name,x.label,x.title,x.value,x.text,x.phone,x.number,x.url):String(x??'').trim()).filter(Boolean);return [...new Set(vals)].join('، ');}if(typeof v==='object')return firstText(v.name,v.label,v.title,v.value,v.text,v.description,v.address,v.phone,v.number);return '';}
function normalizeDialPhone(value){
 const raw=String(value??'').trim().replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c));
 if(!raw)return '';const hadPlus=/^\s*\+/.test(raw);let ds=raw.replace(/\D/g,'');
 if(ds.startsWith('0098')&&ds.length===14)ds='+98'+ds.slice(4);
 else if(ds.startsWith('98')&&ds.length===12)ds='+98'+ds.slice(2);
 else if(ds.length===10&&ds.startsWith('9'))ds='0'+ds;
 else if(ds.startsWith('00')&&ds.length>=10&&ds.length<=17)ds='+'+ds.slice(2);
 if(/^09\d{9}$/.test(ds)||/^0[1-8]\d{8,9}$/.test(ds)||/^\+\d{8,15}$/.test(ds))return ds;
 if(hadPlus&&/^\d{8,15}$/.test(ds))return '+'+ds;
 return '';
}
function listingPhoneItems(r){const vals=[];const add=v=>{if(Array.isArray(v)){v.forEach(add);return;}if(v&&typeof v==='object'){for(const k of ['tel','phone','phoneNumber','phone_number','mobile','number','value','contactPhone','contact_phone','ownerPhone','owner_phone','sellerPhone','seller_phone','customerPhone','customer_phone'])if(v[k])add(v[k]);return;}const raw=String(v??'').trim();if(!raw)return;const parts=raw.split(/[،,;\n|]+/).map(x=>x.trim()).filter(Boolean);for(const part of (parts.length?parts:[raw])){const normalized=normalizeDialPhone(part);if(normalized&&!vals.some(x=>x.tel===normalized))vals.push({text:part,tel:normalized});}};
 for(const k of ['phones','phone','ownerPhone','owner_phone','sellerPhone','seller_phone','customerPhone','customer_phone','contactPhone','contact_phone','phoneNumber','phone_number','mobile','tel','telephone','telephoneNumber','telephone_number'])add(r?.[k]);for(const obj of [r?.owner,r?.seller,r?.contact,r?.contactInfo,r?.contact_info,r?.customer,r?.propertyOwner])add(obj);return vals;}
function telHref(tel){const normalized=normalizeDialPhone(tel);return normalized?'tel:'+normalized.replace(/[^+0-9]/g,''):'#';}
document.addEventListener('click',event=>{const link=event.target?.closest?.('a[data-phone-link]');if(link&&(!link.href||link.getAttribute('href')==='#')){event.preventDefault();setStatus('storageStatus','برای این پرونده شمارهٔ قابل تماس ثبت نشده است.','error');}});
function listingPhoneCell(r){const phones=listingPhoneItems(r);if(!phones.length)return 'شماره تماس ثبت نشده';const wrap=document.createElement('div');wrap.className='listing-phone-links';for(const p of phones){const a=document.createElement('a');a.href=telHref(p.tel);a.dir='ltr';a.textContent=p.text;a.setAttribute('aria-label','تماس با '+p.text);wrap.append(a);}return wrap;}
function dedupeListingDetailRows(rows){const locationLabels=new Set(['استان','شهر','محله','موقعیت','خیابان','نشانی ملک']),areaLabels=new Set(['متراژ بنا','متراژ زمین','متراژ ثبت‌شده']);const seenLabels=new Set(),seenLocation=new Set(),seenArea=new Set(),seenLongText=new Set(),out=[];for(const row of rows||[]){const label=String(row?.label||''),value=String(row?.value??'').trim();if(!value)continue;const normalized=normalizeText(value).replace(/[\s،,؛;|]+/g,' ').trim();if(!normalized)continue;if(seenLabels.has(label))continue;seenLabels.add(label);if(locationLabels.has(label)){if(seenLocation.has(normalized))continue;seenLocation.add(normalized);}if(areaLabels.has(label)){if(seenArea.has(normalized))continue;seenArea.add(normalized);}if(!row.phone&&normalized.length>=30){if(seenLongText.has(normalized))continue;seenLongText.add(normalized);}out.push(row);}return out;}
function listingFieldRows(r){const f=r.facts&&typeof r.facts==='object'?r.facts:{};const rows=[],seen=new Set();const add=(label,value,opts={})=>{if(value===undefined||value===null||value==='')return;const key=String(label);if(seen.has(key))return;seen.add(key);rows.push({label,value,phone:!!opts.phone});};
 const status=listingStatus(r),statusLabel=({published:'منتشرشده',archived:'بایگانی‌شده',saved:'ذخیره‌شده · آماده انتشار'})[status]||status;
 add('کد پیگیری',firstText(r.code,r.trackingCode,r.tracking_code,r.trackingId,r.tracking_id,r.archiveCode,r.archive_code,r.referenceId,r.reference_id,r.id));add('وضعیت آگهی',statusLabel);add('وضعیت ارسال',firstText(r.sendStatus,r.rubika_status));add('منبع',displaySourceLabel(firstText(r.sourceLabel,r.source)));add('نام مالک / رابط',firstText(r.ownerName,r.owner_name,r.ownerFullName,r.owner_full_name,r.ownerSurname,r.owner_surname,r.sellerName,r.seller_name,r.customerName,r.customer_name,r.contactName,r.contact_name,r.clientName,r.client_name,r.name));const phones=listingPhoneItems(r);add('شماره تماس',phones.length?phones.map(x=>x.text).join('، '):'شماره تماس ثبت نشده',{phone:true});
 add('دسته‌بندی آگهی',firstText(r.listingTypeLabel,r.listingType,r.categoryLabel,r.category,r.contactCategory));add('نوع معامله',firstText(f.transactionLabel,f.transactionType,r.transactionType,r.transaction_type,r.dealType,r.deal_type));add('نوع ملک',firstText(f.propertyType,r.propertyType,r.property_type,r.officePropertyType));add('استان',firstText(r.province,f.province));add('شهر',firstText(r.city,f.city));add('محله',firstText(r.neighborhood,f.neighborhood));add('موقعیت',firstText(r.locationText,r.location_text,r.location,r.region,f.location,f.fullLocation));add('خیابان',firstText(r.street,f.street));add('نشانی ملک',firstText(r.exactAddress,r.exact_address,r.address,r.propertyAddress,r.property_address,r.fullAddress,r.full_address,r.addressText,r.address_text,r.addressLine,r.address_line,r.formattedAddress,r.formatted_address,r.property?.address));
 add('تعداد خواب',firstText(r.bedrooms,r.rooms,r.roomCount,r.room_count,f.bedrooms,f.rooms,sourceListingValue(r,['تعداد خواب','تعداد اتاق','اتاق'])));add('متراژ بنا',firstText(r.buildingArea,r.building_area,r.builtArea,r.built_area,r.area_building,f.builtArea,f.buildingArea,sourceListingValue(r,['زیربنا','متراژ بنا','متراژ ساختمان','متراژ ساخت'])));add('متراژ زمین',firstText(r.landArea,r.land_area,r.land_area_sqm,f.landArea,sourceListingValue(r,['متراژ زمین','مساحت زمین','متراژ کل','مساحت کل'])));add('متراژ ثبت‌شده',firstText(r.area_sqm,r.area,f.area));add('سال ساخت',firstText(r.year,r.buildYear,r.build_year,r.age,f.year,f.buildYear));add('طبقه',firstText(r.floor,r.floorNumber,r.floor_number,f.floor));add('تعداد طبقات',firstText(r.totalFloors,r.total_floors,f.totalFloors));add('پارکینگ',firstText(r.parking,f.parking));add('انباری',firstText(r.storage,r.storeRoom,r.store_room,f.storage));add('آسانسور',firstText(r.elevator,f.elevator));add('وضعیت سند',firstText(r.deed,f.deed));add('کاربری زمین',firstText(r.landUse,r.land_use,f.landUse));add('عرض بر',firstText(r.frontage,f.frontage));add('کابینت',firstText(r.kitchen,f.kitchen));add('کف‌پوش',firstText(r.flooring,f.flooring));add('گرمایش',firstText(r.heating,f.heating));add('سرمایش',firstText(r.cooling,f.cooling));add('قابلیت تبدیل',r.convertible===true?'بله':r.convertible===false?'خیر':firstText(f.convertible));add('امکانات',firstText(Array.isArray(r.amenities)?r.amenities.join('، '):r.amenities,Array.isArray(f.amenities)?f.amenities.join('، '):f.amenities));
 const saleInfo=listingSalePriceInfo(r),saleTotalText=saleInfo.amountToman?window.QoqnusListingPresentation.formatToman(saleInfo.amountToman):(saleInfo.rawText||firstText(r.totalSalePriceToman,r.total_sale_price_toman,r.totalPriceToman,r.total_price_toman,r.totalPrice,r.total_price,r.salePrice,r.sale_price_toman,r.sale_price,f.totalSalePriceToman,f.totalPrice,f.salePrice,sourceListingValue(r,['قیمت کل','قیمت فروش','قیمت زمین','قیمت ملک'])));add('قیمت فروش',saleTotalText);add('قیمت هر متر',firstText(r.pricePerMeter,r.price_per_meter,r.price_per_sqm,f.pricePerMeter,sourceListingValue(r,['قیمت هر متر مربع','قیمت هر متر','هر متر مربع'])));add('ودیعه / رهن',firstText(r.deposit,r.deposit_toman,r.rentDeposit,r.rent_deposit,f.deposit,sourceListingValue(r,['ودیعه','مبلغ ودیعه','مبلغ رهن','رهن کامل','رهن'])));add('اجاره ماهانه',firstText(r.monthlyRent,r.monthly_rent_toman,r.monthly_rent,r.rent_price,f.monthlyRent,sourceListingValue(r,['اجاره ماهانه','اجاره ماهیانه','مبلغ اجاره','اجاره'])));
 add('جزئیات کامل',firstText(r.detailText,r.detail_text,r.details,r.detail,r.extraDetails,r.extra_details));add('تاریخ ثبت',recordTimestamp(r)?new Date(recordTimestamp(r)).toLocaleString('fa-IR'):firstText(r.createdAt,r.created_at));add('تاریخ انتشار',firstText(r.publishedAt,r.published_at));add('تاریخ بایگانی',firstText(r.archivedAt,r.archived_at));
 const known=new Set(['facts','id','title','headline','code','trackingCode','tracking_code','trackingId','tracking_id','archiveCode','archive_code','referenceId','reference_id','status','sendStatus','rubika_status','source','sourceLabel','listingType','listingTypeLabel','category','categoryLabel','contactCategory','transactionType','transaction_type','dealType','deal_type','propertyType','property_type','officePropertyType','province','city','neighborhood','location','locationText','location_text','region','fullLocation','full_location','street','exactAddress','exact_address','address','propertyAddress','property_address','fullAddress','full_address','addressText','address_text','addressLine','address_line','formattedAddress','formatted_address','property','bedrooms','rooms','roomCount','room_count','buildingArea','building_area','builtArea','built_area','area_building','landArea','land_area','land_area_sqm','area_sqm','area','year','buildYear','build_year','age','floor','floorNumber','floor_number','totalFloors','total_floors','parking','storage','storeRoom','store_room','elevator','deed','landUse','land_use','frontage','kitchen','flooring','heating','cooling','convertible','amenities','features','tags','salePrice','sale_price_toman','sale_price','price','price_toman','pricePerMeter','price_per_meter','price_per_sqm','deposit','deposit_toman','rentDeposit','rent_deposit','monthlyRent','monthly_rent_toman','monthly_rent','rent_price','description','publicDescription','public_description','detailText','detail_text','details','detail','extraDetails','extra_details','notes','publicPost','public_post','text','content','url','listingUrl','listing_url','createdAt','created_at','publishedAt','published_at','archivedAt','archived_at','updatedAt','updated_at','image','images','imageUrls','image_urls','imageLinks','image_links','photoUrl','photo_url','photoUrls','photo_urls','photoLinks','photo_links','photos','pictures','publishedImageUrl','thumbnailUrl','thumbnail_url','imageDataUrls','imageDataUrl','photoDataUrls','owner','seller','contact','contactInfo','contact_info','customer','ownerName','owner_name','ownerSurname','owner_surname','ownerFullName','owner_full_name','sellerName','seller_name','customerName','customer_name','clientName','client_name','contactName','contact_name','name','phone','phones','ownerPhone','owner_phone','sellerPhone','seller_phone','customerPhone','customer_phone','contactPhone','contact_phone','phoneNumber','phone_number','mobile']);
 const addExtra=(source,prefix='')=>{if(!source||typeof source!=='object')return;for(const [k,v] of Object.entries(source)){if(known.has(k)||LISTING_INTERNAL_KEY.test(k)||/^(?:image|images|imageUrls|image_urls|imageLinks|image_links|photoUrl|photo_url|photoUrls|photo_urls|photoLinks|photo_links|photos|pictures|publishedImageUrl|thumbnailUrl|thumbnail_url|imageDataUrls?|photoDataUrls?)$/i.test(k))continue;if(v===null||v===undefined||v==='')continue;let value=listingScalar(v);if(!value&&typeof v==='object'&&!Array.isArray(v)){const nested=[];for(const [nk,nv] of Object.entries(v)){if(LISTING_INTERNAL_KEY.test(nk)||LISTING_PREPARED_TEXT_KEY.test(nk))continue;const sv=listingScalar(nv);if(sv)nested.push((LISTING_FIELD_LABELS[nk]||nk)+': '+sv);}value=nested.join(' · ');}if(!value)continue;const label=LISTING_FIELD_LABELS[k]||(prefix?prefix+' · ':'')+k.replace(/([a-z0-9])([A-Z])/g,'$1 $2').replace(/[_-]+/g,' ').trim();add(label,value);}};
 addExtra(f,'مشخصات تکمیلی');for(const [key,label] of [['property','جزئیات ملک'],['owner','اطلاعات مالک'],['seller','اطلاعات فروشنده'],['contact','اطلاعات تماس'],['contactInfo','اطلاعات تماس'],['contact_info','اطلاعات تماس'],['customer','اطلاعات مشتری']])addExtra(r[key],label);addExtra(r,'اطلاعات تکمیلی');return dedupeListingDetailRows(rows);}
function compactSummaryMoney(value){const raw=String(value??'').trim();if(!raw)return '';const cleaned=raw.replace(/[\s,٬،]/g,'').replace(/تومان|ریال/g,'');if(!/^[۰-۹٠-٩0-9]+$/.test(cleaned))return raw;const n=Number(digits(cleaned));if(!Number.isFinite(n)||n<=0)return raw;const fmt=x=>x.toLocaleString('fa-IR',{maximumFractionDigits:1});if(n>=1e12)return fmt(n/1e12)+' تریلیون';if(n>=1e9)return fmt(n/1e9)+' میلیارد';if(n>=1e6)return fmt(n/1e6)+' میلیون';return fmt(n)+' تومان';}
function listingSummary(r){const f=r.facts&&typeof r.facts==='object'?r.facts:{};const topic=listingTopic(r),rooms=firstText(r.bedrooms,r.rooms,r.roomCount,r.room_count,f.bedrooms,f.rooms,sourceListingValue(r,['تعداد خواب','تعداد اتاق','اتاق']))||'—';const built=firstText(r.buildingArea,r.building_area,r.builtArea,r.built_area,r.area_building,f.builtArea,f.buildingArea,(topic!=='land'?firstText(r.area_sqm,r.area,f.area):''),sourceListingValue(r,['زیربنا','متراژ بنا','متراژ ساختمان','متراژ ساخت']))||'—';const land=firstText(r.landArea,r.land_area,r.land_area_sqm,f.landArea,(topic==='land'?firstText(r.area_sqm,r.area,f.area):''),sourceListingValue(r,['متراژ زمین','مساحت زمین','متراژ کل','مساحت کل']))||'—';const location=firstText(r.neighborhood,r.locationText,r.location_text,r.street,f.neighborhood,f.locationText,f.location,r.location)||'—';const rent=listingTransaction(r)==='rent';const saleInfo=listingSalePriceInfo(r);const dep=firstText(r.deposit,r.deposit_toman,r.rentDeposit,r.rent_deposit,f.deposit,sourceListingValue(r,['ودیعه','مبلغ ودیعه','مبلغ رهن','رهن کامل','رهن']));const rentVal=firstText(r.monthlyRent,r.monthly_rent_toman,r.monthly_rent,r.rent_price,f.monthlyRent,sourceListingValue(r,['اجاره ماهانه','اجاره ماهیانه','مبلغ اجاره','اجاره']));let price='—';if(rent){const parts=[];if(dep)parts.push('رهن '+compactSummaryMoney(dep));if(rentVal)parts.push('اجاره '+compactSummaryMoney(rentVal));price=parts.join(' / ')||'—';}else if(saleInfo.amountToman){price=window.QoqnusListingPresentation.compactToman(saleInfo.amountToman);}else if(saleInfo.rawText){price=saleInfo.rawText;}else if(saleInfo.pricePerMeterToman){price='هر متر '+window.QoqnusListingPresentation.compactToman(saleInfo.pricePerMeterToman);}return {rooms,built,land,location,price,priceSource:saleInfo.source};}
async function appendListingDetailTable(container,r,id){
 const table=document.createElement('table');table.className='listing-details-table qoqnus-audit-table';const tbody=document.createElement('tbody');
 const keep=new Set(['کد پیگیری','وضعیت آگهی','وضعیت ارسال','منبع','نام مالک / رابط','شماره تماس','دسته‌بندی آگهی','نوع معامله','نوع ملک','استان','شهر','محله','موقعیت','خیابان','نشانی ملک','تعداد خواب','متراژ بنا','متراژ زمین','متراژ ثبت‌شده','سال ساخت','طبقه','تعداد طبقات','پارکینگ','انباری','آسانسور','وضعیت سند','کاربری زمین','عرض بر','کابینت','کف‌پوش','گرمایش','سرمایش','قابلیت تبدیل','امکانات','قیمت فروش','قیمت هر متر','ودیعه / رهن','اجاره ماهانه']);
 for(const row of listingFieldRows(r)){const label=String(row.label||'').trim(),value=String(row.value??'').trim();if(!value||(!row.phone&&/^(?:unknown|نامشخص|—|-|شماره تماس ثبت نشده)$/i.test(value))||!keep.has(label))continue;const tr=document.createElement('tr'),th=document.createElement('th'),td=document.createElement('td');th.scope='row';th.textContent=label;if(row.phone){const control=await createRecordCallControl(r,'listing',id||r.id,'تماس با مالک');if(control.tagName!=='A')continue;control.classList.add('qoqnus-detail-call-control');td.append(control);}else td.textContent=cleanPublicSourceText(maskPhoneNumbersInText(value));tr.append(th,td);tbody.append(tr)}
 if(!tbody.childElementCount){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=2;td.textContent='مشخصات تکمیلی برای این آگهی ثبت نشده است.';tr.append(td);tbody.append(tr)}table.append(tbody);container.append(table);
}
function appendDivarOwnerNameEditor(container,r,id){
 const sourceIsDivar=!!normalizeDivarDetailUrl(r.url||r.detailUrl||r.detail_url||r.sourceUrl||r.source_url||r.canonicalUrl||r.canonical_url)||/^divar:/i.test(String(r.id||r.record_uuid||''));
 if(!sourceIsDivar)return;
 const panel=document.createElement('section');panel.className='divar-owner-editor';
 const label=document.createElement('label');label.textContent='نام صاحب آگهی';
 const input=document.createElement('input');input.type='text';input.maxLength=180;input.value=String(firstText(r.ownerName,r.sellerName,r.owner_name,r.contactName)||'');input.placeholder='نام آگهی‌دهنده (قابل ویرایش)';label.append(input);
 const save=addButton('ذخیره نام','primary',async()=>{try{save.disabled=true;const current=await recordById('listing',id);if(!current)throw new Error('آگهی پیدا نشد.');const name=clean(input.value,180);await storeRecord('listing',{...current,ownerName:name,sellerName:name,owner_name:name,updatedAt:Date.now()});const status=panel.querySelector('.status');if(status)status.textContent='نام صاحب آگهی ذخیره شد.';await renderListings();}catch(e){const status=panel.querySelector('.status');if(status)status.textContent=e?.message||'ذخیره نام ناموفق بود.';}finally{save.disabled=false;}});
 save.type='button';const row=document.createElement('div');row.className='button-row';row.append(save);const status=document.createElement('p');status.className='status';panel.append(label,row,status);container.append(panel);
}
function appendListingDescription(container,r){
 // Show actual source description only. Never expose generated Rubika/Eitaa publication text here.
 const description=cleanPublicSourceText(cleanPublicAdTimeMetadata(firstText(r?.description,r?.description_text,r?.extraDetails,r?.extra_details,r?.details,r?.detail,r?.descriptionOriginal,r?.description_original,r?.publicDescription,r?.public_description,r?.text)));
 const section=document.createElement('section');section.className='listing-actual-description';const heading=document.createElement('h4');heading.textContent='توضیحات آگهی';section.append(heading);
 const body=document.createElement('p');body.className='listing-actual-description-text';body.textContent=description||'توضیح مستقلی برای این آگهی ثبت نشده است.';section.append(body);container.append(section);
}
function listingThumbnailSource(r){
 const inlineKeys=['thumbnailDataUrl','thumbnail_data_url','imageDataUrl','image_data_url','localImageDataUrls','imageDataUrls','localPhotos','photoDataUrls','photoDataUrl'];
 const urlKeys=['thumbnailUrl','thumbnail_url','imageUrl','image_url','photoUrl','photo_url','publishedImageUrl','imageUrls','image_urls','imageLinks','image_links','photoUrls','photo_urls','photoLinks','photo_links','image','images','photos','pictures'];
 const candidates=[];
 const add=(v)=>{if(typeof v==='string'){const x=v.trim();if(x)candidates.push(x);return;}if(Array.isArray(v)){for(const x of v)add(x);return;}if(v&&typeof v==='object'){for(const k of ['dataUrl','data_url','thumbnailDataUrl','imageDataUrl','src','url','href','thumbnailUrl','imageUrl','photoUrl','originalUrl'])if(v[k])add(v[k]);}};
 for(const k of inlineKeys)add(r?.[k]);
 for(const k of urlKeys)add(r?.[k]);
 for(const raw of candidates){
  if(/^data:image\/(?:jpeg|jpg|png|webp|gif);base64,[A-Za-z0-9+/=\r\n]+$/i.test(raw)&&raw.length<=5*1024*1024)return raw.replace(/\s/g,'');
  const url=safeHttpUrl(raw);if(url)return url;
 }
 return '';
}
async function completeListingDeal(id,outcome,button){const current=await recordById('listing',id);if(!current)return;const sale=outcome==='sold',statusText=sale?'فروخته شد':'اجاره شد';if(!confirm('وضعیت این آگهی «'+statusText+'» ثبت شود؟\n\nفایل در دفتر فایل و بایگانی ۲ ذخیره می‌شود و از فهرست آگهی‌ها خارج خواهد شد.'))return;if(button)button.disabled=true;try{const now=Date.now(),phones=listingPhoneItems(current),phone=phones[0]?.tel||'',topic=listingTopic(current),property=topic==='land'?'land':topic==='commercial'?'commercial':'villa',fileId='A2-'+String(current.id||id),existing=await recordById('file',fileId),detailText=listingFieldRows(current).map(row=>String(row.label||'')+': '+String(row.value??'')).join('\n'),photoUrls=listingPhotoUrls(current);const file={...(existing||{}),id:fileId,record_uuid:fileId,sourceListingId:String(current.id||id),archiveBucket:2,archiveLabel:'بایگانی ۲',archiveReason:outcome,dealOutcome:outcome,dealOutcomeLabel:statusText,dealClosedAt:now,archivedAt:now,status:'archived',sendStatus:'not_sent',title:firstText(current.title,current.headline,current.code,'ملک معامله‌شده'),detailText,text:detailText,description:firstText(current.description,current.publicDescription,current.detailText,detailText),publicDescription:firstText(current.publicDescription,current.description,detailText),transactionType:sale?'sale':'rent',officeTransactionType:sale?'sale':'rent',propertyType:property==='land'?'زمین و کلنگی':property==='commercial'?'تجاری و سوله':'خانه و ویلا',officePropertyType:property,city:firstText(current.city,current.facts?.city),neighborhood:firstText(current.neighborhood,current.facts?.neighborhood),street:firstText(current.street,current.facts?.street),location:firstText(current.locationText,current.location,current.neighborhood),area_sqm:firstText(current.area_sqm,current.area,current.buildingArea,current.landArea),landArea:firstText(current.landArea,current.area_sqm),buildingArea:firstText(current.buildingArea,current.builtArea,current.area_sqm),rooms:firstText(current.rooms,current.bedrooms,current.facts?.rooms),salePrice:(listingSalePriceInfo(current).amountToman?String(listingSalePriceInfo(current).amountToman):firstText(current.salePrice,current.sale_price,current.price,current.facts?.salePrice)),deposit:firstText(current.deposit,current.deposit_toman,current.facts?.deposit),monthlyRent:firstText(current.monthlyRent,current.monthly_rent,current.rent_price,current.facts?.monthlyRent),pricePerMeter:firstText(current.pricePerMeter,current.price_per_meter),phone,customerPhone:phone,phones:phones.map(p=>p.tel),ownerName:firstText(current.ownerName,current.owner_name,current.sellerName,current.customerName,current.contactName),customerName:firstText(current.customerName,current.ownerName,current.sellerName,current.contactName),imageUrls:photoUrls,imageDataUrls:[],imagesProvided:photoUrls.length,createdAt:Number(existing?.createdAt)||recordTimestamp(current)||now,updatedAt:now,source:'sold-rented-listing',sourceLabel:'منتقل از آگهی معامله‌شده'};await storeRecord('file',file);await storeRecord('listing',{...current,status:'archived',sendStatus:'archived',archiveBucket:2,archiveLabel:'بایگانی ۲',archiveReason:outcome,dealOutcome:outcome,dealOutcomeLabel:statusText,archivedAt:now,updatedAt:now});await renderFiles();await renderListings();alert('انجام شد: فایل در دفتر فایل و بایگانی ۲ ذخیره شد و از فهرست آگهی‌ها خارج شد.');}catch(e){if(button)button.disabled=false;alert('انتقال انجام نشد: '+(e?.message||'خطای نامشخص'));}}
function setListingActionIcon(button,iconName,label){if(!button)return button;const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.setAttribute('focusable','false');svg.classList.add('qoqnus-listing-action-svg');const add=(tagName,attrs)=>{const node=document.createElementNS(ns,tagName);for(const [key,value] of Object.entries(attrs))node.setAttribute(key,String(value));svg.append(node);};if(iconName==='more'){for(const y of [5,12,19])add('circle',{cx:12,cy:y,r:1.65,fill:'currentColor',stroke:'none'});}else if(iconName==='check'){add('path',{d:'M5 12.5 9.5 17 19 7.5'});}else if(iconName==='bookmark'){add('path',{d:'M6 4.5h12v16l-6-4-6 4z'});}else if(iconName==='bookmark-check'){add('path',{d:'M6 4.5h12v16l-6-4-6 4z'});add('path',{d:'m8.5 10.5 2.2 2.2 4.8-4.8'});}else if(iconName==='trash'){add('path',{d:'M4 7h16M9 7V4.5h6V7m-9 0 1 13h10l1-13M10 11v5m4-5v5'});}else if(iconName==='eye'){add('path',{d:'M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12Z'});add('circle',{cx:12,cy:12,r:2.5});}else if(iconName==='chevron-up'){add('path',{d:'m6 14 6-6 6 6'});}button.replaceChildren(svg);button.classList.add('qoqnus-listing-icon-action');button.setAttribute('aria-label',label);button.setAttribute('title',label);button.dataset.listingIconAction=iconName;button.type='button';return button;}
async function refreshListingSyncAuditExportButton(){
 const button=$('downloadListingSyncAuditReport');
 if(!button)return;
 try{const audit=await getMetaObj('lastListingSyncAudit',null);button.classList.toggle('hidden',!(audit&&Number(audit.at)>0));}
 catch(error){button.classList.add('hidden');console.warn('qoqnus listing audit button state unavailable:',error?.message||error);}
}
async function downloadListingSyncAuditReport(){
 const audit=await getMetaObj('lastListingSyncAudit',null);
 if(!audit||!Number(audit.at))throw new Error('گزارش همگام‌سازی هنوز ثبت نشده است. ابتدا یک همگام‌سازی انجام دهید.');
 const rows=(await recordsOf('listing')).map(x=>x.record).filter(r=>r?.finalArchived!==true);
 const local=window.QoqnusListingSyncAudit?QoqnusListingSyncAudit.summarizeRows(rows):{total:rows.length,visible:rows.length,hidden:0};
 const fileRows=await recordsOf('file');
 const report={schema:'qoqnus.listing-sync-audit.v1',createdAt:Date.now(),appVersion:APP_VERSION,audit:{...audit},counts:{localListingCount:local.total,visibleListingCount:local.visible,hiddenListingCount:local.hidden,localFileCount:fileRows.length}};
 const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download='qoqnus-listing-sync-audit-'+new Date().toISOString().slice(0,10)+'.json';a.click();
 setTimeout(()=>URL.revokeObjectURL(url),10000);
}

async function renderListings(){
 let rows=(await recordsOf('listing')).map(x=>x.record);
 // Normalize existing legacy sale listings once in the encrypted local store.
 // Original fields stay untouched; only a versioned, local-derived total is added.
 if(window.QoqnusListingPresentation){
  if(!listingPriceNormalizationPromise){
   listingPriceNormalizationPromise=(async()=>{
    let normalizedCount=0;
    for(const record of rows){
     if(listingTransaction(record)!=='sale')continue;
     const normalized=window.QoqnusListingPresentation.normalizeRecord(record,{transaction:'sale',topic:listingTopic(record),probe:listingPriceProbe(record)});
     if(normalized!==record){await storeRecord('listing',normalized);normalizedCount++;}
    }
    return normalizedCount>0;
   })().catch(error=>{listingPriceNormalizationPromise=null;console.error('qoqnus legacy listing price normalization failed',error);setStatus('storageStatus','محاسبه و ذخیرهٔ قیمت کل برخی آگهی‌های قدیمی انجام نشد؛ اطلاعات اصلی حفظ شده‌اند.','warn');return false;});
  }
  const didNormalize=await listingPriceNormalizationPromise;
  if(didNormalize)rows=(await recordsOf('listing')).map(x=>x.record);
 }
 syncDashboardCounters();
 const search=normalizeText($('listingSearch').value),period=$('listingPeriodFilter').value,transaction=document.querySelector('input[name="listingTransactionFilter"]:checked')?.value||'all',saleTopic=$('listingSaleTopicFilter').value,rentTopic=$('listingRentTopicFilter').value,topic=transaction==='rent'?rentTopic:(transaction==='sale'?saleTopic:'all'),status=$('listingStatusFilter').value,area=normalizeText($('listingAreaFilter').value),minPrice=Number(digits($('listingMinPrice').value).replace(/[^0-9]/g,''))||0,maxPrice=Number(digits($('listingMaxPrice').value).replace(/[^0-9]/g,''))||0;
 const filtered=rows.filter(r=>{if(Number(r.archiveBucket)===2||['sold','rented'].includes(String(r.dealOutcome||r.archiveReason||'')))return false;const st=listingStatus(r),text=[r.title,r.code,r.trackingCode,r.tracking_code,r.trackingId,r.tracking_id,r.archiveCode,r.archive_code,r.referenceId,r.reference_id,r.id,r.ownerName,r.owner_name,r.owner_name_full,r.ownerFullName,r.owner_full_name,r.sellerName,r.seller_name,r.seller?.name,r.owner?.name,r.contact?.name,r.contactInfo?.name,r.contact_info?.name,r.customerName,r.customer_name,r.contactName,r.contact_name,r.clientName,r.client_name,r.name,...listingPhoneItems(r).map(p=>p.text),r.address,r.propertyAddress,r.property_address,r.locationText,r.location_text,r.addressLine,r.address_line,r.formattedAddress,r.formatted_address,r.property?.address,r.fullAddress,r.full_address,r.addressText,r.address_text,r.street,r.location,r.city,r.neighborhood,r.description,r.publicDescription,r.detailText,r.details,r.detail,r.notes,r.publicPost,r.text,r.content,r.propertyType,r.property_type,r.transactionType,r.transaction_type,r.tags].flat().join(' '),prices=listingFilterPrices(r),priceMatch=(!minPrice&&!maxPrice)||(prices.length>0&&prices.some(v=>(!minPrice||v>=minPrice)&&(!maxPrice||v<=maxPrice)));return (!search||normalizeText(text).includes(search))&&matchesPeriod(r,period)&&listingTransactionMatches(r,transaction)&&(topic==='all'||topicMatches(r,topic,'listing'))&&(status==='all'||st===status)&&(!area||normalizeText([r.address,r.exactAddress,r.street,r.location,r.city,r.neighborhood,r.facts?.location,r.facts?.neighborhood].join(' ')).includes(area))&&priceMatch;});
 $('listingCount').textContent=displayCount(filtered.length);
 const list=$('listingList'),scrollAnchor=captureTimeGroupScrollAnchor(list,'listing'),opened=new Set([...list.querySelectorAll('[data-listing-details]:not([hidden])')].map(x=>String(x.dataset.listingDetails)));list.replaceChildren();if(!filtered.length)list.append(emptyBox('آگهی‌ای با این فیلترها پیدا نشد.'));const groupedSections=filtered.length?buildTimeGroupedSections(list,filtered,'listing',Date.now()):[];
 for(const section of groupedSections){for(const r of section.group.records){const id=String(r.id||r.code||r.trackingCode||uuid()),transactionType=listingTransaction(r),topicKey=listingTopic(r),summary=listingSummary(r),title=compactListingTitle(r),a=document.createElement('article');a.className='record-card source-qoqnus-card qoqnus-property-card qoqnus-listing-card '+(transactionType==='rent'?'listing-rent-card':transactionType==='sale'?'listing-sale-card':'');a.dataset.listingCardId=id;
 const call=await createRecordCallControl(r,'listing',id,'تماس با مالک');
 const areaRaw=summary.land!=='—'?summary.land:summary.built,areaLabel=areaRaw&&areaRaw!=='—'?areaRaw+' متر':'';
 const locationText=firstText(r.neighborhood,r.locationText,r.location_text,r.street,r.facts?.neighborhood,r.facts?.location);
 const createdAt=recordCreatedTimestamp(r),lastFollowUp=recordLastActionTimestamp(r,'listing');
 const features=compactFeatureList(r);
 const summaryBody=createPropertyCardSummary(r,'listing',id,{title,areaLabel,priceLabel:summary.price&&summary.price!=='—'?summary.price:'',locationText,lastFollowUp:recordTimeLabel(lastFollowUp,'هنوز پیگیری نشده'),createdLabel:createdAt?localDateLabel(createdAt):'',ownerName:firstText(r.ownerName,r.owner_name,r.ownerFullName,r.owner_full_name,r.sellerName,r.seller_name,r.seller?.name,r.owner?.name,r.contact?.name,r.customerName,r.customer_name),features,callControl:call,badges:buildPropertyCardBadges(r,'listing',transactionType,topicKey,title)});
 a.append(summaryBody);
 let moreButton=null;const detail=document.createElement('section');detail.className='listing-expanded-details qoqnus-listing-audit';detail.dataset.listingDetails=id;detail.hidden=!opened.has(id);
 const setDetailOpen=open=>{detail.hidden=!open;if(moreButton){moreButton.setAttribute('aria-expanded',String(open));setListingActionIcon(moreButton,'more',open?'جزئیات باز است؛ برای بستن از فلش بالا یا پایین استفاده کنید':'نمایش جزئیات آگهی');}};
 const makeCollapseControl=position=>{const wrap=document.createElement('div');wrap.className='qoqnus-listing-detail-collapse qoqnus-listing-detail-collapse--'+position;const button=addButton('بستن اطلاعات بیشتر','muted',()=>setDetailOpen(false));button.classList.add('qoqnus-detail-collapse-icon');setListingActionIcon(button,'chevron-up','بستن اطلاعات بیشتر همین آگهی');wrap.append(button);return wrap;};
 detail.append(makeCollapseControl('top'));await appendListingDetailTable(detail,r,id);appendDivarOwnerNameEditor(detail,r,id);appendListingDescription(detail,r);appendOfficePrivateEditor(detail,'listing',id);const divarLink=normalizeDivarDetailUrl(r.url||r.detailUrl||r.detail_url||r.listingUrl||r.listing_url||r.sourceUrl||r.source_url||r.canonicalUrl||r.canonical_url||r.originalUrl||r.original_url);if(divarLink){const openDivar=document.createElement('a');openDivar.className='qoqnus-divar-open-link';openDivar.href=divarLink.url;openDivar.target='_blank';openDivar.rel='noopener noreferrer';openDivar.textContent='مشاهدهٔ صفحهٔ مرجع آگهی';detail.append(openDivar);}detail.append(makeCollapseControl('bottom'));a.append(detail);
 const actions=document.createElement('div');actions.className='qoqnus-record-actions qoqnus-listing-actions';const more=addButton('بیشتر','muted',async()=>{const open=detail.hidden;setDetailOpen(open);if(open&&isListingNew(r)){const current=await recordById('listing',id);if(current){await storeRecord('listing',{...current,syncViewedAt:Date.now()});await renderListings();}}});moreButton=more;more.setAttribute('aria-expanded',String(!detail.hidden));setListingActionIcon(more,'more',detail.hidden?'نمایش جزئیات آگهی':'بستن جزئیات آگهی');
 let deal;if(transactionType==='sale'||transactionType==='rent'){deal=addButton(transactionType==='sale'?'فروخته شد':'اجاره شد',transactionType==='sale'?'danger':'warning',()=>completeListingDeal(id,transactionType==='sale'?'sold':'rented',deal));deal.classList.add('qoqnus-deal-action');setListingActionIcon(deal,'check',transactionType==='sale'?'ثبت فروش و انتقال به بایگانی':'ثبت اجاره و انتقال به بایگانی');}else{deal=addButton('وضعیت','muted',()=>{alert('نوع معاملهٔ آگهی مشخص نیست؛ قبل از بستن معامله آن را بررسی کنید.')});deal.disabled=true;setListingActionIcon(deal,'check','وضعیت معامله مشخص نیست');}
 actions.append(more);const needsDivarRead=!!divarLink&&r.mobileReaderState!=='complete'&&r.readerState!=='complete';if(needsDivarRead){let readButton;readButton=addButton('خواندن آگهی','outline',()=>readDivarIntoExistingRecord(id,divarLink.url,readButton));readButton.classList.add('qoqnus-action-button','qoqnus-divar-read-button');setListingActionIcon(readButton,'eye','خواندن آگهی');actions.append(readButton);}actions.append(deal);const finalSaved=!!(r.finalSaved||r.final_saved||r.finalizedAt);const finalSaveButton=addButton(finalSaved?'ذخیره نهایی شد':'ذخیره نهایی',finalSaved?'success':'primary',async()=>{try{finalSaveButton.disabled=true;const current=await recordById('listing',id);if(!current)throw new Error('آگهی پیدا نشد.');const now=Date.now();await storeRecord('listing',{...current,finalSaved:true,final_saved:true,finalizedAt:current.finalizedAt||now,status:'saved',sendStatus:'not_sent',updatedAt:now});await renderListings();setStatus('storageStatus','ذخیره نهایی آگهی ثبت شد و در صف همگام‌سازی سرور قرار گرفت.','success');}catch(e){setStatus('storageStatus',e?.message||'ذخیره نهایی انجام نشد.','error');}finally{finalSaveButton.disabled=false;}});finalSaveButton.classList.add('qoqnus-final-save-button');finalSaveButton.disabled=finalSaved;setListingActionIcon(finalSaveButton,finalSaved?'bookmark-check':'bookmark',finalSaved?'ذخیره نهایی انجام شده':'ذخیره نهایی آگهی');actions.append(finalSaveButton);const isDivarImported=!!divarLink||/^divar:/i.test(String(r.id||r.record_uuid||''))||/divar|دیوار/i.test([r.source,r.sourceLabel,r.source_label,r.origin,r.originLabel,r.collectedFrom].map(v=>String(v||'')).join(' '));if(isDivarImported){const del=addButton('حذف آگهی','danger',()=>deleteLocalRecord('listing',id));del.classList.add('qoqnus-divar-delete-button');del.title='حذف آگهی از این گوشی و ارسال نشانهٔ حذف در همگام‌سازی بعدی';setListingActionIcon(del,'trash','حذف آگهی و ثبت نشانهٔ حذف برای همگام‌سازی');actions.append(del);}a.append(actions);section.body.append(a);
 }}
 restoreTimeGroupScrollAnchor(list,scrollAnchor);
}
async function renderConflicts(){
 const root=$('conflictList');if(!root)return;
 const rows=(await recordsOf('conflict')).map(x=>x.record).sort((a,b)=>(Number(b.createdAt)||0)-(Number(a.createdAt)||0));
 root.replaceChildren();root.classList.toggle('hidden',rows.length===0);
 for(const c of rows){
  const card=document.createElement('article');card.className='record-card qoqnus-conflict-card';
  const heading=document.createElement('h3');heading.textContent='تعارض در '+({'customer':'پروندهٔ مشتری','file':'فایل دفتر','listing':'آگهی','contact':'اطلاعات تماس'}[String(c.kind||'')]||'اطلاعات') ;card.append(heading);
  const remote=c.remoteRecord&&typeof c.remoteRecord==='object'?c.remoteRecord:{};
  const local=c.localRecord&&typeof c.localRecord==='object'?c.localRecord:{};
  const title=firstText(remote.title,remote.headline,remote.name,remote.ownerName,local.title,local.headline,local.name,local.ownerName,c.recordId,'بدون عنوان');
  const details=document.createElement('p');details.textContent='پروندهٔ «'+String(title)+'» در این گوشی و دستگاه مقابل متفاوت است. یکی از نسخه‌ها را انتخاب کنید.';card.append(details);
  const time=document.createElement('small');time.className='hint';time.textContent='ثبت تعارض: '+localDateLabel(c.createdAt);card.append(time);
  const status=document.createElement('p');status.className='status';status.setAttribute('aria-live','polite');card.append(status);
  const actions=document.createElement('div');actions.className='button-row conflict-actions';
  const localButton=document.createElement('button');localButton.type='button';localButton.className='outline';localButton.textContent='حفظ نسخهٔ این گوشی';
  const remoteButton=document.createElement('button');remoteButton.type='button';remoteButton.className='primary';remoteButton.textContent='جایگزینی با نسخهٔ مقابل';
  const run=async(choice,button)=>{localButton.disabled=true;remoteButton.disabled=true;status.textContent='در حال اعمال انتخاب…';try{await resolveConflict(c.id,choice);}catch(e){status.textContent=e?.message||'حل تعارض ناموفق بود.';status.className='status error';localButton.disabled=false;remoteButton.disabled=false;}};
  localButton.addEventListener('click',()=>run('local',localButton));remoteButton.addEventListener('click',()=>run('remote',remoteButton));actions.append(localButton,remoteButton);card.append(actions);root.append(card);
 }
}

async function toggleSpecialRecord(kind,id){
 if(!['customer','file'].includes(String(kind)))return;
 const current=await recordById(String(kind),String(id));if(!current)return;
 const next={...current,qoqnusSpecial:!Boolean(current.qoqnusSpecial),updatedAt:Date.now()};
 await storeRecord(String(kind),next);
 if(kind==='customer')await renderCustomers();else await renderFiles();
 await renderDashboardHighlights();
 setStatus('storageStatus',next.qoqnusSpecial?'پرونده به بخش ویژه‌ها اضافه شد.':'پرونده از بخش ویژه‌ها برداشته شد.','success');
}
function dashboardHighlightCard(kind,r){
 const id=String(r.id||''),card=document.createElement('article');card.className='dashboard-highlight-card';
 const title=document.createElement('strong');title.className='dashboard-highlight-title';title.textContent=kind==='customer'?String(r.name||'مشتری بدون نام'):String(firstText(r.title,r.ownerName,'فایل بدون عنوان'));card.append(title);
 const parts=[];
 if(kind==='customer'){
  const request=customerRequestSummary(r);if(request)parts.push(request);
  const location=firstText(r.neighborhood,r.street);if(location)parts.push(location);
  const budget=r.type==='tenant'?[r.deposit?'رهن '+shortDisplayMoney(r.deposit):'',r.rent?'اجاره '+shortDisplayMoney(r.rent):''].filter(Boolean).join(' / '):((r.min||r.max)?'بودجه '+(r.min?'از '+shortDisplayMoney(r.min):'')+(r.min&&r.max?' تا ':'')+(r.max?shortDisplayMoney(r.max):''):'');if(budget)parts.push(budget);
  parts.push(recordTimeLabel(recordLastActionTimestamp(r,'customer'),'هنوز تماسی ثبت نشده'));
 }else{
  const tx=String(r.officeTransactionType||r.transactionType||'');const txLabel=tx==='rent'?'اجاره':tx==='sale'?'خرید':'';const property=String(r.officePropertyType||r.propertyType||'');const propertyLabel=property==='land'?'زمین':property==='villa'?'ویلایی':property==='commercial'?'تجاری':property;
  const type=[txLabel,propertyLabel].filter(Boolean).join(' · ');if(type)parts.push(type);
  const area=firstText(r.landArea,r.area_sqm,r.area,r.buildingArea);if(area)parts.push(area+' متر');
  const price=tx==='rent'?[r.deposit?'رهن '+shortDisplayMoney(r.deposit):'',r.monthlyRent?'اجاره '+shortDisplayMoney(r.monthlyRent):''].filter(Boolean).join(' / '):shortDisplayMoney(r.salePrice||r.price);if(price)parts.push(price);
  const location=firstText(r.neighborhood,r.location,r.street);if(location)parts.push(location);
  parts.push(recordTimeLabel(recordLastActionTimestamp(r,'file'),'هنوز پیگیری نشده'));
 }
 const meta=document.createElement('div');meta.className='dashboard-highlight-meta';meta.textContent=parts.filter(Boolean).join(' · ');card.append(meta);
 const open=document.createElement('button');open.type='button';open.className='outline dashboard-highlight-open';open.textContent='بازکردن پرونده';open.addEventListener('click',()=>{
  const view=kind==='customer'?'customers':'files';activateView(view);const selector=kind==='customer'?'[data-customer-card-id]':'[data-office-file-id]';const found=[...document.querySelectorAll('#view-'+view+' '+selector)].find(el=>(kind==='customer'?el.dataset.customerCardId:el.dataset.officeFileId)===id);
  if(found){const more=found.querySelector('.qoqnus-record-actions button');more?.click();found.scrollIntoView({behavior:'smooth',block:'center'});}
 });card.append(open);return card;
}
async function renderDashboardHighlights(){
 const filesRoot=$('dashboardSpecialFiles'),customersRoot=$('dashboardSpecialCustomers');if(!filesRoot||!customersRoot)return;
 const [fileRows,customerRows]=await Promise.all([recordsOf('file'),recordsOf('customer')]);
 const fill=(root,rows,kind,label)=>{root.replaceChildren();const selected=rows.map(x=>x.record).filter(r=>r&&r.finalArchived!==true&&r.qoqnusSpecial===true).sort((a,b)=>(Number(b.updatedAt)||Number(b.createdAt)||0)-(Number(a.updatedAt)||Number(a.createdAt)||0)).slice(0,4);if(!selected.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='هنوز '+label+' ویژه‌ای ثبت نشده است.';root.append(empty);return;}for(const r of selected)root.append(dashboardHighlightCard(kind,r));};
 fill(filesRoot,fileRows,'file','فایل');fill(customersRoot,customerRows,'customer','مشتری');
}
function addDashboardSpecialSections(){
 const review=document.querySelector('#view-dashboard .dashboard-review');if(!review||$('dashboardSpecialSections'))return;
 const wrap=document.createElement('section');wrap.id='dashboardSpecialSections';wrap.className='dashboard-featured-grid';wrap.setAttribute('aria-label','پرونده‌های ویژه');
 for(const spec of [{id:'dashboardSpecialFiles',title:'فایل‌های ویژه',hint:'فایل‌های علامت‌گذاری‌شده'},{id:'dashboardSpecialCustomers',title:'مشتریان ویژه',hint:'مشتریان علامت‌گذاری‌شده'}]){
  const section=document.createElement('section');section.className='dashboard-special-section';const heading=document.createElement('div');heading.className='dashboard-special-heading';const h=document.createElement('h3');h.textContent=spec.title;const hint=document.createElement('span');hint.textContent=spec.hint;heading.append(h,hint);const list=document.createElement('div');list.className='dashboard-highlight-list';list.id=spec.id;section.append(heading,list);wrap.append(section);
 }
 review.parentNode.insertBefore(wrap,review);
}
function setupCompactOfficeViews(){
 const configs=[
  {view:'customers',title:'دفتر مشتریان',form:'customerForm',formTitle:'customerEntryTitle',filterNodes:['customerSearchForm','customerAdvancedToggle','customerAdvancedFilters']},
  {view:'files',title:'دفتر فایل',form:'fileForm',formTitle:'fileEntryTitle',filterNodes:['fileSearchForm','fileAdvancedToggle','fileAdvancedFilters']},
  {view:'listings',title:'دفتر آگهی‌ها',filterNodes:['listingAdvancedToggle','listingAdvancedFilters']}
 ];
 for(const cfg of configs){
  const root=$('view-'+cfg.view),head=root?.querySelector('.section-head');if(!root||!head)continue;
  const copy=head.querySelector('p');copy?.remove();head.classList.add('qoqnus-office-section-head');const count=head.querySelector('.count');if(count)count.classList.add('office-header-count-hidden');
  if(!head.querySelector('.office-filter-toggle')){const button=document.createElement('button');button.type='button';button.className='outline office-filter-toggle';button.textContent='فیلترها';button.setAttribute('aria-expanded','false');button.setAttribute('aria-controls',cfg.view+'OfficeFilters');head.append(button);}
  let panel=$(cfg.view+'OfficeFilters');if(!panel){panel=document.createElement('div');panel.id=cfg.view+'OfficeFilters';panel.className='office-filter-panel hidden';panel.setAttribute('aria-label','فیلترهای '+cfg.title);head.insertAdjacentElement('afterend',panel);}
  for(const id of cfg.filterNodes){const node=$(id);if(node){if(/AdvancedToggle$/.test(id))node.classList.add('office-filter-inner-toggle-hidden');if(/AdvancedFilters$/.test(id))node.classList.remove('hidden');panel.append(node);}}
  const button=head.querySelector('.office-filter-toggle');button.onclick=()=>{const open=panel.classList.contains('hidden');panel.classList.toggle('hidden',!open);button.setAttribute('aria-expanded',String(open));};
  if(cfg.form){const form=$(cfg.form);if(form){form.classList.add('hidden');let toolbar=form.querySelector('.qoqnus-entry-toolbar');if(!toolbar){toolbar=document.createElement('div');toolbar.className='qoqnus-entry-toolbar';const title=document.createElement('h3');title.id=cfg.formTitle;title.textContent=cfg.view==='customers'?'افزودن مشتری':'افزودن فایل';const close=document.createElement('button');close.type='button';close.className='outline qoqnus-entry-close';close.textContent='بستن فرم';close.addEventListener('click',()=>{if(quickEntryMode&&quickFormContext?.form===form)cancelQuickEntryForm();else form.classList.add('hidden');});toolbar.append(title,close);form.prepend(toolbar);}}}
 }
 // The reader/link form remains available from the home action, but is not a permanent block in the list.
 for(const id of ['divarShareManualForm','divarShareStatus','.qoqnus-reader-corner-hint']){const node=id.startsWith('.')?document.querySelector(id):$(id);node?.classList.add('hidden');}
 addDashboardSpecialSections();
}

async function renderAll(forceReminderCheck=false){await ensureDailyCustomerFollowupNotifications(forceReminderCheck).catch(error=>console.error('Qoqnus reminders unavailable',error));const results=await Promise.allSettled([renderCustomers(),renderFiles(),renderListings(),renderDashboardHighlights(),renderConflicts(),renderNotifications()]);for(const result of results)if(result.status==='rejected')console.error('Qoqnus view render failed',result.reason);const rows=await recordsOf();$('storageStatus').textContent='ذخیرهٔ محلی رمزگذاری‌شده فعال است · '+displayCount(rows.length)+' رکورد';syncDashboardCounters();}
async function editCustomer(id){const r=await recordById('customer',id);if(!r)return;$('customerForm').classList.remove('hidden');if($('customerEntryTitle'))$('customerEntryTitle').textContent='ویرایش مشتری';$('customerEditId').value=r.id;$('customerName').value=r.name||'';$('customerPhone').value=r.phone||'';const radio=document.querySelector(`input[name="customerType"][value="${r.type}"]`);if(radio)radio.checked=true;$('customerMin').value=r.min||'';$('customerMax').value=r.max||'';$('customerDeposit').value=r.deposit||'';$('customerRent').value=r.rent||'';$('customerProperty').value=canonicalCustomerProperty(r.propertyType||'');document.querySelectorAll('input[name="customerPropertyChoice"]').forEach(x=>x.checked=x.value===$('customerProperty').value);$('customerNeighborhood').value=r.neighborhood||'';$('customerStreet').value=r.street||'';$('customerArea').value=r.desiredArea||'';$('customerNotes').value=r.notes||'';pendingCustomerPhotoWebp=customerPhotoValue(r);updateCustomerPhotoPreview(pendingCustomerPhotoWebp,pendingCustomerPhotoWebp?'تصویر فعلی حفظ می‌شود؛ برای حذف یا جایگزینی از دکمه‌های بالا استفاده کنید.':'این مشتری هنوز تصویر اختصاصی ندارد.');$('customerConfirm').checked=false;$('saveCustomer').textContent='ذخیرهٔ تغییرات';syncConditionalFields();$('customerForm').scrollIntoView({behavior:'smooth',block:'start'})}
async function editFile(id){const r=await recordById('file',id);if(!r)return;$('fileForm').classList.remove('hidden');if($('fileEntryTitle'))$('fileEntryTitle').textContent='ویرایش فایل';$('fileEditId').value=r.id;$('fileName').value=r.ownerName||r.customerName||'';$('filePhone').value=r.phone||r.customerPhone||'';const transaction=r.officeTransactionType||r.transactionType||'sale',radio=document.querySelector(`input[name="fileTransaction"][value="${transaction}"]`);if(radio)radio.checked=true;$('fileProperty').value=r.officePropertyType||'villa';document.querySelectorAll('input[name="filePropertyChoice"]').forEach(x=>x.checked=x.value===$('fileProperty').value);$('fileTitle').value=r.title||'';$('fileNeighborhood').value=r.neighborhood||'';$('fileStreet').value=r.street||'';$('fileArea').value=r.area_sqm||r.landArea||'';$('fileBuiltArea').value=r.buildingArea||'';$('fileSalePrice').value=r.salePrice||'';$('filePricePerMeter').value=r.pricePerMeter||'';$('fileDeposit').value=r.deposit||'';$('fileMonthlyRent').value=r.monthlyRent||'';$('fileRooms').value=String(r.rooms??'0');document.querySelectorAll('input[name="fileRoomsChoice"]').forEach(x=>x.checked=String(r.rooms??'0')===x.value);$('fileYear').value=r.year||'';$('fileLandUse').value=r.landUse||'';$('fileFrontage').value=r.frontage||'';$('fileCommercialKind').value=r.commercialKind||'';$('fileCommercialUse').value=r.commercialUse||'';$('fileDeed').value=r.deed||'';$('fileAccess').value=r.access||'';$('fileKitchen').value=r.kitchen||'';$('fileFlooring').value=r.flooring||'';hydrateHvacChoices('fileHeatingChoice','fileHeating','fileHeatingOther',r.heating||'');hydrateHvacChoices('fileCoolingChoice','fileCooling','fileCoolingOther',r.cooling||'');$('fileConvertible').value=r.convertible===true?'yes':r.convertible===false?'no':'unknown';$('fileAmenities').value=Array.isArray(r.amenities)?r.amenities.join('، '):'';$('fileNotes').value=r.notes||'';$('filePhotos').value='';$('fileConfirm').checked=false;$('saveFile').textContent='ذخیرهٔ تغییرات';syncConditionalFields();$('fileForm').scrollIntoView({behavior:'smooth',block:'start'});setStatus('fileStatus',Array.isArray(r.imageDataUrls)&&r.imageDataUrls.length?'عکس‌های قبلی حفظ می‌شوند؛ انتخاب عکس جدید آن‌ها را جایگزین می‌کند.':'');}

$('divarShareManualForm').addEventListener('submit',async e=>{e.preventDefault();const raw=$('divarShareUrl').value,link=normalizeDivarDetailUrl(raw),button=$('divarShareManualForm').querySelector('button[type=submit]');if(!link){setStatus('divarShareStatus','پیوند باید مستقیم به صفحهٔ آگهی باشد؛ قالب /v/شناسه یا /v/عنوان/شناسه را وارد کنید.','error');return;}if(!cryptoKey){setStatus('divarShareStatus','ابتدا دفتر ققنوس را باز کنید.','error');return;}const oldLabel=button?.textContent;if(button){button.disabled=true;button.textContent='در حال ذخیرهٔ لینک…';}try{await receiveDivarReaderRecord({url:link.url,title:'',source:'mobile-share-target',sourceLabel:'پیوند آگهی ثبت‌شده از فرم گوشی',collectedFrom:'manual-mobile-url',readerState:'link_only',status:'saved',sendStatus:'not_sent',reviewStatus:'not_required',publicationState:'not_sent'});setStatus('divarShareStatus','پیوند آگهی ذخیره شد؛ برای دریافت مشخصات کامل، روی «خواندن آگهی» در کارت همان فایل بزنید.','warn');$('divarShareUrl').value='';}catch(err){setStatus('divarShareStatus',err?.message||'ذخیرهٔ آگهی ناموفق بود.','error');}finally{if(button){button.disabled=false;button.textContent=oldLabel||'ثبت پیوند آگهی';}}});
$('customerSearchForm').addEventListener('submit',e=>{e.preventDefault();appliedCustomerSearchText=$('customerSearch').value;appliedCustomerSearchRole=document.querySelector('input[name="customerSearchRole"]:checked')?.value||'all';$('customerFilter').value=appliedCustomerSearchRole;appliedCustomerSearchFields=collectCustomerSearchFields();renderCustomers();});
$('resetCustomerSearch').addEventListener('click',()=>{$('customerSearch').value='';document.querySelectorAll('input[name="customerSearchRole"]').forEach(x=>x.checked=x.value==='all');document.querySelectorAll('input[name="customerSearchField"]').forEach(x=>x.checked=['name','phone'].includes(x.value));$('customerFilter').value='all';appliedCustomerSearchText='';appliedCustomerSearchRole='all';appliedCustomerSearchFields=['name','phone'];$('customerPeriodFilter').value='all';$('customerTopicFilter').value='all';$('customerAreaFilter').value='';renderCustomers();});
$('fileSearchForm').addEventListener('submit',e=>{e.preventDefault();appliedFileSearchText=$('fileSearch').value;appliedFileCriteria=collectFileSearchCriteria();const tx=appliedFileCriteria.transaction;$('fileFilter').value=tx.length===1?tx[0]:'all';renderFiles();});
$('resetFileSearch').addEventListener('click',()=>{$('fileSearch').value='';document.querySelectorAll('input[name="fileTransactionCriteria"],input[name="filePropertyCriteria"],input[name="fileRoomsCriteria"],input[name="fileHvacCriteria"]').forEach(x=>x.checked=false);appliedFileSearchText='';appliedFileCriteria={transaction:[],property:[],rooms:[],hvac:[]};$('fileFilter').value='all';$('filePeriodFilter').value='all';$('fileTopicFilter').value='all';$('fileStatusFilter').value='all';renderFiles();});
document.querySelectorAll('input[name="fileRoomsChoice"]').forEach(x=>x.addEventListener('change',()=>{if(x.checked)document.querySelectorAll('input[name="fileRoomsChoice"]').forEach(y=>{if(y!==x)y.checked=false;});$('fileRooms').value=selectedBedroomCount();}));
for(const [group,hidden,other] of [['fileHeatingChoice','fileHeating','fileHeatingOther'],['fileCoolingChoice','fileCooling','fileCoolingOther']]){document.querySelectorAll('input[name="'+group+'"]').forEach(x=>x.addEventListener('change',()=>updateHvacChoiceValue(group,hidden,other)));$(other).addEventListener('input',()=>updateHvacChoiceValue(group,hidden,other));}
$('customerFilter').addEventListener('change',renderCustomers);$('fileFilter').addEventListener('change',renderFiles);
for(const id of ['customerPeriodFilter','customerTopicFilter','customerAreaFilter'])$(id).addEventListener(id.endsWith('Filter')?'change':'input',renderCustomers);
for(const id of ['filePeriodFilter','fileTopicFilter','fileStatusFilter'])$(id).addEventListener('change',renderFiles);
for(const id of ['listingSearch','listingMinPrice','listingMaxPrice','listingAreaFilter'])$(id).addEventListener('input',renderListings);for(const id of ['listingPeriodFilter','listingSaleTopicFilter','listingRentTopicFilter','listingStatusFilter'])$(id).addEventListener('change',renderListings);document.querySelectorAll('input[name="listingTransactionFilter"]').forEach(el=>el.addEventListener('change',()=>{const tx=document.querySelector('input[name="listingTransactionFilter"]:checked')?.value||'all';$('listingSaleTopicWrap').classList.toggle('hidden',tx!=='sale');$('listingRentTopicWrap').classList.toggle('hidden',tx!=='rent');renderListings();}));
setupCompactOfficeViews();
for(const [toggleId,panelId] of [['customerAdvancedToggle','customerAdvancedFilters'],['fileAdvancedToggle','fileAdvancedFilters'],['listingAdvancedToggle','listingAdvancedFilters']])$(toggleId).addEventListener('click',()=>{const panel=$(panelId),open=panel.classList.contains('hidden');panel.classList.toggle('hidden',!open);$(toggleId).setAttribute('aria-expanded',open?'true':'false');$(toggleId).textContent=(open?'بستن جست‌وجوی پیشرفته ▴':'جست‌وجوی پیشرفته ▾');});
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>activateView(b.dataset.view)));document.querySelectorAll('.mobile-nav-item[data-mobile-view]').forEach(b=>b.addEventListener('click',()=>activateView(b.dataset.mobileView)));
document.querySelectorAll('[data-home-action]').forEach(button=>button.addEventListener('click',()=>{const action=button.dataset.homeAction;switch(action){case 'customers':activateView('customers');break;case 'files':activateView('files');break;case 'listings':activateView('listings');break;case 'register-file':activateView('files');showEntryForm('file','new');break;case 'register-customer':activateView('customers');showEntryForm('customer','new');break;case 'read-listing':activateView('listings');$('divarShareManualForm')?.classList.remove('hidden');$('divarShareStatus')?.classList.remove('hidden');$('divarShareManualForm')?.scrollIntoView({behavior:'smooth',block:'center'});$('divarShareUrl')?.focus({preventScroll:true});break;case 'sync':activateView('sync');break;case 'notifications':toggleNotificationPanel();break;}}));
$('notificationsButton')?.addEventListener('click',toggleNotificationPanel);$('closeNotificationsButton')?.addEventListener('click',closeNotificationPanel);$('notificationBackdrop')?.addEventListener('click',closeNotificationPanel);$('markAllNotificationsRead')?.addEventListener('click',()=>markAllNotificationsRead().catch(error=>setStatus('storageStatus',String(error?.message||error),'error')));$('clearReadNotifications')?.addEventListener('click',()=>clearReadNotifications().catch(error=>setStatus('storageStatus',String(error?.message||error),'error')));$('downloadListingSyncAuditReport')?.addEventListener('click',()=>downloadListingSyncAuditReport().catch(error=>setSyncFeedback(String(error?.message||error),'error')));
function openAppMenu(){const panel=$('appMenuDrawer'),backdrop=$('appMenuBackdrop');panel?.classList.remove('hidden');backdrop?.classList.remove('hidden');$('mobileMoreButton')?.setAttribute('aria-expanded','true');document.body.classList.add('app-menu-open');if($('appMenuSearch'))$('appMenuSearch').value='';filterAppMenu('');panel?.focus();}
function closeAppMenu(){ $('appMenuDrawer')?.classList.add('hidden');$('appMenuBackdrop')?.classList.add('hidden');$('mobileMoreButton')?.setAttribute('aria-expanded','false');document.body.classList.remove('app-menu-open');}
function filterAppMenu(query){const q=String(query||'').trim().toLocaleLowerCase('fa');let shown=0;document.querySelectorAll('.app-menu-item').forEach(item=>{const hay=(item.innerText+' '+(item.dataset.menuSearch||'')).toLocaleLowerCase('fa');const show=!q||hay.includes(q);item.classList.toggle('hidden',!show);if(show)shown++;});$('appMenuEmpty')?.classList.toggle('hidden',shown!==0);}
$('mobileMoreButton')?.addEventListener('click',openAppMenu);$('closeAppMenuButton')?.addEventListener('click',closeAppMenu);$('appMenuBackdrop')?.addEventListener('click',closeAppMenu);$('appMenuSearch')?.addEventListener('input',e=>filterAppMenu(e.target.value));document.querySelectorAll('.app-menu-item[data-menu-view]').forEach(b=>b.addEventListener('click',()=>{const view=b.dataset.menuView;closeAppMenu();activateView(view);window.scrollTo({top:0,behavior:'smooth'});}));document.querySelectorAll('.app-menu-item[data-menu-action]').forEach(b=>b.addEventListener('click',()=>{const action=b.dataset.menuAction;closeAppMenu();if(action==='notifications')$('notificationsButton')?.click();if(action==='lock')$('lockButton')?.click();}));document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;if($('notificationPanel')&&!$('notificationPanel').classList.contains('hidden'))closeNotificationPanel();if($('appMenuDrawer')&&!$('appMenuDrawer').classList.contains('hidden'))closeAppMenu();});
function refreshOnline(){const badge=$('networkBadge'),online=navigator.onLine;badge.textContent=online?'اینترنت متصل':'آفلاین';badge.classList.toggle('offline',!online)}window.addEventListener('online',refreshOnline);window.addEventListener('offline',refreshOnline);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&cryptoKey&&localDateKey()!==dailyReminderCheckedDate)ensureDailyCustomerFollowupNotifications().then(()=>renderNotifications()).catch(()=>{});});
function showShareInstallHelp(){if(window.qoqnusAppBridge){alert('این نسخهٔ اندرویدی ققنوس خوانشگر آگهی را درون خود دارد. ابتدا دفتر را باز کنید؛ سپس از کارت فایلِ لینک‌دار «خواندن آگهی» را بزنید. برای دریافت لینک از برنامه‌های دیگر، از منوی اشتراک‌گذاری گزینهٔ ققنوس را انتخاب کنید.');return;}alert('برای نمایش ققنوس در گزینه‌های اشتراک‌گذاری گوشی:\n\n۱) سایت ققنوس را در Chrome اندروید باز کنید.\n۲) منوی سه‌نقطهٔ Chrome را بزنید.\n۳) گزینهٔ «نصب برنامه / Install app» را انتخاب کنید؛ فقط «افزودن به صفحهٔ اصلی» کافی نیست.\n۴) اگر نسخهٔ قدیمی نصب است، آن را حذف کنید و پس از به‌روزرسانی سایت دوباره نصب کنید.\n۵) صفحهٔ آگهی را باز کنید، گزینهٔ اشتراک‌گذاری را بزنید و «ققنوس» را انتخاب کنید.\n\nاگر «نصب برنامه» در Chrome وجود ندارد یا پس از نصب واقعی هنوز ققنوس دیده نمی‌شود، باید برنامهٔ اندرویدی ققنوس نصب شود.');}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;$('installButton').classList.remove('hidden')});$('installHelpLock')?.addEventListener('click',openHelpCenter);$('installButton').addEventListener('click',async()=>{if(!deferredInstallPrompt){showShareInstallHelp();return;}deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$('installButton').classList.add('hidden')});
const helpDialog=$('helpCenterDialog');
function openHelpCenter(){if(!helpDialog)return;if(typeof helpDialog.showModal==='function')helpDialog.showModal();else helpDialog.setAttribute('open','');}
function closeHelpCenter(){if(!helpDialog)return;if(typeof helpDialog.close==='function')helpDialog.close();else helpDialog.removeAttribute('open');}
$('helpCenterButton')?.addEventListener('click',openHelpCenter);$('readerHelpButton')?.addEventListener('click',openHelpCenter);$('closeHelpCenter')?.addEventListener('click',closeHelpCenter);
helpDialog?.addEventListener('click',e=>{if(e.target===helpDialog)closeHelpCenter();});
// Legacy PHP, WebRTC, peer-queue and relay file-sync code was removed in V237; V239 adds retry-safe owner-device deletion and preserves acknowledged remote deletions.
// Retained only for the independent central-publication endpoint; never used for file sync.
async function readSavedPairing(){if(!cryptoKey)return null;const saved=await getMetaObj('peerPairing',null);if(!saved||!/^[a-f0-9]{32}$/.test(String(saved.pairId||''))||!saved.tokenEnvelope)return null;try{const token=await decryptValue(saved.tokenEnvelope);if(!/^[a-f0-9]{64}$/.test(String(token||'')))return null;return {pairId:String(saved.pairId),token:String(token),pairedAt:Number(saved.pairedAt)||0};}catch{return null}}
async function refreshPairingUi(){
 const cfg=await centralConfig().catch(()=>null),paired=!!cfg;
 $('pairForm')?.classList.toggle('hidden',paired);$('startPairedSync')?.classList.toggle('hidden',!paired);$('fullRefreshListingSync')?.classList.toggle('hidden',!paired);$('forgetPairing')?.classList.toggle('hidden',!paired);
 if($('centralApiUrl'))$('centralApiUrl').value=String((await getMetaObj('qoqnusCentralOfficeV1',{}))?.apiUrl||$('centralApiUrl').value||'');
 const name=await getMetaObj('deviceName','');if($('mobileDeviceName'))$('mobileDeviceName').value=String(name||cfg?.deviceName||'');
 if(paired)await centralRefreshStatus();else setSyncFeedback('اتصال مستقیم به شیتاچی هنوز تنظیم نشده است.','warn');return cfg;
}
async function startMobileSync(){try{await centralPair();}catch(e){setSyncFeedback(String(e?.message||'جفت‌سازی با شیتاچی ناموفق بود.'),'error');}}
$('fullRefreshListingSync').addEventListener('click',async()=>{const b=$('fullRefreshListingSync');b.disabled=true;try{await centralCheckIncoming();}catch(e){setSyncFeedback(String(e?.message||e),'error');}finally{b.disabled=false;}});
$('startPairedSync').addEventListener('click',async()=>{const b=$('startPairedSync');b.disabled=true;try{await centralSendChanges();}catch(e){setSyncFeedback(String(e?.message||e),'error');}finally{b.disabled=false;}});
$('saveDeviceName').addEventListener('click',async()=>{const b=$('saveDeviceName');b.disabled=true;try{const name=clean($('mobileDeviceName').value,50)||'گوشی ققنوس';await setMetaObj('deviceName',name);const old=await getMetaObj('qoqnusCentralOfficeV1',null);if(old){old.deviceName=name;await setMetaObj('qoqnusCentralOfficeV1',old);}setSyncFeedback('نام این گوشی ذخیره شد.','success');}catch(error){setSyncFeedback(String(error?.message||error),'error');}finally{b.disabled=false;}});
$('pairForm').addEventListener('submit',e=>{e.preventDefault();startMobileSync()});
$('forgetPairing').addEventListener('click',async()=>{if(!confirm('اتصال این گوشی به شیتاچی فقط از همین گوشی پاک شود؟ رکوردهای محلی حذف نمی‌شوند.'))return;await dbDelete(META,'qoqnusCentralOfficeV1');await dbDelete(META,'qoqnusCentralInstallIdV1');await dbDelete(META,'qoqnusCentralPendingIncomingV1');await dbDelete(META,'qoqnusCentralStagingV1');await dbDelete(META,'qoqnusCentralImageDownloadPendingV1');await dbDelete(META,'qoqnusCentralIgnoredIncomingV1');await refreshPairingUi();setSyncFeedback('اطلاعات اتصال از این گوشی پاک شد؛ رکوردهای محلی حفظ شدند.','success');});

setInterval(()=>{if(cryptoKey&&!$('appShell')?.classList.contains('hidden')&&document.visibilityState==='visible'&&localDateKey()!==dailyReminderCheckedDate){ensureDailyCustomerFollowupNotifications().then(()=>renderNotifications()).catch(()=>{});}},300000);

async function resolveConflict(id,choice){const c=await recordById('conflict',id);if(!c)return;if(choice==='remote'){const current=await recordById(c.kind,c.recordId),base=mergeLocalOnlyMedia(c.kind,{...c.remoteRecord,id:c.recordId,record_uuid:c.recordId,updatedAt:Date.now()},current||c.localRecord);await storeRecord(c.kind,base);}else{const base={...c.localRecord,updatedAt:Date.now()};await storeRecord(c.kind,base);}const aliases=await getMetaObj('aliases',{});if(c.remoteRecordId&&c.remoteRecordId!==c.recordId)aliases[c.kind+':'+c.remoteRecordId]=c.recordId;await setMetaObj('aliases',aliases);await removeRecord('conflict',id);await renderAll();}
let qoqnusBackupExportState=null;
let qoqnusPendingBackupImport=null;
let qoqnusBackupImportStreamState=null;
let qoqnusNativeBackupImportActive=false;
function requestNativeBackupImportChunk(offset){
 if(!qoqnusBackupImportStreamState)throw new Error('وضعیت خواندن پشتیبان از بین رفته است.');
 if(!window.qoqnusAppBridge?.postMessage)throw new Error('ارتباط امن با انتخاب‌گر اندروید برقرار نیست.');
 window.qoqnusAppBridge.postMessage(JSON.stringify({type:'IMPORT_BACKUP_CHUNK_REQUEST',offset:Number(offset)||0,size:49152}));
}
window.__qoqnusBeginNativeBackupImport=function(name,totalBytes){
 try{
  if(!window.QoqnusBackupFileReader)throw new Error('ماژول امن خواندن فایل پشتیبان بارگذاری نشده است.');
  qoqnusPendingBackupImport=null;qoqnusNativeBackupImportActive=true;
  qoqnusBackupImportStreamState={receiver:QoqnusBackupFileReader.createChunkReceiver({name:String(name||'qoqnus-backup.json'),totalBytes:Number(totalBytes),maxBytes:150*1024*1024})};
  setStatus('backupStatus','فایل «'+String(name||'qoqnus-backup.json')+'» انتخاب شد؛ در حال خواندن امن از حافظه گوشی…');
  requestNativeBackupImportChunk(0);
 }catch(error){window.__qoqnusBackupImportFailed(String(error?.message||error));}
};
window.__qoqnusReceiveBackupImportChunk=async function(offset,base64,done){
 const state=qoqnusBackupImportStreamState;if(!state)return;
 try{
  const result=state.receiver.push(offset,base64,done);
  if(result.complete){let parsed;try{parsed=JSON.parse(result.text);}catch(parseError){throw new Error('فایل از حافظه خوانده شد، اما JSON معتبر نیست: '+String(parseError?.message||'خطای ساختار'));}if(!window.QoqnusBackupCore)throw new Error('فایل خوانده شد، اما ماژول بررسی پشتیبان بارگذاری نشده است.');const verified=await QoqnusBackupCore.verifyBackupDocument(parsed);qoqnusPendingBackupImport={name:result.name,text:result.text,bytes:result.bytes};qoqnusBackupImportStreamState=null;qoqnusNativeBackupImportActive=false;const count=Number(verified.records?.length)||0,version=Number(verified.formatVersion)||1;setStatus('backupStatus','فایل «'+qoqnusPendingBackupImport.name+'» خوانده و ساختار آن تأیید شد؛ نسخهٔ قالب '+version+'، تعداد '+displayCount(count)+' رکورد'+(verified.manifest?' و '+displayCount(verified.manifest.attachmentCount||0)+' تصویر/ضمیمه':'')+'. اکنون «بازیابی فایل انتخاب‌شده» را بزنید. پشتیبان مشترک افزونه/موبایل رمز جداگانه نمی‌خواهد؛ پشتیبان قدیمی رمزگذاری‌شده ممکن است رمز اصلی دفتر را لازم داشته باشد.','success');return;}
  requestNativeBackupImportChunk(result.nextOffset);
 }catch(error){window.__qoqnusBackupImportFailed(String(error?.message||'خواندن فایل پشتیبان ناموفق بود.'));}
};
window.__qoqnusBackupImportFailed=function(message){qoqnusBackupImportStreamState=null;qoqnusPendingBackupImport=null;qoqnusNativeBackupImportActive=false;setStatus('backupStatus',String(message||'خواندن فایل پشتیبان ناموفق بود.'),'error');};
window.__qoqnusTakeBackupChunk=function(offset,size=65536){try{if(!qoqnusBackupExportState||!window.qoqnusAppBridge?.postMessage)return;const text=qoqnusBackupExportState.text;let end=Math.min(text.length,Math.max(1024,Number(size)||65536)+Number(offset||0));if(end<text.length&&end>0){const code=text.charCodeAt(end-1);if(code>=0xD800&&code<=0xDBFF)end--;}const data=text.slice(Number(offset)||0,end);window.qoqnusAppBridge.postMessage(JSON.stringify({type:'EXPORT_BACKUP_CHUNK',offset:Number(offset)||0,data,done:end>=text.length}));}catch(e){console.error('Qoqnus backup chunk failed',e);}};
window.__qoqnusBackupExportFinished=function(ok,message){qoqnusBackupExportState=null;setStatus('backupStatus',String(message|| (ok?'پشتیبان ذخیره شد.':'ذخیرهٔ پشتیبان ناموفق بود.')),ok?'success':'error');};
async function exportBackup(){
 const imageCheck=await imageNormalizationPromise.catch(()=>({failedImages:1}));
 if(Number(imageCheck&&imageCheck.failedImages)>0)throw new Error('پشتیبان ساخته نشد؛ '+displayCount(imageCheck.failedImages)+' تصویر هنوز استاندارد نشده است. خطای تصویر را برطرف و دوباره تلاش کنید.');
 if(!window.QoqnusBackupCore)throw new Error('ماژول امن پشتیبان بارگذاری نشده است.');
 const records=await dbAll(STORE),meta=await dbAll(META);
 const raw=await QoqnusBackupCore.createExtensionCompatibleBackup({records,appVersion:APP_VERSION,decryptRecord:row=>decryptValue({iv:row.iv,cipher:row.cipher})});
 const verified=await QoqnusBackupCore.verifyBackupDocument(raw);
 if(verified.records.length!==raw.data.queue.length+raw.data.qoqnusCustomers.length+raw.data.qoqnusOfficeFiles.length)throw new Error('اعتبارسنجی خروجی پشتیبان مشترک ناموفق بود؛ تعداد رکوردها برابر نیست.');
 const text=JSON.stringify(raw);const name='qoqnus-shared-backup-'+new Date().toISOString().slice(0,10)+'.json';
 if(window.qoqnusAppBridge&&typeof window.qoqnusAppBridge.postMessage==='function'){
  if(text.length>100*1024*1024)throw new Error('برای سازگاری با افزونه، حجم پشتیبان مشترک نباید از ۱۰۰ مگابایت بیشتر شود.');
  qoqnusBackupExportState={text};window.qoqnusAppBridge.postMessage(JSON.stringify({type:'EXPORT_BACKUP_BEGIN',name,totalChars:text.length}));
  setStatus('backupStatus','پشتیبان مشترک افزونه و موبایل آماده است؛ محل ذخیره را انتخاب کنید…');return;
 }
 const blob=new Blob([text],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);
 setStatus('backupStatus','پشتیبان مشترک افزونه و موبایل ساخته شد؛ فایل شامل داده‌ها و تصاویر است و رمز عبور یا کلید اتصال دستگاه در آن قرار نمی‌گیرد. فایل را در محل امن نگهداری کنید.');
}
$('exportBackup').addEventListener('click',()=>exportBackup().catch(e=>setStatus('backupStatus',e.message,'error')));
async function normalizeBackupPayload(input){
 if(!window.QoqnusBackupCore)throw new Error('ماژول اعتبارسنجی پشتیبان بارگذاری نشده است.');
 const verified=await QoqnusBackupCore.verifyBackupDocument(input);
 const schema=String(verified.schema||input.schema||input.format||input.version||'').toLowerCase();
 const recordsRaw=verified.records;
 let metaRaw=Array.isArray(input.meta)?input.meta:[];
 if(!metaRaw.length&&input.meta&&typeof input.meta==='object')metaRaw=Object.entries(input.meta).map(([key,value])=>({key,value}));
 const meta=[];for(const item of metaRaw){if(!item||typeof item!=='object')continue;const key=String(item.key||'');if(!key)continue;meta.push(Object.prototype.hasOwnProperty.call(item,'value')?{key,value:item.value}:{key,value:item});}
 const rows=[],seenKeys=new Set(),seenIds=new Set();
 const add=raw=>{
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error('یکی از رکوردهای فایل پشتیبان ساختار معتبری ندارد.');
  const nested=raw.record&&typeof raw.record==='object'&&!Array.isArray(raw.record)?raw.record:(raw.legacyPlainRecord&&typeof raw.legacyPlainRecord==='object'&&!Array.isArray(raw.legacyPlainRecord)?raw.legacyPlainRecord:null);
  const kind=String(raw.kind||raw.type||nested?.kind||nested?.type||'record');
  const id=String(raw.id||raw.recordId||raw.uuid||nested?.id||nested?.recordId||'');
  const key=String(raw.key||(id?kind+':'+id:''));
  if(!key||!id)throw new Error('یک رکورد پشتیبان شناسهٔ پایدار ندارد؛ بازیابی برای جلوگیری از اتصال اشتباه متوقف شد.');
  if(seenKeys.has(key)||seenIds.has(kind+':'+id))throw new Error('شناسهٔ تکراری در پشتیبان پیدا شد: '+kind+':'+id+'؛ هیچ داده‌ای تغییر نکرد.');
  seenKeys.add(key);seenIds.add(kind+':'+id);
  if(raw.iv&&raw.cipher){
   if(typeof raw.iv!=='string'||typeof raw.cipher!=='string'||!raw.iv||!raw.cipher)throw new Error('رکورد رمزگذاری‌شده ناقص است.');
   rows.push({key,kind,id,updatedAt:Number(raw.updatedAt||raw.updated_at)||Date.now(),iv:raw.iv,cipher:raw.cipher});
  }else{
   if(verified.formatVersion>=2)throw new Error('پشتیبان نسخهٔ ۲ باید تمام رکوردها را رمزگذاری‌شده داشته باشد.');
   const rec=nested||raw;rows.push({key,kind,id,updatedAt:Number(raw.updatedAt||raw.updated_at)||Date.now(),legacyPlainRecord:rec});
  }
 };
 for(const raw of recordsRaw)add(raw);
 if(!rows.length&&!(verified.formatVersion>=2&&Number(verified.manifest?.recordCount)===0))throw new Error('فایل پشتیبان هیچ رکورد قابل بازیابی ندارد.');
 return {schema,formatVersion:verified.formatVersion,createdAt:verified.createdAt,records:rows,meta,manifest:verified.manifest};
}
async function downloadRecoveryBackup(records,meta){
 const raw=await QoqnusBackupCore.createBackupDocument({records,meta,appVersion:APP_VERSION+'-recovery',recoveryCopy:true,decryptRecord:row=>decryptValue({iv:row.iv,cipher:row.cipher})});
 const blob=new Blob([JSON.stringify(raw)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='qoqnus-before-restore-v2-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),15000);
}

async function readBackupFileAsText(file){
 if(!window.QoqnusBackupFileReader)throw new Error('ماژول خواندن فایل پشتیبان بارگذاری نشده است.');
 return QoqnusBackupFileReader.readFileAsText(file,100*1024*1024);
}
$('restoreBackup').addEventListener('click',async()=>{
 const file=$('restoreBackupFile').files?.[0],pending=qoqnusPendingBackupImport;if(!file&&!pending){setStatus('backupStatus','ابتدا فایل پشتیبان را انتخاب کنید.','error');return}const selectedBytes=Number(pending?.bytes??file?.size??0);if(selectedBytes>100*1024*1024){setStatus('backupStatus','فایل پشتیبان مشترک بیش از ۱۰۰ مگابایت است.','error');return}
 const button=$('restoreBackup');button.disabled=true;setStatus('backupStatus','مرحلهٔ ۱ از ۴: در حال خواندن و بررسی فایل پشتیبان…');
 try{
  const fileText=pending?pending.text:await readBackupFileAsText(file);let parsed;try{parsed=JSON.parse(fileText);}catch(parseError){const where=String(parseError?.message||'');throw new Error('فایل انتخاب‌شده JSON معتبر نیست. '+where+' فایل را دوباره از بخش «پشتیبان مشترک» تهیه کنید.');}const data=await normalizeBackupPayload(parsed);let backupMeta=Object.fromEntries(data.meta.map(x=>[x.key,x.value]));const localMetaRows=await dbAll(META),localMeta=Object.fromEntries(localMetaRows.map(x=>[x.key,x.value]));let key=null;
  const isSharedPlainBackup=String(parsed.schema||'')==='divar-to-rubika-full-backup' && data.records.every(x=>!!x.legacyPlainRecord);
  if(isSharedPlainBackup){if(!cryptoKey)throw new Error('ابتدا قفل همین گوشی را باز کنید؛ برای پشتیبان مشترک رمز جداگانه لازم نیست.');key=cryptoKey;backupMeta={...localMeta,...backupMeta};}
  else if(backupMeta.localSalt&&backupMeta.lockCheck){const password=prompt('رمز اصلی دفتر ققنوس را که هنگام ساخت این پشتیبان تعیین کرده‌اید وارد کنید. کد سریع ۴ رقمی ورود برای بازیابی پشتیبان کافی نیست:');if(!password)throw new Error('بازیابی لغو شد؛ رمز اصلی وارد نشد.');if(/^\d{4}$/.test(password))throw new Error('این پشتیبان با رمز اصلی دفتر رمزگذاری شده است؛ کد ۴ رقمی ورود سریع را وارد نکنید. رمز اصلی حداقل ۸ نویسه‌ای زمان تهیه پشتیبان را وارد کنید.');key=await deriveKey(password,unb64(backupMeta.localSalt));try{const check=await decryptWithKey(key,backupMeta.lockCheck);if(check.magic!=='qoqnus-mobile-lock-v1')throw new Error('قفل پشتیبان معتبر نیست.');}catch{throw new Error('رمز اصلی پشتیبان نادرست است یا اطلاعات قفل فایل خراب است. فایل خوانده شده، اما رمزگشایی انجام نشد؛ اطلاعات فعلی تغییر نکرد.');}}
  else {const password=prompt('این نسخهٔ پشتیبان قدیمی فاقد اطلاعات قفل قابل‌شناسایی است. یک رمز محلی جدید (حداقل ۸ نویسه) برای رمزگذاری داده‌های بازیابی‌شده تعیین کنید:');if(!password||password.length<8)throw new Error('برای بازیابی نسخهٔ قدیمی باید رمز جدیدی با حداقل ۸ نویسه تعیین شود.');const confirmPassword=prompt('رمز جدید را دوباره وارد کنید:');if(password!==confirmPassword)throw new Error('دو رمز واردشده یکسان نیستند؛ هیچ داده‌ای تغییر نکرد.');const salt=crypto.getRandomValues(new Uint8Array(16));key=await deriveKey(password,salt);backupMeta.localSalt=b64(salt);backupMeta.lockCheck=await encryptWithKey(key,{magic:'qoqnus-mobile-lock-v1',createdAt:Date.now()});}
  setStatus('backupStatus','مرحلهٔ ۲ از ۴: در حال اعتبارسنجی رکوردها، شناسه‌ها و تمام تصاویر…');const prepared=[];const ids=new Set();let restoredAttachmentCount=0;
  for(let i=0;i<data.records.length;i++){const row=data.records[i];let record;if(row.legacyPlainRecord){record=row.legacyPlainRecord;}else{try{record=await decryptWithKey(key,{iv:row.iv,cipher:row.cipher});}catch{throw new Error('اعتبارسنجی رکورد '+(i+1)+' ناموفق بود؛ رمز اشتباه یا فایل ناقص است. دیتابیس فعلی دست‌نخورده ماند.');}}
   if(!record||typeof record!=='object'||Array.isArray(record))throw new Error('ساختار یکی از رکوردها معتبر نیست. دیتابیس فعلی دست‌نخورده ماند.');
   const kind=String(row.kind||record.kind||record.type||'record');
   const expectedRecordId=String(row.id||'');const embeddedRecordId=String(record.id??record.recordId??record.uuid??'');if(embeddedRecordId&&embeddedRecordId!==expectedRecordId)throw new Error('شناسهٔ رکورد با کلید ذخیره‌سازی پشتیبان برابر نیست: '+kind+':'+expectedRecordId+'؛ هیچ داده‌ای تغییر نکرد.');
   const rawAttachmentCount=QoqnusBackupCore.countEmbeddedImages(record);restoredAttachmentCount+=rawAttachmentCount;
   if(kind==='customer'&&record.profilePhotoWebp){if(!window.QoqnusCustomerPhoto||typeof record.profilePhotoWebp!=='string'||record.profilePhotoWebp.length>600000)throw new Error('تصویر اختصاصی مشتری در پشتیبان خراب یا بیش از حد مجاز است؛ هیچ اطلاعاتی جایگزین نشد.');try{const photo=await QoqnusCustomerPhoto.normalizeDataUrl(record.profilePhotoWebp);if(Math.max(photo.width,photo.height)>500||photo.bytes>409600||!/^data:image\/webp;base64,/.test(photo.dataUrl))throw new Error('ابعاد یا حجم تصویر مشتری از استاندارد ۵۰۰ پیکسل و ۴۰۰ کیلوبایت بیشتر است.');record.profilePhotoWebp=photo.dataUrl;}catch(error){throw new Error('تصویر مشتری '+String(record.id||row.id||'')+' قابل بازیابی نیست: '+String(error?.message||error));}}
   const imageState={normalizedImages:0,normalizedRecords:0,failedImages:0,lastError:''},memo=new Map();
   for(const imageField of INLINE_IMAGE_FIELDS){if(!(imageField in record))continue;const normalized=await normalizeNestedImageValue(record[imageField],memo,imageState);if(normalized!==record[imageField])record[imageField]=normalized;}
   if(imageState.failedImages)throw new Error('حداقل یک تصویر در رکورد '+String(record.id||row.id||'')+' قابل خواندن یا تبدیل نیست؛ برای جلوگیری از بازیابی ناقص، عملیات متوقف شد. '+imageState.lastError);
   const id=String(row.id||record.id||record.recordId||record.uuid||'');if(!id)throw new Error('رکوردی بدون شناسهٔ پایدار وجود دارد.');
   const keyName=String(row.key||kind+':'+id);if(ids.has(keyName)||ids.has(kind+':'+id))throw new Error('شناسهٔ تکراری در پشتیبان پیدا شد: '+kind+':'+id+'؛ هیچ داده‌ای تغییر نکرد.');ids.add(keyName);ids.add(kind+':'+id);
   const envelope=await encryptWithKey(key,record);prepared.push({key:keyName,kind,id,updatedAt:Number(row.updatedAt||record.updatedAt||record.updated_at)||Date.now(),iv:envelope.iv,cipher:envelope.cipher});
  }
  if(!prepared.length&&!(data.formatVersion>=2&&Number(data.manifest?.recordCount)===0))throw new Error('هیچ رکورد معتبری برای بازیابی باقی نماند.');
  if(data.manifest&&Number.isFinite(Number(data.manifest.recordCount))&&Number(data.manifest.recordCount)!==prepared.length)throw new Error('تعداد رکوردهای معتبرشده با فهرست پشتیبان برابر نیست؛ هیچ داده‌ای تغییر نکرد.');
  if(data.manifest&&Number.isFinite(Number(data.manifest.attachmentCount))&&Number(data.manifest.attachmentCount)!==restoredAttachmentCount)throw new Error('تعداد تصاویر/ضمائم معتبرشده با فهرست پشتیبان مطابقت ندارد؛ بازیابی برای جلوگیری از حذف ضمیمه متوقف شد.');
  const existingRecords=await dbAll(STORE),existingMeta=await dbAll(META);if((existingRecords.length||existingMeta.length)&&!confirm('مرحلهٔ ۳ از ۴: '+displayCount(existingRecords.length)+' رکورد و '+displayCount(existingMeta.length)+' تنظیم محلی فعلی وجود دارد. یک نسخهٔ اضطراری از اطلاعات فعلی تهیه می‌شود و سپس داده‌های فایل جایگزین می‌شوند. ادامه می‌دهید؟'))throw new Error('بازیابی به درخواست شما لغو شد؛ اطلاعات فعلی حفظ شد.');
  if(existingRecords.length||existingMeta.length){try{await downloadRecoveryBackup(existingRecords,existingMeta);}catch(e){console.warn('Recovery download could not be started',e);}}
  setStatus('backupStatus','مرحلهٔ ۴ از ۴: در حال ذخیرهٔ اتمی اطلاعات؛ لطفاً برنامه را نبندید…');const freshDeviceId=uuid();const metaSourceRows=isSharedPlainBackup?[...localMetaRows,...data.meta]:data.meta.filter(x=>String(x.key)!=='peerPairing');const restoredMeta=QoqnusBackupCore.restoreMetaRows(metaSourceRows,{localSalt:backupMeta.localSalt,lockCheck:backupMeta.lockCheck,deviceId:freshDeviceId,deviceCryptoKey:key});
  await new Promise((resolve,reject)=>{const tx=db.transaction([STORE,META,RECOVERY],'readwrite');const rs=tx.objectStore(RECOVERY);rs.put({key:'lastRestoreSafetyCopy',createdAt:Date.now(),records:existingRecords,meta:existingMeta});const store=tx.objectStore(STORE),metaStore=tx.objectStore(META);store.clear();metaStore.clear();for(const row of prepared)store.put(row);for(const row of restoredMeta)metaStore.put(row);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('ذخیرهٔ بازیابی ناموفق بود؛ تراکنش لغو شد.'));tx.onabort=()=>reject(tx.error||new Error('بازیابی لغو شد؛ داده‌های قبلی حفظ شدند.'));});
  cryptoKey=key;deviceId=freshDeviceId;window.qoqnusPasswordExists=true;window.qoqnusQuickPinExists=!!backupMeta.quickPinSalt&&!!backupMeta.quickPinCheck;
  let imageResult={failedImages:0,normalizedImages:0};try{imageNormalizationPromise=normalizeLegacyStoredImages(true);imageResult=await imageNormalizationPromise;await renderAll(true);}catch(postError){console.error('Post-restore UI refresh failed after atomic commit:',postError);}
  const customerCount=prepared.filter(r=>/customer|contact|client/i.test(r.kind)).length,fileCount=prepared.filter(r=>/file|listing|property|estate/i.test(r.kind)).length;
  const manifestNote=data.manifest?' · تصاویر اعتبارسنجی‌شده: '+displayCount(restoredAttachmentCount):' · پشتیبان قدیمی بدون فهرست ضمائم';
  qoqnusPendingBackupImport=null;qoqnusNativeBackupImportActive=false;$('restoreBackupFile').value='';
  setStatus('backupStatus','بازیابی و ذخیرهٔ اتمی انجام شد: '+displayCount(prepared.length)+' رکورد؛ '+displayCount(fileCount)+' فایل/ملک و '+displayCount(customerCount)+' مشتری/مخاطب.'+manifestNote+(imageResult.failedImages?' هشدار: '+displayCount(imageResult.failedImages)+' تصویر پس از بازیابی نیازمند بررسی است.':' همهٔ تصاویر قابل پردازش بودند.')+' شناسه دستگاه و صف همگام‌سازی برای نصب جدید بازنشانی شد.','success');
 }catch(e){setStatus('backupStatus',e.message||'بازیابی ناموفق بود؛ تراکنش ذخیره‌سازی انجام نشد و اطلاعات قبلی حفظ شدند.','error')}finally{button.disabled=false;}
});
$('restoreBackupFile').addEventListener('change',()=>{if(qoqnusNativeBackupImportActive)return;qoqnusPendingBackupImport=null;const file=$('restoreBackupFile').files?.[0];if(file)setStatus('backupStatus','فایل «'+String(file.name||'پشتیبان')+'» انتخاب شد ('+displayCount(file.size)+' بایت). پس از خواندن و بررسی، «بازیابی فایل انتخاب‌شده» را بزنید.');});

function setupAccessibleTheme(){
 const key='qoqnus-ui-theme-v1';let theme='dark';
 try{const saved=localStorage.getItem(key);if(saved==='light'||saved==='dark')theme=saved;}catch{}
 const buttons=[$('themeToggle'),$('themeToggleLock')].filter(Boolean);
 const icons={
  light:'<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/></svg>',
  dark:'<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20.2 15.4A8.4 8.4 0 0 1 8.6 3.8 8.7 8.7 0 1 0 20.2 15.4Z"/></svg>'
 };
 const apply=()=>{
  document.documentElement.dataset.theme=theme;
  const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=theme==='light'?'#f7f8fb':'#17191d';
  for(const button of buttons){button.innerHTML=icons[theme==='dark'?'light':'dark'];button.setAttribute('aria-label',theme==='dark'?'تغییر به حالت روشن':'تغییر به حالت تیره');button.title=theme==='dark'?'فعال کردن حالت روشن':'فعال کردن حالت تیره';button.setAttribute('aria-pressed',String(theme==='light'));}
  try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'SET_SYSTEM_THEME',theme}));}catch{}
 };
 for(const button of buttons)button.addEventListener('click',()=>{theme=theme==='dark'?'light':'dark';try{localStorage.setItem(key,theme);}catch{}apply();});
 apply();
}
setupAccessibleTheme();

setupStartupQuickEntry();
async function boot(){db=await openDb();window.qoqnusPasswordExists=!!(await getMetaObj('localSalt',''));window.qoqnusQuickPinExists=!!(await getMetaObj('quickPinSalt',''))&&!!(await getMetaObj('quickPinCheck',null));if(!window.isSecureContext||!crypto?.subtle){setStatus('lockStatus','برای ذخیرهٔ امن، برنامک باید از HTTPS باز شود.','error');}lockApp();syncLockedOperationsPanel();if(readerLaunchState==='missing'&&!window.qoqnusAppBridge)setStatus('lockStatus','برنامهٔ همراه ققنوس روی گوشی نصب نیست یا باز نشد؛ برای خواندن خودکار باید برنامهٔ اندرویدی ققنوس نصب باشد.','error');syncConditionalFields();if(!window.qoqnusAppBridge&&'serviceWorker'in navigator&&location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(err=>console.warn('PWA service worker registration failed',err));try{if(navigator.storage?.persist){const persistent=await navigator.storage.persist();console.info('qoqnus local persistence requested:',persistent)}}catch{} }
boot().catch(e=>{console.error(e);setStatus('lockStatus','راه‌اندازی پایگاه دادهٔ محلی ناموفق بود: '+(e.message||''),'error')});
})();
