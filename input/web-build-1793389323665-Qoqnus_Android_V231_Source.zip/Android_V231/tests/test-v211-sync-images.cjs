'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const rootDir = path.resolve(__dirname, '..');
const assets = path.join(rootDir, 'app/src/main/assets');
const js = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(assets, 'sw.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(assets, 'manifest.webmanifest'), 'utf8'));
const build = fs.readFileSync(path.join(rootDir, 'app/build.gradle.kts'), 'utf8');
const activity = fs.readFileSync(path.join(rootDir, 'app/src/main/java/ir/qoqnus/divarreader/MainActivity.kt'), 'utf8');

const cases = [];
const test = (name, fn) => cases.push({ name, fn });

test('V231 cache/version/build assets stay aligned and image normalizer is loaded/cached', () => {
  assert.match(js, /const APP_VERSION='V231'/);
  assert.match(html, /qoqnus-build" content="V231-incremental-sync-performance/);
  assert.match(html, /qoqnus-image-normalizer\.js\?v=1-image-400-square/);
  assert.match(sw, /qoqnus-image-normalizer\.js\?v=1-image-400-square/);
  assert.match(sw, /qoqnus-mobile-pwa-v231-incremental-sync-performance/);
  assert.match(manifest.start_url, /build=V231-incremental-sync-performance/);
  assert.match(activity, /build=V231-incremental-sync-performance/);
  assert.match(build, /versionCode\s*=\s*41/);
  assert.match(build, /versionName\s*=\s*"2\.0\.35"/);
});

test('V231 keeps the backup device dropdown removed and uses the selected durable-queue source', () => {
  assert.doesNotMatch(html, /backupSourceDevice|backupSourceHelp/);
  assert.match(html, /id="syncSourceSelect"/);
  assert.match(html, /انتخاب منبع برای همگام‌سازی/);
  assert.match(js, /async function refreshSyncSources\(knownPeers=null\)/);
  assert.match(js, /async function requestSelectedSync\(mode,options=\{\}\)/);
  assert.match(js, /queue-request-sync/);
  assert.match(js, /source_target_id:source/);
  assert.match(js, /async function durableQueueTick\(\)/);
  assert.match(js, /applied:true,ack/);
  assert.doesNotMatch(js, /peerTransport\.sendPayload\(['"]sync-(?:media-)?pack/);
  assert.match(build, /compileSdk = 35/);
  assert.match(build, /versionCode\s*=\s*41/);
});

test('image processor enforces a 400 square JPEG output and preserves aspect ratio with contain-fit', () => {
  const normalizer = fs.readFileSync(path.join(assets, 'qoqnus-image-normalizer.js'), 'utf8');
  assert.match(normalizer, /const SIZE = 400/);
  assert.match(normalizer, /canvas\.width = SIZE/);
  assert.match(normalizer, /canvas\.height = SIZE/);
  assert.match(normalizer, /Math\.min\(SIZE \/ decoded\.width, SIZE \/ decoded\.height\)/);
  assert.match(normalizer, /toBlob\(resolve, 'image\/jpeg', quality\)/);
  assert.match(normalizer, /imageOrientation: 'from-image'/);
  assert.match(normalizer, /marker === 0xe1 \|\| marker === 0xed \|\| marker === 0xfe/);
  assert.match(js, /async function compressImage\(file\).*QoqnusImageNormalizer\.normalizeFile/s);
});

test('existing files are normalized once after unlock; imported backup is normalized before use', () => {
  assert.match(js, /async function normalizeLegacyStoredImages\(force=false\)/);
  assert.match(js, /getMetaObj\('imageNormalization400V1'/);
  assert.match(js, /imageNormalizationPromise=normalizeLegacyStoredImages\(\)/);
  assert.match(js, /imageNormalizationPromise=normalizeLegacyStoredImages\(true\)/);
  assert.match(js, /async function exportBackup\(\)[\s\S]*?QoqnusBackupCore\.createBackupDocument/);
  assert.match(js, /await QoqnusBackupCore\.verifyBackupDocument\(input\)/);
  assert.match(html, /qoqnus-backup-core\.js\?v=224-backup-integrity/);
});

test('incoming media is normalized before persistent store and receipt ACK', () => {
  const start = js.indexOf('async function applyIncomingMobileMediaPack');
  const end = js.indexOf('\nfunction ', start + 10);
  const fn = js.slice(start, end);
  assert.match(fn, /QoqnusImageNormalizer\.normalizeDataUrl\(dataUrl\)/);
  assert.match(fn, /normalized\.width!==400\|\|normalized\.height!==400/);
  assert.ok(fn.includes("const display=(Array.isArray(target.imageUrls)?target.imageUrls:[]).filter("));
  assert.ok(fn.includes('for(const image of data)')); 
  assert.ok(fn.indexOf('await storeRecord(kind,{...target,imageDataUrls:data,imageUrls:display})') < fn.indexOf("accepted.push({key:kind+':'+id+':'+index,hash})"));
});

test('full snapshot and incremental journal delta remain distinct modes', () => {
  assert.match(html, /همگام‌سازی فایل‌های جدید و تغییرات/);
  assert.match(html, /همهٔ فایل‌ها و آگهی‌ها — بازهمگام‌سازی کامل/);
  assert.match(js, /requestedFull=options\.forceFullSnapshot===true\|\|Boolean\(await getMetaObj\('forceFullSnapshotSync',false\)\)/);
  assert.match(js, /forceFullSnapshot\|\|String\(ack\[key\]\|\|''\)!==fp/);
  assert.match(js, /Object\.values\(journal\.changes\|\|\{\}\)\.filter\(x=>x&&Number\(x\.seq\)>cursor\)/);
  assert.match(js, /fullSnapshotRequestV1:requestedFull/);
});

test('daily sync reminder uses the notification bell and opens the sync page', () => {
  assert.match(js, /'daily-sync-reminder','یادآوری روزانهٔ همگام‌سازی','همگام‌سازی فایل‌های جدید را بررسی کنید\.'/);
  assert.match(js, /if\(n\.type==='daily-sync-reminder'\)[\s\S]*activateView\('sync'\)/);
  assert.match(js, /'daily-sync-reminder':'همگام‌سازی روزانه'/);
  // V221 tracks successful work through durable-queue request status and applied ACKs,
  // not the retired direct-WebRTC sync-complete message.
  assert.match(js, /async function durableQueuePollRequestStatus\(pair,state\)/);
  assert.match(js, /queue-request-status/);
  assert.match(js, /status==='completed'/);
  assert.match(js, /lastSuccessfulSyncAt/);
  assert.match(js, /daily-sync-reminder/);
  assert.match(js, /if\(type==='sync-complete'\)\{if\(payload\?\.pairingOnly!==true\)/);
});

// Exercise the actual pure JPEG metadata predicate and canvas sizing path with DOM mocks.
test('image normalizer rejects EXIF/IPTC/comment JPEGs and keeps a safe standard JPEG unchanged', async () => {
  const normalizerPath = path.join(assets, 'qoqnus-image-normalizer.js');
  const normalizer = require(normalizerPath);
  const safeJpeg = Uint8Array.from([0xff,0xd8,0xff,0xe0,0x00,0x04,0x00,0x00,0xff,0xda,0x00,0x02,0xff,0xd9]);
  const exifJpeg = Uint8Array.from([0xff,0xd8,0xff,0xe1,0x00,0x08,0x45,0x78,0x69,0x66,0x00,0x00,0xff,0xda,0x00,0x02,0xff,0xd9]);
  assert.equal(global.QoqnusImageNormalizer.jpegMetadataFree(safeJpeg), true);
  assert.equal(global.QoqnusImageNormalizer.jpegMetadataFree(exifJpeg), false);

  const old = { createImageBitmap: global.createImageBitmap, FileReader: global.FileReader, document: global.document };
  try {
    global.createImageBitmap = async () => ({ width: 400, height: 400, close() {} });
    global.FileReader = class { readAsDataURL(file) { file.arrayBuffer().then(ab => { this.result = `data:${file.type};base64,${Buffer.from(ab).toString('base64')}`; this.onload(); }).catch(e => this.onerror(e)); } };
    global.document = { createElement() { throw new Error('canvas should not be used for an already standard image'); } };
    const file = { type: 'image/jpeg', size: 100, arrayBuffer: async () => safeJpeg.buffer.slice(safeJpeg.byteOffset, safeJpeg.byteOffset + safeJpeg.byteLength) };
    const result = await global.QoqnusImageNormalizer.normalizeFile(file);
    assert.equal(result.width, 400);
    assert.equal(result.height, 400);
    assert.equal(result.unchanged, true);
    assert.match(result.dataUrl, /^data:image\/jpeg;base64,/);
  } finally {
    global.createImageBitmap = old.createImageBitmap;
    global.FileReader = old.FileReader;
    global.document = old.document;
  }
});


test('image normalization actually uses a centered 400x400 contain canvas for a landscape photo', async () => {
  const old = { createImageBitmap: global.createImageBitmap, FileReader: global.FileReader, document: global.document };
  let canvasWidth = 0, canvasHeight = 0, drawArgs = null, outputType = '';
  try {
    global.createImageBitmap = async () => ({ width: 800, height: 400, close() {} });
    global.FileReader = class {
      readAsDataURL(blob) {
        blob.arrayBuffer().then(ab => {
          this.result = `data:${blob.type};base64,${Buffer.from(ab).toString('base64')}`;
          this.onload();
        }).catch(error => this.onerror(error));
      }
    };
    global.document = {
      createElement(name) {
        assert.equal(name, 'canvas');
        const canvas = {
          set width(value) { canvasWidth = value; },
          get width() { return canvasWidth; },
          set height(value) { canvasHeight = value; },
          get height() { return canvasHeight; },
          getContext(kind, options) {
            assert.equal(kind, '2d');
            assert.equal(options.alpha, false);
            return {
              fillStyle: '', fillRect() {},
              drawImage(...args) { drawArgs = args; }
            };
          },
          toBlob(callback, type, quality) {
            outputType = type;
            assert.ok(quality <= 0.84 && quality >= 0.54);
            callback(new Blob([new Uint8Array(12_000)], { type }));
          }
        };
        return canvas;
      }
    };
    const file = { type: 'image/png', size: 1024, arrayBuffer: async () => new Uint8Array([1,2,3]).buffer };
    const result = await global.QoqnusImageNormalizer.normalizeFile(file);
    assert.equal(canvasWidth, 400);
    assert.equal(canvasHeight, 400);
    assert.equal(outputType, 'image/jpeg');
    assert.ok(drawArgs);
    assert.equal(drawArgs[1], 0);
    assert.equal(drawArgs[2], 100);
    assert.equal(drawArgs[3], 400);
    assert.equal(drawArgs[4], 200);
    assert.equal(result.width, 400);
    assert.equal(result.height, 400);
    assert.equal(result.mime, 'image/jpeg');
    assert.match(result.dataUrl, /^data:image\/jpeg;base64,/);
  } finally {
    global.createImageBitmap = old.createImageBitmap;
    global.FileReader = old.FileReader;
    global.document = old.document;
  }
});

(async () => {
  for (const item of cases) { await item.fn(); process.stdout.write(`PASS ${item.name}\n`); }
  process.stdout.write(`V223 sync/image source checks: ${cases.length} passed. These checks do not verify remote server queues or real Android camera/gallery behavior.\n`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
