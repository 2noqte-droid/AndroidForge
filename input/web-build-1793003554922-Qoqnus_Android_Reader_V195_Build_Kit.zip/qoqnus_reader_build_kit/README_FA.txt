ققنوس — بستهٔ ساخت APK خوانشگر اندروید V195

این بسته حاوی سورس Android Studio و اسکریپت Build-Reader-APK.ps1 است؛ APK آماده درون بسته نیست.
برای راهنما فایل BUILD_APK_WINDOWS_FA.md را بخوان.
شناسهٔ برنامه: ir.qoqnus.divarreader
نسخهٔ سورس: 1.4.0 (versionCode 5)
نسخهٔ Gradle مورد انتظار: 8.9
Android Gradle Plugin: 8.7.3
compileSdk: 35

تأکید: تا زمانی که APK ساخته، روی گوشی نصب و اتصال خوانشگر به دفتر رمزگذاری‌شده آزمایش نشده است، قابلیت خواندن آگهی تکمیل‌شده تلقی نمی‌شود.
