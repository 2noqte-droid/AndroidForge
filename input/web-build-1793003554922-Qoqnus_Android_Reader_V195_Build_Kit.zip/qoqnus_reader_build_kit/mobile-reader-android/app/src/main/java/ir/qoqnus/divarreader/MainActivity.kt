package ir.qoqnus.divarreader

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SafeBrowsingResponse
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.util.LinkedHashMap
import java.util.Locale

class MainActivity : Activity() {
    private val appUrl = "https://aghaj.ir/RobikaBot/rubika_realestate/public/mobile-app/"
    private val appOrigin = "https://aghaj.ir"
    private val divarOrigins = setOf("https://divar.ir", "https://www.divar.ir")
    private lateinit var appWeb: WebView
    private lateinit var divarWeb: WebView
    private lateinit var statusText: TextView
    private lateinit var urlInput: EditText
    private lateinit var readButton: Button
    private lateinit var progress: ProgressBar
    private val queuedRecords = LinkedHashMap<String, JSONObject>()
    private var appReady = false
    private var pageIsDivar = false
    private var readerScript = ""
    private var autoReadUrl: String? = null
    private var autoReadAttempts = 0
    private var pendingReaderUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            showUnsupportedWebView()
            return
        }
        readerScript = assets.open("qoqnus-divar-reader.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        buildUi()
        configureWebViews()
        appWeb.loadUrl(appUrl)
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun showUnsupportedWebView() {
        val text = TextView(this).apply {
            text = "نسخهٔ Android System WebView قدیمی است. آن را از فروشگاه به‌روزرسانی کنید و دوباره برنامه را باز کنید."
            textSize = 18f; setPadding(28, 32, 28, 32); gravity = Gravity.CENTER
        }
        setContentView(text)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(243,247,252)) }
        val header = TextView(this).apply { text = "ققنوس — دریافت فایل"; textSize = 18f; setTextColor(Color.WHITE); setPadding(16,14,16,14); setBackgroundColor(Color.rgb(8,62,125)); gravity=Gravity.CENTER_VERTICAL }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,4) }
        urlInput = EditText(this).apply { hint="پیوند مستقیم آگهی /v/…"; textSize=13f; singleLine=true; setTextDirection(View.TEXT_DIRECTION_LTR); setPadding(10,7,10,7) }
        inputRow.addView(urlInput, LinearLayout.LayoutParams(0, 48, 1f))
        val open = Button(this).apply { text="بازکردن"; setOnClickListener { val u=canonicalDetailUrl(urlInput.text.toString()); if(u==null) toast("پیوند باید مستقیم به صفحهٔ جزئیات آگهی /v/ باشد.") else openDivar(u) } }
        inputRow.addView(open, LinearLayout.LayoutParams(-2,48))
        root.addView(inputRow)
        val buttons = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(6,0,6,4) }
        val app = Button(this).apply { text="برنامک ققنوس"; setOnClickListener { showApp() } }
        val sourcePage = Button(this).apply { text="نسخهٔ آگهی‌شدهٔ فایل"; setOnClickListener { if(!pageIsDivar) openDivar(canonicalDetailUrl(urlInput.text.toString()) ?: "https://divar.ir/") else showDivar() } }
        readButton = Button(this).apply { text="خواندن و ذخیره"; isEnabled=false; setOnClickListener { if(pageIsDivar) divarWeb.evaluateJavascript("window.__QOQNUS_READER_READ_CURRENT__ && window.__QOQNUS_READER_READ_CURRENT__();", null) } }
        listOf(app,sourcePage,readButton).forEach { buttons.addView(it, LinearLayout.LayoutParams(0,-2,1f)) }
        root.addView(buttons)
        progress = ProgressBar(this).apply { visibility=View.GONE; isIndeterminate=true }
        root.addView(progress, LinearLayout.LayoutParams(-1,4))
        val body = FrameLayout(this)
        appWeb = WebView(this)
        divarWeb = WebView(this).apply { visibility=View.GONE }
        body.addView(appWeb, FrameLayout.LayoutParams(-1,-1))
        body.addView(divarWeb, FrameLayout.LayoutParams(-1,-1))
        root.addView(body, LinearLayout.LayoutParams(-1,0,1f))
        statusText = TextView(this).apply { text="از صفحهٔ آگهی، پیوند را با گزینهٔ اشتراک‌گذاری به ققنوس بفرست؛ سپس «خواندن و ذخیره» را بزن."; textSize=12f; setTextColor(Color.rgb(48,67,91)); setPadding(12,8,12,10) }
        root.addView(statusText)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebViews() {
        val configure: (WebView, Boolean) -> Unit = { web, isApp ->
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.settings.databaseEnabled = true
            web.settings.allowFileAccess = false
            web.settings.allowContentAccess = false
            web.settings.javaScriptCanOpenWindowsAutomatically = false
            web.settings.setSupportMultipleWindows(false)
            web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (Build.VERSION.SDK_INT >= 26) web.settings.safeBrowsingEnabled = true
            web.webChromeClient = WebChromeClient()
            web.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    progress.visibility = View.VISIBLE
                    if (!isApp) { pageIsDivar = isDivarUrl(url); readButton.isEnabled = false }
                }
                override fun onPageFinished(view: WebView, url: String) {
                    progress.visibility = View.GONE
                    if (isApp) { statusText.text = "برنامک ققنوس باز است. ابتدا قفل دفتر را باز کن؛ پس از ذخیره، اطلاعات به دفتر رمزگذاری‌شده اضافه می‌شود." }
                    else if (isDivarUrl(url)) {
                        pageIsDivar = true; readButton.isEnabled = true
                        val canonical = canonicalDetailUrl(url)
                        view.evaluateJavascript(readerScript, null)
                        if (canonical != null && autoReadUrl != canonical) {
                            autoReadUrl = canonical
                            autoReadAttempts = 0
                            statusText.text = "صفحهٔ آگهی باز شد؛ ققنوس در حال خواندن مشخصات قابل‌مشاهده است…"
                            view.postDelayed({ triggerAutomaticRead(canonical) }, 1800L)
                        } else {
                            statusText.text = "صفحه آماده است. در صورت نیاز «خواندن و ذخیره» را دوباره بزن."
                        }
                    } else { pageIsDivar = false; readButton.isEnabled = false }
                }
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri=request.url
                    if (isApp) {
                        if (uri.scheme=="https" && uri.host?.lowercase(Locale.ROOT)=="aghaj.ir") return false
                        openExternally(uri); return true
                    }
                    if (isDivarUrl(uri.toString()) || (uri.scheme=="https" && uri.host?.lowercase(Locale.ROOT)?.endsWith(".divar.ir")==true)) return false
                    if (uri.scheme=="https" && uri.host?.lowercase(Locale.ROOT)=="divar.ir") return false
                    if (uri.scheme=="tel" || uri.scheme=="mailto") { openExternally(uri); return true }
                    if (uri.scheme=="https" || uri.scheme=="http") { openExternally(uri); return true }
                    return true
                }
            }
            web.setDownloadListener { url, _, _, _, _ -> openExternally(Uri.parse(url)) }
        }
        configure(appWeb, true); configure(divarWeb, false)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(divarWeb, false)
        WebViewCompat.addWebMessageListener(appWeb, "qoqnusAppBridge", setOf(appOrigin), object : WebViewCompat.WebMessageListener {
            override fun onPostMessage(view: WebView, message: WebMessageCompat, sourceOrigin: Uri, isMainFrame: Boolean, replyProxy: JavaScriptReplyProxy) {
                if (!isMainFrame || sourceOrigin.scheme != "https" || sourceOrigin.host != "aghaj.ir") return
                val msg = runCatching { JSONObject(message.data ?: "") }.getOrNull() ?: return
                when (msg.optString("type")) {
                    "PWA_READY" -> { appReady=true; runOnUiThread { deliverQueuedRecords(); openPendingReaderIfReady() } }
                    "PWA_LOCKED" -> { appReady=false }
                    "OPEN_READER" -> {
                        val link = canonicalDetailUrl(msg.optString("url"))
                        if (link == null) runOnUiThread { statusText.text="پیوند مستقیم فایل معتبر نیست." }
                        else runOnUiThread { openDivar(link) }
                    }
                    "RECORD_STORED" -> { val id=msg.optString("id"); if(id.isNotBlank()) queuedRecords.remove(id); runOnUiThread { progress.visibility=View.GONE; statusText.text="✅ آگهی در دفتر رمزگذاری‌شدهٔ ققنوس ذخیره شد."; if(queuedRecords.isEmpty()) showApp() } }
                    "RECORD_ERROR" -> runOnUiThread { progress.visibility=View.GONE; statusText.text="ذخیره در ققنوس انجام نشد: "+msg.optString("message")+" صفحه برای تلاش دوباره باز می‌ماند."; showDivar() }
                }
            }
        })
        WebViewCompat.addWebMessageListener(divarWeb, "qoqnusDivarBridge", divarOrigins, object : WebViewCompat.WebMessageListener {
            override fun onPostMessage(view: WebView, message: WebMessageCompat, sourceOrigin: Uri, isMainFrame: Boolean, replyProxy: JavaScriptReplyProxy) {
                if (!isMainFrame || sourceOrigin.scheme != "https" || sourceOrigin.host !in setOf("divar.ir","www.divar.ir")) return
                val msg=runCatching { JSONObject(message.data ?: "") }.getOrNull() ?: return
                when (msg.optString("type")) {
                    "QOQNUS_DIVAR_READER_ERROR" -> {
                        val error = msg.optString("message", "اطلاعات قابل‌خواندن از این صفحه دریافت نشد.")
                        runOnUiThread {
                            progress.visibility = View.GONE
                            if (pageIsDivar && autoReadAttempts < 2) {
                                autoReadAttempts += 1
                                statusText.text = "صفحه هنوز کامل آماده نیست؛ تلاش خودکار ${autoReadAttempts + 1} از 3…"
                                val current = canonicalDetailUrl(divarWeb.url)
                                if (current != null) divarWeb.postDelayed({ triggerAutomaticRead(current) }, 1700L)
                            } else {
                                statusText.text = error + " برای تلاش دوباره، «خواندن و ذخیره» را بزن."
                                readButton.isEnabled = true
                            }
                        }
                        return
                    }
                    "QOQNUS_DIVAR_READER_RESULT" -> Unit
                    else -> return
                }
                val payload=msg.optJSONObject("payload") ?: return
                if(payload.toString().length>180_000) { runOnUiThread { toast("حجم اطلاعات این آگهی از حد مجاز بیشتر است.") }; return }
                val link=canonicalDetailUrl(payload.optString("url")) ?: return
                val id="divar:"+link.substringAfterLast('/')
                payload.put("id",id);payload.put("record_uuid",id);payload.put("url",link);payload.put("detailUrl",link);payload.put("sourceUrl",link);payload.put("canonicalUrl",link)
                synchronized(queuedRecords) { queuedRecords[id]=payload }
                runOnUiThread { progress.visibility=View.GONE; statusText.text="اطلاعات آگهی خوانده شد. در حال ذخیرهٔ امن در دفتر ققنوس…"; deliverQueuedRecords() }
            }
        })
    }

    private fun deliverQueuedRecords() {
        if (!appReady || queuedRecords.isEmpty()) return
        val first=queuedRecords.entries.firstOrNull() ?: return
        val id=first.key; val payload=first.value.toString(); val quoted=JSONObject.quote(payload)
        val script="(async()=>{try{if(!window.QoqnusMobileDivarReader||typeof window.QoqnusMobileDivarReader.receive!=='function')return;await window.QoqnusMobileDivarReader.receive(JSON.parse($quoted));}catch(e){try{window.qoqnusAppBridge?.postMessage(JSON.stringify({type:'RECORD_ERROR',id:${JSONObject.quote(id)},message:String(e&&e.message||'ثبت ناموفق').slice(0,200)}));}catch(_){}}})();"
        runOnUiThread { appWeb.evaluateJavascript(script,null) }
    }

    private fun handleIncomingIntent(incoming: Intent?) {
        if (incoming == null) return
        val candidate = when (incoming.action) {
            Intent.ACTION_SEND -> incoming.getStringExtra(Intent.EXTRA_TEXT)
                ?: incoming.getStringExtra(Intent.EXTRA_SUBJECT)
                ?: incoming.getStringExtra(Intent.EXTRA_HTML_TEXT)
            Intent.ACTION_VIEW -> {
                val data = incoming.data
                if (data?.scheme == "qoqnus" && data.host == "read") data.getQueryParameter("url") else incoming.dataString
            }
            else -> null
        } ?: return
        val link=canonicalDetailUrl(candidate)
        if(link==null) { statusText.text="پیوند ارسالی، نشانی مستقیم یک آگهی نبود. از همان صفحهٔ آگهی گزینهٔ اشتراک‌گذاری را بزن."; return }
        urlInput.setText(link)
        pendingReaderUrl=link
        showApp()
        statusText.text="پیوند دریافت شد؛ اگر دفتر قفل است ابتدا آن را باز کن. خواندن مشخصات به‌طور خودکار شروع می‌شود."
    }

    private fun openPendingReaderIfReady() {
        if (!appReady || queuedRecords.isNotEmpty()) return
        val link = pendingReaderUrl ?: return
        pendingReaderUrl = null
        openDivar(link)
    }

    private fun canonicalDetailUrl(raw: String?): String? {
        val text = raw?.trim().orEmpty()
        if (text.isEmpty()) return null
        // Divar shares may use either /v/{id} or /v/{slug}/{id}; IDs are case-sensitive.
        val match = Regex(
            "https?://(?:www\\.)?divar\\.ir/v/(?:[^\\s/?#]+/)?[A-Za-z0-9][A-Za-z0-9_-]{2,120}/?(?:\\?[^\\s]*)?",
            RegexOption.IGNORE_CASE
        ).find(text)?.value ?: text
        val uri = runCatching { Uri.parse(match) }.getOrNull() ?: return null
        if (uri.scheme?.lowercase(Locale.ROOT) != "https" || uri.host?.lowercase(Locale.ROOT) !in setOf("divar.ir", "www.divar.ir")) return null
        val segments = uri.path.orEmpty().split('/').filter { it.isNotEmpty() }
        if (segments.size !in 2..3 || !segments[0].equals("v", ignoreCase = true)) return null
        val id = runCatching { Uri.decode(segments.last()) }.getOrNull() ?: return null
        if (!Regex("^[A-Za-z0-9][A-Za-z0-9_-]{2,120}$").matches(id)) return null
        if (segments.size == 3) {
            val slug = segments[1]
            if (slug.isBlank() || slug == "." || slug == ".." || slug.contains('/')) return null
            return "https://divar.ir/v/$slug/$id"
        }
        return "https://divar.ir/v/$id"
    }

    private fun isDivarUrl(raw: String): Boolean {
        val uri=runCatching { Uri.parse(raw) }.getOrNull() ?: return false
        val host=uri.host?.lowercase(Locale.ROOT) ?: return false
        return uri.scheme=="https" && (host=="divar.ir" || host=="www.divar.ir" || host.endsWith(".divar.ir"))
    }

    private fun triggerAutomaticRead(expectedUrl: String) {
        if (!pageIsDivar || divarWeb.visibility != View.VISIBLE) return
        val current = canonicalDetailUrl(divarWeb.url) ?: return
        if (current != expectedUrl) return
        progress.visibility = View.VISIBLE
        statusText.text = "در حال خواندن و ذخیرهٔ اطلاعات قابل‌مشاهدهٔ آگهی…"
        divarWeb.evaluateJavascript("window.__QOQNUS_READER_READ_CURRENT__ && window.__QOQNUS_READER_READ_CURRENT__();", null)
    }

    private fun openDivar(url: String) {
        val target=canonicalDetailUrl(url) ?: if(url=="https://divar.ir/") url else null
        if(target==null) { toast("لینک باید مستقیم به آگهی /v/ باشد."); return }
        urlInput.setText(target); pageIsDivar=true; readButton.isEnabled=false; autoReadUrl=null; autoReadAttempts=0
        divarWeb.loadUrl(target); showDivar()
    }

    private fun showApp() { appWeb.visibility=View.VISIBLE; divarWeb.visibility=View.GONE; pageIsDivar=false; readButton.isEnabled=false; appReady=false; appWeb.evaluateJavascript("!!(window.QoqnusMobileDivarReader && window.QoqnusMobileDivarReader.isReady && window.QoqnusMobileDivarReader.isReady())") { value -> runOnUiThread { appReady=(value=="true"); if(appReady) { deliverQueuedRecords(); openPendingReaderIfReady() } } } }
    private fun showDivar() { appWeb.visibility=View.GONE; divarWeb.visibility=View.VISIBLE; pageIsDivar=true }
    private fun openExternally(uri: Uri) { try { startActivity(Intent(Intent.ACTION_VIEW,uri)) } catch (_:ActivityNotFoundException) { toast("برنامه‌ای برای بازکردن این پیوند پیدا نشد.") } }
    private fun toast(message: String) = Toast.makeText(this,message,Toast.LENGTH_LONG).show()
    override fun onBackPressed() { if(divarWeb.visibility==View.VISIBLE) showApp() else super.onBackPressed() }
}
