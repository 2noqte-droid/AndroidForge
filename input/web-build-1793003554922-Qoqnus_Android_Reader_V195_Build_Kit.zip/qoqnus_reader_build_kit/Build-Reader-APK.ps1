$ErrorActionPreference = 'Stop'

$Project = Join-Path $PSScriptRoot 'mobile-reader-android'
if (-not (Test-Path (Join-Path $Project 'app\build.gradle.kts'))) {
    throw "پروژه پیدا نشد: $Project . این اسکریپت را در پوشهٔ اصلی بسته اجرا کن."
}

$GradleCandidates = @()
if ($env:GRADLE_HOME) { $GradleCandidates += (Join-Path $env:GRADLE_HOME 'bin\gradle.bat') }
$GradleCommand = Get-Command gradle.bat -ErrorAction SilentlyContinue
if ($GradleCommand) { $GradleCandidates += $GradleCommand.Source }
$GradleCandidates += 'C:\Gradle\gradle-8.9\bin\gradle.bat'
if ($env:USERPROFILE) {
    $GradleCache = Join-Path $env:USERPROFILE '.gradle\wrapper\dists\gradle-8.9-bin'
    if (Test-Path $GradleCache) {
        $GradleCandidates += Get-ChildItem -Path $GradleCache -Filter 'gradle.bat' -Recurse -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }
    }
}
$Gradle = $GradleCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $Gradle) {
    throw "Gradle 8.9 پیدا نشد. آن را از https://services.gradle.org/distributions/gradle-8.9-bin.zip دریافت و در C:\Gradle\gradle-8.9 استخراج کن."
}

$Sdk = $env:ANDROID_SDK_ROOT
if (-not $Sdk) { $Sdk = $env:ANDROID_HOME }
if (-not $Sdk -and $env:LOCALAPPDATA) { $Sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not $Sdk -or -not (Test-Path (Join-Path $Sdk 'platforms\android-35\android.jar'))) {
    throw "Android SDK Platform 35 پیدا نشد. در Android Studio از Tools > SDK Manager آن را نصب کن؛ مسیر SDK را در ANDROID_SDK_ROOT بگذار."
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk

Write-Host "Project: $Project"
Write-Host "Gradle:  $Gradle"
Write-Host "SDK:     $Sdk"
Push-Location $Project
try {
    & $Gradle --no-daemon --stacktrace :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "ساخت Gradle ناموفق بود (کد $LASTEXITCODE). متن خطا را ذخیره کن." }
} finally {
    Pop-Location
}

$BuiltApk = Join-Path $Project 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $BuiltApk)) { throw "ساخت پایان یافت ولی APK در مسیر مورد انتظار پیدا نشد: $BuiltApk" }
$Destination = Join-Path $PSScriptRoot 'QoqnusReader-debug.apk'
Copy-Item $BuiltApk $Destination -Force
$Hash = (Get-FileHash $Destination -Algorithm SHA256).Hash
Set-Content -Path (Join-Path $PSScriptRoot 'QoqnusReader-debug.apk.sha256.txt') -Value "$Hash  QoqnusReader-debug.apk" -Encoding ascii
Write-Host "`nساخت APK موفق بود: $Destination" -ForegroundColor Green
Write-Host "SHA-256: $Hash"
